﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net.Mail;
using System.Web.Security;


/// <summary>
/// Summary description for Send
/// </summary>
public static class SendMes
{
    //private const string Username = "ario";
    //private const string Password = "123456";
    //private const string From = "10000022721336";
    private const string Username = "taramoshaver";
    private const string Password = "5M1M@7fB";
    private const string From = "2188898449";
    public static Boolean SendSMS(string to, string message)
    {
        try
        {
            var sms = new WebService.Send();


            sms.SendSimpleSMS2(Username, Password, to, From, message, false);

            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
    //public static string ReceiveSMS(string From)
    //{
    //    var sms = new ReceiveSoapClient("ReceiveSoap");
    //    SMSReceive.MessagesBL res;
    //    sms.Open();
    //    res = sms.GetMessages(Username, Password, 1, From, 0, 1).FirstOrDefault();
    //    sms.Close();
    //    return res.Body;
    //}

    public static bool SendEmail(string to, string Subject, string bodyEmail)
    {
        try
        {
            const string @from = "noreply@noyaban.ir";
            var mail = new MailMessage();
            mail.To.Add(to);
            mail.From = new MailAddress(from);
            mail.Subject = Subject;
            mail.Body = bodyEmail;
            mail.BodyEncoding = System.Text.Encoding.UTF8;
            mail.IsBodyHtml = true;
            mail.Priority = MailPriority.High;
            var smtp = new SmtpClient
            {
                Credentials = new System.Net.NetworkCredential("noreply@noyaban.ir", "~!@#45CGuk"),
                Port = 25,
                Host = "mail.noyaban.ir"
            };
            // smtp.EnableSsl = true;
            smtp.Send(mail);

            return true;
        }
        catch
        {
            return false;
        }
    }
    public static Guid UserID(string UserName)
    {
        var User = Membership.GetUser(UserName);
        return (Guid)User.ProviderUserKey;
    }
    public static bool InsertMessage(string UserName, string Subject, string Body)
    {
        try
        {
            var Data = new Data();
            var item = new Send
            {
                UserId = UserID(UserName),
                DateS = DateTime.Now,
                Subject = Subject,
                Body = Body,
                Read = false
            };
            Data.DB.Sends.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public static int GetSendMesCount(string UserName = "")
    {
        try
        {
            var Data = new Data();
            int res;
            if (UserName.Length > 0)
            {
                var g = UserID(UserName);
                res = Data.DB.Sends.AsQueryable().Where(p => p.UserId.Equals(g)).Count();
            }
            else
            {
                res = Data.DB.Sends.AsQueryable().Count();
            }
            return res;
        }
        catch
        {
            return 0;
        }
    }
    public static int GetNEWMesCount(string UserName)
    {
        try
        {
            var Data = new Data();
            int res;
            var g = UserID(UserName);
            res = Data.DB.Sends.AsQueryable().Where(p => p.UserId.Equals(g) && p.Read.Equals(true)).Count();
            return res;
        }
        catch
        {
            return 0;
        }
    }
    public static IQueryable<Send> GetSendMes(string UserName = "", int skip = 0, int take = 0)
    {
        try
        {
            var Data = new Data();
            IQueryable<Send> res;
            if (UserName.Length > 0)
            {
                var g = UserID(UserName);
                res = Data.DB.Sends.Where(p => p.UserId.Equals(g)).AsQueryable();
            }
            else
            {
                res = Data.DB.Sends.AsQueryable();
            }

            if (skip > 0)
            {
                return res.Skip(skip).Take(take);
            }
            else
            {
                return res;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
