﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Configuration;
using System.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

public class clsCompare
{
    public db_atrDataContext DB = new db_atrDataContext();
    public class CompA
    {
        public int Id { get; set; }
    }

    public class CompP
    {
        public int Id0 { get; set; }
        public int Id1 { get; set; }
        public int Id2 { get; set; }
        public int Id3 { get; set; }
        public int Col { get; set; }

    }

    public void AddCompare()
    {
        if (HttpContext.Current.Session["ComSes"] == null)
        {
            var item = new List<CompA>();
            item.Add(new CompA {Id = 0});
            item.Add(new CompA { Id = 0 });
            item.Add(new CompA { Id = 0 });
            item.Add(new CompA { Id = 0 });
            ListData = item;
        }
    }

    public void Add(int Id)
    {
        if (ListData.Count(p => p.Id.Equals(Id)) > 0)
            return;
        if (ListData[0].Id.Equals(0))
        {
            ListData[0].Id = Id;
        }
        else if (ListData[1].Id.Equals(0))
        {
            ListData[1].Id = Id;
        }
        else if (ListData[2].Id.Equals(0))
        {
            ListData[2].Id = Id;
        }
        else if (ListData[3].Id.Equals(0))
        {
            ListData[3].Id = Id;
        }
        else
        {
            ListData.RemoveAt(0);
            var t = new CompA
            {
                Id = Id
            };
            ListData.Add(t);
        }
    }

    public void Remove(int Id)
    {
        var r=new CompA
        {
            Id = Id
        };
        ListData.Find(p => p.Id == Id).Id = 0;
    }

    public List<CompA> ListData
    {
        get
        {
            var options = new List<CompA>();

            if (HttpContext.Current.Session["ComSes"] != null)
                options = (List<CompA>)HttpContext.Current.Session["ComSes"];
            return options;
        }
        set
        {
            HttpContext.Current.Session["ComSes"] = value;
        }
    }

    




    public IList<spProductCompResult> ProductCompare(int PID0, int PID1, int PID2, int PID3)
    {
        return DB.spProductComp(PID0, PID1, PID2, PID3).ToList();
    }

    public IList<spGetAttrCompResult> GetAttributeName(int PID0, int PID1, int PID2, int PID3)
    {
        return DB.spGetAttrComp(PID0, PID1, PID2, PID3).ToList();
    }

    public IList<spGetAttrValCompResult> GetAttributeValue(int AID, int PID0, int PID1, int PID2, int PID3)
    {
        return DB.spGetAttrValComp(AID, PID0, PID1, PID2, PID3).ToList();
    }

    public IList<spGetAttrProdCompResult> GetProductValue(int PID, int AID)
    {
        return DB.spGetAttrProdComp(PID, AID).ToList();
    }
}