﻿// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Public License.
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
// All other rights reserved.

using System.Collections.Generic;
using System.Linq;
using System.Web.Services;

///<summary>
/// Summary description for AutoComplete
///</summary>

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX,
// uncomment the following line.
[System.Web.Script.Services.ScriptService]
public class AutoComplete : System.Web.Services.WebService
{
    public AutoComplete()
    {
        //Uncomment the following line if using designed components
        //InitializeComponent();
    }

    [WebMethod]
    public List<string> GetCompletionList(string prefixText, int count)
    {
        using (var db = new db_atrDataContext())
        {
            var product =
                db.spProductSearch(prefixText,0);
            return product.Select(p => p.Name).ToList();
        }
    }
    [WebMethod]
    public List<string> GetCompletionListWiki(string prefixText, int count)
    {
        using (var db = new db_atrDataContext())
        {
            var wiki =
                db.spWikiSearch(prefixText);
            return wiki.Select(p => p.Title).ToList();
        }
    }
}