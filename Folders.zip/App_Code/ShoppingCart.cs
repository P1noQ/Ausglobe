﻿using System;
using System.Activities.Expressions;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

/// <summary>
/// Summary description for ShoppingCart
/// </summary>
public class clsShoppingCart
{

    public db_atrDataContext Db = new db_atrDataContext();
    public void ShoppingCart()
    {

    }
    public class Ca
    {
        public Guid UserId { get; set; }
        public long Balance { get; set; }
    }
    public class key
    {
        public int PId { get; set; }
        public int SID { get; set; }
        public int CID { get; set; }
    }
    public void AddList()
    {
        if (HttpContext.Current.Session["buy"] == null)
        {
            var dt = new DataTable("ShoppingCart");
            DataColumn[] keys = new DataColumn[3];

            dt.Columns.Add("PId", typeof(int));
            dt.Columns.Add("SId", typeof(int));
            dt.Columns.Add("CId", typeof(int));
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Image");
            dt.Columns.Add("Title");
            dt.Columns.Add("Price", typeof(long));
            dt.Columns.Add("IsSale", typeof(bool));
            dt.Columns.Add("RealPrice", typeof(long));
            dt.Columns.Add("Count", typeof(int));
            dt.Columns.Add("Ord", typeof(long));
            dt.Columns.Add("Total", typeof(long));
            dt.Columns.Add("Benefit", typeof(long));
            dt.Columns["Total"].Expression = "Price*Count";
            dt.Columns["Benefit"].Expression = "RealPrice*Count";
            keys[0] = dt.Columns["PID"];
            keys[1] = dt.Columns["SID"];
            keys[2] = dt.Columns["CID"];
            dt.PrimaryKey = keys;
            ListData = dt;
        }
    }

    public void AddGiftList()
    {
        if (HttpContext.Current.Session["Giftbuy"] == null)
        {
            var dt = new DataTable("ShoppingGiftCart");
            DataColumn[] keys = new DataColumn[1];
            dt.Columns.Add("GiftId", typeof(Guid));
            dt.Columns.Add("GiftCode", typeof(string));
            dt.Columns.Add("Title", typeof(string));
            dt.Columns.Add("Image");
            dt.Columns.Add("Price", typeof(long));
            dt.Columns.Add("Balance", typeof(long));
            dt.Columns.Add("Expiry", typeof(DateTime));
            dt.Columns.Add("Ord", typeof(long));

            GiftListData = dt;
        }
    }
    public DataTable ListData
    {
        get
        {
            var options = new DataTable();

            if (HttpContext.Current.Session["buy"] != null)
                options = (DataTable)HttpContext.Current.Session["buy"];
            return options;
        }
        set
        {
            HttpContext.Current.Session["buy"] = value;
        }
    }
    public DataTable GiftListData
    {
        get
        {
            var options = new DataTable();

            if (HttpContext.Current.Session["Giftbuy"] != null)
                options = (DataTable)HttpContext.Current.Session["Giftbuy"];
            return options;
        }
        set
        {
            HttpContext.Current.Session["Giftbuy"] = value;
        }
    }
    public long OrdId
    {
        get
        {
            long ret;
            if (ListData.Rows.Count > 0)
                ret = ListData.Rows[0].Field<long>("Ord");
            else
                ret = 0;

            return ret;
        }
    }
    public bool Change()
    {
        var Data = new Data();
        var id = 0;
        var sid = 0;
        var cid = 0;
        var price = 0;
        var ret = false;
        foreach (DataRow d in ListData.Rows)
        {
            id = d.Field<int>("PID");
            sid = d.Field<int>("SID");
            cid = d.Field<int>("CID");
            var it = Data.GetProductWSize(id, cid).First();
            if (d.Field<bool>("IsSale"))
            {
                
                if (it.DateDis.GetValueOrDefault(DateTime.Now) <= DateTime.Now)
                {
                    price = it.Price.GetValueOrDefault(0);
                    ret = true;
                    d.SetField<bool>("IsSale", false);
                    d.SetField<long>("Price", price);
                    d.AcceptChanges();
                }
            }
            var dCount = d.Field<int>("Count");
            int? count = it.Count;
            if (count.HasValue)
            {
                if (count.Value < dCount)
                {
                    if (count.Value.Equals(0))
                    {
                        ListData.Rows.Remove(d);
                        ret = true;
                    }
                    else
                    {
                        d.SetField<int>("Count", count.Value);
                        d.AcceptChanges();
                        ret = true;
                    }
                }
            }


        }
        return ret;
    }
    public void UpdatePrice(bool isjob = false)
    {
        var Pid = 0;
        var Sid = 0;
        var Cid = 0;
        spGetProductwithsizeResult ds;
        var Data = new Data();
        foreach (DataRow dr in ListData.Rows)
        {
            Pid = Convert.ToInt32(dr["PId"].ToString());
            Sid = Convert.ToInt32(dr["SId"].ToString());
            Cid = Convert.ToInt32(dr["CId"].ToString());
            
            var itemUpdate = ListData.Rows.Find(new object[]{Pid,Sid,Cid});
            var itemProduct = Data.GetProductWSize(Pid,Cid).First();
            if (itemUpdate != null)
            {
                ds = Data.GetProductWSize(Pid,Cid).First();
                itemUpdate.BeginEdit();
            
                var finalPrice = itemProduct.Price.GetValueOrDefault(0);
                var real = 0;
                if (itemProduct.RealPrice.HasValue)
                {
                    real = itemProduct.RealPrice.Value;
                }
                var IsSale = false;

                if (itemProduct.DateDis.HasValue)
                {
                    if (itemProduct.DateDis.Value > DateTime.Now)
                    {
                        IsSale = true;
                        finalPrice = itemProduct.DisPrice.GetValueOrDefault(0);

                    }
                }
                if (isjob == true)
                {
                    finalPrice = itemProduct.CoPrice.GetValueOrDefault(0);
                }

                itemUpdate.SetField("Price", finalPrice);
                itemUpdate.EndEdit();
                itemUpdate.AcceptChanges();
            }
        }

    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="PID"></param>
    /// <param name="Sid"></param>
    /// <param name="Cid"></param>
    /// <param name="Count"></param>
    /// <param name="Ord"></param>
    /// <param name="isjob"></param>
    /// <returns>
    /// 0 Success
    /// 1 No Price
    /// 2 Rmove Row
    /// 3 No More
    /// 4 No Avail
    /// 5 Insert Avail
    /// </returns>
    public int InsertShoppingCart(int PID,int Sid,int Cid, int Count = 1, long Ord = 0, bool isjob = false)
    {
        try
        {
            var Data = new Data();
            var itemProduct = Data.GetProductWSize(PID, Cid).First();
            var itemImage = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(Sid)).Image;
            if (itemProduct.Price.GetValueOrDefault(0) < 1000)
            {
                return 1;
            }
            var keys = new object[] { PID, Sid, Cid };
            var itemUpdate = ListData.Rows.Find(keys);

            if (itemUpdate != null)
            {
                var dCount = itemUpdate.Field<int>("Count") + Count;
                int? count = itemProduct.Count;
                if (count.HasValue)
                {
                    if (count.Value < dCount)
                    {
                        if (count.Value.Equals(0))
                        {
                            ListData.Rows.Remove(itemUpdate);
                            return 2;
                        }
                        else
                        {
                            return 3;
                        }
                    }
                    else
                    {
                        itemUpdate.BeginEdit();
                        itemUpdate.SetField("Count", itemUpdate.Field<int>("Count") + Count);
                        itemUpdate.EndEdit();
                        return 0;
                    }
                }
                else
                {
                    itemUpdate.BeginEdit();
                    itemUpdate.SetField("Count", itemUpdate.Field<int>("Count") + Count);
                    itemUpdate.EndEdit();
                    return 0;
                }
            }
            
           
            var price = itemProduct.Price.GetValueOrDefault(0);
            var real = 0;
            if (itemProduct.RealPrice.HasValue)
            {
                real = itemProduct.RealPrice.Value;
            }
            var IsSale = false;
            var getpro = Data.GetProduct(PID).First();
            if (getpro.DateDis.HasValue)
            {
                IsSale = true;
                price = itemProduct.DisPrice.GetValueOrDefault(0);
                if (price < 1000) return 1;
            }

            else if (itemProduct.DateDis.HasValue)
            {
                if (itemProduct.DateDis.Value > DateTime.Now)
                {
                    IsSale = true;
                    price = itemProduct.DisPrice.GetValueOrDefault(0);
                    if (price < 1000) return 1;
                }
            }
            if (isjob == true)
            {
                price = itemProduct.CoPrice.GetValueOrDefault(0);
            }
            string image;
            if (String.IsNullOrEmpty(itemProduct.Image))
            {
                image = getpro.Image;
            }
            else
            {
                image = "Psize" + itemImage;
            }
            var c = 0;
            int? dcount = itemProduct.Count;
            if (dcount.HasValue)
            {
                if (dcount.Value < Count)
                {
                    if (dcount.Value.Equals(0))
                    {
                        return 4;
                    }
                    else
                    {
                        Count = dcount.Value;
                        c = 5;

                    }
                }
            }

            var row = ListData.Rows.Add(new object[] { PID,Sid,Cid, itemProduct.Id, image, getpro.Name, price, IsSale, real - price, Count, Ord });
            return c;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertShoppingGiftCart(string Gid, long Ord = 0)
    {
        try
        {
            var Data = new Data();


            var itemProduct = Data.GetCurrentGiftCard(Gid);

            var row = GiftListData.Rows.Add(new object[] { itemProduct.GiftId, itemProduct.GiftCode, itemProduct.Title, itemProduct.Image, itemProduct.Price, itemProduct.Balance, itemProduct.Expiry, Ord });
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    //public bool EditShoppingCart(long OrderId)
    //{
    //    try
    //    {
    //        var Data = new Data();
    //        ListData.Rows.Clear();
    //        var Od = Data.DB.OrderDetails.ToList().Where(p => p.OId.Equals(OrderId));
    //        foreach (OrderDetail ord in Od)
    //        {
    //            InsertShoppingCart(ord.PId.GetValueOrDefault(0), ord.Count.GetValueOrDefault(0), OrderId);
    //        }
    //        return true;
    //    }
    //    catch
    //    {

    //        return false;
    //    }
    //}
    public int Number
    {
        get
        {
            return ListData.Select().Sum(r => r.Field<int>("Count"));
        }
    }

    public int? SizeCount(int CID)
    {
        return Db.PColors.FirstOrDefault(p =>p.Id.Equals(CID)).Count;
    }

    public void UpdateShoppingCart(int PID,int Sid,int Cid, int Count)
    {
        var keys = new object[] { PID, Sid, Cid };
        var itemUpdate = ListData.Rows.Find(keys);

        if (itemUpdate != null)
        {
            var sCount = SizeCount(Cid);

            var co = Count;
            if (sCount.HasValue)
            {
                if (sCount.Value.Equals(0))
                {
                    ListData.Rows.Remove(itemUpdate);
                    return;
                }
                else if (sCount.Value < co)
                {
                    co = sCount.Value;
                }
            }
            itemUpdate.BeginEdit();
            itemUpdate.SetField("Count", co);
            itemUpdate.EndEdit();
        }
    }
    public void DeleteShoppingCart(int PID,int Sid,int Cid)
    {
        try
        {
            var keys = new object[] { PID, Sid, Cid };
            ListData.Rows.Remove(ListData.Rows.Find(keys));
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public void DeleteShoppingGiftCart(string Gid)
    {
        try
        {
            GiftListData.Rows.RemoveAt(0);
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }

    public long InsertOrder(long Price, string UserName, string TypePay, bool role, int Post, int PostPrice, int Address, bool gift)
    {
        var data = new Data();


        long discount = Db.Fn_discount(role).GetValueOrDefault(0);
        try
        {
            var Data = new Data();
            var item = new Order
            {
                Price = Price,
                Date = DateTime.Now,
                Status = "معلق",
                UserId = (Guid)Membership.GetUser(UserName).ProviderUserKey,
                TypePay = TypePay,
                discount = Convert.ToInt32(discount),
                PostId = Post,
                AddressId = Address,
                PostPrice = PostPrice,
                Finish = false,
                Gift = gift
            };
            if (TypePay.Contains("کسر"))
            {
                item.Cash = (((100 - discount) * Price) / 100) + PostPrice;
            }
            Data.DB.Orders.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            var Code = item.Id;
            Data.DB.spCreateOrderCode(Code);
            return Code;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public long InsertCashOrder(long Price, string UserName)
    {
        var data = new Data();
        try
        {
            var Data = new Data();
            var item = new Order
            {
                Price = Price,
                Date = DateTime.Now,
                Status = "معلق",
                UserId = (Guid)Membership.GetUser(UserName).ProviderUserKey,
                TypePay = "آنلاین",
                discount = null,
                PostId = null,
                AddressId = null,
                PostPrice = null,
                Finish = false,
                Gift = null
            };
            Data.DB.Orders.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            var Code = item.Id;
            Data.DB.spCreateOrderCode(Code);
            return Code;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    public void InsertOrderGift(long OrderId, int GiftId, bool State)
    {
        try
        {
            var item = new OrderGift
            {
                OId = OrderId,
                GID = GiftId,
                stateFactor = State
            };
            Db.OrderGifts.InsertOnSubmit(item);
            Db.SubmitChanges();
        }
        catch
        {

        }
    }
    public void insertPayGift(long OrderId, int CityId, string Message, string ImagePath)
    {
        try
        {

            var item = new PayGift
            {
                orderId = OrderId,
                cityId = CityId,
                text = Message,
                file = ImagePath,
                date = DateTime.Now
            };
            Db.PayGifts.InsertOnSubmit(item);
            Db.SubmitChanges();
        }
        catch
        {

        }
    }
    public void InsertAddress(int CID, string Name, string Mobile, string Tel, string Address, string ZipCode, Guid UID)
    {
        try
        {
            var item = new UAddress
            {
                CityId = CID,
                FullName = Name,
                Mobile = Mobile,
                Tel = Tel,
                UserId = UID,
                Address = Address,
                ZipCode = ZipCode,
                Date = DateTime.Now
            };
            Db.UAddresses.InsertOnSubmit(item);
            Db.SubmitChanges();
        }
        catch
        {

        }
    }

    public string GetCode(long OrderId)
    {
        try
        {
            var Data = new Data();
            var ret = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(OrderId)).ConCode.GetValueOrDefault(0);
            return ret.Equals(0) ? "" : ret.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace(".00", "");
        }
        catch
        {
            return "";
        }
    }
    public void EditOrder(long OrderId)
    {
        try
        {
            var Data = new Data();
            var Order = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(OrderId));
            Order.Price = SumPrice();
            Data.DB.SubmitChanges();
        }
        catch
        {

        }
    }
    public void InsertDetailOrder(long OrderId)
    {
        var Data = new Data();
        var detailsOrder = Data.DB.OrderDetails.Where(p => p.OId.GetValueOrDefault(0).Equals(OrderId));
        var t = new List<key>();
        key keyd;
        if (detailsOrder != null)
        {
            foreach (OrderDetail o in detailsOrder)
            {

                t.Add(new key { PId = o.PId.GetValueOrDefault(0), CID = o.CID.GetValueOrDefault(0), SID = o.SID.GetValueOrDefault(0) });
            }
            EditOrder(OrderId);
        }
        foreach (DataRow row in ListData.Rows)
        {
            var PID = row.Field<int>("PID");
            var SId = row.Field<int>("SID");
            var CId = row.Field<int>("CID");

            var detailsOrderF = detailsOrder.FirstOrDefault(p => p.PId.Equals(PID) && p.SID.Equals(SId) && p.CID.Equals(CId));
            if (detailsOrderF != null)
            {
                detailsOrderF.Price = row.Field<long>("Price");
                detailsOrderF.Count = row.Field<int>("Count");
                keyd = new key();
                keyd.PId = PID;
                keyd.SID = SId;
                keyd.CID = CId;
                t.Remove(keyd);
            }
            else
            {
                var insdetailsOrder = new OrderDetail
                {
                    OId = OrderId,
                    PId = PID,
                    CID = CId,
                    SID = SId,
                    Price = row.Field<long>("Price"),
                    Count = row.Field<int>("Count")

                };
                Data.DB.OrderDetails.InsertOnSubmit(insdetailsOrder);
                var editSize = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(CId));
                if (editSize.Count.HasValue)
                {
                    editSize.Count = editSize.Count.Value - row.Field<int>("Count");
                    Data.DB.SubmitChanges();
                }


            }
            Data.DB.SubmitChanges();
        }
        if (t.Count > 0)
        {
            foreach (key i in t)
            {
                var del = Data.DB.OrderDetails.FirstOrDefault(p => p.OId.GetValueOrDefault(0).Equals(OrderId) && p.PId.GetValueOrDefault(0).Equals(i.PId) && p.CID.GetValueOrDefault(0).Equals(i.CID) && p.SID.GetValueOrDefault(0).Equals(i.SID));
                var editSize = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(del.SID));
                if (editSize.Count.HasValue)
                {
                    editSize.Count = editSize.Count.Value + del.Count;
                    Data.DB.SubmitChanges();
                }
                Data.DB.OrderDetails.DeleteOnSubmit(del);
                Data.DB.SubmitChanges();
            }
        }
    }
    public bool InsertOrderState(long OrderId, string State)
    {
        try
        {
            var Data = new Data();
            var item = new OrderState
            {
                OId = OrderId,
                State = State,
                Date = DateTime.Now
            };
            Data.DB.OrderStates.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool EditOrderState(int Id, string State)
    {
        try
        {
            var Data = new Data();
            var OrderSt = Data.DB.OrderStates.FirstOrDefault(p => p.Id.Equals(Id));
            OrderSt.State = State;
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public IQueryable<OrderState> GetState(long OrderId)
    {
        var Data = new Data();
        return Data.DB.OrderStates.ToList().Where(p => p.OId.Equals(OrderId)).AsQueryable().OrderBy(p => p.Id);
    }
    public IList<spGetFactorResult> GetFactor(long OrderId)
    {
        var Data = new Data();
        return Data.DB.spGetFactor(OrderId).ToList();
        //return Da
    }
    //public long SumFactor(long OrderId)
    //{
    //    var Data = new Data();

    //}
    public int PayType(long OrderId)
    {
        var Data = new Data();
        var item = Data.DB.Orders.FirstOrDefault(p => p.Id == OrderId);
        var res = -1;
        if (item != null)
        {
            switch (item.TypePay)
            {
                case "card":
                    res = 1;
                    break;
                case "local":
                    res = 2;
                    break;
                case "online":
                    res = 3;
                    break;
            }
        }
        return res;
    }
    public int LocalPayment(long OrderId, string Des)
    {
        var Data = new Data();
        var Factor = Data.DB.Orders.FirstOrDefault(p => p.Id == OrderId);
        if (Factor == null)
        {
            return 0;
        }
        else if (Data.DB.PayPlaces.Count(p => p.OId.GetValueOrDefault(0) == OrderId) > 0)
        {
            return 1;
        }
        else
        {
            var Local = new PayPlace
            {
                OId = OrderId,
                description = Des
            };
            Data.DB.PayPlaces.InsertOnSubmit(Local);
            Data.DB.SubmitChanges();
            return 2;
        }
    }
    public int CardPayment(long OrderId, string BankName, string Card4, long Price, string Des, string CodeFish, DateTime Date)
    {
        var Data = new Data();
        var Factor = Data.DB.Orders.FirstOrDefault(p => p.Id == OrderId);
        if (Factor == null)
        {
            return 0;
        }
        else if (Data.DB.PayCards.Count(p => p.OId.GetValueOrDefault(0) == OrderId) > 0)
        {
            return 1;
        }
        else
        {
            var Card = new PayCard
            {

                OId = OrderId,
                BankName = BankName,
                Card4 = Card4,
                Price = Price,
                Description = Des,
                CodeFish = CodeFish,
                Date = Date
            };
            Data.DB.PayCards.InsertOnSubmit(Card);
            Data.DB.SubmitChanges();
            return 3;
        }
    }
    public string LastTextDate(long OrderId)
    {
        var res = "";
        var Data = new Data();
        var Item = Data.DB.OrderStates.ToList().Where(p => p.OId.Equals(OrderId)).OrderByDescending(p => p.Date);
        if (Item.Count() > 0)
        {
            var dt = Item.First().Date;
            res = dt.Hour.ToString() + ":" + dt.Minute.ToString() + ":" + dt.Second.ToString() + " " + Data.PersianDate(dt);
        }
        return res;
    }
    public long SumPrice()
    {
        if (ListData.Rows.Count > 0)
        {
            return ListData.Select().Sum(p => (long)p["Total"]);
        }
        else
        {
            return 0;
        }
    }
    public long Benefit()
    {
        if (ListData.Rows.Count > 0)
        {
            return ListData.Select().Sum(p => (long)p["Benefit"]);
        }
        else
        {
            return 0;
        }
    }

    public static void Message(Label lblMessage, string message, Color color)
    {
        lblMessage.ForeColor = color;
        lblMessage.Text = message;
    }

    public static void EmptyMessage(Label lblMessage)
    {
        lblMessage.Text = string.Empty;
    }

    public IQueryable<Post> SelectPost(Guid userId)
    {
        var item = Db.Posts.Where(p => p.userId.Equals(userId)).ToList().AsQueryable();

        return item;
    }

}