﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

/// <summary>
/// Summary description for Club
/// </summary>
public class Club
{
    private Data Data = new Data();

    public class Paging
    {
        public int Id { get; set; }
        public string Class { get; set; }
    }
    public Club()
    {

    }
    public IList<spGetClubResult> GetClub()
    {
        return Data.DB.spGetClub().ToList();
    }
    public IList<spGetClubUserResult> GetClubUser(string User)
    {
        var UserId = new Guid(User);
        var res = Data.DB.spGetClubUser(UserId).ToList();
        return res;
    }
    public IList<spGetClubUserLResult> GetClubUserStat(string User)
    {
        var UserId = new Guid(User);
        
        var res = Data.DB.spGetClubUserL(UserId).ToList();
        return res;
    }
    public IList<spGetFriendResult> GetFriend()
    {
        return Data.DB.spGetFriend().ToList();
    }
    public IQueryable<ProductShare> GetProductShare()
    {
        
        var res = Data.DB.ProductShares.AsQueryable();
        return res;
    }
    public IQueryable<InfoShare> GetInfoShare()
    {
        var res = Data.DB.InfoShares.AsQueryable();
        return res;
    }
    public IQueryable<Warranty> GetWarranty()
    {
        return Data.DB.Warranties.AsQueryable();
    }
    public IQueryable<Poll> GetPoll()
    {
        return (from a in Data.DB.Polls
                select a);
    }

    public IList<spGetCommentResult> GetInfoComment(int InfoId, string Cat)
    {
        return Data.DB.spGetComment().Where(p => p.FID.Equals(InfoId) && p.Cat.Equals(Cat) && p.Show).ToList();
    }
    public IList<spGetProductCommentResult> GetProductComment(int PID)
    {
        return Data.DB.spGetProductComment().Where(p => p.PID.Equals(PID) && p.Show).ToList();
    }
    public IQueryable<CommentInfo> GetInfoComment(int InfoId, int Cat, bool Act = false)
    {
        return (from a in Data.DB.CommentInfos
                where (a.Active.Equals(Act) || !Act) && a.InfoId.Equals(InfoId) && a.Cat.Equals(Cat)
                orderby a.Id descending
                select a).ToList().AsQueryable();
    }
    public IList<spGetCommentResult> GetComment()
    {
        return Data.DB.spGetComment().ToList();
    }
    public IQueryable<Score> GetScore(string UserId = "")
    {
        return from a in Data.DB.Scores
               where a.UserId.Equals(new Guid(UserId)) || UserId.Length.Equals(0)
               select a;
    }

    public int ConvertPrice(string Name,float Point)
    {
        try
        {
           return Data.DB.spGetPrice(Name, Point);
        }
        catch
        {
            return 1;
        }
    }
    public bool InsertFriend(string Address, int Type, Guid UserId)
    {
        try
        {
            var item = new Friend
            {
                address = Address,
                Type = Type,
                UserId = UserId,
                Date = DateTime.Now
            };
            Data.DB.Friends.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Data.DB.spInsertScore(1, UserId, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int InsertPoll()
    {
        try
        {
            var poll = new Poll
            {
                
            };
            return 0;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }
    public bool InsertProductShare(int PID, Guid UID , string Social)
    {
        try
        {
            if (
                Data.DB.ProductShares.Any(
                    p => p.ProductId.Equals(PID) && p.UserId.Equals(UID) && p.Provider.Equals(Social))) return false;

            var item = new ProductShare
            {
                ProductId = PID,
                UserId = UID,
                Date=DateTime.Now,
                Provider = Social
            };
            Data.DB.ProductShares.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Data.DB.spInsertScore(1, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertInfoShare(int IID, Guid UID, int Cat, string Social, int SID = 0)
    {
        try
        {
            if (
                Data.DB.InfoShares.Any(
                    p => p.infoId.Equals(IID) && p.cat.Equals(Cat) && p.UserId.Equals(UID) && p.Provider.Equals(Social)))
                return false;

            var item = new InfoShare
            {
                infoId = IID,
                UserId = UID,
                cat = Cat,
                Date = DateTime.Now,
                Provider = Social
            };
            Data.DB.InfoShares.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            if (SID != 0)
                Data.DB.spInsertScore(SID, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertRate(int PID,Guid UID,int Rate)
    {
        try
        {
            if (Data.DB.Ratings.Count(p => p.UserId.Equals(UID) && p.ProductId.Equals(PID)) > 0) return false;
            var item = new Rating
            {
                Date = DateTime.Now,
                ProductId = PID,
                UserId = UID,
                Rating1 = Rate
            };
            Data.DB.Ratings.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Data.DB.spInsertScore(5, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertInfoRate(int IID, Guid UID, int Rate, int Cat, int SID = 0)
    {
        try
        {
            if (Data.DB.InfoRatings.Count(p => p.UserId.Equals(UID) && p.InfoId.Equals(IID) && p.Cat.Equals(Cat)) > 0) return false;
            var item = new InfoRating
            {
                Date = DateTime.Now,
                InfoId = IID,
                UserId = UID,
                Cat = Cat,
                Rating = Rate
            };
            Data.DB.InfoRatings.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            if (SID != 0)
                Data.DB.spInsertScore(SID, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public int InsertProductComment(int PID,string UserName,string Subject,string Text)
    {
        try
        {
            var res = Data.DB.SpProductComment(PID, "/", UserName, Subject, Text);
            return res;
        }
        catch
        {
            return 10;
        }
    }

    public int InsertNewsComment(int NID, string UserName, string Subject, string Text)
    {
        try
        {
            var res = Data.DB.spNewsComment(NID, "/", UserName, Subject, Text);
            return res;
        }
        catch
        {
            return 10;
        }
    }

    public int InsertDownloadComment(int NID, string UserName, string Subject, string Text)
    {
        try
        {
            var res = Data.DB.spDownloadComment(NID, "/", UserName, Subject, Text);
            return res;
        }
        catch
        {
            return 10;
        }
    }
    public int InsertAboutComment(int NID, string UserName, string Subject, string Text)
    {
        try
        {
            var res = Data.DB.spAboutComment(NID, "/", UserName, Subject, Text);
            return res;
        }
        catch
        {
            return 10;
        }
    }

    public bool InsertComment(Guid UserId,int InfoId,string Subject,string Message,int Cat,int SID = 0)
    {
        try
        {
            var g = new Guid();
            if (Data.DB.CommentInfos.Count(p => p.InfoId.Equals(InfoId) && p.Cat.Equals(Cat) && p.UserId.GetValueOrDefault(g).Equals(g)) > 0)
            {
                var dt = Data.DB.CommentInfos.Where(p => p.InfoId.Equals(InfoId) && p.Cat.Equals(Cat) && p.UserId.GetValueOrDefault(g).Equals(g)).Max(p => p.Date);

                if (dt.AddDays(1) >= DateTime.Now)
                    return false;
            }
            var comment = new CommentInfo
            {
                UserId = UserId,
                InfoId = InfoId,
                Reply = "",
                Subject = Subject,
                Message = Message,
                Cat = Cat,
                Date = DateTime.Now,
                Active = false
            };
            Data.DB.CommentInfos.InsertOnSubmit(comment);
            Data.DB.SubmitChanges();
            if (SID != 0)
                Data.DB.spInsertScore(SID, UserId, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditInfoComment(int Cid, string Subject, string Message, string Reply, bool Act)
    {
        try
        {
            var Comment = Data.DB.CommentInfos.FirstOrDefault(p => p.Id.Equals(Cid));
            Comment.Subject = Subject;
            Comment.Reply = Reply;
            Comment.Message = Message;
            Comment.Active = Act;
            Data.DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteComment(int Id)
    {
        try
        {
            var Item = Data.DB.CommentInfos.FirstOrDefault(p => p.Id.Equals(Id));
            Data.DB.CommentInfos.DeleteOnSubmit(Item);
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public IList<spGetRatioResult> GetRatio()
    {
        return Data.DB.spGetRatio().ToList();
    }
    public bool EditRatio(int Id, int Value)
    {
        try
        {
            var item = Data.DB.ScoreRoles.FirstOrDefault(p => p.Id.Equals(Id));
            item.Value = Value;
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
}