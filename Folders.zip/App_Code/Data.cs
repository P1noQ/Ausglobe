﻿using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using log4net.Core;
using Remotion.Data.Linq.Clauses.ResultOperators;

/// <summary>
/// Summary description for Data
/// </summary>
/// 

public class Data
{
    public db_atrDataContext DB = new db_atrDataContext();
  
    public Data()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public string FFrame
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            return item.Frame1;
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            item.Frame1 = value;
            DB.SubmitChanges();
        }
    }
    public string FAQ
    {
        get
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(1));
            return item.FAQ1;
        }
        set
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(1));
            item.FAQ1 = value;
            DB.SubmitChanges();
        }
    }
    public string Cred
    {
        get
        {
            var item = DB.Credits.FirstOrDefault(p => p.Id.Equals(1));
            return item.Credits;
        }
        set
        {
            var item = DB.Credits.FirstOrDefault(p => p.Id.Equals(1));
            item.Credits = value;
            DB.SubmitChanges();
        }
    }
    public string FAQWiki
    {
        get
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(2));
            return item.FAQ1;
        }
        set
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(2));
            item.FAQ1 = value;
            DB.SubmitChanges();
        }
    }

    public bool FShow
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            return item.Show.GetValueOrDefault(false);
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            item.Show = value;
            DB.SubmitChanges();
        }
    }
    public IList<spGetFrameResult> GetFrame(bool Top)
    {
        return DB.spGetFrame(Top).ToList();
    }

    public string LFrame
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            return item.Frame1;
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            item.Frame1 = value;
            DB.SubmitChanges();
        }
    }
    public bool LShow
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            return item.Show.GetValueOrDefault(false);
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            item.Show = value;
            DB.SubmitChanges();
        }
    }

    public string Agreement
    {
        get
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(1));
            return item.Agreement1;
        }
        set
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(1));
            item.Agreement1 = value;
            DB.SubmitChanges();
        }
    }
    public string OrderAgreement
    {
        get
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(2));
            return item.Agreement1;
        }
        set
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(2));
            item.Agreement1 = value;
            DB.SubmitChanges();
        }
    }
    public string Factor
    {
        get
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(3));
            return item.Agreement1;
        }
        set
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(3));
            item.Agreement1 = value;
            DB.SubmitChanges();
        }
    }
    public string Contact
    {
        get
        {
            var item = DB.Addresses.FirstOrDefault(p => p.Id.Equals(2));
            return item.Address1;
        }
        set
        {
            var item = DB.Addresses.FirstOrDefault(p => p.Id.Equals(1));
            item.Address1 = value;
            DB.SubmitChanges();
        }
    }

    public string Benefit
    {
        get
        {
            var item = DB.Benefits.FirstOrDefault(p => p.Id.Equals(1));
            return item.Benefit1;
        }
        set
        {
            var item = DB.Benefits.FirstOrDefault(p => p.Id.Equals(1));
            item.Benefit1 = value;
            DB.SubmitChanges();
        }
    }
    public string Help
    {
        get
        {
            var item = DB.Helps.FirstOrDefault(p => p.Id.Equals(1));
            return item.Help1;
        }
        set
        {
            var item = DB.Helps.FirstOrDefault(p => p.Id.Equals(1));
            item.Help1 = value;
            DB.SubmitChanges();
        }
    }
    public string FText
    {
        get
        {
            var item = DB.FooterTexts.FirstOrDefault(p => p.Id.Equals(1));
            return item.Text;
        }
        set
        {
            var item = DB.FooterTexts.FirstOrDefault(p => p.Id.Equals(1));
            item.Text = value;
            DB.SubmitChanges();
        }
    }
    public string UClub
    {
        get
        {
            var item = DB.TbClubs.FirstOrDefault(p => p.Id.Equals(1));
            return item.Body;
        }
        set
        {
            var item = DB.TbClubs.FirstOrDefault(p => p.Id.Equals(1));
            item.Body = value;
            DB.SubmitChanges();
        }
    }
    public string En
    {
        get
        {
            var item = DB.Englishes.FirstOrDefault(p => p.Id.Equals(1));
            return item.English1;
        }
        set
        {
            var item = DB.Englishes.FirstOrDefault(p => p.Id.Equals(1));
            item.English1 = value;
            DB.SubmitChanges();
        }
    }
    public string Footer
    {
        get
        {
            var item = DB.FooterLefts.FirstOrDefault(p => p.Id.Equals(1));
            return item.Body;
        }
        set
        {
            var item = DB.FooterLefts.FirstOrDefault(p => p.Id.Equals(1));
            item.Body = value;
            DB.Connection.Close();
        }
    }
    public DataTable UserData(string ApplicationName)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetUserData", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@ApplicationName", ApplicationName);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UserDataNews(string ApplicationName)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetUserDataNews", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@ApplicationName", ApplicationName);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }

    public DataTable State()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from State order by State asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable News()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from News order by Id desc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }


    public DataTable WNews()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from WNews order by Id asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable Certificate()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Certificate order by Id asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable OnSell()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select *,[dbo].fnProductAvailable(Id,0) as Available,[dbo].Fn_RateResualt(Id) as Rate from Product where DateDis<>'' And DisPrice<>'' And DateDis>=GETDATE()  order by Id asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable Download()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Download order by Id asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<State> StateQ()
    {
        return DB.States.ToList().AsQueryable();
    }
    public string StateName(int Id)
    {
        try
        {
            return DB.States.FirstOrDefault(p => p.ID.Equals(Id)).State1;
        }
        catch
        {
            return "خطا";
        }
    }
    public DataTable City(int StateId)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from City Where SID = " + StateId + " order by City asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<City> CityQ(int StateId)
    {
        return DB.Cities.Where(p => p.SID.GetValueOrDefault(0).Equals(StateId)).ToList().AsQueryable().OrderBy(p => p.City1);
    }
    public string CityName(int Id)
    {

        try
        {
            return DB.Cities.FirstOrDefault(p => p.ID.Equals(Id)).City1;
        }
        catch
        {
            return "خطا";
        }
    }
    public DataTable Meet()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Meet order by Meet asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<Meet> MeetQ()
    {
        return DB.Meets.OrderBy(p => p.Meet1).ToList().AsQueryable();
    }
    public DataTable Education()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Education order by ID asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<Education> EducationQ()
    {
        return DB.Educations.OrderBy(p => p.ID).ToList().AsQueryable();
    }
    public DataTable Active()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Active order by Active asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<Active> ActiveQ()
    {
        return DB.Actives.OrderBy(p => p.Active1).ToList().AsQueryable();
    }

    public bool InsertContact(int Cat, string Mail, string Name, string Subject, string Message)
    {
        try
        {
            var contact = new Contact
            {
                Cat = Cat,
                Mail = Mail,
                Name = Name,
                Subject = Subject,
                Message = Message,
                Date = DateTime.Now,
                Read = false
            };
            DB.Contacts.InsertOnSubmit(contact);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool ReadContact(int Id)
    {
        try
        {
            var item = GetContact(Id).First();
            item.Read = true;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public string GetDescription(int Id, string Type)
    {
        try
        {
            var item = DB.Descriptions.FirstOrDefault(p => p.Id.Equals(Id));
            var ret = "";
            switch (Type)
            {
                case "t":
                    ret = item.Title;
                    break;
                case "d":
                    ret = item.Description1;
                    break;
                case "k":
                    ret = item.Keywords;
                    break;
            }
            return ret;
        }
        catch
        {
            return "خطا";
        }


    }
    public IQueryable<Role> GetRole()
    {
        try
        {
            return DB.Roles.ToList().AsQueryable();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<About> GetInfoMenuDrop(int type)
    {
        try
        {
            IQueryable<About> res;
            res = DB.Abouts.AsQueryable().Where(p => p.Type.Equals(type)).OrderBy(p => p.Name);
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<Cat> GetCatDrop(string Type)
    {
        try
        {
            IQueryable<Cat> res;
            res = DB.Cats.AsQueryable().Where(p => p.Type.Equals(Type)).OrderBy(p => p.Name);
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<CatPart> GetCatPart()
    {
        try
        {
            IQueryable<CatPart> res;
            res = DB.CatParts.ToList().AsQueryable();
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<CatDoctor> GetCatDoctor()
    {
        try
        {
            IQueryable<CatDoctor> res;
            res = DB.CatDoctors.ToList().AsQueryable();
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IList<spGetUserDataDoctorResult> GetDoctor(int Cat)
    {
        try
        {
            return DB.spGetUserDataDoctor("/admin", Cat).ToList();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public IList<spGetQAResult> GetQAByUser(string Name)
    {
        return DB.spGetQA("/", "", Name).ToList();
    }

    public IList<spGetParentCatResult> GetParentCat(int Id, int Bid)
    {
        return DB.spGetParentCat(Id, Bid).ToList();
    }
    public bool CatWithB(int Id, int Bid)
    {
        if (DB.spGetParentCat(Id, Bid).ReturnValue.Equals(-1))
            return false;
        else
            return true;
    }
    public CatProduct CatProductData(int Id)
    {
        try
        {
            return DB.CatProducts.ToList().First(p => p.Id.Equals(Id));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public CatPrint CatPrintData(int Id)
    {
        try
        {
            return DB.CatPrints.ToList().First(p => p.Id.Equals(Id));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IList<spGatCatProductLevelResult> GetProductChildMenu(int Level, int Id)
    {
        return DB.spGatCatProductLevel(Level, Id).ToList();
    }

    public IList<spGetChildNameResult> GetChildName(string Name, string BName, int Level)
    {
        return DB.spGetChildName(Name, BName, Level).ToList();
    }
    public IList<spGetCatBranddResult> Getbran(int Id)
    {
        return DB.spGetCatBrandd(Id).OrderBy(p => p.Name).ToList();
    }
    public IQueryable<Gallery> GetGalleryData()
    {
        return DB.Galleries.ToList().AsQueryable();
    }
    public IList<spGetBrandResult> GetLeftBrand()
    {
        return DB.spGetBrand(false).ToList();
    }
    public IList<spGetCatBrandResult> GetBrandMenu(int Id)
    {
        return DB.spGetCatBrand(Id).ToList();
    }
    public IList<spGetCatPrintLevelResult> GetPrintChildMenu(int Level, int Id)
    {
        return DB.spGetCatPrintLevel(Level, Id).ToList();
    }
    public IList<spGetCatPrintLevelByResult> GetPrintChildMenuBY(int Id)
    {
        return DB.spGetCatPrintLevelBy(3, Id).ToList();
    }
    public IList<spGetCatProductResult> GetProductMenu()
    {
        return DB.spGetCatProduct().ToList();
    }
    public IList<spGetCatProductLResult> GetProductMenuA()
    {
        return DB.spGetCatProductL().ToList();
    }
    public IList<spGetCatPrintResult> GetPrintMenu()
    {
        return DB.spGetCatPrint().ToList();
    }
    public IList<spGetAboutMenuResult> GetAboutMenu(int Type)
    {
        return DB.spGetAboutMenu(Type).ToList();
    }
    public IList<spGetInfoResult> GetInfo()
    {
        return DB.spGetInfo().ToList();
    }
    public IList<spGetServiceResult> GetService()
    {
        return DB.spGetService().ToList();
    }
    public IQueryable<Part> GetPart(int Id)
    {
        return DB.Parts.ToList().Where(p => p.Cat.Equals(Id) || Id.Equals(0)).AsQueryable();
    }
    public IList<spGetCatAttrResult> GetCatAttr(int? Cat)
    {
        return DB.spGetCatAttr(Cat).ToList();
    }
    public IList<spGetCatAttrValResult> GetCatAttrVal(int AID)
    {
        return DB.spGetCatAttrVal(AID).ToList();
    }

    public IList<spGetProductwithsizeResult> GetProductWSize(int Id = 0,int SId=0)
    {
        return DB.spGetProductwithsize(Id,SId).ToList();
    }

    public IList<spGetProductResult> GetProduct(int Id = 0)
    {
        return DB.spGetProduct(Id).Where(p => p.View.GetValueOrDefault(true)).ToList();
    }
    public int insertFav(string UserName, int PID)
    {
        return DB.spAddFav("/", UserName, PID);
    }
    public int deleteFav(int FAVID)
    {
        return DB.spClearFav(FAVID);
    }

    public int deleteFav(Guid UserId)
    {
        return DB.spClearFavUser(UserId);
    }
    public IList<spGetFavResult> getFav(string username)
    {
        return DB.spGetFav("/", username).ToList();

    }
    public IList<spGetFavListResult> getFavList(string username)
    {
        return DB.spGetFavList("/", username).ToList();

    }

    public IList<spProductSearchResult> GetProductByWord(string Search,int SortIndex)
    {
        return DB.spProductSearch(Search, SortIndex).Where(p => p.View.GetValueOrDefault(true)).ToList();
    }
    public IList<ProductSearchResult> GetProductByMenu(int Cat, int level, int B = 0)
    {
        string n = null;
        IList<ProductSearchResult> prod = DB.ProductSearch(n, n, n, n, n, n, 0, 0, null, null).Where(p => p.View.GetValueOrDefault(true)).ToList();


        switch (level)
        {
            case 0:
                prod = prod.Where(p => p.Level0.GetValueOrDefault(0).Equals(Cat)).Where(p => p.View.GetValueOrDefault(true)).ToList();
                break;
            case 1:
                prod = prod.Where(p=>p.Level1.GetValueOrDefault(0).Equals(Cat) && p.BID.Equals(B)).Where(p => p.View.GetValueOrDefault(true)).ToList();
                break;
            case 2:
                prod = prod.Where(p => p.Level2.GetValueOrDefault(0).Equals(Cat) && p.BID.Equals(B)).Where(p => p.View.GetValueOrDefault(true)).ToList();
                break;
            case 3:
                prod = prod.Where(p => p.Level3.GetValueOrDefault(0).Equals(Cat) && p.BID.Equals(B)).Where(p => p.View.GetValueOrDefault(true)).ToList();
                break;
            default:
                prod = prod.Where(p => p.Level0.GetValueOrDefault(0).Equals(Cat) && p.BID.Equals(B)).Where(p => p.View.GetValueOrDefault(true)).ToList();
                break;
        }
        return prod.OrderByDescending(p => p.Name).ToList();
    }
    public IList<spGetPrintResult> GetPrint(int Id = 0)
    {
        return DB.spGetPrint(Id).ToList();
    }
    public IQueryable<Info> GetInfo(int Id = 0)
    {
        return DB.Infos.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }

    public IList<spGetGiftResult> GetGift()
    {
        return DB.spGetGift().Where(p => p.Active).ToList();
    }
    public IQueryable<Service> GetService(int Id = 0)
    {
        return DB.Services.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<New> GetNews(int Id = 0)
    {
        return DB.News.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Article> GetArticle(int Id = 0)
    {
        return DB.Articles.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Download> GetDownload(int Id = 0)
    {
        return DB.Downloads.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Contact> GetContact(int Id = 0)
    {
        return DB.Contacts.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IList<spGetContactResult> GetContact(string User, bool Read)
    {
        return DB.spGetContact(User).Where(p => p.Read.Equals(Read)).ToList();
    }
    public IQueryable<UnitMessage> GetUnit()
    {
        var item = DB.UnitMessages.ToList();
        return item.AsQueryable();
    }
    public IQueryable<Page> GetPage(int Id = 0)
    {
        return DB.Pages.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public Description GetDescription(int Id)
    {
        return DB.Descriptions.FirstOrDefault(p => p.Id.Equals(Id));
    }
    public IList<spDepResult> GetDep(string Product = "", string Print = "")
    {
        return DB.spDep(Print, Product).ToList();
    }
    public IList<spDepPrResult> GetDepPr(string Product = "", string Print = "", bool Show = false)
    {
        return DB.spDepPr(Print, Product, Show).ToList();
    }

    public IList<spGetOrderListResult> GetOrderList(string UserName = "", bool NoCash = false)
    {
        if (NoCash == false)
            return DB.spGetOrderList(UserName,0).Where(p => p.NoCash.GetValueOrDefault(NoCash)).ToList();
        return DB.spGetOrderList(UserName,0).ToList();
    }

    public string GetItemCount(string OrderId)
    {
        var OID = Convert.ToInt64(OrderId);
        return DB.OrderDetails.Where(p => p.OId.GetValueOrDefault(0).Equals(OID)).Sum(p => p.Count).ToString();
        //return DB.OrderDetails.Count(p => p.OId.GetValueOrDefault(0) == 2).ToString();
    }

    public string GetPrintMenuDrop(int id, int Level)
    {
        var data = DB.spGetCatPrint().ToList().First(p => p.Id == id);
        var ret = "";
        switch (Level)
        {
            case 0:
                ret = data.LEVEL0;
                break;
        }
        return ret;
    }

    public int GetProductDrop(int id, int Level)
    {
        var data = DB.spGetProduct(id).ToList().First();
        var ret = 0;
        switch (Level)
        {
            case 0:
                ret = data.Level0.GetValueOrDefault(0);
                break;
            case 1:
                ret = data.Level1.GetValueOrDefault(0);
                break;
            case 2:
                ret = data.Level2.GetValueOrDefault(0);
                break;
            case 3:
                ret = data.Level3.GetValueOrDefault(0);
                break;
        }
        return ret;
    }
    public int GetPrintDrop(int id, int Level)
    {
        var data = DB.spGetPrint(id).ToList().First();
        var ret = 0;
        switch (Level)
        {
            case 0:
                ret = data.Level0;
                break;
            case 1:
                ret = data.Level1;
                break;
        }
        return ret;
    }
    public bool HaveChildMenu(int Id)
    {
        if (DB.CatProducts.Count(p => p.Parent.GetValueOrDefault(0) == Id) > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool HaveChildMenuP(int Id)
    {
        if (DB.CatPrints.Count(p => p.Parent.GetValueOrDefault(0) == Id) > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public int MaxPrice()
    {

        try
        {
            return DB.PColors.Max(p => p.Price.GetValueOrDefault(0));
        }
        catch (Exception)
        {
            return 0;
        }
    }
    public int MaxAge()
    {
        return DB.Products.Max(p => p.MaxAge.GetValueOrDefault(0));
    }
    public int MaxLevel()
    {
        if (DB.CatProducts.Count() == 0)
        {
            return -1;
        }
        return DB.CatProducts.Max(p => p.Level);
    }
    public int MaxLevelP()
    {
        if (DB.CatPrints.Count() == 0)
        {
            return -1;
        }
        return DB.CatPrints.Max(p => p.Level);
    }

    public IList<GetAddressUserResult> GetAddressUser(string UserName)
    {
        return DB.GetAddressUser("/", UserName).ToList();
    }
    public DataTable member(string User)
    {

        var dt = new DataTable();
        var c = new DataColumn("U");

        dt.Columns.Add("UserName");
        dt.Columns.Add("Email");
        dt.Columns.Add("IsApproved", typeof(bool));
        dt.Columns.Add("CreateDate");
        dt.Columns.Add("Comment");
        dt.Columns.Add("Role");
        dt.Columns.Add("Name");
        dt.Columns.Add("Family");
        dt.Columns.Add("Sex", typeof(bool));
        dt.Columns.Add("BirthDate");
        dt.Columns.Add("NationalCode");
        dt.Columns.Add("IdNo");
        dt.Columns.Add("PostalCode");
        dt.Columns.Add("Tel");
        dt.Columns.Add("Mobile");
        dt.Columns.Add("Fax");
        dt.Columns.Add("Address");
        dt.Columns.Add("State");
        dt.Columns.Add("City");
        dt.Columns.Add("Meet");
        dt.Columns.Add("News");
        dt.Columns.Add("Education");

        if (Roles.FindUsersInRole("Real", User).Count() > 0)
        {
            dt.Columns.Add("Job");
        }
        else
        {
            dt.Columns.Add("Type");
            dt.Columns.Add("CorpName");
            dt.Columns.Add("Activity");
            dt.Columns.Add("EconomicCode");
            dt.Columns.Add("NationalId");
            dt.Columns.Add("Position");
            dt.Columns.Add("DirectPhone");
        }
        return dt;
    }
    public static string PersianDate(DateTime DTime)
    {
        var per = new PersianCalendar();
        var res = per.GetYear(DTime).ToString() + "/" + per.GetMonth(DTime).ToString("00") + "/" + per.GetDayOfMonth(DTime).ToString("00");
        return res;
    }
    public static string PersianTime(DateTime DTime)
    {
        var res = DTime.Hour.ToString() + ":" + DTime.Minute.ToString() + ":" + DTime.Second.ToString();
        return res;
    }
    public bool IsRegister(Guid WId)
    {
        if (DB.WarrantyRegisters.Count(p => p.Warranty.Equals(WId)) == 1)
            return true;
        else
            return false;
    }
    public static bool IsShop(string Price)
    {
        if (Price == "0")
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public long GetUserCharge(Guid UserID)
    {
        try
        {
            return DB.Cashes.Where(p => p.UserId.Equals(UserID)).Sum(p => p.Charge);
        }
        catch
        {
            return 0;
        }
    }
    public static string getdataDis(DateTime? date, long? disprice, long price)
    {
        if (date.HasValue)
        {
            if (date.Value >= DateTime.Now)
            {
                return disprice.GetValueOrDefault(0).ToString();
            }
            else
            {
                return price.ToString();

            }
        }
        else
        {
            return price.ToString();
        }
    }
    public static string PricePersian(string Price, bool isPrice = true)
    {
        var res = "";
        if (Price.Contains("درصد"))
            return Price;

        Int64 p = 0;
        Int64 p1 = 0;
        if (!String.IsNullOrEmpty(Price))
        {
            if (Price.Contains("/"))
            {
                var sp = Price.Split("/".ToArray());
                p = Convert.ToInt64(sp[0]);
                p1 = Convert.ToInt64(sp[1]);
            }
            if (Price.Contains("."))
            {
                var sp = Price.Split(".".ToArray());
                p = Convert.ToInt64(sp[0]);
                p1 = Convert.ToInt64(sp[1]);
            }
            else
            {
                p = Convert.ToInt64(Price);
            }
        }
        if (isPrice)
        {
            if (Price == "0") res = "&nbsp;";
            else
                res = p.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace("/00", "").Replace(".00", "") + " ريال";
        }
        else
        {
            if (p.Equals(0))
                res = "";
            else
            {
                res = p.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace("/00", "").Replace(".00", "");
                if (p1 != 0) res = res + "." + p1.ToString();
            }
        }
        return res;
    }

    public static string GetRate(int Rate)
    {
        return "catalog/view/theme/pacifico-pro/image/icons/" + Rate + ".png";
    }
    public static string Active(bool act)
    {
        if (act)
        {
            return "fa fa-check text-success text-active";

        }
        else
        {
            return "fa fa-times text-danger text-active";

        }
    }
    public static void ActiveUser(string User, bool Active, string app = "")
    {
        var paap = Membership.ApplicationName;
        var ap = "/" + app;
        Membership.ApplicationName = ap;
        var m = Membership.GetUser(User);
        m.IsApproved = Active;
        Membership.UpdateUser(m);
        Membership.ApplicationName = paap;
    }

    public IQueryable<FooterMenu> GetFooterName()
    {
        return DB.FooterMenus.AsQueryable();
    }
    public IQueryable<FooterLink> GetFooterLink(int Id)
    {
        return DB.FooterLinks.ToList().Where(p => p.Cat.GetValueOrDefault(0).Equals(Id) && p.Show.Equals(true)).AsQueryable();
    }
    public IQueryable<FlowLink> GetSocialLink()
    {
        return DB.FlowLinks.ToList().AsQueryable();
    }
    public IQueryable<SlideShow> GetSlideData()
    {
        return DB.SlideShows.ToList().AsQueryable();
    }

    public IQueryable<MenuB> GetBanerMenu(int Id)
    {
        return DB.MenuBs.ToList().Where(p => p.Id.Equals(Id) || Id == 0).AsQueryable();
    }
    public IQueryable<TopBaner> GetTopBanerData()
    {
        return DB.TopBaners.ToList().AsQueryable();
    }
    public IQueryable<Baner> GetBanerData()
    {
        return DB.Baners.ToList().AsQueryable();
    }
    public IQueryable<Link> GetLink()
    {
        return DB.Links.ToList().OrderBy(p => p.Id).AsQueryable();
    }
    public IQueryable<Event> GetEvent()
    {
        return DB.Events.ToList().OrderByDescending(p => p.Id).AsQueryable();
    }
    public IList<spGetRandomEventResult> GetRandomEvent()
    {
        return DB.spGetRandomEvent().ToList();
    }
    public IQueryable<Agent> GetAgent()
    {
        return DB.Agents.ToList().AsQueryable();
    }
    public IQueryable<Warranty> GetWarranty()
    {
        return DB.Warranties.ToList().AsQueryable();
    }
    public IList<spGetWarrantyUserResult> GetWarranty(Guid? UserId)
    {
        return DB.spGetWarrantyUser(UserId).ToList();
    }
    public IQueryable<Failure> GetFailture()
    {
        return DB.Failures.ToList().AsQueryable();
    }
    public IQueryable<Failure> GetFailture(int Id)
    {
        return DB.Failures.Where(p => p.Id.Equals(Id)).ToList().AsQueryable();
    }
    public IList<spGetBanerResult> GetBaner(int Pos, int Take)
    {
        return DB.spGetBaner(Pos, Take).ToList();
    }
    public string GetGiftImage(int id)
    {
        try
        {
            var item = DB.Gifts.FirstOrDefault(p => p.id.Equals(id));

            return item.Image.ToString();
        }

        catch
        {
            return "";

        }
    }
    public int CreateUserSetting(string UserName)
    {
        try
        {
            return DB.spUserSetCreate(UserName);
        }
        catch
        {
            return 10;
        }
    }

    public int UpdateUserSetting(string UserName, string Cat, bool Mail, bool Mobile)
    {
        try
        {
            return DB.spUpdateUserSet(UserName, Cat, Mail, Mobile);
        }
        catch
        {
            return 5;
        }
    }

    public IList<spGetUserSetResult> UserSetting(string UserName)
    {
        return DB.spGetUserSet(UserName).ToList();
    }

    public Guid GetUserId(string User)
    {
        var u = Membership.GetUser(User);
        var ret = new Guid(u.ProviderUserKey.ToString());
        return ret;
    }
    public string GetUserName(string UserId)
    {
        var Usr = Membership.GetUser(new Guid(UserId)).UserName;

        var pr = ProfileBase.Create(Usr);
        return pr.GetPropertyValue("Name") + " " + pr.GetPropertyValue("Family");
    }

    public bool IsAvailSize(int PID, int SID)
    {
        return DB.fnProductAvailable(PID, SID).GetValueOrDefault(false);
    }
    public bool IsAvailable(string ApplicationName, string UserName)
    {
        return DB.IsAvailable(ApplicationName, UserName).GetValueOrDefault(false);
    }
    public static string GenerateRandomCode()
    {
        Random r = new Random();
        string s = "";
        for (int j = 0; j < 5; j++)
        {
            int i = r.Next(3);
            int ch;
            switch (i)
            {
                case 1:
                    ch = r.Next(0, 9);
                    s = s + ch.ToString();
                    break;
                case 2:
                    ch = r.Next(65, 90);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
                case 3:
                    ch = r.Next(97, 122);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
                default:
                    ch = r.Next(97, 122);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
            }
            r.NextDouble();
            r.Next(100, 1999);
        }
        return s;
    }

    public static string GetReply(string Reply)
    {
        if (String.IsNullOrWhiteSpace(Reply))
            return "";
        else
            return "متن جواب &nbsp:&nbsp" + Reply;
    }

    public static string Join(string str1, string str2)
    {
        var ret = "";
        if (str1.Length > 0 && str2.Length > 0)
            ret = str1 + " " + str2;
        else if (str1.Length > 0)
            ret = str1;
        else
            ret = str2;
        return ret;
    }

    public IQueryable<Post> GetPost()
    {
        var item = DB.Posts.ToList().AsQueryable();


        return item;
    }



    public IQueryable<GetAddressUserResult> SelectAddress(string appname, string username)
    {
        return DB.GetAddressUser(applicationName: appname, userName: username).ToList().AsQueryable();
    }
    //public IQueryable<Post> GetUserPost(string UN)
    //{
    //    var g = GetUserId()
    //    var item = from a in DB.Posts
    //               join b in SelectUser() on a.userId equals b.UserId
    //               select a;
    //    return item;
    //}
    public IQueryable<City> SelectCity()
    {
        var item = DB.Cities.ToList().AsQueryable();

        return item;
    }
    public IList<spGetGiftCardsResult> GetGiftCart()
    {
        return DB.spGetGiftCards().ToList();
    }
    public IList<About> GetAbout()
    {
        return DB.Abouts.ToList();
    }
    public spGetGiftCardsResult GetCurrentGiftCard(string GiftCode)
    {
        return DB.spGetGiftCards().FirstOrDefault(p => p.GiftCode.Equals(GiftCode));
    }

    public long InsertOrderGiftCard(long Price, string UserName, int DiscountPrice)
    {
        try
        {
            var item = new Order
            {
                Price = Price,
                discount = DiscountPrice,
                UserId = (Guid)Membership.GetUser(UserName).ProviderUserKey,
                TypePay = "آنلاین",
                Finish = false,
            };
            DB.Orders.InsertOnSubmit(item);
            DB.SubmitChanges();
            return item.Id;
        }

        catch { return 0; }
    }

    public bool InsertUserGiftCard(Guid GiftID, long OrID, Guid UserID, string GiftCode, string Name = "",
        string NewUserName = "", string NewName = "", bool IsUSed = false)
    {
        try
        {
            string s = GenerateRandomNumbers(GiftCode);
            var CurrentGiftcard = DB.GiftCards.FirstOrDefault(p => p.GiftId.Equals(GiftID));

            var itemGiftCard = new UserGiftCard
            {
                GiftId = GiftID,
                UserId = UserID,
                GiftCode = s,
                Price = CurrentGiftcard.Price,
                Balance = CurrentGiftcard.Balance,
                IsUsed = IsUSed,
                Date = DateTime.Now,
                OrId = OrID,
                From = Name,
                To = NewName

            };

            DB.UserGiftCards.InsertOnSubmit(itemGiftCard);
            DB.SubmitChanges();
            return true;
        }

        catch { return false; }
    }

    public string GenerateRandomNumbers(string GiftCode)
    {
        try
        {
            string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            string index1 = chars.ElementAt(random.Next(1, chars.Length)).ToString();
            string index2 = chars.ElementAt(random.Next(1, chars.Length)).ToString();
            string index3 = chars.ElementAt(random.Next(1, chars.Length)).ToString();
            string index4 = chars.ElementAt(random.Next(1, chars.Length)).ToString();

            int place1 = random.Next(1, 11);
            int place2 = random.Next(1, 11);
            int place3 = random.Next(1, 11);
            int place4 = random.Next(1, 11);


            string G1 = GiftCode.ReplaceAt(place1, index1.ToCharArray()[0]);
            string G2 = GiftCode.ReplaceAt(place2, index2.ToCharArray()[0]);
            string G3 = GiftCode.ReplaceAt(place3, index3.ToCharArray()[0]);
            string G4 = GiftCode.ReplaceAt(place4, index4.ToCharArray()[0]);
            string NewGiftCode = G3;
            return G3;
        }

        catch
        {
            return "";

        }


    }

    public bool AddCash(Guid UserID, long Balance, string Type)
    {
        try
        {
            var item = new Cash
            {
                UserId = UserID,
                Charge = Balance,
                Type = Type,
                Date = DateTime.Now
            };
            DB.Cashes.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }

    public bool RemoveCash(Guid UserID, long Balance)
    {
        try
        {
            var item = new Cash
            {
                UserId = UserID,
                Charge = -Balance,
                Date = DateTime.Now
            };
            DB.Cashes.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    //وارد نمودن کد شارژ
    public int CharageUserDirect(Guid UserID, string GiftCode)
    {
        //var item = DB.UserGiftCards.Join(DB.GiftCards).FirstOrDefault(p => p.GiftCode.Equals(GiftCode));
        var item = (from gifts in DB.UserGiftCards
                    where gifts.GiftCode.Equals(GiftCode)
                    join gift in DB.GiftCards on gifts.GiftId equals gift.GiftId
                    select new { gift, gifts }).FirstOrDefault();
        if (item == null)
            return 1;
        else
        {
            int res = 0;
            if (item.gifts.IsUsed)
                res = 2;
            if (DateTime.Now < item.gift.Expiry.Value && item.gift.Expiry.HasValue)
                res = 4;
            if (!item.gifts.IsUsed && DateTime.Now < item.gift.Expiry)
            {
                AddCash(UserID, item.gifts.Balance, "وارد نمودن کد شارژ");
                item.gifts.IsUsed = true;
                DB.SubmitChanges();
                res = 3;
            }
            return res;
        }
    }
    //توسط خود کاربر
    public int ChargeUser(Guid UserID, Guid GiftID, bool s = false)
    {
        try
        {

            var itemGift = DB.UserGiftCards.Where(p => p.GiftId.Equals(GiftID)  && p.UserId.Equals(UserID));

            if (itemGift == null)
                return 1;
            else
            {
                int res = 0;
                foreach (var item in itemGift)
                {
                    if (item.IsUsed)
                        res = 2;

                    if (!item.IsUsed)
                    {
                        if (s == false)
                            AddCash(UserID, item.Balance, "افزایش اعتبار توسط خود کاربر");
                        else
                        {
                            AddCash(UserID, item.Balance, "افزایش اعتبار توسط کاربر دیگر");

                        }
                        item.IsUsed = true;
                        DB.SubmitChanges();
                        res = 3;
                    }
                }
                return res;
            }
        }
        catch
        {
            return -1;
        }
    }
    public IQueryable<Certificate> GetCert(int Id = 0)
    {
        return DB.Certificates.AsQueryable().Where(p => p.id.Equals(Id) || Id.Equals(0));
    }
    public int ChargeUserByPhysicalCard(Guid UserID, String GiftCode)
    {
        try
        {

            var itemGift = DB.spGetRepeatedGiftCards(GiftCode).FirstOrDefault();
            if (itemGift == null)
                return 1;
            else
            {
                int res = 0;
                AddCash(UserID, itemGift.Balance, "شارژ توسط کارت فیزیکی");
                Guid GiftID = itemGift.GiftId;
                var item = DB.GiftCards.FirstOrDefault(p => p.GiftId == GiftID);
                DB.GiftCards.DeleteOnSubmit(item);
                DB.SubmitChanges();
                res = 3;
                return res;

            }

        }
        catch
        {
            return -1;
        }
    }

    public static bool InSale(DateTime? date)
    {
        var ret = false;
        if (date.HasValue)
        {
            if (date.Value >= DateTime.Now)
            {
                ret = true;
            }
        }
        return ret;
    }

    public static string removeAMPM(DateTime? date, bool isep = false)
    {
        var st = "yyyy-M-d HH:mm:ss";
        if (isep) st = "d/M/yyyy HH:mm:ss";
        var ret = "";
        if (date.HasValue)
        {
            ret = date.Value.ToString(st, CultureInfo.InvariantCulture);
        }
        return ret;
    }
    public static string checkstate(bool avlb)
    {
        var ret = "";
        if (!avlb)
        {
            ret = "(موجود نیست)";
        }
        return ret;
    }
    public static string ChangeStateName(bool avlb)
    {
        var ret = "";
        if (!avlb)
        {
            ret = "(استفاده شده)";
        }
        else
        {
            ret = "(استفاده نشده)";
        }
        return ret;
    }
    public AddMessage getMes(int cat)
    {
        return DB.AddMessages.FirstOrDefault(p => p.CatId.Equals(cat));
    }
    public static string PriceState(bool span)
    {
        return span ? "csprice" : "csprice lo";
    }
    public static string StateColor(bool Insale, bool MostShop, bool MostView, bool Newest)
    {
        if (Insale)
        {
            return "isinsale";
        }
        else if (MostShop)
        {
            return "ismostsale";
        }
        else if (MostView)
        {
            return "ismostview";
        }

        else if (Newest)
        {
            return "isnew";
        }
        return "";
    }
    public static string GetPk(int pid, int sid, int cid)
    {
        return pid.ToString() + "&&" + sid.ToString() + "&&" + cid.ToString();
    }

    public IList<spGetBrandResult> GetBrand(bool IsMenu = true)
    {
        return DB.spGetBrand(IsMenu).ToList();
    }

    public DataView AdvancedSearch(string RootCats,string Brands,string ProductAttrs,
        int MaxPrice, int MinPrice, int MaxAge,int MinAge, int SortIndex, string OnlyAvailables)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("ProductAdvancedSearch", myConnection);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Parameters.AddWithValue("RootCats", RootCats);
        myCommand.Parameters.AddWithValue("Brands", Brands);
        myCommand.Parameters.AddWithValue("ProductAttrs", ProductAttrs);
        myCommand.Parameters.AddWithValue("MaxPrice", MaxPrice);
        myCommand.Parameters.AddWithValue("MinPrice", MinPrice);
        myCommand.Parameters.AddWithValue("MaxAge", MaxAge);
        myCommand.Parameters.AddWithValue("MinAge", MinAge);
        myCommand.Parameters.AddWithValue("SearchOnlyAvailables", OnlyAvailables);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        //return Res;
        string sort = "";
        if (SortIndex == 0)
            sort = "asc";
        else
            sort = "desc";
        DataView dv = Res.AsDataView();
        dv.Sort = "Price" + " " + sort;
        return dv;
        //var res = Res.Rows.AsEnumerable().Where(p =>p.Field<bool>("Available") == false);
        //DataTable dt = res.AsDataView().Table;
        //return dt;
    }
    public int GetCurrentLevel(int CatId)
    {
        return DB.CatProducts.FirstOrDefault(p => p.Id.Equals(CatId)).Level;
    }
}