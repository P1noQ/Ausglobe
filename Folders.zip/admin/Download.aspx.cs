﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;

namespace admin
{
    public partial class Download : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            
            LoadDate();
        }
        private void LoadDate()
        {

            txtTitle.Text = Data.GetDescription(3, "t");
            txtDescription.Text = Data.GetDescription(3, "d");
            txtKeyword.Text = Data.GetDescription(3, "k");

            var item = Data.GetDownload().ToList();
            gvList.DataSource = item;
            gvList.DataBind();
            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void EditKey(object sender, EventArgs e)
        {
            try
            {
                var Title = Server.HtmlEncode(txtTitle.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Des = Server.HtmlEncode(txtDescription.Text);
                Data.EditDescription(3, Title, Keyword, Des);
                Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            LoadDate();
        }

        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                Message.EmptyMessage(lblMessage1);
                lblh.InnerText = "ویرایش دانلود";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                var item = Data.GetDownload(id).First();
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Title;
                txtBrief.Text = item.Brief;
                txtBody.Value = item.Body;
                txtDDescription.Text = item.Description;
                txtDKeyword.Text = item.Keyword;
                hdfFile.Value = item.Image;

                imgMenu.ImageUrl = "uploadimage/download/" + item.Image;
                MultiView1.ActiveViewIndex = 1;

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                Message.EmptyMessage(lblMessage1);
                var item = Data.GetDownload(id).First();

                if (item != null && !string.IsNullOrEmpty(item.Image))
                {
                    switch (Data.DeleteDownload(id, Server.MapPath("~/uploadimage/download/")))
                    {
                        case true:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                            break;
                        case false:
                            Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                            break;
                    }
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }

        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر دانلود را انتخاب نمایید", Color.Red);
                    return;
                }
                if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/download/") + filename))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر دانلود لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;
                var Body = Server.HtmlEncode(txtBody.Value);
                var Brief = Server.HtmlEncode(txtBrief.Text);
                var Des = Server.HtmlEncode(txtDDescription.Text);
                var Key = Server.HtmlEncode(txtDKeyword.Text);
                var p = Data.InsertDownload(Name, Brief, Image, Body, Des, Key);
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }

        protected void BtnAddClick(object sender, EventArgs e)
        {

            BtnEdit.Visible = false;
            BtnInsert.Visible = true;

            lblh.InnerText = "ایجاد دانلود";
            txtName.Text = "";
            txtBrief.Text = "";
            txtBody.Value = "";
            Message.EmptyMessage(lblMessage);
            Message.EmptyMessage(lblMessage1);
            MultiView1.ActiveViewIndex = 1;

        }

        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    FileJob.DeleteFile(Server.MapPath("~/uploadimage/downlaod/") + hdfFile.Value);
                    FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/download/") + filename);
                }
                else
                {
                    filename = hdfFile.Value;
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;

                var Brief = Server.HtmlEncode(txtBrief.Text);
                var Des = Server.HtmlEncode(txtDDescription.Text);
                var Key = Server.HtmlEncode(txtDKeyword.Text);
                var Body = txtBody.Value;

                try
                {
                    Data.EditDownload(int.Parse(hdfId.Value), Name, Brief, Image, Body, Des, Key);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
    }
}