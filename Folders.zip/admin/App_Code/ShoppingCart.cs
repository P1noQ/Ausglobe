﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Globalization;
using System.Web.Security;

/// <summary>
/// Summary description for ShoppingCart
/// </summary>
public class clsShoppingCart
{
    public void ShoppingCart()
    {

    }
    
    public void AddList()
    {
        if (HttpContext.Current.Session["buy"] == null)
        {
            var dt = new DataTable("ShoppingCart");
            DataColumn[] keys = new DataColumn[1];
            
            dt.Columns.Add("PId", typeof(int));
            dt.Columns.Add("Id", typeof(int));
            dt.Columns.Add("Image");
            dt.Columns.Add("Title");
            dt.Columns.Add("Price", typeof(long));
            dt.Columns.Add("Count", typeof(int));
            dt.Columns.Add("Ord", typeof(long));
            dt.Columns.Add("Total", typeof(long));
             
            dt.Columns["Total"].Expression = "Price*Count";
            keys[0] = dt.Columns["PID"];
            dt.PrimaryKey = keys;
            ListData = dt;
        }
    }
    public DataTable ListData
    {
        get
        {
            var options = new DataTable();

            if (HttpContext.Current.Session["buy"] != null)
                options = (DataTable)HttpContext.Current.Session["buy"];
            return options;
        }
        set
        {
            HttpContext.Current.Session["buy"] = value;
        }
    }
    public long OrdId
    {
        get
        {
            long ret;
            if (ListData.Rows.Count > 0)
                ret=ListData.Rows[0].Field<long>("Ord");
            else
                ret = 0;

            return ret;
        }
    }
    public int Number
    {
        get
        {
            return ListData.Select().Sum(r => r.Field<int>("Count"));
        }
    }
    public void UpdateShoppingCart(int PID, int Count)
    {
        var itemUpdate = ListData.Rows.Find(PID);

        if (itemUpdate != null)
        {
            itemUpdate.BeginEdit();
            itemUpdate.SetField("Count", Count);
            itemUpdate.EndEdit();
        }
    }
    public void DeleteShoppingCart(int PID)
    {
        try
        {
            ListData.Rows.Remove(ListData.Rows.Find(PID));
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public long InsertOrder(long Price,string UserName,string TypePay)
    {
        try
        {
            var Data = new Data();
            var item = new Order
            {
                Price = Price,
                Date = DateTime.Now,
                Status = "معلق",
                UserId = (Guid)Membership.GetUser(UserName).ProviderUserKey,
                TypePay = TypePay,
            };
            Data.DB.Orders.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            var Code = item.Id;
            return Code;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public string GetCode(long OrderId)
    {
        try
        {
            var Data = new Data();
            var ret = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(OrderId)).ConCode.GetValueOrDefault(0);
            return ret.Equals(0) ? "" : ret.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace(".00", "");
        }
        catch
        {
            return "";
        }
    }
    public void EditOrder(long OrderId)
    {
        try
        {
            var Data=new Data();
            var Order = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(OrderId));
            Order.Price = SumPrice();
            Data.DB.SubmitChanges();
        }
        catch
        {

        }
    }
    public void InsertDetailOrder(long OrderId)
    {
        var Data = new Data();
        var detailsOrder = Data.DB.OrderDetails.Where(p => p.OId.GetValueOrDefault(0).Equals(OrderId));
        var t = new List<int>();
        if (detailsOrder != null)
        {
            foreach (OrderDetail o in detailsOrder)
            {
                t.Add(o.PId.GetValueOrDefault(0));
            }
            EditOrder(OrderId);
        }
        foreach (DataRow row in ListData.Rows)
        {
            var PID = row.Field<int>("PID");
            var detailsOrderF = detailsOrder.FirstOrDefault(p => p.PId.Equals(PID));
            if (detailsOrderF != null)
            {
                detailsOrderF.Price = row.Field<long>("Price");
                detailsOrderF.Count = row.Field<int>("Count");
                t.Remove(PID);
            }
            else
            {
                var insdetailsOrder = new OrderDetail
                {
                    OId = OrderId,
                    PId = PID,
                    Price = row.Field<long>("Price"),
                    Count = row.Field<int>("Count")
                    
                };
                Data.DB.OrderDetails.InsertOnSubmit(insdetailsOrder);
            }
            Data.DB.SubmitChanges();
        }
        if (t.Count > 0)
        {
            foreach (int i in t)
            {
                var del = Data.DB.OrderDetails.FirstOrDefault(p => p.OId.GetValueOrDefault(0).Equals(OrderId) && p.PId.GetValueOrDefault(0).Equals(i));
                Data.DB.OrderDetails.DeleteOnSubmit(del);
                Data.DB.SubmitChanges();
            }
        }
    }
    public bool InsertOrderState(long OrderId, string State)
    {
        try
        {
            var Data = new Data();
            var item = new OrderState
            {
                OId = OrderId,
                State = State,
                Date = DateTime.Now
            };
            Data.DB.OrderStates.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool EditOrderState(int Id, string State)
    {
        try
        {
            var Data = new Data();
            var OrderSt = Data.DB.OrderStates.FirstOrDefault(p => p.Id.Equals(Id));
            OrderSt.State = State;
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public IQueryable<OrderState> GetState(long OrderId)
    {
        var Data = new Data();
        return Data.DB.OrderStates.ToList().Where(p => p.OId.Equals(OrderId)).AsQueryable().OrderBy(p => p.Id);
    }
    public IList<spGetFactorResult> GetFactor(long OrderId)
    {
        var Data = new Data();
        return Data.DB.spGetFactor(OrderId).ToList();
        //return Da
    }
    //public long SumFactor(long OrderId)
    //{
    //    var Data = new Data();
        
    //}
    public int PayType(long OrderId)
    {
        var Data = new Data();
        var item = Data.DB.Orders.FirstOrDefault(p => p.Id == OrderId);
        var res = -1;
        if (item != null)
        {
            switch (item.TypePay)
            {
                case "card":
                    res = 1;
                    break;
                case "local":
                    res = 2;
                    break;
            }
        }
        return res;
    }
    public int LocalPayment(long OrderId ,string Des)
    {
        var Data = new Data();
        var Factor = Data.DB.Orders.FirstOrDefault(p => p.Id == OrderId);
        if (Factor == null)
        {
            return 0;
        }
        else if (Data.DB.PayPlaces.Count(p => p.OId.GetValueOrDefault(0) == OrderId) > 0)
        {
            return 1;
        }
        else
        {
            var Local = new PayPlace
            {
                OId = OrderId,
                description = Des
            };
            Data.DB.PayPlaces.InsertOnSubmit(Local);
            Data.DB.SubmitChanges();
            return 2;
        }
    }
    public int CardPayment(long OrderId, string BankName, string Card4, long Price, string Des, string CodeFish, string Date)
    {
        var Data = new Data();
        var Factor = Data.DB.Orders.FirstOrDefault(p => p.Id == OrderId);
        if (Factor == null)
        {
            return 0;
        }
        else if (Data.DB.PayCards.Count(p => p.OId.GetValueOrDefault(0) == OrderId) > 0)
        {
            return 1;
        }
        else
        {
            var Card = new PayCard
            {

                OId = OrderId,
                BankName = BankName,
                Card4 = Card4,
                Price = Price,
                Description = Des,
                CodeFish = CodeFish,
                Date = Date
            };
            Data.DB.PayCards.InsertOnSubmit(Card);
            Data.DB.SubmitChanges();
            return 3;
        }
    }
    public string LastTextDate(long OrderId)
    {
        var res = "";
        var Data = new Data();
        var Item = Data.DB.OrderStates.ToList().Where(p => p.OId.Equals(OrderId)).OrderByDescending(p => p.Date);
        if (Item.Count() > 0)
        {
            var dt = Item.First().Date;
            res = dt.Hour.ToString() + ":" + dt.Minute.ToString() + ":" + dt.Second.ToString() + " " + Data.PersianDate(dt);
        }
        return res;
    }
    public long SumPrice()
    {
        if (ListData.Rows.Count > 0)
        {
             return ListData.Select().Sum(p => (long)p["Total"]);
        }
        else
        {
            return 0;
        }
    }
}