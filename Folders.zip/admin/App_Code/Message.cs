﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

/// <summary>
/// Summary description for Message
/// </summary>
public static class Message
{
    public static void MessageGen(Label lblMessage, string message, Color color)
    {
        lblMessage.ForeColor = color;
        lblMessage.Text = message;
    }
    public static void EmptyMessage(Label lblMessage)
    {
        lblMessage.Text = string.Empty;
    }
}