﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Security.Cryptography;
using System.IO;

/// <summary>
/// Summary description for Hash
/// </summary>
public static class Hash
{
    public static string GetString(byte[] Value)
    {
        var ret = "";
        foreach (byte s in Value)
        {
            ret = ret + char.ConvertFromUtf32(s);
        }
        return ret;
    }
    public static byte[] GetStream(string Value)
    {
        var res = new List<byte>();

        for (int i = 0; i < Value.Length; i++)
        {
            res.Add(Convert.ToByte(char.ConvertToUtf32(Value, i)));
        }
        return res.ToArray();
    }
    public static byte[] EncryptStringToBytes_Des(string plainText)
    {
        // Check arguments. 
        if (plainText == null || plainText.Length <= 0)
            throw new ArgumentNullException("plainText");

        var Key = new byte[8];
        Key[0] = 85;
        Key[1] = 221;
        Key[2] = 147;
        Key[3] = 112;
        Key[4] = 78;
        Key[5] = 157;
        Key[6] = 141;
        Key[7] = 111;
        var IV = new byte[8];
        IV[0] = 80;
        IV[1] = 104;
        IV[2] = 98;
        IV[3] = 205;
        IV[4] = 214;
        IV[5] = 125;
        IV[6] = 42;
        IV[7] = 228;


        byte[] encrypted;
        // Create an Aes object 
        // with the specified key and IV. 
        using (DES desAlg = DES.Create())
        {
            desAlg.Key = Key;
            desAlg.IV = IV;

            // Create a decrytor to perform the stream transform.
            ICryptoTransform encryptor = desAlg.CreateEncryptor(desAlg.Key
, desAlg.IV);

            // Create the streams used for encryption. 
            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt
, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(
csEncrypt))
                    {

                        //Write all data to the stream.
                        swEncrypt.Write(plainText);

                    }
                    encrypted = msEncrypt.ToArray();
                }
            }
        }


        // Return the encrypted bytes from the memory stream. 
        return encrypted;

    }
    public static string DecryptStringFromBytes_Des(string Text)
    {
        var cipherText = GetStream(Text);
        var Key = new byte[8];
        Key[0] = 85;
        Key[1] = 221;
        Key[2] = 147;
        Key[3] = 112;
        Key[4] = 78;
        Key[5] = 157;
        Key[6] = 141;
        Key[7] = 111;
        var IV = new byte[8];
        IV[0] = 80;
        IV[1] = 104;
        IV[2] = 98;
        IV[3] = 205;
        IV[4] = 214;
        IV[5] = 125;
        IV[6] = 42;
        IV[7] = 228;

        // Check arguments. 
        if (cipherText == null || cipherText.Length <= 0)
            throw new ArgumentNullException("cipherText");
        // Declare the string used to hold 
        // the decrypted text. 
        string plaintext = null;

        // Create an Aes object 
        // with the specified key and IV. 
        using (DES desAlg = DES.Create())
        {
            desAlg.Key = Key;
            desAlg.IV = IV;

            // Create a decrytor to perform the stream transform.
            ICryptoTransform decryptor = desAlg.CreateDecryptor(desAlg.Key
, desAlg.IV);

            // Create the streams used for decryption. 
            using (MemoryStream msDecrypt = new MemoryStream(cipherText))
            {
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt
, decryptor, CryptoStreamMode.Read))
                {
                    using (StreamReader srDecrypt = new StreamReader(
csDecrypt))
                    {

                        // Read the decrypted bytes from the decrypting 

                        // and place them in a string.
                        plaintext = srDecrypt.ReadToEnd();
                    }
                }
            }

        }

        return plaintext;
    }

}