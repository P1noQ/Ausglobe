﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Captcha
/// </summary>
public static class Captcha
{
    public static string rpHash(string value)
    {
        int hash = 5381;
        value = value.ToUpper();
        for (int i = 0; i < value.Length; i++)
        {
            hash = ((hash << 5) + hash) + value[i];
        }
        return hash.ToString();
    } 
}