﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

/// <summary>
/// Summary description for Club
/// </summary>
public class Club
{
    private Data Data = new Data();
    public Club()
    {

    }
    public IList<spGetClubResult> GetClub()
    {
        return Data.DB.spGetClub().ToList();
    }
    public IList<spGetClubUserResult> GetClubUser(string User)
    {
        var UserId = new Guid(User);
        var res = Data.DB.spGetClubUser(UserId).ToList();
        return res;
    }
    public IList<spGetFriendResult> GetFriend()
    {
        return Data.DB.spGetFriend().ToList();
    }
    public IQueryable<ProductShare> GetProductShare()
    {
        var res = Data.DB.ProductShares.AsQueryable();
        return res;
    }
    public IQueryable<InfoShare> GetInfoShare()
    {
        var res = Data.DB.InfoShares.AsQueryable();
        return res;
    }
    public IQueryable<Warranty> GetWarranty()
    {
        return Data.DB.Warranties.AsQueryable();
    }
    public IQueryable<Poll> GetPoll()
    {
        return (from a in Data.DB.Polls
                select a);
    }
    public IQueryable<CommentInfo> GetInfoComment(int InfoId, int Cat, bool Act = false)
    {
        return (from a in Data.DB.CommentInfos
                where (a.Show.Equals(Act) || !Act) && a.FID.Equals(InfoId) && a.Type.Equals(Cat)
                orderby a.Id descending
                select a).ToList().AsQueryable();
    }
    public IList<spGetCommentResult> GetComment()
    {
        return Data.DB.spGetComment().ToList();
    }
    public IList<spGetProductCommentResult> GetCommentProduct()
    {
        return Data.DB.spGetProductComment().ToList();
    }
    public IQueryable<Score> GetScore(string UserId = "")
    {
        return from a in Data.DB.Scores
               where a.UserId.Equals(new Guid(UserId)) || UserId.Length.Equals(0)
               select a;
    }
    public bool InsertFriend(string Address, int Type, Guid UserId)
    {
        try
        {
            var item = new Friend
            {
                address = Address,
                Type = Type,
                UserId = UserId,
                Date = DateTime.Now
            };
            Data.DB.Friends.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Data.DB.spInsertScore(1, UserId, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int InsertPoll()
    {
        try
        {
            var poll = new Poll
            {
                
            };
            return 0;
        }
        catch (Exception ex)
        {
            
            throw ex;
        }
    }
    public bool InsertProductShare(int PID, Guid UID)
    {
        try
        {
            var item = new ProductShare
            {
                ProductId = PID,
                UserId = UID,
                Date=DateTime.Now
            };
            Data.DB.ProductShares.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Data.DB.spInsertScore(2, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertInfoShare(int IID, Guid UID, int Cat, int SID = 0)
    {
        try
        {
            var item = new InfoShare
            {
                infoId = IID,
                UserId = UID,
                cat = Cat,
                Date = DateTime.Now
            };
            Data.DB.InfoShares.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            if (SID != 0)
                Data.DB.spInsertScore(SID, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertRate(int PID,Guid UID,int Rate)
    {
        try
        {
            if (Data.DB.Ratings.Count(p => p.UserId.Equals(UID) && p.ProductId.Equals(PID)) > 0) return false;
            var item = new Rating
            {
                Date=DateTime.Now,
                ProductId=PID,
                UserId=UID,
                Rating1=Rate
            };
            Data.DB.Ratings.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Data.DB.spInsertScore(11, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertInfoRate(int IID, Guid UID, int Rate, int Cat, int SID = 0)
    {
        try
        {
            if (Data.DB.InfoRatings.Count(p => p.UserId.Equals(UID) && p.InfoId.Equals(IID) && p.Cat.Equals(Cat)) > 0) return false;
            var item = new InfoRating
            {
                Date = DateTime.Now,
                InfoId = IID,
                UserId = UID,
                Cat = Cat,
                Rating = Rate
            };
            Data.DB.InfoRatings.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            if (SID != 0)
                Data.DB.spInsertScore(SID, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool EditInfoComment(int Cid, string Subject, string Message, string Reply, bool Act)
    {
        try
        {
            var Comment = Data.DB.CommentInfos.FirstOrDefault(p => p.Id.Equals(Cid));
            var Lock = Comment.Lock.GetValueOrDefault(false);
            var SID = 0;
            var UID = Comment.UserId;
            switch (Comment.Type)
            {
                case 1:
                    SID = 11;
                    break;
                case 2:
                    SID = 12;
                    break;
                case 3:
                    SID = 10;
                    break;
                case 4:
                    SID = 22;
                    break;
                case 5:
                    SID = 21;
                    break;
            }
            Comment.Subject = Subject;
            Comment.Reply = Reply;
            Comment.Body = Message;
            Comment.Show = Act;
            Comment.DateR = DateTime.Now;
            Comment.Lock = true;
            Data.DB.SubmitChanges();
            if(!Lock)
                Data.DB.spInsertScore(SID, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditProductComment(int PId, string Subject, string Message, string Reply, bool Act)
    {
        try
        {
            var Comment = Data.DB.CommentProducts.FirstOrDefault(p => p.Id.Equals(PId));
            var Lock = Comment.Lock.GetValueOrDefault(false);
            var SID = 9;
            var UID = Comment.UserId;
            Comment.Subject = Subject;
            Comment.Reply = Reply;
            Comment.Body = Message;
            Comment.Show = Act;
            Comment.DateR = DateTime.Now;
            Comment.Lock = true;
            Data.DB.SubmitChanges();
            if (!Lock)
                Data.DB.spInsertScore(SID, UID, 1);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteComment(int Id)
    {
        try
        {
            var Item = Data.DB.CommentInfos.FirstOrDefault(p => p.Id.Equals(Id));
            Data.DB.CommentInfos.DeleteOnSubmit(Item);
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeleteProductComment(int Id)
    {
        try
        {
            var Item = Data.DB.CommentProducts.FirstOrDefault(p => p.Id.Equals(Id));
            Data.DB.CommentProducts.DeleteOnSubmit(Item);
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public IList<spGetRatioResult> GetRatio()
    {
        return Data.DB.spGetRatio().ToList();
    }
    public bool EditRatio(int Id, float Value,long? Price)
    {
        try
        {
            var item = Data.DB.ScoreRoles.FirstOrDefault(p => p.Id.Equals(Id));
            item.Value = Value;
            if (Price.HasValue)
                item.Price = Price;
            Data.DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
}