﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Web.Security;
using System.Web.Profile;
using System.Data.Linq;
using System.Text;
using AjaxControlToolkit;

/// <summary>
/// This Class for Insert ,Edit ,Delete and Report Hooraa Database.
/// </summary>
public class Data
{
    public Data()
    {

    }
    public db_atrDataContext DB = new db_atrDataContext();

    public string FFrame
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            return item.Frame1;
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            item.Frame1 = value;
            DB.SubmitChanges();
        }
    }
    public string FText
    {
        get
        {
            var item = DB.FooterTexts.FirstOrDefault(p => p.Id.Equals(1));
            return item.Text;
        }
        set
        {
            var item = DB.FooterTexts.FirstOrDefault(p => p.Id.Equals(1));
            item.Text = value;
            DB.SubmitChanges();
        }
    }
    public bool FShow
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            return item.Show.GetValueOrDefault(false);
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(1));
            item.Show = value;
            DB.SubmitChanges();
        }
    }
    public string UClub
    {
        get
        {
            var item = DB.TbClubs.FirstOrDefault(p => p.Id.Equals(1));
            return item.Body;
        }
        set
        {
            var item = DB.TbClubs.FirstOrDefault(p => p.Id.Equals(1));
            item.Body = value;
            DB.SubmitChanges();
        }
    }
    public IList<spGetFrameResult> GetFrame(bool Top)
    {
        return DB.spGetFrame(Top).ToList();
    }
    public string LFrame
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            return item.Frame1;
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            item.Frame1 = value;
            DB.SubmitChanges();
        }
    }
    public bool LShow
    {
        get
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            return item.Show.GetValueOrDefault(false);
        }
        set
        {
            var item = DB.Frames.FirstOrDefault(p => p.Id.Equals(2));
            item.Show = value;
            DB.SubmitChanges();
        }
    }
    public string Agreement
    {
        get
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(1));
            return item.Agreement1;
        }
        set
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(1));
            item.Agreement1 = value;
            DB.SubmitChanges();
        }
    }
    public string OrderAgreement
    {
        get
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(2));
            return item.Agreement1;
        }
        set
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(2));
            item.Agreement1 = value;
            DB.SubmitChanges();
        }
    }
    public string Factor
    {
        get
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(3));
            return item.Agreement1;
        }
        set
        {
            var item = DB.Agreements.FirstOrDefault(p => p.Id.Equals(3));
            item.Agreement1 = value;
            DB.SubmitChanges();
        }
    }
    public string Contact
    {
        get
        {
            var item = DB.Addresses.FirstOrDefault(p => p.Id.Equals(2));
            return item.Address1;
        }
        set
        {
            var item = DB.Addresses.FirstOrDefault(p => p.Id.Equals(2));
            item.Address1 = value;
            DB.SubmitChanges();
        }
    }

    public string Benefit
    {
        get
        {
            var item = DB.Benefits.FirstOrDefault(p => p.Id.Equals(1));
            return item.Benefit1;
        }
        set
        {
            var item = DB.Benefits.FirstOrDefault(p => p.Id.Equals(1));
            item.Benefit1 = value;
            DB.SubmitChanges();
        }
    }
    public string Help
    {
        get
        {
            var item = DB.Helps.FirstOrDefault(p => p.Id.Equals(1));
            return item.Help1;
        }
        set
        {
            var item = DB.Helps.FirstOrDefault(p => p.Id.Equals(1));
            item.Help1 = value;
            DB.SubmitChanges();
        }
    }
    public string FAQ
    {
        get
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(1));
            return item.FAQ1;
        }
        set
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(1));
            item.FAQ1 = value;
            DB.SubmitChanges();
        }
    }
    public string FAQWiki
    {
        get
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(2));
            return item.FAQ1;
        }
        set
        {
            var item = DB.FAQs.FirstOrDefault(p => p.Id.Equals(2));
            item.FAQ1 = value;
            DB.SubmitChanges();
        }
    }
    public string Footer
    {
        get
        {
            var item = DB.FooterLefts.FirstOrDefault(p => p.Id.Equals(1));
            return item.Body;
        }
        set
        {
            var item = DB.FooterLefts.FirstOrDefault(p => p.Id.Equals(1));
            item.Body = value;
            DB.SubmitChanges();
        }
    }

    public DataTable CFile()
    {
        var res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spCreateUnUsedImage", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(res);
        return res;
    }
    public DataTable GetUnused(DataTable File)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetUnUsedImage", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@File", File);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UDTAttr()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetAttrTable", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UDTColor()
    {
        var Res = new DataTable();
        SqlConnection myConnection = new SqlConnection(DB.Connection.ConnectionString);
        var myCommand = new SqlCommand("spGetColorTable", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UDTColor(int PID)
    {

        var Res = new DataTable();
        SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetProductColor", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Parameters.AddWithValue("@PID", PID);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UDTSize()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetSizeTable", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UDTSize(int PID)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetProductSize", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        myCommand.Parameters.AddWithValue("@PID", PID);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }

    public DataTable UserData(string ApplicationName)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetUserData", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@ApplicationName", ApplicationName);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UserDataNews(string ApplicationName)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetUserDataNews", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@ApplicationName", ApplicationName);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable UserExcell(string ApplicationName)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetExcellUser", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@ApplicationName", ApplicationName);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable OrderExcell()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetExcellOrder", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();

        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable WarrantyExcell()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spGetExcellWarranty", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();

        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable ColorAction(int PID, DataTable Color)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spColorAction", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@PID", PID);
        myCommand.Parameters.AddWithValue("@PColor", Color);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable SizeAction(int PID, DataTable Size)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spSizeAction", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Parameters.AddWithValue("@PID", PID);
        myCommand.Parameters.AddWithValue("@PSize", Size);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IList<spGetUserDataAdminResult> UserDataAdmin(string ApplicationName)
    {
        return DB.spGetUserDataAdmin(ApplicationName).ToList();
    }
    public IQueryable<AdminPageAccess> Access()
    {
        var ac = from p in DB.AdminPageAccesses
                 orderby p.PersianPagename
                 select p;
        return ac;
    }
    public IList<spUserAccessResult> AccessPageRole(Guid UserId, string RoleName, bool? Enable)
    {
        return DB.spUserAccess(RoleName, UserId).Where(p => Enable.HasValue == false || p.RoleEn.GetValueOrDefault(false).Equals(Enable.Value)).ToList();
    }
    public DataTable State()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from State order by State asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<State> StateQ()
    {
        return DB.States.ToList().AsQueryable();
    }
    public string StateName(int Id)
    {
        try
        {
            return DB.States.FirstOrDefault(p => p.ID.Equals(Id)).State1;
        }
        catch
        {
            return "خطا";
        }
    }
    public DataTable City(int StateId)
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from City Where SID = " + StateId + " order by City asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<City> CityQ(int StateId)
    {
        return DB.Cities.Where(p => p.SID.GetValueOrDefault(0).Equals(StateId)).ToList().AsQueryable().OrderBy(p => p.City1);
    }
    public string CityName(int Id)
    {

        try
        {
            return DB.Cities.FirstOrDefault(p => p.ID.Equals(Id)).City1;
        }
        catch
        {
            return "خطا";
        }
    }
    public DataTable Meet()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Meet order by Meet asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<Meet> MeetQ()
    {
        return DB.Meets.OrderBy(p => p.Meet1).ToList().AsQueryable();
    }
    public DataTable Education()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Education order by ID asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public DataTable Active()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from Active order by Active asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public IQueryable<Active> ActiveQ()
    {
        return DB.Actives.OrderBy(p => p.Active1).ToList().AsQueryable();
    }
    public IQueryable<spGetExcellUserResult> GetUserSel()
    {
        return DB.spGetExcellUser("/").AsQueryable();
    }
    public int GetMaxMail()
    {
        return int.Parse(DB.EmailConfigs.FirstOrDefault(p => p.Id.Equals(2)).MaxMail.ToString());
    }
    public bool AllowPage(string UserName, string PageName)
    {
        try
        {
            if (UserName.ToLower().Equals("admin") || PageName.ToLower().Equals("profile")) return true;
            if (Roles.GetRolesForUser(UserName).Count() == 0)
            {
                return false;
            }
            var UserId = new Guid(Membership.GetUser(UserName).ProviderUserKey.ToString());
            var ro = Roles.GetRolesForUser(UserName)[0];
            if (ro.Equals("Legal") || ro.Equals("Real")) return false;

            var al = DB.spUserAccess(ro, UserId).FirstOrDefault(p => p.PagesName.Equals(PageName));
            if (al.RoleEn.GetValueOrDefault(false) == al.PageEn.GetValueOrDefault(false))
                return false;
            else
                return true;
        }
        catch
        {
            return false;
        }
    }
    public bool CreateRole(string RoleName, string persianRoleName)
    {
        try
        {
            if (!Roles.RoleExists(RoleName))
            {
                Roles.CreateRole(RoleName);
                try
                {
                    DB.spCreateRole(RoleName, persianRoleName);
                }
                catch (Exception ex)
                {
                    Roles.DeleteRole(RoleName);
                    throw ex;
                }
                return true;
            }
            return false;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool CreateRoleData(Guid RoleId, int PageId)
    {
        try
        {
            var RD = DB.spInsertRoleData(RoleId, PageId);
            if (RD == 1)
                return true;
            else
                return false;
        }
        catch
        {
            return false;
        }
    }
    public bool InsertInfoMenu(string Name, int CType, string Body, string Image)
    {
        try
        {
            if (DB.Abouts.Count(p => p.Type.Equals(CType) && p.Name.Equals(Name)) > 0) return false;
            var menu = new About
            {
                Name = Name,
                Type = CType,
                Body = Body,
                Image = Image
            };
            DB.Abouts.InsertOnSubmit(menu);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertCatLink(int CatId, string Name, string Link)
    {
        try
        {
            if (DB.catLinks.Count(p => p.categoryId.Equals(CatId)) > 0) return false;
            var menu = new catLink
            {
                Name = Name,
                categoryId = CatId,
                link = Link,
            };
            DB.catLinks.InsertOnSubmit(menu);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertMenu(string Name, string Image, string CType)
    {
        try
        {
            if (DB.Cats.Count(p => p.Type.Equals(CType) && p.Name.Equals(Name)) > 0)
            {
                return false;
            }
            var menu = new Cat
            {
                Name = Name,
                Image = Image,
                Type = CType
            };
            DB.Cats.InsertOnSubmit(menu);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertPartMenu(string Name)
    {
        try
        {
            if (DB.CatParts.Count(p => p.Part.Equals(Name)) > 0)
            {
                return false;
            }
            var part = new CatPart
            {
                Part = Name
            };
            DB.CatParts.InsertOnSubmit(part);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int InsertMenuProduct(string Name, string Image, int Level, int? Parent, int? Brand)
    {
        try
        {
            //if (DB.CatProducts.Count(p => p.Name.Equals(Name) && p.BrId.GetValueOrDefault(0).Equals(Brand.GetValueOrDefault(0))  && p.Parent.GetValueOrDefault(0) == Parent.GetValueOrDefault(0)) > 0) return -1;
            var menu = new CatProduct
            {
                Name = Name,
                Image = Image,
                Level = Level,
                Parent = Parent,
                BrId = Brand,
            };
            DB.CatProducts.InsertOnSubmit(menu);
            DB.SubmitChanges();
            return menu.Id;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public int InsertCatComment(int catId, string comment, string Image)
    {
        try
        {
            //if (DB.CatProducts.Count(p => p.Name.Equals(Name) && p.BrId.GetValueOrDefault(0).Equals(Brand.GetValueOrDefault(0))  && p.Parent.GetValueOrDefault(0) == Parent.GetValueOrDefault(0)) > 0) return -1;
            var menu = new catComment
            {
                catId = catId,
                comment = comment,
                image = Image,
            };
            DB.catComments.InsertOnSubmit(menu);
            DB.SubmitChanges();
            return menu.id;
        }
        catch (Exception Ex)
        {
            throw Ex;
        }
    }

    public bool InsertBrandCat(int CID, int BID)
    {
        try
        {
            if (DB.CatBrands.Any(p => p.BrandId.Equals(BID) && p.CatId.Equals(CID))) return false;
            var item = new CatBrand
            {
                BrandId = BID,
                CatId = CID
            };
            DB.CatBrands.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertMenuPrint(string Name, int Level, int? Parent)
    {
        try
        {
            if (DB.CatPrints.Count(p => p.Name.Equals(Name) && p.Parent.GetValueOrDefault(0) == Parent.GetValueOrDefault(0)) > 0) return false;
            var item = new CatPrint
            {
                Name = Name,
                Level = Level,
                Parent = Parent
            };
            DB.CatPrints.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertInfo(string Name, int Cat, string Body, string Image)
    {
        try
        {
            if (DB.Infos.Count(p => p.Name.Equals(Name)) > 0) return false;
            var item = new Info
            {
                Cat = Cat,
                Name = Name,
                Body = Body,
                Image = Image
            };
            DB.Infos.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertInfo(string Name, int Cat, string Image, string Body, string URL)
    {
        try
        {
            if (DB.Abouts.Count(p => p.Name.Equals(Name)) > 0) return false;
            var item = new Info
            {
                Cat = Cat,
                Name = Name,
                Body = Body,
                URL = URL,
                Image = Image
            };
            DB.Infos.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertWNews(string Name, string Brief, int cat, string Body, string Image)
    {
        try
        {
            if (DB.WNews.Count(p => p.Title.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new WNew
            {
                Title = Name,
                Brief = Brief,
                Cat = cat,
                Image = Image,
                Body = Body,
                Date = DateTime.Now
            };
            DB.WNews.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool InsertWArticle(string Name, string Brief, int cat, string Body, string Image, string BImage)
    {
        try
        {
            if (DB.Articles.Count(p => p.Title.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new Article
            {
                Title = Name,
                Brief = Brief,
                Cat = cat,
                Image = Image,
                BImage = BImage,
                Body = Body,
                Date = DateTime.Now
            };
            DB.Articles.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertCertificate(string Name, string Image, string Body, string keyword, string Brief)
    {
        try
        {
            if (DB.Certificates.Count(p => p.Name.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new Certificate
            {
                Name = Name,
                Image = Image,
                Description = Body,
                Keyword = keyword,
                Brief = Brief


            };
            DB.Certificates.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertService(int Cat, string Name, string Image, string Body)
    {
        try
        {
            if (DB.Services.Count(p => p.Name.Equals(Name)) > 0) return false;
            var item = new Service
            {
                Cat = Cat,
                Name = Name,
                Body = Body,
                Image = Image
            };
            DB.Services.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertService(string Name, int Cat, string Image, string Body, string URL)
    {
        try
        {
            if (DB.Services.Count(p => p.Name.Equals(Name)) > 0) return false;
            var item = new Service
            {
                Cat = Cat,
                Name = Name,
                Body = Body,
                URL = URL,
                Image = Image
            };
            DB.Services.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertGallery(string Image, string Name)
    {
        try
        {
            var item = new Gallery
            {
                Image = Image,
                Name = Name
            };
            DB.Galleries.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public int InsertPart(int Id, string Mail, string Tel, string User, bool? Pan)
    {
        try
        {
            if (DB.Parts.Count(p => p.Mail.Equals(Mail) && p.Cat.Equals(Id)) > 0) return 1;
            if (Tel.Length > 0 && DB.Parts.Count(p => p.Tel.Equals(Tel) && p.Cat.Equals(Id)) > 0) return 2;
            if (DB.Parts.Count(p => p.User.Equals(User) && p.Cat.Equals(Id)) > 0 && User.Length > 0) return 3;
            var item = new Part
            {
                Cat = Id,
                Mail = Mail,
                Tel = Tel,
                User = User,
                InPanel = Pan
            };
            DB.Parts.InsertOnSubmit(item);
            DB.SubmitChanges();
            return 4;
        }
        catch
        {
            return 0;
        }
    }
    public int InsertUnit(string Mail, string Tel, int Type, string User, bool? Pan)
    {
        try
        {
            if (DB.UnitMessages.Count(p => p.Mail.Equals(Mail) && p.Type.Equals(Type)) > 0 && Mail.Length > 0) return 1;
            if (DB.UnitMessages.Count(p => p.Tel.Equals(Tel) && p.Type.Equals(Type)) > 0 && Tel.Length > 0) return 2;
            if (DB.UnitMessages.Count(p => p.User.Equals(User) && p.Type.Equals(Type)) > 0 && User.Length > 0) return 3;
            var Unit = new UnitMessage
            {
                Mail = Mail,
                Tel = Tel,
                Type = Type,
                User = User,
                InPanel = Pan
            };
            DB.UnitMessages.InsertOnSubmit(Unit);
            DB.SubmitChanges();
            return 4;
        }
        catch
        {
            return 0;
        }
    }

    public bool InsertPost(string title, string breif, int price, int priceFree, string image, Boolean active)
    {
        try
        {
            var item = new Post
            {
                Title = title,
                Breif = breif,
                Image = image,
                Active = active,
                userId = (Guid)Membership.GetUser().ProviderUserKey,
                Price = price,
                priceFree = priceFree
            };
            DB.Posts.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public int InsertProduct(string Name, int Cat, int? DisPrice, string Body, string Brief, string Keyword,
        string Description, string Image, DateTime? DateDis, bool Spec, bool View, int? MinAge, int? MaxAge, int? BID,
        bool IsAvalible, bool IsVisit, DataTable Attr)
    {
        int Res;
        //try
        //{
        //    if (DB.Products.Any(p => p.Name.Equals(Name) && p.Cat.Equals(Cat) && p.BID.Equals(BID)))
        //    {
        //        Res = 1;
        //    }
        //    var NewProd = new Product
        //    {
        //        Name = Name,
        //        BID = BID,
        //        Body = Body,
        //        Brief = Brief,
        //        Cat = Cat,
        //        DisPrice = DisPrice,
        //        Keyword = Keyword,
        //        Description = Description,
        //        Image = Image,
        //        DateDis = DateDis,
        //        Date = DateTime.Now,
        //        Spec = Spec,
        //        View = View,
        //        MinAge = MinAge,
        //        MaxAge = MaxAge,
        //        IsAvalible = IsAvalible,
        //        IsVisit = IsVisit

        //    };
        //    DB.Products.InsertOnSubmit(NewProd);
        //    DB.SubmitChanges();
        //    Res = 0;
        //}
        //catch
        //{
        //    Res = 1;
        //}
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spInsertProduct", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        myCommand.Parameters.AddWithValue("@Name", Name);
        myCommand.Parameters.AddWithValue("@Cat", Cat);
        myCommand.Parameters.AddWithValue("@DisPrice", ToDBNull(DisPrice));
        myCommand.Parameters.AddWithValue("@Body", Body);
        myCommand.Parameters.AddWithValue("@Brief", Brief);
        myCommand.Parameters.AddWithValue("@Keyword", Keyword);
        myCommand.Parameters.AddWithValue("@Description", Description);
        myCommand.Parameters.AddWithValue("@Image", Image);
        myCommand.Parameters.AddWithValue("@DateDis", ToDBNull(DateDis));
        myCommand.Parameters.AddWithValue("@Spec", Spec);
        myCommand.Parameters.AddWithValue("@View", View);
        myCommand.Parameters.AddWithValue("@MinAge", ToDBNull(MinAge));
        myCommand.Parameters.AddWithValue("@MaxAge", ToDBNull(MaxAge));
        myCommand.Parameters.AddWithValue("@BID", BID);
        myCommand.Parameters.AddWithValue("@IsAvalible", IsAvalible);
        myCommand.Parameters.AddWithValue("@IsVisit", IsVisit);
        myCommand.Parameters.AddWithValue("@Attr", Attr);


        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Connection.Open();
        Res = Convert.ToInt32(myCommand.ExecuteScalar().ToString());
        myCommand.Connection.Close();
        return Res;
    }

    public int InsertProduct(string Name, string Keyword, string Description, string Image, string Brief, string Body,
        DateTime? DateDis, int Cat, bool Spec,
        bool View, int? minAge, int? maxAge, int BID, bool avalible, bool VisitState)
    {
        try
        {
            if (DB.Products.Any(p => p.Name.Equals(Name) && p.Cat.Equals(Cat) && p.BID.Equals(BID)))
            {
                return 0;
            }
            var item = new Product
            {
                Name = Name,
                Keyword = Keyword,
                Description = Description,
                Image = Image,
                Brief = Brief,
                Date = DateTime.Now,
                DateDis = DateDis,
                Body = Body,
                Cat = Cat,
                Spec = Spec,
                View = View,
                MinAge = minAge,
                MaxAge = maxAge,
                BID = BID,
                IsAvalible = avalible,
                IsVisit = VisitState
            };
            DB.Products.InsertOnSubmit(item);
            DB.SubmitChanges();
            return item.Id;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public int InsertAttribute(string Attribute, int? Cat)
    {
        try
        {
            if (DB.Attrs.Any(p => p.Cat.Equals(Cat) && p.Text.Equals(Attribute))) return 0;

            var item = new Attr
            {
                Cat = Cat,
                Text = Attribute
            };
            DB.Attrs.InsertOnSubmit(item);
            DB.SubmitChanges();
            return item.Id;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool InsertAttrValue(int AID, string Value)
    {
        try
        {
            if (DB.AttrValues.Any(p => p.AID.Equals(AID) && p.Value.Equals(Value))) return false;
            var item = new AttrValue
            {
                AID = AID,
                Value = Value
            };
            DB.AttrValues.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;

        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool InsertPrint(string Model, int Cat)
    {
        try
        {
            if (DB.Prints.Count(p => p.Model == Model) > 0)
            {
                return false;
            }
            var item = new Print
            {
                Model = Model,
                Cat = Cat
            };
            DB.Prints.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool InsertProductAttr(int PID, int AID, int VID)
    {
        try
        {

            if (DB.ProductAttrs.Any(p => p.AID.Equals(AID) && p.PID.Equals(PID) && p.VID.Equals(VID))) return false;
            var nItem = new ProductAttr
            {
                PID = PID,
                AID = AID,
                VID = VID
            };
            DB.ProductAttrs.InsertOnSubmit(nItem);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }

    }
    public bool InsertPrintDep(int PrintID, int ProductId)
    {
        try
        {
            if (DB.DepPrints.Count(p => p.PrintId.Equals(PrintID) && p.ProductId.Equals(ProductId)) > 0)
            {
                return false;
            }
            var item = new DepPrint
            {
                PrintId = PrintID,
                ProductId = ProductId
            };
            DB.DepPrints.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //public bool InsertProductColor(int PID, string Name, string Image, string PImage)
    //{
    //    try
    //    {
    //        if (DB.PColors.Any(p => p.PID.Equals(PID) && p.Name.Equals(Name))) return false;
    //        var item = new PColor
    //        {
    //            PID = PID,
    //            Image = Image,
    //            PImage = PImage
    //        };
    //        DB.PColors.InsertOnSubmit(item);
    //        DB.SubmitChanges();
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {   
    //        throw ex;
    //    }
    //}

    public bool InsertCert(string Name, string Image, string Description, string KeyWord)
    {
        try
        {
            if (DB.Certificates.Count(p => p.Name.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new Certificate
            {
                Name = Name,
                Image = Image,
                Visit = 0,
                Description = Description,
                Keyword = KeyWord
            };
            DB.Certificates.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertWarranty(Guid UserId, string code, DateTime? startDate, DateTime? expiryDate, string subject, bool active = true)
    {
        try
        {
            var codear = code.Split(char.ConvertFromUtf32(300).ToArray());
            if (DB.Warranties.Any(p => p.code3.Equals(codear[2]))) return false;
            DB.sp_Insert_Warranty(UserId, codear[0], codear[1], codear[2], subject, startDate ?? DateTime.Now, expiryDate ?? DateTime.Now, active);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int RegisterWarranty(Guid UId, Guid WId)
    {
        try
        {

            if (DB.WarrantyRegisters.Count(p => p.Warranty.Equals(WId)) > 0) return 0;
            if (DB.Warranties.Count(p => p.WarrantyId.Equals(WId) && p.active.Equals(false)) > 0) return 1;
            if (DB.Warranties.Count(p => p.WarrantyId.Equals(WId) && (p.startDate.GetValueOrDefault(DateTime.Now) > DateTime.Now || p.expiryDate.GetValueOrDefault(DateTime.Now) < DateTime.Now)) > 0) return 2;
            var war = new WarrantyRegister
            {
                active = false,
                date = DateTime.Now,
                User = UId,
                Warranty = WId
            };
            DB.WarrantyRegisters.InsertOnSubmit(war);
            DB.SubmitChanges();
            return 3;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertFailture(Guid UserId, Guid WarrantyId, string Description)
    {
        try
        {
            if (DB.Failures.Count(p => p.User.Equals(UserId) && p.Warranty.Equals(WarrantyId)) > 0) return false;
            var item = new Failure
            {
                User = UserId,
                Warranty = WarrantyId,
                Description = Description,
                CreateDate = DateTime.Now
            };
            DB.Failures.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool InsertGift(string Image, bool Active)
    {
        try
        {
            var item = new Gift
            {
                Image = Image,
                Active = Active,
                Date = DateTime.Now
            };
            DB.Gifts.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool InsertNews(string Name, string Brief, string Image, string Body)
    {
        try
        {
            if (DB.News.Count(p => p.Title.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new New
            {
                Title = Name,
                Brief = Brief,
                Image = Image,
                Body = Body,
                Date = DateTime.Now
            };
            DB.News.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertArticle(string Name, int Cat, string Brief, string Image, string Body)
    {
        try
        {
            if (DB.Articles.Count(p => p.Title.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new Article
            {
                Title = Name,
                Cat = Cat,
                Brief = Brief,
                Image = Image,
                Body = Body
            };
            DB.Articles.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertDownload(string Name, string Brief, string Image, string Body, string Des, string Key)
    {
        try
        {
            if (DB.Downloads.Count(p => p.Title.Equals(Name)) > 0)
            {
                return false;
            }
            var item = new Download
            {
                Title = Name,
                Brief = Brief,
                Image = Image,
                Body = Body,
                Description = Des,
                Keyword = Key
            };
            DB.Downloads.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool CreatePage(string Title, string Keyword, string Des, string Body)
    {
        try
        {
            if (DB.Pages.Count(p => p.Title.Equals(Title)) > 0)
            {
                return false;
            }
            var page = new Page
            {
                Title = Title,
                Keywords = Keyword,
                Description = Des,
                Body = Body
            };
            DB.Pages.InsertOnSubmit(page);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertContact(int Cat, string Mail, string Name, string Subject, string Message)
    {
        try
        {
            var contact = new Contact
            {
                Cat = Cat,
                Mail = Mail,
                Name = Name,
                Subject = Subject,
                Message = Message,
                Date = DateTime.Now,
                Read = false
            };
            DB.Contacts.InsertOnSubmit(contact);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertSlide(string Image, string Link)
    {
        try
        {
            var item = new SlideShow
            {
                Image = Image,
                Link = Link
            };
            DB.SlideShows.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public bool InsertTopBaner(string Name, string Text, string Image, string Link, string Color)
    {
        try
        {
            var item = new TopBaner
            {
                Name = Name,
                Text = Text,
                Image = Image,
                Link = Link,
                Color = Color
            };
            DB.TopBaners.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool InsertBrand(string Name, string Image)
    {
        try
        {
            if (DB.Brands.Any(p => p.Name.Equals(Name))) return false;
            var item = new Brand
            {
                Name = Name,
                Image = Image
            };
            DB.Brands.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertBrand(string Name, string Image, string Link)
    {
        try
        {
            if (DB.Brands.Any(p => p.Name.Equals(Name) && p.Link.Equals(Link))) return false;
            var item = new Brand
            {
                Name = Name,
                Image = Image,
                Link = Link
            };
            DB.Brands.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertBaner(int Pos, string Image, string Link)
    {
        try
        {
            var item = new Baner
            {
                Pos = Pos,
                Image = Image,
                Link = Link
            };
            DB.Baners.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public bool InsertLink(string Name, string Link)
    {
        try
        {
            var item = new Link
            {
                Name = Name,
                Link1 = Link
            };
            DB.Links.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertEvent(string Name, string Link)
    {
        try
        {
            var item = new Event
            {
                Name = Name,
                Link = Link,
                Date = DateTime.Now
            };
            DB.Events.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool InsertAgent(string Name, int StateId, int CityId, string Manager, string Tel, string Address, string Email, string Site)
    {
        try
        {

            if (DB.Agents.Count(p => p.Name.Equals(Name)) > 0) return false;
            var item = new Agent
            {
                Name = Name,
                SID = StateId,
                CID = CityId,
                ManName = Manager,
                Tel = Tel,
                Address = Address,
                Email = Email,
                Site = Site
            };
            DB.Agents.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditMenuProduct(int Id, string Name, string Image, int? Parent, int? Brand)
    {
        try
        {
            var menu = DB.CatProducts.FirstOrDefault(p => p.Id == Id);
            menu.Name = Name;
            menu.Image = Image;
            menu.Parent = Parent;
            menu.BrId = Brand;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditCategoryComment(int catId, string comment, string Image)
    {
        try
        {
            var Catcomment = DB.catComments.FirstOrDefault(p => p.catId == catId);
            Catcomment.comment = comment;
            Catcomment.image = Image;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditMenuPrint(int Id, string Name, int? Parent)
    {
        try
        {
            if (
                DB.CatPrints.Any(
                    p => p.Name.Equals(Name) && p.Parent.GetValueOrDefault(0).Equals(Parent.GetValueOrDefault(0))))
                return false;
            var menu = DB.CatPrints.FirstOrDefault(p => p.Id == Id);
            menu.Name = Name;
            menu.Parent = Parent;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditInfoMenu(int Id, string Name, string Body, string Image)
    {
        try
        {
            var menu = DB.Abouts.FirstOrDefault(p => p.Id.Equals(Id));
            menu.Name = Name;
            menu.Body = Body;
            menu.Image = Image;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditMenu(int Id, string Name, string Image)
    {
        try
        {
            var menu = DB.Cats.FirstOrDefault(p => p.Id.Equals(Id));
            menu.Name = Name;
            menu.Image = Image;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditInfo(int Id, int Cat, string Name, string Body, string Image, string URL = "")
    {
        try
        {
            var item = DB.Infos.FirstOrDefault(p => p.Id.Equals(Id));
            item.Cat = Cat;
            item.Name = Name;
            item.Body = Body;
            item.Image = Image;
            item.URL = URL;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditWNews(int Id, string Name, string Brief, string Image, string Body, int cat)
    {
        try
        {

            var item = DB.WNews.FirstOrDefault(p => p.Id.Equals(Id));

            item.Title = Name;
            item.Brief = Brief;
            item.Image = Image;
            item.Body = Body;
            item.Cat = cat;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool EditWArticle(int Id, string Name, string Brief, string Image, string Bimage, string Body, int cat)
    {
        try
        {

            var item = DB.Articles.FirstOrDefault(p => p.Id.Equals(Id));

            item.Title = Name;
            item.Brief = Brief;
            item.Image = Image;
            item.BImage = Bimage;
            item.Body = Body;
            item.Cat = cat;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditCertificate(int Id, string Name, string Brief, string Image, string Body, string keyword)
    {
        try
        {

            var item = DB.Certificates.FirstOrDefault(p => p.id.Equals(Id));

            item.Name = Name;
            item.Brief = Brief;
            item.Image = Image;
            item.Description = Body;
            item.Keyword = keyword;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool EditService(int Id, int Cat, string Name, string Image, string Body, string URL = "")
    {
        try
        {
            var item = DB.Services.FirstOrDefault(p => p.Id.Equals(Id));
            item.Cat = Cat;
            item.Name = Name;
            item.Body = Body;
            item.Image = Image;
            item.URL = URL;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditGallery(int Id, string Image, string Name)
    {
        try
        {
            var item = DB.Galleries.FirstOrDefault(p => p.Id.Equals(Id));
            item.Image = Image;
            item.Name = Name;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditPost(int id, string title, string breif, int price, int priceFree, string image, Boolean active)
    {
        try
        {
            var item = GetPosts().FirstOrDefault(p => p.Id == id);
            if (item != null)
            {
                item.Title = title;
                item.Breif = breif;
                item.Image = image;
                item.Active = active;
                item.Price = price;
                item.priceFree = priceFree;
            }
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
    public int EditProduct(int Id, string Name, int Cat, int? DisPrice, string Body, string Brief, string Keyword,
        string Description, string Image, DateTime? DateDis, bool Spec, bool View, int? MinAge, int? MaxAge, int BID,
        bool IsAvalible, bool IsVisit, DataTable Attr)
    {
        int Res;
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("spEditProduct", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.CommandType = CommandType.StoredProcedure;
        SqlParameter parameter = new SqlParameter();
        myCommand.Parameters.AddWithValue("@PID", Id);
        myCommand.Parameters.AddWithValue("@Name", Name);
        myCommand.Parameters.AddWithValue("@Cat", Cat);
        myCommand.Parameters.AddWithValue("@DisPrice", ToDBNull(DisPrice));
        myCommand.Parameters.AddWithValue("@Body", Body);
        myCommand.Parameters.AddWithValue("@Brief", Brief);
        myCommand.Parameters.AddWithValue("@Keyword", Keyword);
        myCommand.Parameters.AddWithValue("@Description", Description);
        myCommand.Parameters.AddWithValue("@Image", Image);
        myCommand.Parameters.AddWithValue("@DateDis", ToDBNull(DateDis));
        myCommand.Parameters.AddWithValue("@Spec", Spec);
        myCommand.Parameters.AddWithValue("@View", View);
        myCommand.Parameters.AddWithValue("@MinAge", ToDBNull(MinAge));
        myCommand.Parameters.AddWithValue("@MaxAge", ToDBNull(MaxAge));
        myCommand.Parameters.AddWithValue("@BID", BID);
        myCommand.Parameters.AddWithValue("@IsAvalible", IsAvalible);
        myCommand.Parameters.AddWithValue("@IsVisit", IsVisit);
        myCommand.Parameters.AddWithValue("@Attr", Attr);


        //The parameter for the SP must be of SqlDbType.Structured
        myCommand.Connection.Open();
        Res = Convert.ToInt32(myCommand.ExecuteScalar().ToString());
        myCommand.Connection.Close();
        return Res;
    }
    public bool EditProduct(int Id, string Name, string Keyword, string Description, string Image, string Brief, string Body, int Cat, bool Spec, DateTime? DateDis, bool View, int? minAge, int? maxAge, int BID, bool VisitedState)
    {
        try
        {
            if (DB.Products.Any(p => p.Id != Id && p.Name.Equals(Name) && p.Cat.Equals(Cat) && p.BID.Equals(BID)))
                return false;
            var item = DB.Products.FirstOrDefault(p => p.Id == Id);
            item.Name = Name;
            item.Keyword = Keyword;
            item.Description = Description;
            item.DateDis = DateDis;
            item.Image = Image;
            item.Brief = Brief;
            item.Body = Body;
            item.Cat = Cat;
            item.Spec = Spec;
            item.MinAge = minAge;
            item.MaxAge = maxAge;
            item.View = View;
            item.BID = BID;
            item.IsVisit = VisitedState;

            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public int EditAttribute(int Id, int? Cat, string Attribute)
    {

        try
        {
            if (DB.Attrs.Any(p => p.Id != Id && p.Text.Equals(Attribute) && p.Cat.Equals(Cat))) return 1;
            var item = DB.Attrs.FirstOrDefault(p => p.Id.Equals(Id));


            if (DB.ProductAttrs.Any(p => p.AID.Equals(Id) && item.Cat != Cat))
            {
                item.Text = Attribute;
                DB.SubmitChanges();
                return 2;
            }
            else
            {
                item.Cat = Cat;
                item.Text = Attribute;
                DB.SubmitChanges();
                return 0;
            }



        }
        catch
        {
            return 3;
        }
    }

    public bool EditAttrValue(int Id, string Value)
    {
        try
        {
            if (!DB.AttrValues.Any(p => p.Id.Equals(Id)))
            {
                return false;
            }
            var item = DB.AttrValues.FirstOrDefault(p => p.Id.Equals(Id));
            item.Value = Value;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }

    public bool EditPrint(int Id, string Model, int Cat)
    {
        try
        {
            if (DB.Prints.Count(p => p.Model.Equals(Model) && p.Cat.Equals(Cat) && p.Id != Id) > 0)
            {
                return false;
            }
            var item = DB.Prints.FirstOrDefault(p => p.Id == Id);
            item.Model = Model;
            item.Cat = Cat;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //public bool EditProductColor(int Id, int PID,string Name, string Image, string PImage)
    //{
    //    try
    //    {
    //        if (DB.PColors.Any(p => p.PID.Equals(PID) && p.Name.Equals(Name) && p.Id.Equals(Id))) return false;
    //        var item = DB.PColors.ToList().FirstOrDefault(p => p.Id.Equals(Id));
    //        item.Name = Name;
    //        item.Image = Image;
    //        item.PImage = PImage;
    //        DB.SubmitChanges();
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}
    public bool EditCatPart(int Id, string Name)
    {
        try
        {
            var par = DB.CatParts.FirstOrDefault(p => p.Id.Equals(Id));
            par.Part = Name;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool EditPart(int Id, string Mail, string Tel, bool? Pan)
    {
        try
        {
            var par = DB.Parts.FirstOrDefault(p => p.Id.Equals(Id));
            par.Mail = Mail;
            par.Tel = Tel;
            par.InPanel = Pan;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool EditUnit(int Id, string Mail, string Tel, bool? Pan)
    {
        try
        {
            var unit = DB.UnitMessages.FirstOrDefault(p => p.Id.Equals(Id));
            unit.Mail = Mail;
            unit.Tel = Tel;
            unit.InPanel = Pan;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool EditWarranty(Guid UserId, string id, string code, DateTime? startDate, DateTime? expiryDate, string subject, bool active)
    {
        try
        {
            if (!id.Equals(code) && DB.Warranties.Any(p => p.code3.Equals(id)))
            {
                DeleteWarranty(id);
                InsertWarranty(UserId, code, startDate ?? DateTime.Now, expiryDate ?? DateTime.Now, subject, active);
                return true;
            }
            var item = GetWarranty().FirstOrDefault(p => p.code3.Equals(code));
            if (item != null)
            {
                item.subject = subject;
                item.startDate = startDate ?? DateTime.Now;
                item.expiryDate = expiryDate ?? DateTime.Now;
                item.date = DateTime.Now;
                item.active = active;
            }
            else
            {
                return false;
            }
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
    public bool EditSlide(int Id, string Image, string Link)
    {
        try
        {
            var item = DB.SlideShows.FirstOrDefault(p => p.Id.Equals(Id));
            item.Image = Image;
            item.Link = Link;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditAgent(int Id, string Name, int StateId, int CityId, string Manager, string Tel, string Address, string Email, string Site)
    {
        try
        {
            var Item = DB.Agents.FirstOrDefault(p => p.Id.Equals(Id));
            Item.Name = Name;
            Item.SID = StateId;
            Item.CID = CityId;
            Item.ManName = Manager;
            Item.Tel = Tel;
            Item.Address = Address;
            Item.Email = Email;
            Item.Site = Site;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditTopBaner(int Id, string Name, string Text, string Image, string Link, string Color)
    {
        try
        {
            var item = DB.TopBaners.FirstOrDefault(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Text = Text;
            item.Image = Image;
            item.Link = Link;
            item.Color = Color;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool EditBrand(int Id, string Name, string Image)
    {
        try
        {
            //if (DB.Brands.Any(p => p.Id != Id && p.Name.Equals(Name))) return false;
            var item = DB.Brands.First(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Image = Image;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {

            throw ex;
        }
    }
    public bool EditBrand(int Id, string Name, string Image, string Link)
    {
        try
        {
            if (DB.Brands.Any(p => p.Id != Id && p.Name.Equals(Name) && p.Link.Equals(Link))) return false;
            var item = DB.Brands.First(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Image = Image;
            item.Link = Link;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditBaner(int Id, int Pos, string Image, string Link)
    {
        try
        {
            var item = DB.Baners.FirstOrDefault(p => p.Id.Equals(Id));
            item.Pos = Pos;
            item.Image = Image;
            item.Link = Link;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditLink(int Id, string Name, string Link)
    {
        try
        {

            var item = DB.Links.FirstOrDefault(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Link1 = Link;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditEvent(int Id, string Name, string Link)
    {
        try
        {

            var item = DB.Events.FirstOrDefault(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Link = Link;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditNews(int Id, string Name, string Brief, string Image, string Body)
    {
        try
        {

            var item = DB.News.FirstOrDefault(p => p.Id.Equals(Id));

            item.Title = Name;
            item.Brief = Brief;
            item.Image = Image;
            item.Body = Body;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditArticle(int Id, string Name, int Cat, string Brief, string Image, string Body)
    {
        try
        {

            var item = DB.Articles.FirstOrDefault(p => p.Id.Equals(Id));

            item.Title = Name;
            item.Cat = Cat;
            item.Brief = Brief;
            item.Image = Image;
            item.Body = Body;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditDownload(int Id, string Name, string Brief, string Image, string Body, string Des, string Key)
    {
        try
        {
            var item = DB.Downloads.FirstOrDefault(p => p.Id.Equals(Id));

            item.Title = Name;
            item.Brief = Brief;
            item.Image = Image;
            item.Body = Body;
            item.Description = Des;
            item.Keyword = Key;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditMes(int Id, string title, string mes, int cat)
    {
        try
        {
            var item = DB.AddMessages.FirstOrDefault(p => p.Id.Equals(Id));
            item.Title = title;
            item.Text = mes;
            item.CatId = cat;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }
    public bool EditGift(int Id, string Image, bool Active)
    {
        try
        {
            var item = DB.Gifts.FirstOrDefault(p => p.id.Equals(Id));
            item.Image = Image;
            item.Active = Active;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool ReadContact(int Id)
    {
        try
        {
            var item = GetContact(Id).First();
            item.Read = true;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditPage(int Id, string Title, string Keyword, string Des, string Body)
    {
        try
        {
            var item = DB.Pages.FirstOrDefault(p => p.Id.Equals(Id));

            item.Title = Title;
            item.Keywords = Keyword;
            item.Description = Des;
            item.Body = Body;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditDescription(int Id, string Title, string Keyword, string Des)
    {
        try
        {
            var item = DB.Descriptions.FirstOrDefault(p => p.Id.Equals(Id));
            if (item == null)
            {
                var item2 = new Description
                {
                    Title = Title,
                    Keywords = Keyword,
                    Description1 = Des,
                };
                DB.Descriptions.InsertOnSubmit(item2);
                DB.SubmitChanges();
                return true;
            }
            item.Title = Title;
            item.Keywords = Keyword;
            item.Description1 = Des;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditFooterName(int Id, string Name)
    {
        try
        {
            var menu = DB.FooterMenus.FirstOrDefault(p => p.Id.Equals(Id));
            menu.Name = Name;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditFooterLink(int Id, string Name, string Link, bool View)
    {
        try
        {
            var item = DB.FooterLinks.FirstOrDefault(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Link = Link;
            item.Show = View;
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditSocialLink(int Id, string Name, string Link, string Image, bool show)
    {
        try
        {
            var item = DB.FlowLinks.FirstOrDefault(p => p.Id.Equals(Id));
            item.Name = Name;
            item.Link = Link;
            item.Image = Image;
            item.Show = show;
            item.Share = "";
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteRoleData(Guid RoleId, int PageId)
    {
        try
        {
            var RD = DB.RoleDatas.FirstOrDefault(p => p.RoleId.Equals(RoleId) && p.PageId.Equals(PageId));
            DB.RoleDatas.DeleteOnSubmit(RD);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeletePartMenu(int Id)
    {
        try
        {
            var Partm = DB.CatParts.FirstOrDefault(p => p.Id.Equals(Id));
            DB.CatParts.DeleteOnSubmit(Partm);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeleteCatComment(int Catid)
    {
        try
        {
            var Partm = DB.catComments.FirstOrDefault(p => p.catId.Equals(Catid));
            DB.catComments.DeleteOnSubmit(Partm);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public int DeleteProductMenu(int Id, string path, string thumbpath, string thumbpath2)
    {
        try
        {
            if (DB.CatProducts.Count(p => p.Parent.GetValueOrDefault(0).Equals(Id)) > 0 || DB.Products.Count(p => p.Cat.Equals(Id)) > 0) return 0;
            var menu = DB.CatProducts.FirstOrDefault(p => p.Id == Id);
            var catbrand = DB.CatBrands.Where(p => p.CatId.Equals(Id));
            if (catbrand != null)
            {
                DB.CatBrands.DeleteAllOnSubmit(catbrand);
                DB.SubmitChanges();
            }
            if (!FileJob.DeleteFile(System.IO.Path.Combine(path, menu.Image)) &&
                path.Length > 0) return 1;
            if (!FileJob.DeleteFile(System.IO.Path.Combine(thumbpath, menu.Image)) &&
                thumbpath.Length > 0) return 1;
            if (!FileJob.DeleteFile(System.IO.Path.Combine(thumbpath2, menu.Image)) &&
                thumbpath2.Length > 0) return 1;
            DB.CatProducts.DeleteOnSubmit(menu);
            DB.SubmitChanges();
            return 2;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeletePrintMenu(int Id)
    {
        try
        {
            if (DB.Prints.Count(q => q.Cat.Equals(Id)) > 0 || DB.CatPrints.Count(q => q.Parent.GetValueOrDefault(0).Equals(Id)) > 0) return false;
            var menu = DB.CatPrints.FirstOrDefault(p => p.Id == Id);
            DB.CatPrints.DeleteOnSubmit(menu);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int DeleteInfoMenu(int Id, string path)
    {
        try
        {
            if (DB.Infos.Count(q => q.Cat.Equals(Id)) > 0) return 0;
            var menu = DB.Abouts.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + menu.Image)) return 1;
            DB.Abouts.DeleteOnSubmit(menu);
            DB.SubmitChanges();
            return 2;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int DeleteServiceMenu(int Id, string path)
    {
        try
        {
            if (DB.Services.Count(q => q.Cat.Equals(Id)) > 0) return 0;
            var menu = DB.Abouts.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + menu.Image)) return 1;
            DB.Abouts.DeleteOnSubmit(menu);
            DB.SubmitChanges();
            return 2;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteInfo(int Id, string path)
    {
        try
        {
            var item = DB.Infos.FirstOrDefault(p => p.Id.Equals(Id));
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Infos.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int DeleteMenu(int Id, string path)
    {
        try
        {
            if (DB.WNews.Any(q => q.Cat.Equals(Id)) || DB.Articles.Any(p => p.Cat.Equals(Id))) return 0;
            var menu = DB.Cats.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + menu.Image)) return 1;
            DB.Cats.DeleteOnSubmit(menu);
            DB.SubmitChanges();
            return 2;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteWNews(int Id, string path)
    {
        try
        {
            var item = DB.WNews.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.WNews.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeleteWArticle(int Id, string path, string path2)
    {
        try
        {
            var item = DB.Articles.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image) || !FileJob.DeleteFile(path2 + item.BImage)) return false;
            DB.Articles.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteCertificate(int Id, string path)
    {
        try
        {
            var item = DB.Certificates.FirstOrDefault(p => p.id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Certificates.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteService(int Id, string path)
    {
        try
        {
            var item = DB.Services.FirstOrDefault(p => p.Id.Equals(Id));
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Services.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteGallery(int Id, string path)
    {
        try
        {
            var item = DB.Galleries.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Galleries.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeletePart(int Id)
    {
        try
        {
            if (DB.Parts.Count(p => p.Id.Equals(Id)) == 0) return false;
            var par = DB.Parts.FirstOrDefault(p => p.Id.Equals(Id));
            DB.Parts.DeleteOnSubmit(par);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteUnit(int Id)
    {
        try
        {
            if (DB.UnitMessages.Count(p => p.Id.Equals(Id)) == 0) return false;
            var par = DB.UnitMessages.FirstOrDefault(p => p.Id.Equals(Id));
            DB.UnitMessages.DeleteOnSubmit(par);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeletePost(int id)
    {
        try
        {
            var item = GetPosts().FirstOrDefault(p => p.Id == id);
            if (item != null) DB.Posts.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {
            return false;
        }
    }

    public int DeleteProduct(int Id, string path, string thumbImagePth)
    {
        try
        {

            var item = DB.Products.FirstOrDefault(p => p.Id == Id);
            if (path.Length > 0 && thumbImagePth.Length > 0 && !GetOrderList("", Id).Any())
            {
                if (!FileJob.DeleteFile(System.IO.Path.Combine(path, item.Image)) ||
                    !FileJob.DeleteFile(System.IO.Path.Combine(thumbImagePth, item.Image))
                    ) return -1;
            }
            return DB.spDeleteProduct(Id);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeleteAttribut(int Id)
    {
        try
        {
            if (DB.ProductAttrs.Any(p => p.AID.Equals(Id))) return false;

            var item = DB.Attrs.FirstOrDefault(p => p.Id.Equals(Id));
            DB.Attrs.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeleteBrandCat(int BID, int CID)
    {
        try
        {
            if (DB.CatBrands.Any(p => p.BrandId.Equals(BID) && p.CatId.Equals(CID)))
            {
                var item = DB.CatBrands.FirstOrDefault(p => p.BrandId.Equals(BID) && p.CatId.Equals(CID));
                DB.CatBrands.DeleteOnSubmit(item);
                DB.SubmitChanges();

                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteAttrValue(int Id)
    {
        try
        {
            if (DB.AttrValues.Any(p => p.Id.Equals(Id)))
            {
                var item = DB.AttrValues.FirstOrDefault(p => p.Id.Equals(Id));
                DB.AttrValues.DeleteOnSubmit(item);
                DB.SubmitChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeletePrint(int Id)
    {
        try
        {
            if (DB.DepPrints.Count(p => p.PrintId.Equals(Id)) > 0) return false;
            var item = DB.Prints.FirstOrDefault(p => p.Id == Id);
            DB.Prints.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    //public int DeleteProductColor(int Id, string path, string productPath, string thumbImagePth)
    //{
    //    try
    //    {
    //        var item = DB.PColors.FirstOrDefault(p => p.Id == Id);
    //        if (path.Length > 0 && thumbImagePth.Length > 0)
    //        {
    //            if (!FileJob.DeleteFile(System.IO.Path.Combine(path, item.Image)) ||
    //                !FileJob.DeleteFile(System.IO.Path.Combine(productPath, item.PImage)) ||
    //                !FileJob.DeleteFile(System.IO.Path.Combine(thumbImagePth, item.PImage))
    //                ) return 1;
    //        }
    //        if (DB.OrderDetails.Any(p => p.CID.GetValueOrDefault(0).Equals(Id))) return 2;
    //        if (DB.PSizes.Any(p => p.CID.GetValueOrDefault(0).Equals(Id))) return 3;
    //        DB.PColors.DeleteOnSubmit(item);
    //        DB.SubmitChanges();
    //        return 0;
    //    }
    //    catch (Exception ex)
    //    {   
    //        throw ex;
    //    }
    //}
    public bool DeleteWarranty(string code)
    {
        try
        {

            var item = DB.Warranties.FirstOrDefault(p => p.code3.Equals(code));
            DB.Warranties.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeleteWarrantyReg(Guid WId, Guid UId)
    {
        try
        {
            var item = DB.WarrantyRegisters.FirstOrDefault(p => p.Warranty.Equals(WId) && p.User.Equals(UId));
            DB.WarrantyRegisters.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeleteFailture(Guid WId, Guid UId)
    {
        try
        {
            var item = DB.Failures.FirstOrDefault(p => p.Warranty.Equals(WId) && p.User.Equals(UId));
            DB.Failures.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeleteNews(int Id, string path)
    {
        try
        {
            var item = DB.News.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.News.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteArticle(int Id, string path)
    {
        try
        {
            var item = DB.Articles.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Articles.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteDownload(int Id, string path)
    {
        try
        {
            var item = DB.Downloads.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Downloads.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteMes(int Id)
    {
        try
        {
            var item = DB.AddMessages.FirstOrDefault(p => p.Id.Equals(Id));
            DB.AddMessages.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {
            throw;
        }
    }
    public bool DeleteSlide(int Id, string path)
    {
        try
        {
            var item = DB.SlideShows.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.SlideShows.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteTopBaner(int Id, string path)
    {
        try
        {
            var item = DB.TopBaners.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.TopBaners.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeleteBrand(int Id, string Path)
    {
        try
        {
            var item = DB.Brands.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(Path + item.Image)) return false;
            DB.Brands.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public int DeleteBrand(int Id, string pathstring, string thumbpath, string thumbpath2)
    {
        try
        {
            if (DB.CatProducts.Any(p => p.BrId.GetValueOrDefault(0).Equals(Id))) return 1;
            var item = DB.Brands.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(pathstring + item.Image)) return 2;
            if (!FileJob.DeleteFile(System.IO.Path.Combine(thumbpath, item.Image))) return 2;
            if (!FileJob.DeleteFile(System.IO.Path.Combine(thumbpath2, item.Image))) return 2;
            DB.Brands.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return 0;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteCert(int Id, string path)
    {
        try
        {
            var item = DB.Certificates.FirstOrDefault(p => p.id.Equals(Id));
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Certificates.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteBaner(int Id, string path)
    {
        try
        {
            var item = DB.Baners.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            DB.Baners.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteLink(int Id)
    {
        try
        {
            var item = DB.Links.FirstOrDefault(p => p.Id.Equals(Id));
            DB.Links.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteEvent(int Id)
    {
        try
        {
            var item = DB.Events.FirstOrDefault(p => p.Id.Equals(Id));
            DB.Events.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteAgent(int Id)
    {
        try
        {
            var item = DB.Agents.FirstOrDefault(p => p.Id.Equals(Id));
            DB.Agents.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteRole(string RoleName)
    {
        try
        {
            var item = DB.Roles.FirstOrDefault(p => p.RoleName.Equals(RoleName));
            DB.Roles.DeleteOnSubmit(item);
            DB.SubmitChanges();
            Roles.DeleteRole(RoleName);
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeletePage(int Id)
    {
        try
        {
            var item = DB.Pages.FirstOrDefault(p => p.Id == Id);
            DB.Pages.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteContact(int Id)
    {
        try
        {
            var item = DB.Contacts.FirstOrDefault(p => p.Id == Id);
            DB.Contacts.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteProductAttr(int PID, int AID)
    {
        try
        {
            if (DB.ProductAttrs.Any(p => p.PID.Equals(PID) && p.AID.Equals(AID)))
            {
                var item = DB.ProductAttrs.Where(p => p.PID.Equals(PID) && p.AID.Equals(AID));
                DB.ProductAttrs.DeleteAllOnSubmit(item);
                DB.SubmitChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteProductAttrValue(int PID, int AID, int VID)
    {
        try
        {
            if (DB.ProductAttrs.Any(p => p.PID.Equals(PID) && p.AID.Equals(AID) && p.VID.Equals(VID)))
            {
                var item = DB.ProductAttrs.FirstOrDefault(p => p.PID.Equals(PID) && p.AID.Equals(AID) && p.VID.Equals(VID));
                DB.ProductAttrs.DeleteOnSubmit(item);
                DB.SubmitChanges();
                return true;
            }
            else
            {
                return false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeletePrintDep(int PrintID, int ProductID)
    {
        try
        {
            var Item = DB.DepPrints.FirstOrDefault(p => p.PrintId == PrintID && p.ProductId == ProductID);
            DB.DepPrints.DeleteOnSubmit(Item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public bool DeleteOrder(long Id)
    {
        try
        {
            var item = DB.Orders.FirstOrDefault(p => p.Id == Id);

            foreach (OrderDetail od in item.OrderDetails)
            {
                try
                {
                    BackSize(od.SID.GetValueOrDefault(0), 0, od.Id);

                }
                catch
                {

                }

            }
            if (item.Gift.GetValueOrDefault(false))
            {
                var q = DB.OrderGifts.Where(p => p.OId.Equals(Id));
                if (q != null)
                {
                    DB.OrderGifts.DeleteAllOnSubmit(q);
                    DB.SubmitChanges();
                }
            }
            var paygiftid = DB.PayGifts.Where(p => p.orderId.Equals(Id));
            if (paygiftid != null)
            {
                DB.PayGifts.DeleteAllOnSubmit(paygiftid);
                DB.SubmitChanges();
            }
            var payonline = DB.PayOnlines.Where(p => p.orderId.Equals(Id));
            if (payonline != null)
            {
                DB.PayOnlines.DeleteAllOnSubmit(payonline);
                DB.SubmitChanges();
            }
            var orderstate = DB.OrderStates.Where(p => p.OId.Equals(Id));
            if (orderstate != null)
            {
                DB.OrderStates.DeleteAllOnSubmit(orderstate);
                DB.SubmitChanges();
            }
            var UserGitCards = DB.UserGiftCards.Where(p => p.OrId.Equals(Id));
            if (UserGitCards != null)
            {
                DB.UserGiftCards.DeleteAllOnSubmit(UserGitCards);
                DB.SubmitChanges();
            }
            DB.Orders.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    //public bool DeleteOrder(long Id)
    //{
    //    try
    //    {
    //        var item = DB.Orders.FirstOrDefault(p => p.Id == Id);

    //        foreach (OrderDetail od in item.OrderDetails)
    //        {
    //            try
    //            {
    //                BackSize(od.SID.GetValueOrDefault(0), 0, od.Id);
    //            }
    //            catch
    //            {

    //            }

    //        }
    //        if (item.Gift.GetValueOrDefault(false))
    //        {
    //            var q = DB.OrderGifts.FirstOrDefault(p => p.OId.Equals(Id));
    //            DB.OrderGifts.DeleteOnSubmit(q);
    //            DB.SubmitChanges();
    //        }
    //        DB.Orders.DeleteOnSubmit(item);
    //        DB.SubmitChanges();
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        throw ex;
    //    }
    //}

    public int DeleteGift(int Id, string path, string tumb)
    {
        try
        {

            if (DB.OrderGifts.Any(p => p.GID.Equals(Id))) return 1;
            var item = DB.Gifts.FirstOrDefault(p => p.id.Equals(Id));
            if (!FileJob.DeleteFile(path + item.Image) || !FileJob.DeleteFile(tumb + item.Image)) return 2;
            DB.Gifts.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return 0;
        }
        catch
        {
            return 3;
        }
    }
    public string GetDescription(int Id, string Type)
    {
        try
        {
            var item = DB.Descriptions.FirstOrDefault(p => p.Id.Equals(Id));
            var ret = "";
            switch (Type)
            {
                case "t":
                    ret = item.Title;
                    break;
                case "d":
                    ret = item.Description1;
                    break;
                case "k":
                    ret = item.Keywords;
                    break;
            }
            return ret;
        }
        catch
        {
            return "خطا";
        }


    }
    public IQueryable<Role> GetRole()
    {
        try
        {
            return DB.Roles.ToList().AsQueryable();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<About> GetInfoMenuDrop(int type)
    {
        try
        {
            IQueryable<About> res;
            res = DB.Abouts.AsQueryable().Where(p => p.Type.Equals(type)).OrderBy(p => p.Name);
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<Cat> GetCatDrop(string Type)
    {
        try
        {
            IQueryable<Cat> res;
            res = DB.Cats.AsQueryable().Where(p => p.Type.Equals(Type)).OrderBy(p => p.Name);
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public IQueryable<CatPart> GetCatPart()
    {
        try
        {
            IQueryable<CatPart> res;
            res = DB.CatParts.ToList().AsQueryable();
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public CatProduct CatProductData(int Id)
    {
        try
        {
            return DB.CatProducts.ToList().First(p => p.Id.Equals(Id));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public catComment catCommentData(int catId)
    {
        try
        {
            return DB.catComments.ToList().FirstOrDefault(p => p.catId.Equals(catId));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public CatPrint CatPrintData(int Id)
    {
        try
        {
            return DB.CatPrints.ToList().First(p => p.Id.Equals(Id));
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public IList<spGetBrandResult> GetBrand(bool IsMenu = true)
    {
        return DB.spGetBrand(IsMenu).ToList();
    }

    public IList<spGetCatPBrandResult> GetBrandMenu(int Id)
    {
        return DB.spGetCatPBrand(Id).OrderByDescending(p => p.Name).ToList();
    }

    public IList<spGetBrandByResult> Getbran(int Id)
    {
        return DB.spGetBrandBy(Id).OrderBy(p => p.Name).ToList();
    }

    public IList<spGatCatProductLevelResult> GetProductChildMenu(int Level, int Id)
    {
        return DB.spGatCatProductLevel(Level, Id).ToList();
    }
    public IList<spGetCatPrintLevelResult> GetPrintChildMenu(int Level, int Id)
    {
        return DB.spGetCatPrintLevel(Level, Id).ToList();
    }
    public IList<spGetCatPrintLevelByResult> GetPrintChildMenuBY(int Id)
    {
        return DB.spGetCatPrintLevelBy(3, Id).ToList();
    }
    public IList<spGetCatProductResult> GetProductMenu()
    {
        return DB.spGetCatProduct().ToList();
    }
    public IList<catComment> GetCatComment()
    {
        return DB.catComments.ToList();
    }
    public IList<spGetCatProductLResult> GetProductMenuA()
    {
        return DB.spGetCatProductL().ToList();
    }
    public IList<spGetCatPrintResult> GetPrintMenu()
    {
        return DB.spGetCatPrint().ToList();
    }
    public IList<spGetAboutMenuResult> GetAboutMenu(int Type)
    {
        return DB.spGetAboutMenu(Type).ToList();
    }

    public IQueryable<Post> GetPosts()
    {
        return DB.Posts.ToList().AsQueryable();
    }
    public IQueryable<UserGiftCard> GetAllUserGiftCards()
    {
        return DB.UserGiftCards.ToList().AsQueryable();
    }
    public IQueryable<Cat> GetNewsCat()
    {
        return DB.Cats.Where(p => p.Type.Equals("news")).AsQueryable();
    }
    public IList<spGetInfoResult> GetInfo()
    {
        return DB.spGetInfo().ToList();
    }
    public IList<spGetServiceResult> GetService()
    {
        return DB.spGetService().ToList();
    }
    public IQueryable<Part> GetPart(int Id)
    {
        return DB.Parts.ToList().Where(p => p.Cat.Equals(Id) || Id.Equals(0)).AsQueryable();
    }
    public IList<spGetProductResult> GetProduct(int Id = 0)
    {
        return DB.spGetProduct(Id).ToList();
    }
    //public IList<spGetProductColorResult> GetProductColor(int Id = 0)
    //{
    //    return DB.spGetProductColor(Id).ToList();
    //}
    public IList<spGetProductDResult> GetProductD(int Id = 0)
    {
        return DB.spGetProductD(Id).ToList();
    }

    public IList<spGetAttrDResult> GetAttributeD(int Id = 0)
    {
        return DB.spGetAttrD(Id).ToList();
    }

    public IList<ProductAttr> GetProductAttr(int PID)
    {
        return DB.ProductAttrs.Where(p => p.PID.Equals(PID)).OrderBy(p => p.Id).ToList();
    }

    public IList<spGetProductAttrResult> GetProducttAttr(int Cat, int Id = 0)
    {
        return DB.spGetProductAttr(Id, Cat).ToList();
    }

    public IList<spGetProductAttrValueResult> GetProductAttrValue(int Id, int AID)
    {
        return DB.spGetProductAttrValue(Id, AID).ToList();
    }

    public IList<spGetGiftResult> GetGift()
    {
        return DB.spGetGift().OrderByDescending(p => p.id).ToList();
    }
    public IList<spGetPrintDResult> GetPrint(int Id = 0)
    {
        return DB.spGetPrintD(Id).ToList();
    }

    //public IQueryable<PColor> GetColor(int Id = 0)
    //{
    //    return DB.PColors.ToList().AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    //}
    public IQueryable<Info> GetInfo(int Id = 0)
    {
        return DB.Infos.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Service> GetService(int Id = 0)
    {
        return DB.Services.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<New> GetNews(int Id = 0)
    {
        return DB.News.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<WNew> GetWikiNews(int Id = 0)
    {
        return DB.WNews.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Article> GetWikiArticle(int Id = 0)
    {
        return DB.Articles.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Article> GetArticle(int Id = 0)
    {
        return DB.Articles.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Download> GetDownload(int Id = 0)
    {
        return DB.Downloads.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<AddMessage> GetMessage(int Id = 0)
    {
        return DB.AddMessages.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Certificate> GetCert(int Id = 0)
    {
        return DB.Certificates.AsQueryable().Where(p => p.id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<Contact> GetContact(int Id = 0)
    {
        return DB.Contacts.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public IList<spGetContactResult> GetContact(string User)
    {
        return DB.spGetContact(User).ToList();
    }
    public IQueryable<UnitMessage> GetUnit()
    {
        var item = DB.UnitMessages.ToList();
        return item.AsQueryable();
    }
    public IQueryable<Page> GetPage(int Id = 0)
    {
        return DB.Pages.AsQueryable().Where(p => p.Id.Equals(Id) || Id.Equals(0));
    }
    public Description GetDescription(int Id)
    {
        return DB.Descriptions.FirstOrDefault(p => p.Id.Equals(p.Id));
    }

    public IQueryable<AttrValue> GetAttrValues(int Id)
    {
        return DB.AttrValues.ToList().Where(p => p.AID.Equals(Id)).AsQueryable();
    }

    public AttrValue GetAttrValue(int Id)
    {
        return DB.AttrValues.FirstOrDefault(p => p.Id.Equals(Id));
    }
    public IList<spDepResult> GetDep(string Product = "", string Print = "")
    {
        return DB.spDep(Print, Product).ToList();
    }
    public IList<spDepPrResult> GetDepPr(string Product = "", string Print = "", bool Show = false)
    {
        return DB.spDepPr(Print, Product, Show).ToList();
    }
    public IList<spGetOrderListResult> GetOrderList(string UserName = "", int PID = 0)
    {
        return DB.spGetOrderList(UserName, PID).ToList();
    }
    public string GetItemCount(string OrderId)
    {
        return DB.OrderDetails.Where(p => p.OId.GetValueOrDefault(0).Equals(OrderId)).Sum(p => p.Count).ToString();
        //return DB.OrderDetails.Count(p => p.OId.GetValueOrDefault(0) == 2).ToString();
    }
    public string GetProductMenuDrop(int id, int Level)
    {
        var data = DB.spGetCatProduct().ToList().First(p => p.Id == id);
        var ret = "";
        switch (Level)
        {
            case 0:
                ret = data.LEVEL0;
                break;
            case 1:
                ret = data.LEVEL1;
                break;
            case 2:
                ret = data.LEVEL2;
                break;
        }
        return ret;
    }
    public string GetPrintMenuDrop(int id, int Level)
    {
        var data = DB.spGetCatPrint().ToList().First(p => p.Id == id);
        var ret = "";
        switch (Level)
        {
            case 0:
                ret = data.LEVEL0;
                break;
        }
        return ret;
    }

    public int GetProductDrop(int id, int Level)
    {
        var data = DB.spGetProduct(id).ToList().First();
        var ret = 0;
        switch (Level)
        {
            case 0:
                ret = data.Level0.GetValueOrDefault(0);
                break;
            case 1:
                ret = data.Level1.GetValueOrDefault(0);
                break;
            case 2:
                ret = data.Level2.GetValueOrDefault(0);
                break;
            case 3:
                ret = data.Level3.GetValueOrDefault(0);
                break;
        }
        return ret;
    }
    public int GetPrintDrop(int id, int Level)
    {
        var data = DB.spGetPrint(id).ToList().First();
        var ret = 0;
        switch (Level)
        {
            case 0:
                ret = data.Level0;
                break;
            case 1:
                ret = data.Level1;
                break;
        }
        return ret;
    }
    public bool HaveChildMenu(int Id)
    {
        if (DB.CatProducts.Count(p => p.Parent.GetValueOrDefault(0) == Id) > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public bool HaveChildMenuP(int Id)
    {
        if (DB.CatPrints.Count(p => p.Parent.GetValueOrDefault(0) == Id) > 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public int MaxLevel()
    {
        if (DB.CatProducts.Count() == 0)
        {
            return -1;
        }
        return DB.CatProducts.Max(p => p.Level);
    }
    public int MaxLevelP()
    {
        if (DB.CatPrints.Count() == 0)
        {
            return -1;
        }
        return DB.CatPrints.Max(p => p.Level);
    }
    public DataTable member(string User)
    {

        var dt = new DataTable();
        var c = new DataColumn("U");

        dt.Columns.Add("UserName");
        dt.Columns.Add("Email");
        dt.Columns.Add("IsApproved", typeof(bool));
        dt.Columns.Add("CreateDate");
        dt.Columns.Add("Comment");
        dt.Columns.Add("Role");
        dt.Columns.Add("Name");
        dt.Columns.Add("Family");
        dt.Columns.Add("Sex", typeof(bool));
        dt.Columns.Add("BirthDate");
        dt.Columns.Add("NationalCode");
        dt.Columns.Add("IdNo");
        dt.Columns.Add("PostalCode");
        dt.Columns.Add("Tel");
        dt.Columns.Add("Mobile");
        dt.Columns.Add("Fax");
        dt.Columns.Add("Address");
        dt.Columns.Add("State");
        dt.Columns.Add("City");
        dt.Columns.Add("Meet");
        dt.Columns.Add("News");
        dt.Columns.Add("Education");

        if (Roles.FindUsersInRole("Real", User).Count() > 0)
        {
            dt.Columns.Add("Job");
        }
        else
        {
            dt.Columns.Add("Type");
            dt.Columns.Add("CorpName");
            dt.Columns.Add("Activity");
            dt.Columns.Add("EconomicCode");
            dt.Columns.Add("NationalId");
            dt.Columns.Add("Position");
            dt.Columns.Add("DirectPhone");
        }
        return dt;
    }
    public static string PricePersian2(string Price, bool isPrice = true)
    {
        var res = "";
        Int64 p = 0;
        if (!string.IsNullOrEmpty(Price))
            p = Convert.ToInt64(Price);
        if (isPrice)
        {
            if (Price == "0") res = " 0.00 " + " ریال ";
            else
                res = p.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace(".00", "") + " ريال";
        }
        else
        {
            if (p.Equals(0))
                res = "";
            else
            {
                res = p.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace(".00", "");
            }
        }
        return res;
    }
    public static string PersianDate(DateTime DTime)
    {
        var per = new PersianCalendar();
        var res = per.GetYear(DTime).ToString() + "/" + per.GetMonth(DTime).ToString("00") + "/" + per.GetDayOfMonth(DTime).ToString("00");
        return res;
    }
    public static string PersianDate2(DateTime DTime)
    {
        var per = new PersianCalendar();
        var res = per.GetYear(DTime).ToString() + "/" + per.GetMonth(DTime).ToString("00") + "/" + per.GetDayOfMonth(DTime).ToString("00");
        return res + " ساعت " + DTime.Hour + ":" + DTime.Minute;
    }
    public bool IsRegister(Guid WId)
    {
        if (DB.WarrantyRegisters.Count(p => p.Warranty.Equals(WId)) == 1)
            return true;
        else
            return false;
    }
    public bool IsShop(string Price)
    {
        if (Price == "0")
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public static string PricePersian(string Price, bool isPrice = true)
    {
        var res = "";
        Int64 p = 0;
        if (!string.IsNullOrEmpty(Price))
            p = Convert.ToInt64(Price);
        if (isPrice)
        {
            if (Price == "0") res = "تماس بگیرید";
            else
                res = p.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace(".00", "") + " ريال";
        }
        else
        {
            if (p.Equals(0))
                res = "";
            else
            {
                res = p.ToString("N", CultureInfo.GetCultureInfoByIetfLanguageTag("fa-ir")).Replace(".00", "");
            }
        }
        return res;
    }
    public static string Active(bool act)
    {
        if (act)
        {
            return "fa fa-check text-success text-active";

        }
        else
        {
            return "fa fa-times text-danger text-active";

        }
    }
    public static void ActiveUser(string User, bool Active, string app = "")
    {
        var paap = Membership.ApplicationName;
        var ap = "/" + app;
        Membership.ApplicationName = ap;
        var m = Membership.GetUser(User);
        m.IsApproved = Active;
        Membership.UpdateUser(m);
        Membership.ApplicationName = paap;
    }
    public string GenerateUl(List<CatProduct> menu, Table<CatProduct> table, StringBuilder sb, string address, int level)
    {
        if (!menu.Any()) return sb.ToString();
        foreach (var dr in menu)
        {
            var handler = dr.Id.ToString(CultureInfo.InvariantCulture);
            var menuText = dr.Name;
            string line;

            if (dr.Level.Equals(level))
            {
                line = String.Format("<li class=''><a href=" + "{0}?id={1}" + ">{2}</a>", address, handler, menuText);
            }
            else
            {
                if (dr.Level.Equals(0))
                {
                    line = String.Format("<li class='title'><a href=Category.aspx?id=" + "{0}>{1}</a>", dr.Id, menuText);
                    sb.Append("</li>");
                }
                else
                {
                    var pidc = dr.Id;
                    var subMenuc = new List<CatProduct>(DB.CatProducts.Where(p => p.Parent.GetValueOrDefault(0) == pidc));
                    if (subMenuc.Count() > 0)
                    {
                        line = String.Format("<li><a class=sec href=Category.aspx?id=" + "{0}>{1}</a>", dr.Id, menuText);
                    }
                    else
                    {
                        line = String.Format("<li><a href=Category.aspx?id=" + "{0}>{1}</a>", dr.Id, menuText);
                    }
                }
            }
            sb.Append(line);
            var pid = dr.Id;
            var subMenu = new List<CatProduct>(DB.CatProducts.Where(p => p.Parent.GetValueOrDefault(0) == pid));
            {
                var subMenuBuilder = new StringBuilder();
                if (dr.Level.Equals(0))
                {
                    sb.Append(GenerateUl(subMenu, table, subMenuBuilder, address, level));
                }
                else
                {
                    sb.AppendLine("<ul class=''>");
                    sb.Append(GenerateUl(subMenu, table, subMenuBuilder, address, level));
                    sb.Append("</ul>");
                }

            }
            sb.Append("</li>");
        }
        return sb.ToString();
    }
    public IQueryable<FooterMenu> GetFooterName()
    {
        return DB.FooterMenus.AsQueryable();
    }
    public IQueryable<FooterLink> GetFooterLink(int Id, bool All = true)
    {
        return DB.FooterLinks.Where(p => p.Cat.GetValueOrDefault(0).Equals(Id) && ((!All && p.Show.Equals(true)) || All)).AsQueryable();
    }
    public IQueryable<FlowLink> GetSocialLink()
    {
        return DB.FlowLinks.ToList().AsQueryable();
    }
    public IQueryable<SlideShow> GetSlideData()
    {
        return DB.SlideShows.ToList().AsQueryable();
    }
    public IQueryable<TopBaner> GetTopBanerData()
    {
        return DB.TopBaners.ToList().AsQueryable();
    }
    public IQueryable<Baner> GetBanerData()
    {
        return DB.Baners.ToList().AsQueryable();
    }

    public IQueryable<Link> GetLink()
    {
        return DB.Links.ToList().OrderByDescending(p => p.Id).AsQueryable();
    }
    public IQueryable<Event> GetEvent()
    {
        return DB.Events.ToList().OrderByDescending(p => p.Id).AsQueryable();
    }
    public IQueryable<Agent> GetAgent()
    {
        return DB.Agents.ToList().AsQueryable();
    }
    public IQueryable<Warranty> GetWarranty()
    {
        return DB.Warranties.ToList().AsQueryable();
    }
    public IList<spGetWarrantyUserResult> GetWarranty(Guid? UserId)
    {
        return DB.spGetWarrantyUser(UserId).ToList();
    }
    public IQueryable<Failure> GetFailture()
    {
        return DB.Failures.ToList().AsQueryable();
    }
    public IQueryable<Failure> GetFailture(int Id)
    {
        return DB.Failures.Where(p => p.Id.Equals(Id)).ToList().AsQueryable();
    }
    public IList<spGetBanerResult> GetBaner(int Pos, int Take)
    {
        return DB.spGetBaner(Pos, Take).ToList();
    }
    public IQueryable<MenuB> GetBanerMenu(int Id)
    {
        return DB.MenuBs.ToList().Where(p => p.Id.Equals(Id) || Id == 0).AsQueryable();
    }

    public bool EditBanerMenu(int Id, string Image, string Url)
    {
        try
        {
            var item = DB.MenuBs.FirstOrDefault(p => p.Id.Equals(Id));
            item.Image = Image;
            item.Url = Url;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }

    }
    public bool EditCatLink(int Id, string Name, string Link)
    {
        try
        {
            var item = DB.catLinks.FirstOrDefault(p => p.categoryId.Equals(Id));
            item.Name = Name;
            item.link = Link;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }

    }

    public static string GetUserNameById(Guid UserId)
    {
        var Usr = Membership.GetUser(UserId).UserName;
        return Usr;
    }

    public string GetUserName(string UserId)
    {
        var Usr = Membership.GetUser(new Guid(UserId)).UserName;

        var pr = ProfileCommon.Create(Usr);
        return pr.GetPropertyValue("Name") + " " + pr.GetPropertyValue("Family");
    }
    public string GetUserNameAdmin(string UserName)
    {
        ProfileManager.ApplicationName = "/admin";
        var pr = ProfileCommon.Create(UserName);
        return pr.GetPropertyValue("Name") + " " + pr.GetPropertyValue("Family");
    }
    public bool IsAvailable(string ApplicationName, string UserName)
    {
        return DB.IsAvailable(ApplicationName, UserName).GetValueOrDefault(false);
    }
    public static string GenerateRandomCode()
    {
        Random r = new Random();
        string s = "";
        for (int j = 0; j < 5; j++)
        {
            int i = r.Next(3);
            int ch;
            switch (i)
            {
                case 1:
                    ch = r.Next(0, 9);
                    s = s + ch.ToString();
                    break;
                case 2:
                    ch = r.Next(65, 90);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
                case 3:
                    ch = r.Next(97, 122);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
                default:
                    ch = r.Next(97, 122);
                    s = s + Convert.ToChar(ch).ToString();
                    break;
            }
            r.NextDouble();
            r.Next(100, 1999);
        }
        return s;
    }
    public static string Join(string str1, string str2)
    {
        var ret = "";
        if (str1.Length > 0 && str2.Length > 0)
            ret = str1 + " " + str2;
        else if (str1.Length > 0)
            ret = str1;
        else
            ret = str2;
        return ret;
    }
    public static string GetUserData(Guid UserId, int Col)
    {
        ProfileManager.ApplicationName = "/";
        Membership.ApplicationName = "/";
        var User = Membership.GetUser(UserId);
        var P = new ProfileCommon();
        var pr = P.GetProfile(User.UserName);
        var ret = "";
        if (Col.Equals(1))
            ret = pr.Name + " " + pr.Family;
        else if (Col.Equals(2))
            ret = pr.Mobile;
        else if (Col.Equals(3))
            ret = User.Email;
        else if (Col.Equals(4))
            ret = User.UserName;

        Membership.ApplicationName = "/admin";
        ProfileManager.ApplicationName = "/admin";
        return ret;
    }
    public string GetUserDataW(Guid WarrantyId, int Col, string AppName = "")
    {
        var papp = ProfileManager.ApplicationName;
        var app = "/" + AppName;

        ProfileManager.ApplicationName = app;
        var ret = "";
        try
        {
            var UserId = DB.WarrantyRegisters.FirstOrDefault(p => p.Warranty.Equals(WarrantyId)).User;
            var User = Membership.GetUser(UserId);
            var i = DB.spGetUserData("/").ToList();


            var P = new ProfileCommon();
            var pr = P.GetProfile(User.UserName);

            if (Col.Equals(1))
                ret = pr.Name + " " + pr.Family;
            else if (Col.Equals(2))
                ret = pr.Mobile;
            else if (Col.Equals(3))
                ret = User.Email;
            else if (Col.Equals(4))
                ret = i.FirstOrDefault(p => p.UserName == User.UserName).Type.ToString();
        }
        catch
        {
            ret = "";
        }
        ProfileManager.ApplicationName = papp;
        return ret;
    }
    public IQueryable<Doctor> GetDoctors(int Id)
    {
        return (from doctors in DB.Doctors where doctors.Cat == Id select doctors).ToList().AsQueryable();
    }
    public IQueryable<CatDoctor> GetCatDoctors()
    {
        try
        {
            IQueryable<CatDoctor> res;
            res = DB.CatDoctors.ToList().AsQueryable();
            return res;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool EditCatDoctor(int Id, string Name)
    {
        try
        {
            var doc = DB.CatDoctors.FirstOrDefault(p => p.Id.Equals(Id));
            doc.Group = Name;
            DB.SubmitChanges();
            return true;
        }
        catch
        {

            return false;
        }
    }
    public bool InsertDoctorGroup(string Name)
    {
        try
        {
            if (DB.CatDoctors.Count(p => p.Group.Equals(Name)) > 0)
            {
                return false;
            }
            var catdoc = new CatDoctor
            {
                Group = Name
            };
            DB.CatDoctors.InsertOnSubmit(catdoc);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DeleteCatDoctor(int ID)
    {
        try
        {
            var item = DB.CatDoctors.FirstOrDefault(p => p.Id == ID);
            var doc = DB.Doctors.FirstOrDefault(p => p.Cat.Equals(ID));
            if (doc != null)
            {
                if (DelteDoctorByID(ID, doc.Id, doc.User))
                {

                    DB.CatDoctors.DeleteOnSubmit(item);
                    DB.SubmitChanges();
                    return true;
                }
                else
                    return false;
            }

            DB.CatDoctors.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public bool DelteDoctorByID(int CatID, int DoctorID, string un)
    {
        var doci = (from doc in DB.Doctors
                    where doc.Cat == CatID
                    && doc.Id == DoctorID
                    select doc).FirstOrDefault();

        var doctor = GetUserDataDoctor(CatID).FirstOrDefault(p => p.UserName.Equals(un));

        QA asked = DB.QAs.FirstOrDefault(p => p.DrId.Equals(doctor.UserId));

        if (asked == null)
        {
            DB.Doctors.DeleteOnSubmit(doci);
            DB.SubmitChanges();
            return true;
        }
        else
            return false;


        //Message.MessageGen(lblMessage,string.Format( "{0} از دکتر" + "سوال پرسیده شده است")
        //    ,GetUserDataDoctor(null).Select(p => new {Name = p.Name + " "+ p.Family}));


    }
    public int InsertDoctor(int Id, string Mail, string Tel, string User, bool? Pan)
    {
        try
        {
            if (DB.Doctors.Count(p => p.User.Equals(User) && p.Cat.Equals(Id)) > 0) return 1;
            var item = new Doctor
            {
                Cat = Id,
                Mail = Mail,
                Tel = Tel,
                User = User,
                InPanel = Pan
            };
            DB.Doctors.InsertOnSubmit(item);
            DB.SubmitChanges();
            return 2;
        }
        catch
        {
            return 0;
        }
    }

    public bool EditDoctor(int Id, string Mail, string Tel, bool? Pan)
    {
        try
        {
            var par = DB.Doctors.FirstOrDefault(p => p.Id.Equals(Id));
            par.Mail = Mail;
            par.Tel = Tel;
            par.InPanel = Pan;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public bool DeleteDoctor(int Id)
    {
        try
        {
            var Partm = DB.Doctors.FirstOrDefault(p => p.Id.Equals(Id));
            DB.Doctors.DeleteOnSubmit(Partm);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }

    //public string GetCatDocNameByCatID(int ID)
    //{
    //    return DB.CatDoctors.FirstOrDefault(p => p.Id.Equals(ID)).ToString();
    //}

    public IList<spGetUserDataDoctorResult> GetUserDataDoctor(int? CatID, string AppName = "/admin")
    {
        return DB.spGetUserDataDoctor(AppName, CatID).ToList();
    }
    public int GetDoctorCatIDByName(string Name)
    {
        var name = DB.CatDoctors.Select(p => p.Group.Equals(Name));
        return int.Parse(name.ToString());
    }
    public IList<spGetQuestionsForDoctorResult> GetQA(string DRName)
    {
        return DB.spGetQuestionsForDoctor(DRName).ToList();
    }

    public bool QuestionAnswered(int id, string answer, bool? Lock, string UserName)
    {
        try
        {

            //var item = GetQA(DRName:UserName).FirstOrDefault(p => p.Id.Equals(id));
            var item = DB.QAs.First(p => p.Id.Equals(id));
            var lock1 = item.Lock.GetValueOrDefault(false);
            item.Reply = answer;
            item.DateR = DateTime.Now;
            if (!lock1 && Lock.GetValueOrDefault(false))
            {
                DB.spInsertScore(13, item.UserId, 1);
            }
            DB.SubmitChanges();
            return true;
        }

        catch
        {
            return false;
        }

    }

    public bool DeleteQuestion(int ID)
    {
        try
        {
            var item = DB.QAs.First(p => p.Id.Equals(ID));
            DB.QAs.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }

    }


    public IList<spGetGiftCardsResult> GetGiftCards()
    {
        return DB.spGetGiftCards().ToList();

    }

    public IList<GiftCard> GetCards()
    {
        return DB.GiftCards.ToList();
    }
    public bool EditCert(int Id, string Name, string Image, string Description, string Keyword)
    {
        try
        {
            var item = DB.Certificates.FirstOrDefault(p => p.id == Id);
            item.Name = Name;
            item.Image = Image;
            item.Description = Description;
            item.Keyword = Keyword;
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }

    }
    public bool EditGiftCards(Guid GiftID, string Title, string Image, long Price, long Balance, DateTime Expiry)
    {
        var item = DB.GiftCards.FirstOrDefault(p => p.GiftId == GiftID);
        try
        {
            item.Balance = Balance;
            item.Date = DateTime.Now;
            item.Expiry = Expiry;
            item.Price = Price;
            item.Image = Image;
            item.Title = Title;
            DB.SubmitChanges();
            return true;
        }

        catch { return false; }
    }

    public bool DeleteGiftCard(Guid Gid, string path)
    {
        try
        {
            var item = DB.GiftCards.FirstOrDefault(p => p.GiftId.Equals(Gid));
            var giftitem = DB.UserGiftCards.Where(p => p.GiftId.Equals(item.GiftId));
            if (item.Image == "" || item.Image.Contains("def"))
            {
                DB.GiftCards.DeleteOnSubmit(item);
                DB.SubmitChanges();
                return true;
            }
            if (giftitem != null)
            {
                DB.UserGiftCards.DeleteAllOnSubmit(giftitem);
                DB.SubmitChanges();
            }
            DB.GiftCards.DeleteOnSubmit(item);
            DB.SubmitChanges();
            if (!FileJob.DeleteFile(path + item.Image)) return false;
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public DataTable InsertGiftCard(string Image, string Title, long Price, long Balance, DateTime Expiry, int Number)
    {
        try
        {
            var Res = new DataTable();
            var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
            var myCommand = new SqlCommand("spInsertGiftCard", myConnection);
            var UserAdaptor = new SqlDataAdapter(myCommand);
            myCommand.CommandType = CommandType.StoredProcedure;
            myConnection.Open();
            myCommand.Parameters.AddWithValue("@Title", Title);
            myCommand.Parameters.AddWithValue("@Image", Image);
            myCommand.Parameters.AddWithValue("@Price", Price);
            myCommand.Parameters.AddWithValue("@Balance", Balance);
            myCommand.Parameters.AddWithValue("@ExpiryDate", Expiry);
            myCommand.Parameters.AddWithValue("@Num", Number);
            myCommand.ExecuteNonQuery();
            UserAdaptor.Fill(Res);
            myConnection.Close();
            return Res;

        }

        catch { return new DataTable(); }
    }

    public DataTable GetGroupAddedGiftCardsByDate(string Date)
    {
        try
        {
            var Res = new DataTable();
            var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
            var myCommand = new SqlCommand("spGetRepeatedGiftCardsExcelArchieve", myConnection);
            var UserAdaptor = new SqlDataAdapter(myCommand);
            myCommand.CommandType = CommandType.StoredProcedure;
            myConnection.Open();
            myCommand.Parameters.AddWithValue("@Date", Date);

            myCommand.ExecuteNonQuery();
            UserAdaptor.Fill(Res);
            myConnection.Close();
            return Res;

        }

        catch { return new DataTable(); }
    }

    public GiftCard GetCurrentGiftCard(Guid GiftID)
    {
        return DB.GiftCards.FirstOrDefault(p => p.GiftId.Equals(GiftID));
    }

    public IList<spGetAllGiftCardsResult> GetAllGiftCards()
    {
        return DB.spGetAllGiftCards().ToList();
    }
    public bool InsertMessage(string title, string text, int cat)
    {
        try
        {
            var item = new AddMessage
            {
                Title = title,
                Text = text,
                CatId = cat
            };
            DB.AddMessages.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception)
        {

            return false;
        }
    }
    public bool InsertOneGiftCard(string Image, string Title, long Price, long Balance, DateTime Expiry)
    {
        try
        {

            var item = new GiftCard
            {
                GiftId = Guid.NewGuid(),
                Title = Title,
                Image = Image,
                Price = Price,
                Balance = Balance,
                Expiry = Expiry,
                Date = DateTime.Now
            };
            DB.GiftCards.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public IQueryable<Certificate> GetCertificate(int Id = 0)
    {
        return DB.Certificates.AsQueryable().Where(p => p.id.Equals(Id) || Id.Equals(0));
    }
    public IQueryable<catLink> GetCatLink(int CatId = 0)
    {
        return DB.catLinks.AsQueryable().Where(p => p.categoryId.Equals(CatId) || CatId.Equals(0));
    }
    public IQueryable<Gallery> GetGalleryData()
    {
        return DB.Galleries.ToList().AsQueryable();
    }
    public static string ChangeStateName(bool state)
    {
        string stds = "";
        if (state == true)
        {

            stds = "استفاده شده";
        }
        else
        {
            stds = "استفاده نشده";
        }
        return stds;
    }
    public IList<spGetRepeatedGiftCardsDateResult> GetExcelFileDates()
    {
        return DB.spGetRepeatedGiftCardsDate().ToList();

    }

    public PayGift GetDetailsForOrder(long OrId)
    {
        var item = DB.PayGifts.FirstOrDefault(p => p.orderId.Equals(OrId));
        if (item != null)
            return item;
        else
            return new PayGift();

    }
    public bool AddCash(Guid UserID, long Balance, string Type, string Description)
    {
        try
        {
            var item = new Cash
            {
                UserId = UserID,
                Charge = Balance,
                Type = Type,
                Date = DateTime.Now,
                Description = Description
            };
            DB.Cashes.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }

    public bool RemoveCash(Guid UserID, long Balance)
    {
        try
        {
            var item = new Cash
            {
                UserId = UserID,
                Charge = -Balance,
                Date = DateTime.Now
            };
            DB.Cashes.InsertOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch
        {
            return false;
        }
    }
    public IList<spGetUserCreditsResult> GetUserCredits()
    {
        return DB.spGetUserCredits().ToList();
    }

    public bool BackSize(int SID, int Count, int OD)
    {
        try
        {

            var size = DB.PSizes.FirstOrDefault(p => p.Id.Equals(SID));
            var color = DB.PColors.FirstOrDefault(p => p.Id.Equals(SID));
            var od = DB.OrderDetails.FirstOrDefault(p => p.Id.Equals(OD));
            var order = DB.Orders.FirstOrDefault(p => p.Id.Equals(od.OId));
            if (order.Status.Equals("در حال رسیدگی") && color.Count.HasValue)
            {
                var co = od.Count.GetValueOrDefault(0);
                if (co > Count)
                {
                    color.Count = color.Count + co - Count;
                    DB.SubmitChanges();
                    return true;
                }
                else if (co.Equals(Count))
                    return true;
                else if (color.Count + co - Count >= 0)
                {
                    color.Count = color.Count + co - Count;
                    DB.SubmitChanges();
                    return true;
                }
                else
                    return false;
            }
            else
            {
                return true;
            }
        }
        catch (Exception)
        {

            throw;
        }
    }

    public void BackSizeOrder(int SID, int Count, int O)
    {

    }


    public DataTable NewsLetterData()
    {
        var Res = new DataTable();
        var myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["HooraaConnectionString"].ConnectionString);
        var myCommand = new SqlCommand("Select * from NewsLetter order by Mail asc", myConnection);
        var UserAdaptor = new SqlDataAdapter(myCommand);
        myCommand.Connection.Open();
        myCommand.ExecuteNonQuery();
        myCommand.Connection.Close();
        UserAdaptor.Fill(Res);
        return Res;
    }
    public static object ToDBNull(object value)
    {
        if (null != value)
            return value;
        return DBNull.Value;
    }
    public IQueryable<UploadFile> GetUpFile()
    {
        return DB.UploadFiles.ToList().AsQueryable();
    }

    public bool DeleteUpFile(int Id, string path)
    {
        try
        {
            var item = DB.UploadFiles.FirstOrDefault(p => p.Id == Id);
            if (!FileJob.DeleteFile(path + item.FileName)) return false;
            DB.UploadFiles.DeleteOnSubmit(item);
            DB.SubmitChanges();
            return true;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    public Guid GetUserId(string User)
    {
        var u = Membership.GetUser(User);
        if (u != null)
        {
            var ret = new Guid(u.ProviderUserKey.ToString());
            return ret;
        }
        else
        {
            return Guid.Parse("00000000-0000-0000-0000-000000000000");
        }

    }
    public bool DeleteUser(string UserName)
    {
        Guid UId = GetUserId(UserName);
        var item1 = DB.UserSets.Where(p => p.UserId.Equals(UId));
        if (item1 != null) DB.UserSets.DeleteAllOnSubmit(item1);
        DB.SubmitChanges();
        var item2 = DB.CommentInfos.FirstOrDefault(p => p.UserId.Equals(UId));
        if (item2 != null) DB.CommentInfos.DeleteOnSubmit(item2);
        //var item3 = DB.UserPoints.FirstOrDefault(p => p.UserId.Equals(UId));
        //if (item3 != null) DB.UserPoints.DeleteOnSubmit(item3);
        var item3 = DB.UserGiftCards.Where(p => p.UserId.Equals(UId));
        if (item3 != null) DB.UserGiftCards.DeleteAllOnSubmit(item3);
        var item4 = DB.Cashes.Where(p => p.UserId.Equals(UId));
        if (item4.Count() != 0) DB.Cashes.DeleteAllOnSubmit(item4);
        var item5 = DB.CommentProducts.Where(p => p.UserId.Equals(UId));
        if (item5.Count() != 0) DB.CommentProducts.DeleteAllOnSubmit(item5);
        var item6 = DB.Favs.Where(p => p.UserId.Equals(UId));
        if (item6.Count() != 0) DB.Favs.DeleteAllOnSubmit(item6);
        var item7 = DB.ProductShares.Where(p => p.UserId.Equals(UId));
        if (item7.Count() != 0) DB.ProductShares.DeleteAllOnSubmit(item7);
        var item8 = DB.Ratings.Where(p => p.UserId.Equals(UId));
        if (item8.Count() != 0) DB.Ratings.DeleteAllOnSubmit(item8);
        var item9 = DB.Scores.Where(p => p.UserId.Equals(UId));
        if (item9.Count() != 0) DB.Scores.DeleteAllOnSubmit(item9);
        var item10 = DB.Sends.Where(p => p.UserId.Equals(UId));
        if (item10.Count() != 0) DB.Sends.DeleteAllOnSubmit(item10);
        DB.SubmitChanges();
        return true;
    }

    public bool GetUserSet(string UserName, string Cat)
    {
        var dt = DB.spGetUserSet(UserName).Where(p => p.Cat.Equals(Cat)).ToList();
        if (dt.Where(p => p.Mail.Equals(true)).Count() != 0)
        {
            return true;
        }
        else
        {
            return false;
        }

    }

}