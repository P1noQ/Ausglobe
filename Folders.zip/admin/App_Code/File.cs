﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Text;
using Persia;

/// <summary>
/// Summary description for File
/// </summary>
public static class FileJob
{
    public static Boolean ThumbImage(string path, string pathThumb, string fileName, int width, int height)
    {
        try
        {
            var extension = Path.GetExtension(fileName);
            var imgFormat = ImageFormat.Png;
            if (extension != null)
                switch (extension.ToUpper())
                {
                    case ".JPG":
                        imgFormat = ImageFormat.Jpeg;
                        break;

                    case ".JPEG":
                        imgFormat = ImageFormat.Jpeg;
                        break;

                    case ".BMP":
                        imgFormat = ImageFormat.Bmp;
                        break;

                    case ".PNG":
                        imgFormat = ImageFormat.Png;
                        break;

                    case ".GIF":
                        imgFormat = ImageFormat.Gif;
                        break;
                }
            var displayedImg = path + fileName;
            var displayedImgThumb = pathThumb;
            var imgFileName = Path.GetFileName(displayedImg);
            using (var myimg = System.Drawing.Image.FromFile(displayedImg))
            {
                var img = myimg.GetThumbnailImage(width, height, null, IntPtr.Zero);
                img.Save(displayedImgThumb + imgFileName, imgFormat);
                img.Dispose();
                return true;
            }
        }
        catch (Exception)
        {
            return false;
        }
    }

    public static bool SaveFile(FileUpload fileUpload1, string path)
    {
        try
        {
            fileUpload1.PostedFile.SaveAs(path);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static bool DeleteFile(string path)
    {
        try
        {
            File.Delete(path);
            return true;
        }
        catch
        {
            return false;
        }
    }

    public static bool CheckFileExisted(string path)
    {
        if (File.Exists(path))
            return true;
        else
            return false;
    }
    public static string FileUpload(FileUpload fileUpload1)
    {
        string savePaths = null;
        try
        {
            if (fileUpload1.HasFile)
            {
                var fileExt = Path.GetExtension(fileUpload1.FileName);
                if (fileExt != null &&
                    (fileExt.ToUpper() == ".JPG" || fileExt.ToUpper() == ".BMP" || fileExt.ToUpper() == ".PNG" ||
                     fileExt.ToUpper() == ".GIF"))
                {
                    var filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now)
                            .Simple.Replace("/", "")
                            .Remove(0, 2)) +
                        "-" + DateTime.Now.Hour +
                        DateTime.Now.Minute +
                        DateTime.Now.Second +
                        "-1-" +
                        fileUpload1.FileName;
                    savePaths = filename;
                }
            }
        }
        catch
        {
            return savePaths;
        }
        return savePaths;
    }

}