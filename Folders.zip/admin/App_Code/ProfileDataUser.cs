﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;

/// <summary>
/// Summary description for ProfileDataUser
/// </summary>
public static class ProfileDataUser
{
    public static void SetAdmin()
    {
        ProfileManager.ApplicationName = "/admin";
    }
    public static void SetUser()
    {
        ProfileManager.ApplicationName = "/";
    }
    public static ProfileCommon UserProf(string UserName)
    {
        ProfileManager.ApplicationName = "/";
        var pr = new ProfileCommon();
        return pr.GetProfile(UserName);
    }
}