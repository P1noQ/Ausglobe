﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Net.Mail;
using System.Web.Profile;

namespace admin
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage.Width = 283;
            CaptchaImage.Height = 75;
            CaptchaImage.Text = imgcode;
        }
        protected void GetCaptcha(object sender, EventArgs e)
        {
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage.Width = 283;
            CaptchaImage.Height = 75;
            CaptchaImage.Text = imgcode;
        }
        protected void btnForgetClick(object sender, EventArgs e)
        {

            var Code = Server.HtmlEncode(txtCode.Text);
            if (Code.ToLower() != CaptchaImage.Text.ToLower())
            {
                lblMessage.Text = "کد امنیتی را درست وارد نمایید";
                lblMessage.CssClass = "text-danger input-lg";
                lblMessage.Visible = true;

                return;
            }
            var text = Server.HtmlEncode(txtName.Text);

            var user = "";
            try
            {
                if (Membership.FindUsersByEmail(user).Count.Equals(1))
                    user = Membership.GetUserNameByEmail(text);
                else if (Membership.FindUsersByName(text.ToLower()).Count.Equals(1))
                    user = text;
                else
                {
                    lblMessage.Text = "نام کاربری یا پست الکترونیکی یافت نشد";
                    lblMessage.CssClass = "text-danger input-lg";
                    lblMessage.Visible = true;
                    return;
                }
                var US = Membership.GetUser(user);
                var cook = new HttpCookie(US.UserName, "t");
                cook.Expires = DateTime.Now.AddDays(1);
                cook.HttpOnly = true;
                Response.Cookies.Add(cook);
                var href = "";
                if (Request.Url.Query.Length > 0)
                    href = Request.Url.OriginalString.Replace("Forget", "Reset").Replace(Request.Url.Query, "?UserId=" + US.ProviderUserKey.ToString());
                else
                    href = Request.Url.OriginalString.Replace("Forget", "Reset") + "?UserId=" + US.ProviderUserKey.ToString();
                var body = "<div dir=\"rtl\">برای بازیابی روز عبور در سایت تارا " + "<a href=\"" + href + "\">کلیک</a>" + " نمایید</div>";
                SendMes.SendEmail(US.Email, "بازیابی رمز عبور", body);
                lblMessage.Text = "درصورت موجود بودن ایمیل و نام کاربری وارد شده،ایمیل حاوی لینک تغییر رمز عبور برای شما ارسال می شود.لطفاٌ ایمیل خود را بررسی نمایید و در صورت عدم مشاهده پوشه اسپم را بررسی نمایید.";
                lblMessage.CssClass = "text-success input-lg";
                lblMessage.Visible = true;
            }
            catch
            {

            }
        }
    }
}