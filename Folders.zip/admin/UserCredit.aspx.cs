﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class UserCredit : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        MVCreditManage.ActiveViewIndex = 0;
       
        BindGrid();
        lblh.InnerText = "افزایش/کاهش اعتبار کاربر";
        Page.Title = "مدیریت اعتبار کاربران";
        if (Session["Success"] != null)
        {
            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد.", Color.Green);
            Session.Remove("Success");
        }
        else if (!string.IsNullOrEmpty( Request.QueryString["e"]))
            Message.MessageGen(lblMessage, "عملیات با خطا مواجه شد.", Color.Red);
    }
    Data dt = new Data();
    public void BindGrid()
    {
        try
        {
            var source = dt.GetUserCredits().OrderByDescending(p=>p.Credit);
            gvList.DataSource =source ;
            gvList.DataBind();

            if (source != null)
            {
                gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvList.FooterRow.TableSection = TableRowSection.TableFooter;

            }
        }
        catch
        {

        }
    }
    protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Manage"))
        {
            MVCreditManage.ActiveViewIndex = 1;
            lblh.InnerText = "افزایش/کاهش اعتبار کاربر";
            ViewState["UserId"] = e.CommandArgument;
        }
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MVCreditManage.ActiveViewIndex = 0;
        BindGrid();
        lblh.InnerText = "افزایش/کاهش اعتبار کاربر";

    }
    protected void BtnEdit_Click(object sender, EventArgs e)
    {
        long price = long.Parse(txtPrice.Text);
        string des = txtDescription.Text;
        Guid UserId = Guid.Parse(ViewState["UserId"].ToString());
        List<object> props = new List<object>();
        props.Add(UserId);
        if (drpAction.SelectedIndex == 0)
        {
            props.Add(price);
            props.Add("افزایش اعتبار توسط ادمین");
           
        }
        else
        {
            props.Add(-price);
            props.Add("کاهش اعتبار توسط ادمین");
          
        }
        props.Add(des);
        Session["props"] = props;
        Response.Redirect("~/UserCreditMiddle.aspx");
        BindGrid();
        MVCreditManage.ActiveViewIndex = 0;
    }
}