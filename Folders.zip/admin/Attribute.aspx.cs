﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;
using System.Collections.ObjectModel;

namespace admin
{
    public partial class Attribute : System.Web.UI.Page
    {
        public Data Data = new Data();
        public static int gc;
        public static bool edit;
        public static bool editp;
        public static Collection<AttrValue> Rel;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            Page.MaintainScrollPositionOnPostBack = true;
            Rel = new Collection<AttrValue>();
            LoadDate();
        }
        private void LoadDate()
        {
            var item = Data.GetAttributeD().ToList();
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        private void LoadValue(int Id)
        {

            var item = Data.GetAttrValues(Id).AsEnumerable();
            GvVal.DataSource = item;
            if (item.Any())
            {
                GvVal.DataBind();
                Rel.Clear();
                foreach (AttrValue av in item)
                {
                    Rel.Add(av);
                }
                
            }
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش ویژگی ها";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                btnSave.Visible = false;
                var item = Data.GetAttributeD(id).First();
                if (item == null) return;

                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Text;
                var list = new ListItemCollection();
                if (item.Cat.HasValue)
                {
                    var lv = "1";
                    if (item.Level1.HasValue) lv = "2";
                    if (item.Level2.HasValue) lv = "3";
                    if (item.Level3.HasValue) lv = "4";

                    if (lv == "4")
                    {
                        list.Add(new ListItem("0", "4"));
                        list.Add(new ListItem(item.Level0.ToString(), "4"));
                        list.Add(new ListItem(item.Level1.ToString(), "4"));
                        list.Add(new ListItem(item.Level2.ToString(), "4"));
                    }
                    else if(lv=="3")
                    {
                        list.Add(new ListItem("0", "3"));
                        list.Add(new ListItem(item.Level0.ToString(), "3"));
                        list.Add(new ListItem(item.Level1.ToString(), "3"));

                    }
                    else if (lv == "2")
                    {
                        list.Add(new ListItem("0", "2"));
                        list.Add(new ListItem(item.Level0.ToString(), "2"));
                    }
                    else
                    {
                        list.Add(new ListItem("0", "1"));
                    }
                    edit = true;
                    rpDropMenu.DataSource = list;
                    rpDropMenu.DataBind();
                }
                else
                {
                    rpDropMenu.DataBind();
                }
                LoadValue(id);

                MultiView1.ActiveViewIndex = 1;

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.GetAttributeD(id).First();

                if (item != null)
                {
                    
                    switch (Data.DeleteAttribut(id))
                    {
                        case true:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                            break;
                        case false:
                            Message.MessageGen(lblMessage, "حذف ویژگی امکانپذیر نمی باشد", Color.Red);
                            break;
                    }
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        protected void BtnBackVClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessageV);
            MvValue.ActiveViewIndex = 0;

        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                string filename;

                var Name = Server.HtmlEncode(txtName.Text);
                int? Cat = null;
                if (rpDropMenu.Items.Count > 0)
                {
                    var drop = (DropDownList) rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    Cat = Convert.ToInt32(drop.SelectedValue.ToString());
                }

                
                var p = Data.InsertAttribute(Name, Cat);
                var Er = false;
                if (p > 0)
                {
                    if (Rel.Count > 0)
                    {
                        try
                        {
                            foreach (AttrValue r in Rel)
                            {
                                Data.InsertAttrValue(p, r.Value);
                            }
                        }
                        catch
                        {
                            Er = true;
                        
                        }
                    }

                    if (Er)
                    {
                        Message.MessageGen(lblMessage, "مقدار به درستی درج نشد",
                            Color.Red);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                    }
                    LoadDate();
                    var btn = (Button) sender;
                    if (btn.CommandName.Equals("Save"))
                    {
                        MultiView1.ActiveViewIndex = 0;
                    }
                    txtName.Text = "";
                }
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            btnSave.Visible = true;
            lblh.InnerText = "ایجاد ویژگی";
            txtName.Text = "";
            GvVal.DataBind();
            Rel.Clear();
            edit = false;
            gc = 0;
            //if (dropMenuLevel.SelectedIndex != 0)
            //{
                var ml = 0;
                Message.EmptyMessage(lblMessage);
                var List = new ListItemCollection();
                var j = 0;
                for (int i = 1; i <= ml; i++)
                {
                    if (i == 1)
                    {
                        j = 0;
                    }
                    else
                    {
                        j = Data.GetProductChildMenu(ml, j).First().Id;
                    }
                    List.Add(new ListItem(j.ToString(), ml.ToString()));
                }
                rpDropMenu.DataSource = List;
                
            //}
            rpDropMenu.DataBind();
            MultiView1.ActiveViewIndex = 1;
        }
        protected void rpDropMenu_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {

        }
        protected void rpDropMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            var d = (DropDownList)sender;
            var line = Data.CatProductData(Convert.ToInt32(d.SelectedValue.ToString())).Level;
            
            for (int I = line + 1; I < rpDropMenu.Items.Count; I++)
            {
                var pdrop = (DropDownList)rpDropMenu.Items[I - 1].FindControl("rpDropLevel");

                var drop = (DropDownList)rpDropMenu.Items[I].FindControl("rpDropLevel");
                try
                {
                    gc = Convert.ToInt32(pdrop.SelectedValue.ToString());
                    var lvl = rpDropMenu.Items.Count;
                    var data = Data.GetProductChildMenu(lvl, gc);
                    drop.DataSource = data;
                    drop.DataTextField = "Name";
                    drop.DataValueField = "Id";
                    drop.DataBind();

                }
                catch
                {
                    drop.Items.Clear();
                }
            }
            //var city = Library.Db.tblCities.OrderBy(q => q.name).Where(p => p.parentId.Equals(int.Parse(ddlProvince.SelectedValue)));
            //ddlCity.DataSource = city;
            //ddlCity.DataBind();
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                
                var Name = Server.HtmlEncode(txtName.Text);

                int? Cat = null;
                if (rpDropMenu.Items.Count > 0)
                {
                    var drop = (DropDownList) rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    Cat = Convert.ToInt32(drop.SelectedValue.ToString());
                }
                try
                {
                    var rel = Data.GetAttrValues(int.Parse(hdfId.Value)).ToList();
                    var ret = Data.EditAttribute(int.Parse(hdfId.Value), Cat, Name);
                    var er = 0;
                    if (ret == 0)
                    {
                        try
                        {

                            foreach (AttrValue r in Rel)
                            {
                                if (r.Id == 0)
                                {
                                    Data.InsertAttrValue(int.Parse(hdfId.Value), r.Value);
                                }
                                else
                                {
                                    Data.EditAttrValue(r.Id, r.Value);
                                    var ind = rel.FindIndex(p => p.Id.Equals(r.Id));
                                    rel.RemoveAt(ind);
                                }
                            }
                            if (rel.Count() > 0)
                            {
                                foreach (AttrValue r in rel)
                                {
                                    Data.DeleteAttrValue(r.Id);
                                }
                            }
                        }
                        catch
                        {
                            er = 1;
                        }
                    }
                    
                    if (ret == 1)
                    {
                        Message.MessageGen(lblMessage, "ویژگی وارد شده وجود دارد", Color.Red);
                    }
                    else if (ret==2)
                    {
                        Message.MessageGen(lblMessage, "تغییر نوع امکانپذیر نیست", Color.Orange);
                    }
                    else if (ret == 0 && er == 0)
                    {
                        Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);    
                    }
                    else if (ret == 0 && er == 1)
                    {
                        Message.MessageGen(lblMessage, "ارتباط مقدار با ویژگی به درستی درج یا حذف نشد", Color.Red);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                        MultiView1.ActiveViewIndex = 1;        
                    }
                    

                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                
            }
        }
        protected void rpDropMenu_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            try
            {
                var ind = e.Item.ItemIndex;
                if (ind != -1)
                {
                    var drop = (DropDownList)e.Item.FindControl("rpDropLevel");

                    var DT = (ListItem)e.Item.DataItem;
                    if (DT != null)
                    {
                        gc = Convert.ToInt32(DT.Text.ToString());
                        var lvl = Convert.ToInt32(DT.Value.ToString());
                        var data = Data.GetProductChildMenu(lvl, gc);
                        drop.DataSource = data;
                        drop.DataTextField = "Name";
                        drop.DataValueField = "Id";
                        drop.DataBind();
                        if (edit)
                        {
                            var par = Data.GetProductDrop(Convert.ToInt32(hdfId.Value), e.Item.ItemIndex);
                            drop.SelectedIndex = drop.Items.IndexOf(drop.Items.FindByValue(par.ToString()));
                        }
                    }
                }
                else
                {
                    var last = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    last.AutoPostBack = false;
                    gc = 0;
                    rpDropMenu.Visible = true;
                }
            }
            catch
            {
                if (rpDropMenu.Items.Count == 0)
                {
                    rpDropMenu.Visible = false;
                }
            }

        }
        protected void GvValRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteValRecord(Convert.ToInt32(e.CommandArgument));


                        break;
                    case "change":
                        ChangeValRecord(Convert.ToInt32(e.CommandArgument));

                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessageV, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeValRecord(int id)
        {
            vlblh.InnerText = "ویرایش مقدار";
            hdfVid.Value = id.ToString();
            var item = Data.GetAttrValue(id);
            txtValue.Text = item.Value;
            BtnInsertV.Visible = false;
            BtnEditV.Visible = true;
            MvValue.ActiveViewIndex = 1;
        }
        protected void DeleteValRecord(int id)
        {
            try
            {
                var item = Rel.FirstOrDefault(p => p.Id == id);
                Rel.Remove(item);
                GvVal.DataSource = Rel;
                GvVal.DataBind();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void btnAddValueClick(object sender, EventArgs e)
        {
            vlblh.InnerText = "ایجاد مقدار";
            txtValue.Text = "";

            BtnInsertV.Visible = true;
            BtnEditV.Visible = false;
            MvValue.ActiveViewIndex = 1;
        }
        protected void BtnInsertVClick(object sender, EventArgs e)
        {
            var Value = Server.HtmlEncode(txtValue.Text);
            if (Rel.Count(q => q.Value.Equals(Value)) == 0)
            {
                var item = new AttrValue
                {
                    AID = 0,
                    Value = Value
                };
                Rel.Add(item);
                GvVal.DataSource = Rel;
                GvVal.DataBind();
            }
            MvValue.ActiveViewIndex = 0;
        }
        protected void BtnEditVClick(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 1;
            var vid = Convert.ToInt32(hdfVid.Value.ToString());
            var it = Rel.FirstOrDefault(q => q.Id == vid);
            var ind = Rel.IndexOf(it);
            var value = Server.HtmlEncode(txtValue.Text);
            var item = Rel.ElementAt(ind);
            if (Rel.Count(q => q.Value.Equals(value)) == 0)
            {
                item.Value = value;

                GvVal.DataSource = Rel;
                GvVal.DataBind();
            }
            MvValue.ActiveViewIndex = 0;
            return;
        }
    }
}