﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace admin
{
    public partial class OrderAgreement : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            txtBody.Value = Data.OrderAgreement;
            txtBody2.Value = Data.Factor;
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                var text = txtBody.Value;
                Data.OrderAgreement = text;
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnEditClick2(object sender, EventArgs e)
        {
            try
            {
                var text = txtBody2.Value;
                Data.Factor = text;
                Message.MessageGen(lblMessage2, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage2, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
    }
}