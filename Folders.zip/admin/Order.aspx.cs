﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.Security;
using System.Web.Profile;
using System.Web.UI;
using System.IO;
using System.Data;
using System.Xml;
using System.Xml.Xsl;
using System.Collections.Generic;

namespace admin
{
    public partial class Order : System.Web.UI.Page
    {
        public Data Data = new Data();
        public clsShoppingCart Cart = new clsShoppingCart();
        private void ExportGridToExcel()
        {
            string procInfo = "type='text/xsl' href='" + "\\transform.xslt" + "'";//Processing info for XSLT
            string TempPath = Server.MapPath("~/");
            string XMLPath = TempPath + "\\Products.xml"; //temp path to store the XML file
            string XLSPath = TempPath + "\\Products.xls";//temp path to store the XLS file


            //Write the dataset as XML file with some XSLT processing information
            using (XmlTextWriter tw = new XmlTextWriter(XMLPath,
                       null))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                var dt = Data.OrderExcell();
                dt.TableName = "سفارش";
                var ds = new DataSet();
                ds.Tables.Add(dt);
                //ds.WriteXml(Server.MapPath("~/data.xml"));
                //ds.WriteXmlSchema(Server.MapPath("~/schema.xml"));
                tw.WriteProcessingInstruction("xml-stylesheet", procInfo);
                ds.WriteXml(tw);
            }


            XmlDataDocument xmldoc = new XmlDataDocument();
            xmldoc.Load(XMLPath);
            XslCompiledTransform xsl = new XslCompiledTransform();
            xsl.Load(Server.MapPath(".") + "\\excell\\Transform.xslt");

            using (XmlTextWriter tw = new XmlTextWriter(XLSPath, System.Text.Encoding.UTF8))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                xsl.Transform(xmldoc, null, tw);//Performa XSLT transformation.
            }



            //Streams the generated XLS file to the user
            byte[] Buffer = null;
            using (FileStream MyFileStream = new FileStream(XLSPath, FileMode.Open))
            {
                // Total bytes to read: 
                long size;
                size = MyFileStream.Length;
                Buffer = new byte[size];
                MyFileStream.Read(Buffer, 0, int.Parse(MyFileStream.Length.ToString()));
            }
            Response.ContentType = "application/xls";
            string header = "attachment; filename=" + "order" + DateTime.Now.Ticks.ToString() + ".xls";
            Response.AddHeader("content-disposition", header);
            Response.BinaryWrite(Buffer);
            Response.Flush();
            Response.End();

        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            if (Page.PreviousPage != null)
            {
                var User = Request.QueryString["user"].ToString();
                hdfUser.Value = User;
            }
            if (Request.QueryString["pid"] != null)
            {
                var PID = Convert.ToInt32(Request.QueryString["pid"].ToString());
                hdfPID.Value = PID.ToString();
            }

            LoadDate();
        }
        private void LoadDate()
        {
            var user = hdfUser.Value.Length > 0 ? hdfUser.Value.ToString() : "";
            var pid = hdfPID.Value.Length > 0 ? Convert.ToInt32(hdfPID.Value.ToString()) : 0;
            var item = Data.GetOrderList(user, pid);
            if (dpStart.Text.Length > 0)
            {
                item = item.Where(p => p.Date.GetValueOrDefault(DateTime.Now) >= dpStart.Date.GetValueOrDefault(DateTime.Now)).ToList();
            }
            if (dpEnd.Text.Length > 0)
            {
                item = item.Where(p => p.Date <= dpEnd.Date.GetValueOrDefault(DateTime.Now).AddDays(1)).ToList();
            }
            if (!btnNewView.Enabled)
            {
                item = item.Where(p => p.Status.Equals("در حال رسیدگی")).ToList();
            }
            else
            {
                item = item.Where(p => !p.Status.Equals("در حال رسیدگی") && !p.Status.Equals("معلق")).ToList();

            }
            gvList.DataSource = item;
            gvList.DataBind();
            //gvlistpanel.Update();
            if (item.Any())
            {
                //gvlistpanel.Update();
                gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvList.FooterRow.TableSection = TableRowSection.TableFooter;

                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "forPoolix();", true);
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetDataTable();", true);
                
            }
            //gvlistpanel.Update();
        }
        protected void LoadEnable(object sender, EventArgs e)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var btnDisable = (System.Web.UI.WebControls.Button)sender;
                if (btnNewView.Enabled.Equals(false))
                {
                    btnNewView.Enabled = true;
                    btnNewView.CssClass = "btn btn-info";
                    //gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    //gvList.FooterRow.TableSection = TableRowSection.TableFooter;

                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetDataTable();", true);
                    //gvlistpanel.Update();
                }
                if (btnConView.Enabled.Equals(false))
                {
                    btnConView.Enabled = true;
                    btnConView.CssClass = "btn btn-info";


                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetDataTable();", true);
                    //gvlistpanel.Update();
                }
                btnDisable.Enabled = false;
                btnDisable.CssClass = "btn btn-primary";

                LoadDate();
                //selectpanel.Update();
                //gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                //gvList.FooterRow.TableSection = TableRowSection.TableFooter;
                //gvlistpanel.Update();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);

            }
        }
        protected void btnSearchClick(object sender, EventArgs e)
        {
            try
            {
                //System.Threading.Thread.Sleep(5000);
                var Reset = (System.Web.UI.WebControls.Button)sender;
                if (Reset == btnReset)
                {
                    dpStart.Text = "";
                    dpEnd.Text = "";
                    gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    gvList.FooterRow.TableSection = TableRowSection.TableFooter;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetDataTable();", true);

                }
                else
                {
                    gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    gvList.FooterRow.TableSection = TableRowSection.TableFooter;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetDataTable();", true);
                }
                LoadDate();
                //gvlistpanel.Update();
                //gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                //gvList.FooterRow.TableSection = TableRowSection.TableFooter;
                //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetDataTable();", true);
                
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            var gr = (GridView)sender;
            switch (e.CommandName)
            {
                case "Select":
                    {
                        
                        Response.Redirect("~/EditOrder.aspx?id=" + e.CommandArgument.ToString());



                        break;
                    }
                case "Remove":
                    DeleteRecord(Convert.ToInt64(e.CommandArgument.ToString()));
                    LoadDate();
                    break;
                case "ViewState":
                    Response.Redirect("~/ViewOrderState.aspx?id=" + e.CommandArgument.ToString());
                   

                    break;
                //case "Stat":

                //    if (btnConView.Enabled)
                //    {
                //        ChangeStat((Convert.ToInt64(e.CommandArgument.ToString())), "تایید شده و در حال بسته بندی");
                //    }
                //    else
                //    {
                //        ChangeStat((Convert.ToInt64(e.CommandArgument.ToString())), "ارسال شده");
                //    }
                //    LoadDate();
                //    break;
                //case "StatD":

                //    if (btnSendView.Enabled)
                //    {
                //        ChangeStat((Convert.ToInt64(e.CommandArgument.ToString())), "در صف بررسی");
                //    }
                //    else
                //    {
                //        ChangeStat((Convert.ToInt64(e.CommandArgument.ToString())), "تایید شده و در حال بسته بندی");
                //    }
                //    LoadDate();
                //    break;
            }
        }
        private void ChangeStat(Int64 id, string Status)
        {
            try
            {
                var item = Data.DB.Orders.FirstOrDefault(p => p.Id == id);
                if (Status.Contains("تایید"))
                {
                    if (item.Lock.GetValueOrDefault(false).Equals(false))
                    {
                        Data.DB.spInsertScore(17, item.UserId, 1);
                        item.Lock = true;
                    }
                }
                item.Status = Status;
                Data.DB.SubmitChanges();
                Message.MessageGen(lblMessage, "وضعیت جدید ثبت شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        

        protected void DeleteRecord(long id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.GetOrderList().FirstOrDefault(p => p.Id == id);
                if (item != null)
                {
                    switch (Data.DeleteOrder(id))
                    {
                        case true:
                            Message.MessageGen(lblMessage, "سفارش مورد نظر حذف شد", Color.Green);
                            break;
                    }
                }
            }
            catch(Exception ex)
            {
                Message.MessageGen(lblMessage, "خظا در انجام عملیات " + ex.Message, Color.Red);
                //Message.MessageGen(lblMessage,ex.Message, Color.Red);
            }
        }

        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiViewShoppingCart.ActiveViewIndex = 0;
            gvList.EditIndex = -1;
            LoadDate();
        }
        protected void BtnCancelClick(object sender, EventArgs e)
        {
            MultiViewShoppingCart.ActiveViewIndex = 0;
            gvList.EditIndex = -1;
            lblMessage.Text = "";
            LoadDate();
        }
        protected void GvListPageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvList.PageIndex = e.NewPageIndex;
            LoadDate();
        }
       
        protected void AddState(object sender, EventArgs e)
        {
           
        }
      
        protected void btnImportClick(object sender, EventArgs e)
        {
            ExportGridToExcel();
        }
        
        protected void DeleteOrderItem(int id)
        {
            try
            {
                var OD = Data.DB.OrderDetails.FirstOrDefault(p => p.Id.Equals(id));
                var Price = OD.Count.GetValueOrDefault(0) * OD.Price.GetValueOrDefault(0);
                var ordId = OD.OId.GetValueOrDefault(0);
                Data.DB.OrderDetails.DeleteOnSubmit(OD);
                var Ord = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(ordId));
                Ord.Price = Ord.Price - Price;
                Data.DB.SubmitChanges();
                //Selectecord(ordId);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
       
       
     
        public static string GetCharacter(string Char, int Len)
        {
            var Res="";
            if (!String.IsNullOrWhiteSpace(Char))
            {
                if (Char.Length > Len)
                    Res = Char.Substring(Char.Count() - Len);
                else
                    Res = Char;
            }
            return Res;
        }
        public static string GetTime(DateTime dt)
        {
            return dt.Hour.ToString() + ":" + dt.Minute.ToString("00") + ":" + dt.Second.ToString("00");
        }
        public static bool IsState(string State)
        {
            if (String.IsNullOrWhiteSpace(State))
                return false;
            else
                return true;
        }
        public static string StatClass(string Status)
        {
            var res = "pull-right fa fa-";
            if (Status.Equals("در حال رسیدگی"))
            {
                res = res + "refresh text-warning";
            }
            else if (Status.Equals("به اتمام رسیده"))
            {
                res = res + "check text-success";
            }
            else if (Status.Equals("لغو شده"))
            {
                res = res + "times text-danger";
            }
            return res;
        }
}
}