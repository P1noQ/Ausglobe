﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;

namespace admin
{
    public partial class Agent : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
            var State = Data.StateQ().OrderBy(p => p.State1);
            dropState.DataSource = State;
            dropState.DataBind();
        }
        private void LoadDate()
        {
            var item = Data.GetAgent();
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش نمایندگی";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                var item = Data.GetAgent().FirstOrDefault(p => p.Id.Equals(id));
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Name;
                dropState.SelectedValue = item.SID.ToString();
                var city = Data.CityQ(item.SID);
                dropCity.DataSource = city;
                dropCity.DataBind();
                dropCity.SelectedValue = item.CID.ToString();
                txtMan.Text = item.ManName;
                txtAddress.Text = item.Address;
                txtTel.Text = item.Tel;
                txtMail.Text = item.Email;
                txtWeb.Text = item.Site;
                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                if (Data.DeleteAgent(id))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }

        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {

                var Name = Server.HtmlEncode(txtName.Text);
                var State = Convert.ToInt32(dropState.SelectedValue.ToString());
                var City = Convert.ToInt32(dropCity.SelectedValue.ToString());
                var Man = Server.HtmlEncode(txtMan.Text);
                var Address = Server.HtmlEncode(txtAddress.Text);
                var Tel = Server.HtmlEncode(txtTel.Text);
                var Mail = Server.HtmlEncode(txtMail.Text);
                var Site = Server.HtmlEncode(txtWeb.Text);
                if (Data.InsertAgent(Name, State, City, Man, Tel, Address, Mail, Site))
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "فروشگاه وارد شده وجود دارد", Color.Red);
                }
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            lblh.InnerText = "ایجاد نمایندگی";
            txtName.Text = "";
            txtMan.Text = "";
            txtTel.Text = "";
            txtAddress.Text = "";
            txtMail.Text = "";
            txtWeb.Text = "";
            dropState.SelectedIndex = 0;
            var sid = Convert.ToInt32(dropState.SelectedValue);
            var city = Data.CityQ(sid);
            dropCity.DataSource = city;
            dropCity.DataBind();
            Message.EmptyMessage(lblMessage);

            MultiView1.ActiveViewIndex = 1;
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {

                var Name = Server.HtmlEncode(txtName.Text);
                var State = Convert.ToInt32(dropState.SelectedValue.ToString());
                var City = Convert.ToInt32(dropCity.SelectedValue.ToString());
                var Man = Server.HtmlEncode(txtMan.Text);
                var Address = Server.HtmlEncode(txtAddress.Text);
                var Tel = Server.HtmlEncode(txtTel.Text);
                var Mail = Server.HtmlEncode(txtMail.Text);
                var Site = Server.HtmlEncode(txtWeb.Text);
                try
                {
                    Data.EditAgent(int.Parse(hdfId.Value), Name, State, City, Man, Tel, Address, Mail, Site);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
        protected void StateSelect(object sender, EventArgs e)
        {
            try
            {
                var sid = Convert.ToInt32(dropState.SelectedValue);
                var city = Data.CityQ(sid);
                dropCity.DataSource = city;
                dropCity.DataBind();
            }
            catch
            {

            }
        }
    }
}