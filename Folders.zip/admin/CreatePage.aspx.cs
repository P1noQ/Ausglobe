﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;

namespace admin
{
    public partial class CreatePage : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
        }
        private void LoadDate()
        {
            //var page = Library.Db.tblPages.FirstOrDefault(p => p.id.Equals(9));
            //if (page != null)
            //{
            //    ltrMain.Text = page.main; ;
            //}
            var item = Data.GetPage();
            
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش صفحات ایجاد شده";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                var item = Data.GetPage(id).FirstOrDefault(p => p.Id.Equals(id));
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Title;
                txtDes.Text = item.Description;
                txtKeyword.Text = item.Keywords;
                txtBody.Value = item.Body;
                
                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {


                Message.EmptyMessage(lblMessage);
                var item = Data.GetPage(id).FirstOrDefault(p => p.Id.Equals(id));
                if (item != null && Data.DeletePage(id))
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                var Name = Server.HtmlEncode(txtName.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Des = Server.HtmlEncode(txtDes.Text);
                var Body = txtBody.Value;
                if (Data.CreatePage(Name, Keyword, Des, Body))
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                LoadDate();
                MultiView1.ActiveViewIndex = 0;

            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            lblh.InnerText = "ایجاد صفحه";
            txtName.Text = "";
            txtKeyword.Text = "";
            txtDes.Text = "";
            txtBody.Value = "";
            
            Message.EmptyMessage(lblMessage);
           
            MultiView1.ActiveViewIndex = 1;
        }
        
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                var Name = Server.HtmlEncode(txtName.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Des = Server.HtmlEncode(txtDes.Text);
                var Body = txtBody.Value;
                try
                {
                    Data.EditPage(int.Parse(hdfId.Value), Name, Keyword, Des, Body);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
        public static string getUrl(string Id,System.Web.UI.Page Page)
        {
            var res = "";
            res = Page.Request.Url.OriginalString.Replace("/admin", "").Replace("/CreatePage","/Pages") + "?id=" + Id;
            return res;
        }
    }
}