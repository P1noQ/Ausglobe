﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.Profile;

public partial class Factor : System.Web.UI.Page
{
    public Data D = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.PreviousPage == null) return;
        var E = new clsShoppingCart();
        var item = D.DB.Orders.FirstOrDefault();
        if (Request.QueryString["Id"] != null)
        {
            if(Page.PreviousPage.AppRelativeVirtualPath.Contains("Order.aspx"))
            {
                Int64 Ord = 0;
                try
                {
                    Ord = Convert.ToInt64(Request.QueryString["Id"].ToString());
                }
                catch (Exception)
                {
                    return;
                }
                var order = D.DB.Orders.FirstOrDefault(p => p.Id.Equals(Ord));
                if (order == null) return;
                Membership.ApplicationName = "/";
                ProfileManager.ApplicationName = "/";
                var U = Membership.GetUser(order.UserId);
                var cd = "";
                if (order.ConCode.HasValue)
                    cd = order.ConCode.Value.ToString();

                if (order.Status.Equals("در حال رسیدگی"))
                {
                    if (cd.Length > 0)
                    {
                        Page.Title = "پیش فاکتور " + cd;
                        lblCode.Text = "کد پیگیری: " + cd;
                    }
                    else
                        Page.Title = "پیش فاکتور";
                    lblDate.Text = "تاریخ ثبت پیش فاکتور: " + Data.PersianDate(order.Date.GetValueOrDefault(DateTime.Now));
                }
                else
                {
                    if (cd.Length > 0)
                    {
                        Page.Title = "پیش فاکتور " + cd;
                        lblCode.Text = "کد پیگیری: " + cd;
                    }
                    else
                        Page.Title = "فاکتور";
                    lblDate.Text = "تاریخ ثبت فاکتور: " + Data.PersianDate(order.Date.GetValueOrDefault(DateTime.Now));
                }
                lblMail.Text = "ایمیل: <span>" + U.Email + "</span>";
                var pr = Profile.GetProfile(U.UserName);
                
                lblStat.Text = "وضعیت: " + order.Status;
                lblName.Text = "نام و نام خانوادگی: " + pr.Name + " " + pr.Family;
                
                lblMobile.Text = "موبایل: " + pr.Mobile;
                lblTel.Text = "شماره تماس: " + pr.CodeTel + pr.Tel;

                lblAddress.Text = "آدرس: استان " + pr.State + " شهر " + pr.City + " " + pr.Address;
                lblEcoCode.Text = "کد اقتصادی: " + pr.Legal.EconomicCode;

                txtFoot.Text = D.Factor;

                var fac = E.GetFactor(Ord);
                rpFactor.DataSource = fac;
                rpFactor.DataBind();
                Membership.ApplicationName = "/admin";
                ProfileManager.ApplicationName = "/admin";
            }
        }
    }
    public static string Total()
    {
        var res = "";
        var E= new clsShoppingCart();

        if (HttpContext.Current.Request.QueryString["Id"] != null)
        {
            var Ord = Convert.ToInt64(HttpContext.Current.Request.QueryString["Id"]);
            res = Data.PricePersian(E.GetFactor(Ord).Sum<spGetFactorResult>(p => p.TotalPrice.GetValueOrDefault(0)).ToString());
        }
        return res;
    }
}