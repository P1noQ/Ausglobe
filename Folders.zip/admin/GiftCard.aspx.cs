﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Xsl;

public partial class GiftCards : System.Web.UI.Page
{
    Data db = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        BindGird();
    }
    public void BindGird()
    {
        var source = db.GetAllGiftCards();
        gvList.DataSource = source;
        gvList.DataBind();
        if (source.Any())
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

    }
    public void BindForm(Guid GiftCode)
    {

        var item = db.GetCurrentGiftCard(GiftCode);
        ViewState["Image"] = item.Image;
        txtTitle.Text = item.Title;
        txtDisPrice.Text = item.Balance.ToString();
        txtRealPrice.Text = item.Price.ToString();
        imgMenu.ImageUrl = "uploadimage/giftcard/" + item.Image;
        dpDis.Text = Data.PersianDate(item.Expiry.Value);
    }
    private void InsertExcel(string Image, string Title, long Price, long Balance, DateTime Expiry, int Number)
    {
        string procInfo = "type='text/xsl' href='" + "\\transform.xslt" + "'";//Processing info for XSLT
        string TempPath = Server.MapPath("~/");
        string XMLPath = TempPath + "\\Products.xml"; //temp path to store the XML file
        string XLSPath = TempPath + "\\Products.xls";//temp path to store the XLS file


        //Write the dataset as XML file with some XSLT processing information
        using (XmlTextWriter tw = new XmlTextWriter(XMLPath,
                   null))
        {
            Data db = new Data();
            tw.Formatting = Formatting.Indented;
            tw.Indentation = 3;
            tw.WriteStartDocument();
            var dt = db.InsertGiftCard(Image, Title, Price, Balance, Expiry, Number);
            foreach (DataRow dr in dt.Rows)
            {
                dr.SetField<string>("GiftId", dr.Field<string>("GiftId"));
            }
            dt.TableName = "کارت_هدیه";
            var ds = new DataSet();
            ds.Tables.Add(dt);
            //ds.WriteXml(Server.MapPath("~/data.xml"));
            //ds.WriteXmlSchema(Server.MapPath("~/schema.xml"));
            tw.WriteProcessingInstruction("xml-stylesheet", procInfo);
            ds.WriteXml(tw);
        }


        XmlDataDocument xmldoc = new XmlDataDocument();
        xmldoc.Load(XMLPath);
        XslCompiledTransform xsl = new XslCompiledTransform();
        xsl.Load(Server.MapPath(".") + "\\excell\\Transform2.xslt");



        using (XmlTextWriter tw = new XmlTextWriter(XLSPath, System.Text.Encoding.UTF8))
        {
            tw.Formatting = Formatting.Indented;
            tw.Indentation = 3;
            tw.WriteStartDocument();
            xsl.Transform(xmldoc, null, tw);//Performa XSLT transformation.
        }



        //Streams the generated XLS file to the user
        byte[] Buffer = null;
        using (FileStream MyFileStream = new FileStream(XLSPath, FileMode.Open))
        {
            // Total bytes to read: 
            long size;
            size = MyFileStream.Length;
            Buffer = new byte[size];
            MyFileStream.Read(Buffer, 0, int.Parse(MyFileStream.Length.ToString()));
        }
        Response.ContentType = "application/xls";
        string header = "attachment; filename=" + "GiftCardsList" + DateTime.Now.Ticks.ToString() + ".xls";
        Response.AddHeader("content-disposition", header);
        Response.BinaryWrite(Buffer);
        Response.Flush();
        Response.End();

    }
    private void GetExcel(string Date)
    {

        {
            string procInfo = "type='text/xsl' href='" + "\\transform.xslt" + "'";//Processing info for XSLT
            string TempPath = Server.MapPath("~/");
            string XMLPath = TempPath + "\\Products.xml"; //temp path to store the XML file
            string XLSPath = TempPath + "\\Products.xls";//temp path to store the XLS file


            //Write the dataset as XML file with some XSLT processing information
            using (XmlTextWriter tw = new XmlTextWriter(XMLPath,
                       null))
            {
                Data db = new Data();
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                //DateTime dT =Convert.ToDateTime( Date.ToLongDateString());
                var dt = db.GetGroupAddedGiftCardsByDate(Date);
                foreach (DataRow dr in dt.Rows)
                {
                    dr.SetField<string>("GiftId", dr.Field<string>("GiftId"));
                }
                dt.TableName = "کارت_هدیه";
                var ds = new DataSet();
                ds.Tables.Add(dt);
                //ds.WriteXml(Server.MapPath("~/data.xml"));
                //ds.WriteXmlSchema(Server.MapPath("~/schema.xml"));
                tw.WriteProcessingInstruction("xml-stylesheet", procInfo);
                ds.WriteXml(tw);
            }


            XmlDataDocument xmldoc = new XmlDataDocument();
            xmldoc.Load(XMLPath);
            XslCompiledTransform xsl = new XslCompiledTransform();
            xsl.Load(Server.MapPath(".") + "\\excell\\Transform2.xslt");



            using (XmlTextWriter tw = new XmlTextWriter(XLSPath, System.Text.Encoding.UTF8))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                xsl.Transform(xmldoc, null, tw);//Performa XSLT transformation.
            }



            //Streams the generated XLS file to the user
            byte[] Buffer = null;
            using (FileStream MyFileStream = new FileStream(XLSPath, FileMode.Open))
            {
                // Total bytes to read: 
                long size;
                size = MyFileStream.Length;
                Buffer = new byte[size];
                MyFileStream.Read(Buffer, 0, int.Parse(MyFileStream.Length.ToString()));
            }
            Response.ContentType = "application/xls";
            string header = "attachment; filename=" + "GiftCardsList" + DateTime.Now.Ticks.ToString() + ".xls";
            Response.AddHeader("content-disposition", header);
            Response.BinaryWrite(Buffer);
            Response.Flush();
            Response.End();

        }
    }
    protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
    {
        Guid GiftCode = Guid.Parse(e.CommandArgument.ToString());
        ViewState["id"] = GiftCode;
        if (e.CommandName == "change")
        {
            btnSave.Visible = false;
            BtnInsert.Visible = false;
            txtNumber.Visible = false;
            MultiView1.ActiveViewIndex = 2;
            BindForm(GiftCode);

        }
        if (e.CommandName == "remove")
            try
            {
                if (db.DeleteGiftCard(GiftCode, Server.MapPath("~/uploadimage/giftcard/")))
                {
                    Message.MessageGen(lblMessage, ".عملیات با موفقیت انجام شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                }

            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل شده است.", Color.Red);
            }





        BindGird();
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 0;
        BindGird();
    }
    protected void BtnInsertClick(object sender, EventArgs e)
    {

        string title = txtTitle.Text;
        long balance = long.Parse(txtDisPrice.Text);
        DateTime expiry = dpDis.Date.Value;
        long price = long.Parse(txtRealPrice.Text);
        string image = "";
        if (FileUpload1.Visible == true)
        {
            if (FileUpload1.HasFile)
            {
                Random r = new Random();
                int rand = int.Parse(r.Next(1, 100000000).ToString());

                image = FileUpload1.PostedFile.FileName + rand + ".jpg";
                FileUpload1.PostedFile.SaveAs(Server.MapPath("~/uploadimage/giftcard/" + FileUpload1.PostedFile.FileName + rand + ".jpg"));
                if (!db.InsertOneGiftCard(image, title, price, balance, expiry))
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است.", Color.Red);
                    return;
                }
            }
            else
            {
                Message.MessageGen(lblMessage, "ارسال عکس اجباری است.", Color.Red);
                return;
            }
        }
        else
        {
            try
            {
                InsertExcel("def.jpg", title, price, balance, expiry, int.Parse(txtNumber.Text));
                return;
            }

            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است.", Color.Red);
                return;

            }
        }
        //if (db.InsertGiftCard == )
        //{
        //    Message.MessageGen(lblMessage, "سیستم دچار مشکل است.", Color.Red);
        //    return;
        //}

        Message.MessageGen(lblMessage, ".عملیات با موفقیت انجام شد", Color.Green);
        BindGird();
        MultiView1.ActiveViewIndex = 0;

    }
    protected void BtnEditClick(object sender, EventArgs e)
    {
        Guid GiftCode = Guid.Parse(ViewState["id"].ToString());
        string title = txtTitle.Text;
        long balance = long.Parse(txtDisPrice.Text);
        DateTime expiry = dpDis.Date.Value;
        long price = long.Parse(txtRealPrice.Text);
        string image = "";
        Random r = new Random();
        int rand = int.Parse(r.Next(1, 100000000).ToString());
        if (FileUpload1.HasFile)
        {
            image = FileUpload1.PostedFile.FileName + rand + ".jpg";


            if (FileJob.CheckFileExisted(Server.MapPath("~/uploadimage/giftcard/") + ViewState["Image"].ToString()))
                FileJob.DeleteFile(Server.MapPath("~/uploadimage/giftcard/") + ViewState["Image"].ToString());
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/uploadimage/giftcard/" + FileUpload1.PostedFile.FileName + rand + ".jpg"));
        }
        else
        {
            image = ViewState["Image"].ToString();
        }

        if (string.IsNullOrEmpty(image))
        {
            Message.MessageGen(lblMessage, "ارسال عکس اجباری است.", Color.Red);
            return;
        }

        if (!db.EditGiftCards(GiftCode, title, image, price, balance, expiry))
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است.", Color.Red);
            return;

        }
        Message.MessageGen(lblMessage, ".عملیات با موفقیت انجام شد", Color.Green);
        BindGird();
        MultiView1.ActiveViewIndex = 0;


    }
    protected void BtnAddClick(object sender, EventArgs e)
    {
        BtnEdit.Visible = false;
        BtnInsert.Visible = true;
        btnSave.Visible = true;
        txtNumber.Visible = true;
        lblh.InnerText = "ایجاد محصولات";
        MultiView1.ActiveViewIndex = 1;

    }

    public void BindGridArchieve()
    {
        var source = db.GetExcelFileDates();
        gvarchieve.DataSource = source;
        gvarchieve.DataBind();
        if (source.Any())
        {
            try
            {
                gvarchieve.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvarchieve.FooterRow.TableSection = TableRowSection.TableFooter;
            }
            catch { }
        }

    }

    protected void btnAddone_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
        txtNumber.Visible = false;
        FileUpload1.Visible = true;
        imgMenu.Visible = true;


    }

    protected void btnAddGroup_Click1(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 2;
        FileUpload1.Visible = false;
        imgMenu.Visible = false;
        txtNumber.Visible = true;
        btnSave.Visible = false;
        BtnInsert.Text = "ذخیره و دریافت خروجی اکسل";

    }
    protected void btnArchieve_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 3;
        BindGridArchieve();
        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "GetDataTable()", true);


    }
    protected void gvarchieve_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Download")
        {
            DateTime Dt = Convert.ToDateTime(e.CommandArgument);
            string Date = Dt.ToString("yyyy-MM-dd HH:mm:ss.fff", CultureInfo.InvariantCulture);
            GetExcel(Date);

        }
    }
}