﻿doAfterJQueryLoaded(function() {
    jQuery(function($) {
        $('input, select, .checkbox').hover(function() {
            $(this).addClass('ui-state-hover');
        }, function() {
            $(this).removeClass('ui-state-hover');
        }).focus(function() {
            $(this).addClass('ui-state-active');
        }).blur(function() {
            $(this).removeClass('ui-state-active');
        });
        $('.checkbox').click(function(e) {
            if (e.target == this) {
                $(':checkbox', this).click();
            }
        }).disableSelection();
        $(':disabled').addClass('ui-state-disabled');
    });
});

function doAfterJQueryLoaded(action) {
    doAfterCondition(function() { return typeof (jQuery) != 'undefined'; }, action);
}
function doAfterCondition(condition, action, timeout) {
    if (typeof (condition) == 'function' ? condition() : eval(condition)) {
        action();
    } else {
        setTimeout(function() { doAfterCondition(condition, action); }, timeout || 0);
    }
}
