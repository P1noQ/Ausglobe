﻿function del(path) {
    var myData = "{'Path': '" + path + "'}";
    $.ajax
    ({
        data: myData,
        type: "POST",
        dataType: "json",
        url: "http://hooraa.com/Image.aspx/DeleteFile",
        contentType: "application/json; charset=utf-8"
    });
}