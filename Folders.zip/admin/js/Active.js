﻿/* File Created: December 31, 2014 */
function Active(link) {
    $("#nav ul.nav li a[href='" + link + "']").parent().addClass("active");
    if (link != "Index.aspx") {
        var ul = $("#nav ul.nav > li > ul > li > a[href='" + link + "']").parent().parent();
        ul.css("display", "block");
        var li = $(ul).parent();
        li.addClass("active");
        $("#nav ul.nav > li > ul > li > a[href='" + link + "']").parent().parent.parent().addClass("active");
    }

}
$(document).ready(function () {


    var d = document.location.pathname.split("/");
    Active(d[d.length - 1].split(".")[0] + ".aspx");
});