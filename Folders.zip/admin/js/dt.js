﻿$(document).ready(function () {
    var ln = $('#ContentPlaceHolder1_gvList.table.order').length;
    if (ln > 0) {
        var data = $('#ContentPlaceHolder1_gvList').dataTable();
        data.on('search.dt', function () {
            forPoolix();
        });
        data.on('order.dt', function () {
            forPoolix();
        });
        data.on('init.dt', function () {
            forPoolix();
        });
        data.on('length.dt', function () {
            forPoolix();
        });
        data.on('page.dt', function () {
            forPoolix();
        });
    }
    else {
        var db = $('#ContentPlaceHolder1_gvList').dataTable();
        $('#ContentPlaceHolder1_gvList2').dataTable();
        $('thead input[type="checkbox"]').change(function () {

            if ($('.dataTable thead input[type="checkbox"]:checked').length == 1) {
                $('.dataTable tbody input[type="checkbox"]').prop("checked", true);
            }
            else {
                $('.dataTable tbody input[type="checkbox"]').prop("checked", false);
            }
        });
    }
});
function forPoolix() {
    var sum = 0;
    $('.poolix').each(function (i) {

        var hop = this.innerHTML;
        var ind = parseFloat(hop.replace("ريال", "").replace(/,/gi, ""));

        sum = sum + ind;
    });
    var res = "مجموع :" + sum.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1,") + " ريال";
    var p = $(".dataTables_wrapper").html();
    var p = p + '<div class="dataTables_info" role="status" aria-live="polite">مجموع کل :' + res + '</div>';
    $("tfoot").attr("style", "padding-left: 15px; position: absolute; text-align: left; width: 100%;");
    $("tfoot").html(res);
}

function GetDataTable() {

    var data = $('#ContentPlaceHolder1_gvList').dataTable();
}

function GetUserDataTable() {

    var data = $('#ContentPlaceHolder1_GVUser').dataTable();
}
function GetUserPointDataTable() {

    var data = $('#ContentPlaceHolder1_gvList2').dataTable();
}

