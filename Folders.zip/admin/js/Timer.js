﻿var m = 30;
var s = 0;
function timer() {
    if (s == 0 && m == 0) {

    }
    else if (s == 0) {
        s = 59;
        m = m - 1;
    }
    else {
        s = s - 1;
    }
    var sh = "مدت زمان باقیمانده " + m + " دقیقه و " + s + " ثانیه";
    $("#remind").html(sh);

    if (s == 0 && m == 0) {
        setTimeout(timer, 0);
    }
    else {
        setTimeout(timer, 1000);
    }
}
$(document).ready(function () {
    timer();
});