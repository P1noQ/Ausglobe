﻿using System;
using System.Activities.Expressions;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;
using System.Collections.ObjectModel;
using System.Collections.Generic;

namespace admin
{
    public partial class Product : System.Web.UI.Page
    {
        public Data Data = new Data();
        public static DataTable USize;
        public static DataTable UColor;
        public static int gc;
        public static bool edit;
        public static bool editp;
        public static Collection<spDepResult> Rel;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
            DeleteUnsavedData();
        }
        private void LoadDate()
        {
            var item = Data.GetProductD().ToList();
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        static int level2 = 0;
        static int level3 = 0;
        static int level4 = 0;
        protected void ChangeRecord(int id)
        {
            string filename = "";
            try
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش محصولات";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                btnSave.Visible = false;
                var item = Data.GetProduct(id).First();
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);

                USize = Data.UDTSize(id);
                GVSize.DataSource = Data.DB.PSizes.Where(p => p.PID.Equals(int.Parse(hdfId.Value))).ToList();
                GVSize.DataBind();


                UColor = Data.UDTColor(id);
                GVColor.DataSource = UColor.AsDataView();
                GVColor.DataBind();


                hdfspid.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                hdfcpid.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Name;
                txtDescription.Text = item.Description;
                txtKeyword.Text = item.Keyword;

                if (item.DateDis.HasValue)
                {
                    dpDis.Text = Data.PersianDate(item.DateDis.Value);
                }
                if (item.MinAge.HasValue) txtMin.Text = item.MinAge.ToString();
                if (item.MaxAge.HasValue) txtMax.Text = item.MaxAge.ToString();
                txtBrief.Text = item.Brief;
                txtBody.Value = item.Body;
                chkavalible.Checked = item.IsAvalible.GetValueOrDefault(false);
                chkSpec.Checked = item.Spec.GetValueOrDefault(false);
                chkView.Checked = item.View.GetValueOrDefault(false);
                chkIsVisited.Checked = item.IsVisited.GetValueOrDefault(false);
                if (!string.IsNullOrEmpty(item.Image))
                    hdfFile.Value = item.Image;
                else
                    hdfFile.Value = filename;

                drplevel2.Visible = false;
                lbldropleve2.Visible = false;
                drplevel3.Visible = false;
                lbldropleve3.Visible = false;
                //hdfFile2.Value = item.Image2;
                //hdfFile3.Value = item.Image3;
                var list = new ListItemCollection();
                imgMenu.ImageUrl = "uploadimage/product/" + item.Image;

                var droplevel0 = Data.DB.CatProducts.Where(p => p.Parent == null);
                drplevel0.DataSource = droplevel0;
                drplevel0.DataTextField = "Name";
                drplevel0.DataValueField = "Id";
                drplevel0.DataBind();

                int level0 = Data.GetProductDrop(int.Parse(hdfId.Value.ToString()), 0);
                drplevel0.SelectedValue = level0.ToString();

                var droplevel11 = Data.DB.CatProducts.Where(p => p.Parent.Equals(level0));
                drplevel11.DataSource = droplevel11;
                drplevel11.DataTextField = "Name";
                drplevel11.DataValueField = "Id";
                drplevel11.DataBind();

                level2 = Data.GetProductDrop(int.Parse(hdfId.Value.ToString()), 1);
                drplevel11.SelectedValue = level2.ToString();

                level3 = Data.GetProductDrop(int.Parse(hdfId.Value.ToString()), 2);
                if (level3 != 0)
                {
                    drplevel2.Visible = true;
                    lbldropleve2.Visible = true;
                    var droplevel2 = Data.DB.CatProducts.Where(p => p.Parent.Equals(level2));
                    drplevel2.DataSource = droplevel2;
                    drplevel2.DataTextField = "Name";
                    drplevel2.DataValueField = "Id";
                    drplevel2.DataBind();
                    drplevel2.SelectedValue = level3.ToString();

                }
                level4 = Data.GetProductDrop(int.Parse(hdfId.Value.ToString()), 3);
                if (level4 != 0)
                {
                    drplevel3.Visible = true;
                    lbldropleve3.Visible = true;
                    var droplevel3 = Data.DB.CatProducts.Where(p => p.Parent.Equals(level3));
                    drplevel3.DataSource = droplevel3;
                    drplevel3.DataTextField = "Name";
                    drplevel3.DataValueField = "Id";
                    drplevel3.DataBind();
                    drplevel3.SelectedValue = level4.ToString();

                }

                var brand = Data.Getbran(level2);
                dropBrand.DataSource = brand;
                dropBrand.DataBind();
                dropBrand.DataTextField = "Name";
                dropBrand.DataValueField = "Id";

                var BID = Data.DB.Products.FirstOrDefault(p => p.Id == id).BID.GetValueOrDefault(0);

                if (BID > 0)
                {
                    try
                    { dropBrand.SelectedValue = BID.ToString(); }
                    catch { }
                }
                var j = item.Cat;
                var Attr = Data.GetProducttAttr(j, id);
                rpAttribute.DataSource = Attr;
                rpAttribute.DataBind();
                MultiView1.ActiveViewIndex = 1;

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.GetProduct(id).First();


                if (item != null && !string.IsNullOrEmpty(item.Image))
                {
                    var path = "";
                    var thumbPath = "";
                    if (item.Image != "def.jpg")
                    {
                        path = Server.MapPath("~/uploadimage/product/");
                        thumbPath = Server.MapPath("~/uploadimage/product/185/");

                    }

                    switch (Data.DeleteProduct(id, path, thumbPath))
                    {
                        case 0:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                            break;
                        case -1:
                            Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                            break;
                        case 1:
                            Message.MessageGen(lblMessage, "به دلیل وجود سفارش امکان حذف وجود ندارد؛ برای مشاهده لیست سفارشات <a href=\"Order.aspx?pid=" + id.ToString() + "\">کلیک</a> نمایید", Color.Red);
                            break;
                        case 2:
                            Message.MessageGen(lblMessage, "خطا در حذف نظرات", Color.Red);
                            break;
                        case 3:
                            Message.MessageGen(lblMessage, "خطا در حذف علاقه مندیها", Color.Red);
                            break;
                        case 4:
                            Message.MessageGen(lblMessage, "خطا در حذف نوع", Color.Red);
                            break;
                        case 5:
                            Message.MessageGen(lblMessage, "خطا در حذف تکه", Color.Red);
                            break;
                        case 6:
                            Message.MessageGen(lblMessage, "خطا در حذف ویژگیها", Color.Red);
                            break;
                        case 7:
                            Message.MessageGen(lblMessage, "خطا در حذف اشتراک محصولات", Color.Red);
                            break;
                        case 8:
                            Message.MessageGen(lblMessage, "خطا در حذف امتیازدهی به محصول", Color.Red);
                            break;
                        case 9:
                            Message.MessageGen(lblMessage, "خطا در حذف محصول", Color.Red);
                            break;

                    }
                }
            }
            catch (Exception ex)
            {
                Message.MessageGen(lblMessage, ex.Message + "خطا در انجام عملیات", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            MvSize.ActiveViewIndex = 0;
            MvColor.ActiveViewIndex = 0;
            chkNoSize.Checked = false;
            LoadDate();
            DeleteUnsavedData();
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                int PID = 0;
                if (!string.IsNullOrEmpty(hdfId.Value))
                    PID = int.Parse(hdfId.Value);

                Label lblId;
                Repeater rpIn;
                Label lblVId;
                CheckBox chkValue;
                var UAttr = Data.UDTAttr();
                var i = 0;
                if (rpAttribute.Items.Count > 0)
                {
                    foreach (RepeaterItem rItem in rpAttribute.Items)
                    {
                        lblId = (Label)rItem.FindControl("lblId");
                        rpIn = (Repeater)rItem.FindControl("rpIn");
                        var AID = Convert.ToInt32(lblId.Text);
                        foreach (RepeaterItem ri in rpIn.Items)
                        {
                            lblVId = (Label)ri.FindControl("lblVId");
                            chkValue = (CheckBox)ri.FindControl("chkValue");

                            var VID = Convert.ToInt32(lblVId.Text);
                            if (chkValue.Checked)
                            {
                                i += 1;
                                UAttr.Rows.Add(new object[] { i, 0, AID, VID });
                            }
                        }
                    }
                }



                string filename;

                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    filename = "def.jpg";
                }



                if (filename != "def.jpg")
                {

                    if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/product/") + filename)

        || !FileJob.ThumbImage(Server.MapPath("~/uploadimage/product/"), Server.MapPath("~/uploadimage/product/185/")
        , filename, 185, 185)

        )
                    {
                        Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر محصول لطفا دوباره تصویر را وارد نمایید", Color.Red);
                        return;
                    }

                    if (chkNoSize.Checked)
                    {
                        FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/Size/") + filename);

                    }
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Description = Server.HtmlEncode(txtDescription.Text);

                var Image = filename;
                var Body = txtBody.Value;
                var Brief = Server.HtmlEncode(txtBrief.Text);
                var View = chkView.Checked;

                var bitavalible = chkavalible.Checked;



                var DateDis = dpDis.Date;
                int? minAge = null;
                int? maxAge = null;
                
                int Cat;
                //var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                int level = 0;
                if (level4 != 0)
                    level = level4;
                else
                    if (level3 != 0)
                        level = level3;
                    else
                        level = level2;
                // Cat = Convert.ToInt32(drop.SelectedValue.ToString());
                Cat = level;
                var Spec = chkSpec.Checked;
                var Visited = chkIsVisited.Checked;
                var BID = Convert.ToInt32(dropBrand.SelectedValue.ToString());

                if (chkNoSize.Checked)
                {
                    var curSize = Data.DB.PSizes.FirstOrDefault(p => p.PID.Equals(PID) && p.SizeName.Contains("بدون نوع"));
                    if (curSize != null)
                    {
                        curSize.Image = filename;
                        Data.DB.SubmitChanges();
                    }

                }
                if (GVSize.Rows.Count == 0)
                {
                    Message.MessageGen(lblMessage, "درج نوع ضروری می باشد", Color.Red);
                    return;
                }


                if (GVColor.Rows.Count == 0)
                {
                    Message.MessageGen(lblMessage, "درج تکه ضروری می باشد", Color.Red);
                    return;
                }
                var res = Data.InsertProduct(Name, Cat, null, Body, Brief, Keyword,
                    Description, Image, DateDis, Spec, View, 1, 100, BID,
                    bitavalible, Visited, UAttr);

                switch (res)
                {
                    case 0:
                        {
                            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                            int pid = Data.DB.Products.FirstOrDefault().Id;
                            if (GVSize.Rows.Count > 0)
                            {

                                var ZeroSizes = Data.DB.PSizes.Where(p => p.PID.Equals(0));
                                foreach (var item in ZeroSizes)
                                {
                                    item.PID = pid;
                                    Data.DB.SubmitChanges();
                                }

                            }
                            if (GVColor.Rows.Count > 0)
                            {
                                var ZeroColors = Data.DB.PColors.Where(p => p.PID.Equals(0));
                                foreach (var item in ZeroColors)
                                {
                                    item.PID = pid;
                                    Data.DB.SubmitChanges();
                                }

                            }

                        }
                        break;
                    case 1:
                        Message.MessageGen(lblMessage, "با نام مورد نظر محصول دیگری وجود دارد", Color.Red);
                        break;
                    case 2:
                        Message.MessageGen(lblMessage, "خطا در درج محصول", Color.Red);
                        break;
                    case 3:
                        Message.MessageGen(lblMessage, "خطا در درج ویژگی محصول", Color.Red);
                        break;
                    case 4:
                        Message.MessageGen(lblMessage, "خطا در درج نوع محصول", Color.Red);
                        break;
                    case 5:
                        Message.MessageGen(lblMessage, "خطا در درج تکه محصول", Color.Red);
                        break;
                }
                //LoadDate();
                var btn = (Button)sender;
                if (btn.CommandName.Equals("Save"))
                {
                    ClearForm();
                    MultiView1.ActiveViewIndex = 0;
                    LoadDate();
                }
                ClearForm();


            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }

        public void ClearForm()
        {
            txtName.Text = "";
            txtKeyword.Text = "";
            txtDescription.Text = "";
            dpDis.Text = "";
            txtMin.Text = "";
            txtMax.Text = "";
            txtBrief.Text = "";
            txtBody.Value = "";
            hdfId.Value = "0";
            chkavalible.Checked = false;
            chkIsVisited.Checked = false;
            chkSpec.Checked = false;
            chkView.Checked = false;
            chkNoSize.Checked = false;
            chkNoColor.Checked = false;
            //USize = Data.UDTSize();
            //UColor = Data.UDTColor();

            GVSize.DataSource = null;
            GVSize.DataBind();
            hdfspid.Value = "0";

            drpSize.DataSource = null;
            drpSize.DataBind();

            GVColor.DataSource = null;
            GVColor.DataBind();
            hdfcpid.Value = "0";
            dropBrand.SelectedIndex = 0;
            drplevel0.SelectedIndex = 0;
            drplevel11.SelectedIndex = 0;
            if (drplevel2.Visible == true)
            drplevel2.SelectedIndex = 0;
            if (drplevel3.Visible == true)
            drplevel3.SelectedIndex = 0;
            ////foreach (var d in rpDropMenu.Controls)
            ////{

            ////    try
            ////    {
            ////        DropDownList dl = d as DropDownList;
            ////        dl.SelectedIndex = 0;
            ////    }
            ////    catch { }
            ////}
            //CheckBox chkValue = new CheckBox();
            //foreach (RepeaterItem ri in rpAttribute.Items)
            //{
            //    try
            //    {
            //        chkValue = (CheckBox)ri.FindControl("chkValue");

            //        chkValue.Checked = false;
            //    }
            //    catch { }
            //}
            foreach (var item in rpAttribute.Items)
            {
                try
                {
                    if (item is CheckBox)
                        (item as CheckBox).Checked = false;
                }
                catch { }

            }
        }

        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            btnSave.Visible = true;
            lblh.InnerText = "ایجاد محصولات";
            //USize = Data.UDTSize();
            //UColor = Data.UDTColor();

            GVSize.DataSource = null;
            GVSize.DataBind();
            GVColor.DataSource = null;
            GVColor.DataBind();
            hdfId.Value = "0";
            hdfspid.Value = "0";


            //GVColor.DataSource = UColor.AsDataView();
            //GVColor.DataBind();
            hdfcpid.Value = "0";

            txtName.Text = "";
            txtDescription.Text = "";
            txtKeyword.Text = "";
            txtBrief.Text = "";
            txtBody.Value = "";
            txtMin.Text = "";
            txtMax.Text = "";
            dpDis.Text = "";
            imgMenu.ImageUrl = "";
            chkSpec.Checked = false;
            chkView.Checked = false;
            chkIsVisited.Checked = false;
            edit = false;
            gc = 0;
            var ml = dropMenuLevel.SelectedIndex + 2;
            Message.EmptyMessage(lblMessage);
            var List = new ListItemCollection();
            var j = 0;
            for (int i = 1; i <= ml; i++)
            {
                if (i == 1)
                {
                    j = 0;
                }
                else
                {
                    j = Data.GetProductChildMenu(ml, j).First().Id;
                }
                List.Add(new ListItem(j.ToString(), ml.ToString()));
            }
            j = Data.GetProductChildMenu(ml, j).First().Id;
            var Attr = Data.GetProducttAttr(j);
            rpAttribute.DataSource = Attr;
            rpAttribute.DataBind();

            drplevel3.Visible = false;
            lbldropleve3.Visible = false;
            var droplevel0 = Data.DB.CatProducts.Where(p => p.Parent == null);
            drplevel0.DataSource = droplevel0;
            drplevel0.DataTextField = "Name";
            drplevel0.DataValueField = "Id";
            drplevel0.DataBind();



            var droplevel11 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel0.SelectedValue));
            drplevel11.DataSource = droplevel11;
            drplevel11.DataTextField = "Name";
            drplevel11.DataValueField = "Id";
            drplevel11.DataBind();

            level2 = int.Parse(drplevel11.SelectedValue);


            if (dropMenuLevel.SelectedIndex == 1)
            {
                 try
                {
                drplevel2.Visible = true;
                lbldropleve2.Visible = true;
                var droplevel2 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel11.SelectedValue));
                drplevel2.DataSource = droplevel2;
                drplevel2.DataTextField = "Name";
                drplevel2.DataValueField = "Id";
                drplevel2.DataBind();
                if (droplevel2.Count()> 0)
                level3 = int.Parse(drplevel2.SelectedValue);
                }
                 catch { }

            }
            if (dropMenuLevel.SelectedIndex == 2)
            {
                try
                {
                    drplevel2.Visible = true;
                    lbldropleve2.Visible = true;
                    drplevel3.Visible = true;
                    lbldropleve3.Visible = true;
                    var droplevel3 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel2.SelectedValue));
                    drplevel3.DataSource = droplevel3;
                    drplevel3.DataTextField = "Name";
                    drplevel3.DataValueField = "Id";
                    drplevel3.DataBind();
                    if (droplevel3.Count() > 0)
                        level4 = int.Parse(drplevel3.SelectedValue);
                }
                catch { }
               

            }

            var brand = Data.Getbran(level2);
            dropBrand.DataSource = brand;
            dropBrand.DataBind();
            dropBrand.DataTextField = "Name";
            dropBrand.DataValueField = "Id";

            MultiView1.ActiveViewIndex = 1;
        }
        protected void rpDropMenu_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {

        }


        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                int PID = 0;
                if (!string.IsNullOrEmpty(hdfId.Value))
                    PID = int.Parse(hdfId.Value);
                string filename;
                var lastIndex = 0;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;


                    if (hdfFile.Value != "def.jpg")
                    {
                        if (FileJob.CheckFileExisted(Server.MapPath("~/uploadimage/product/") + hdfFile.Value))
                            FileJob.DeleteFile(Server.MapPath("~/uploadimage/product/") + hdfFile.Value);
                        if (FileJob.CheckFileExisted(Server.MapPath("~/uploadimage/product/185/") + hdfFile.Value))
                            FileJob.DeleteFile(Server.MapPath("~/uploadimage/product/185/") + hdfFile.Value);


                    }
                    FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/product/") + filename);

                    FileJob.ThumbImage(Server.MapPath("~/uploadimage/product/"), Server.MapPath("~/uploadimage/product/185/")
                               , filename, 185, 185);

                    if (chkNoSize.Checked)
                    {
                        FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/Size/") + filename);
                    }
                }
                else
                {
                    filename = hdfFile.Value;

                    if (chkNoSize.Checked)
                    {
                        FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/Size/") + filename);
                    }
                }

                if (chkNoSize.Checked)
                {
                    var curSize = Data.DB.PSizes.FirstOrDefault(p => p.PID.Equals(PID) && p.SizeName.Contains("بدون نوع"));
                    if (curSize != null)
                    {
                        curSize.Image = filename;

                        Data.DB.SubmitChanges();

                    }

                }

                if (GVSize.Rows.Count == 0)
                {
                    Message.MessageGen(lblMessage, "درج نوع ضروری می باشد", Color.Red);
                    return;
                }

                if (GVColor.Rows.Count == 0)
                {
                    Message.MessageGen(lblMessage, "درج تکه ضروری می باشد", Color.Red);
                    return;
                }


                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;
                int level = 0;
                if (level4 != 0)
                    level = level4;
                else
                    if (level3 != 0)
                        level = level3;
                else
                    level = level2;
                // var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                var Id = Convert.ToInt32(hdfId.Value);
                // var Cat = Convert.ToInt32(drop.SelectedValue.ToString());
                var Cat = level;
                var BID = Convert.ToInt32(dropBrand.SelectedValue.ToString());
                var Catp = Data.GetProductD(Id).First().Cat;
                var UAttr = Data.UDTAttr();
                var UEAttr = Data.UDTAttr();
                var fat = Data.GetProductAttr(Id);

                foreach (ProductAttr pa in fat)
                {
                    UAttr.Rows.Add(new object[] { pa.Id, pa.PID, pa.AID, pa.VID });
                }
                Label lblId;
                Repeater rpIn;
                Label lblVId;
                CheckBox chkValue;
                var i = 0;
                if (rpAttribute.Items.Count > 0)
                {

                    foreach (RepeaterItem rItem in rpAttribute.Items)
                    {
                        lblId = (Label)rItem.FindControl("lblId");
                        rpIn = (Repeater)rItem.FindControl("rpIn");
                        var AID = Convert.ToInt32(lblId.Text);
                        foreach (RepeaterItem ri in rpIn.Items)
                        {
                            lblVId = (Label)ri.FindControl("lblVId");
                            chkValue = (CheckBox)ri.FindControl("chkValue");

                            var VID = Convert.ToInt32(lblVId.Text);
                            if (chkValue.Checked)
                            {
                                i += 1;
                                UEAttr.Rows.Add(new object[] { i, Id, AID, VID });
                            }
                        }
                    }
                }

                if (UEAttr.Rows.Count.Equals(0))
                    UAttr.Rows.Clear();
                else if (UAttr.Rows.Count.Equals(0))
                    UAttr = UEAttr.Copy();
                else
                {
                    if (UAttr.Rows.Count > UEAttr.Rows.Count)
                    {
                        for (int k = UAttr.Rows.Count - 1; k >= UEAttr.Rows.Count; k--)
                        {
                            UAttr.Rows.RemoveAt(k);
                        }
                    }
                    for (int j = 0; j < UEAttr.Rows.Count; j++)
                    {
                        if (j < UAttr.Rows.Count)
                        {
                            UAttr.Rows[j].SetField("AID", UEAttr.Rows[j].Field<int>("AID"));
                            UAttr.Rows[j].SetField("VID", UEAttr.Rows[j].Field<int>("VID"));
                            lastIndex = UAttr.Rows[j].Field<int>("Id");
                        }
                        else
                        {
                            lastIndex += 1;
                            UAttr.Rows.Add(new object[] { lastIndex, Id, UEAttr.Rows[j].Field<int>("AID"), UEAttr.Rows[j].Field<int>("VID") });
                        }
                    }
                }

                var Brief = Server.HtmlEncode(txtBrief.Text);

                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Description = Server.HtmlEncode(txtDescription.Text);
                var Spec = chkSpec.Checked;
                var view = chkView.Checked;
                var Body = txtBody.Value;
                var Visited = chkIsVisited.Checked;


                var DateDis = dpDis.Date;
                var bitavlb = chkavalible.Checked;

                int? minAge = null;
                if (txtMin.Text.Length > 0) minAge = Convert.ToInt32(Server.HtmlEncode(txtMin.Text));
                int? maxAge = null;
                if (txtMin.Text.Length > 0) maxAge = Convert.ToInt32(Server.HtmlEncode(txtMax.Text));
                try
                {
                    var res = Data.EditProduct(Id, Name, Cat, null, Body, Brief, Keyword, Description, Image,
                        DateDis, Spec, view, minAge, maxAge, BID, bitavlb, Visited, UAttr);
                    switch (res)
                    {
                        case 0:
                            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                            break;
                        case 1:
                            Message.MessageGen(lblMessage, "با نام مورد نظر محصول دیگری وجود دارد", Color.Red);
                            break;
                        case 2:
                            Message.MessageGen(lblMessage, "خطا در ویرایش محصول", Color.Red);
                            break;
                        case 3:
                            Message.MessageGen(lblMessage, "خطا در ویرایش ویژگی محصول", Color.Red);
                            break;
                        case 4:
                            Message.MessageGen(lblMessage, "خطا در ویرایش نوع محصول", Color.Red);
                            break;
                        case 5:
                            Message.MessageGen(lblMessage, "خطا در ویرایش تکه محصول", Color.Red);
                            break;
                    }
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }

                MultiView1.ActiveViewIndex = 0;
                LoadDate();

                ClearForm();

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }

        #region SizeArea
        protected void btnAddSizeClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessageSize);
            slblh.Text = "ایجاد نوع";
            txtSizeName.Text = "";


            btnInsertSize.Visible = true;
            btnEditSize.Visible = false;
            MvSize.ActiveViewIndex = 1;
        }
        protected void btnBackSizeClick(object sender, EventArgs e)
        {
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);
            MvSize.ActiveViewIndex = 0;
            GVSize.DataSource = Data.DB.PSizes.Where(p => p.PID.Equals(PID)).ToList();
            GVSize.DataBind();
        }
        protected void GVSize_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            Message.EmptyMessage(lblMessageSize);
            var Id = Convert.ToInt32(e.CommandArgument.ToString());
            if (e.CommandName.Equals("change"))
            {
                var r = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(Id));
                slblh.Text = "ویرایش نوع";
                txtSizeName.Text = r.SizeName;



                hdfsid.Value = Id.ToString();

                btnInsertSize.Visible = false;
                btnEditSize.Visible = true;
                MvSize.ActiveViewIndex = 1;
            }
            else
            {
                int PID = 0;
                if (!string.IsNullOrEmpty(hdfId.Value))
                    PID = int.Parse(hdfId.Value);
                var r = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(Id));
                var deps = Data.DB.PColors.Where(p => p.SID.Equals(Id));

                if (deps.Count() > 0)
                {
                    Message.MessageGen(lblMessageSize, "ابتدا تکههای مربوط به این نوع را حذف نمایید",
                        Color.Red);
                    return;
                }
                //var PID = r.PID;

                if (Data.DB.OrderDetails.Any(p => p.SID.HasValue && p.SID.Value.Equals(Id) && p.PId.Equals(PID)))
                {
                    Message.MessageGen(lblMessageSize, "با این نوع سفارش درج شده است ،برای مشاهده سفارش <a href=\"Order.aspx?pid=" + PID.ToString() + "\">کلیک</a> نمایید",
                        Color.Red);
                    return;
                }




                //FileJob.DeleteFile(Server.MapPath("uploadimage/size/" + r.Image));
                //FileJob.DeleteFile(Server.MapPath("uploadimage/size/50/" + r.Image));
                var q = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(Id));
                Data.DB.PSizes.DeleteOnSubmit(q);
                Data.DB.SubmitChanges();
                //USize.Rows.Remove(USize.Select().FirstOrDefault(p => p.Field<int>("Id").Equals(Id)));
                GVSize.DataSource = Data.DB.PSizes.Where(p => p.PID.Equals(PID)).ToList();
                GVSize.DataBind();
            }
        }
        protected void BtnEditSizeClick(object sender, EventArgs e)
        {
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);
            Message.EmptyMessage(lblMessageSize);
            var ID = Convert.ToInt32(hdfsid.Value.ToString());

            var r = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(ID));


            var Col = Data.DB.OrderDetails.FirstOrDefault(p => p.SID.Equals(ID) && p.PId == PID);

            if (Col != null)
            {

                Message.MessageGen(lblMessageColor, "امکان تغییر نوع وجود ندارد برای مشاهده سفارش <a href=\"Order.aspx?pid=" + int.Parse(hdfId.Value) + "\">کلیک</a>نمایید",
                Color.Red);
                return;
            }
            string filename = r.Image;

            if (FileUpload2.HasFile)
            {
                filename =
                    Number.ConvertToLatin(
                        Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" +
                    DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload2.FileName;


                if (!FileJob.SaveFile(FileUpload2, Server.MapPath("~/uploadimage/size/") + filename) ||
                    !FileJob.ThumbImage(Server.MapPath("~/uploadimage/size/"), Server.MapPath("~/uploadimage/size/50/"),
                        filename, 50, 50))
                {
                    Message.MessageGen(lblMessageSize, "مشکل در ذخیره تصویر نوع لطفا دوباره تصویر را وارد نمایید",
                        Color.Red);
                    return;
                }
            }

            var sizeName = Server.HtmlEncode(txtSizeName.Text);


            //var ch = USize.Rows[ind];
            //ch["SizeName"] = sizeName;
            //ch["Price"] = price;
            //ch["CoPrice"] = coPrice;
            //ch["RealPrice"] = realPrice;
            //ch["DisPrice"] = Data.ToDBNull(disPrice);
            //ch["CharPrice"] = Data.ToDBNull(charPrice);
            //ch["DateDis"] = Data.ToDBNull(dateDis);
            //ch["Count"] = Data.ToDBNull(Count);
            //ch["Image"] = filename;
            //ch.AcceptChanges();

            var NewSize = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(ID));
            NewSize.SizeName = sizeName;
            NewSize.Image = filename;
            Data.DB.SubmitChanges();

            GVSize.DataSource = Data.DB.PSizes.Where(p => p.PID.Equals(PID)).ToList();
            GVSize.DataBind();
            var Gridsrc = from siz in Data.DB.PSizes
                          join color in Data.DB.PColors
                          on siz.Id equals color.SID
                          let Name = color.Name
                          let SizeName = siz.SizeName
                          let Image = color.Image
                          let Id = color.Id
                          where color.PID == PID
                          select new { Name, SizeName, Image, Id };

            //UColor = Data.DB.PColors;
            GVColor.DataSource = Gridsrc;
            GVColor.DataBind();
            MvSize.ActiveViewIndex = 0;

        }
        List<PSize> NewS = new List<PSize>();
        protected void BtnInsertSizeClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessageSize);
            string filename = "";

            if (FileUpload2.HasFile)
            {
                filename =
                    Number.ConvertToLatin(
                        Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" +
                    DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload2.FileName;
            }
            else
            {
                Message.MessageGen(lblMessageSize, "تصویر نوع را لطفا انتخاب نمایید", Color.Red);
                return;
            }
            if (!FileJob.SaveFile(FileUpload2, Server.MapPath("~/uploadimage/size/") + filename) ||
                    !FileJob.ThumbImage(Server.MapPath("~/uploadimage/size/"), Server.MapPath("~/uploadimage/size/50/"),
                        filename, 50, 50))
            {
                Message.MessageGen(lblMessageSize, "مشکل در ذخیره تصویر نوع لطفا دوباره تصویر را وارد نمایید",
                    Color.Red);
                return;
            }

            //var lastId = 1;
            //if (USize.Rows.Count > 0)
            //{
            //    lastId = USize.Rows[USize.Rows.Count - 1].Field<int>("Id") + 1;
            //}
            var sizeName = Server.HtmlEncode(txtSizeName.Text);

            //var pid = Data.DB.Products.FirstOrDefault().Id;

            //USize.Rows.Add(new object[]
            //{
            //    lastId, pid, sizeName, price, coPrice, realPrice, Data.ToDBNull(disPrice), Data.ToDBNull(charPrice),
            //    Data.ToDBNull(dateDis), filename, Data.ToDBNull(Count)
            //});

            int Pid = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                Pid = int.Parse(hdfId.Value);
            var NewSize = new PSize
            {
                PID = Pid,
                SizeName = sizeName,
                Image = filename

            };
            Data.DB.PSizes.InsertOnSubmit(NewSize);
            Data.DB.SubmitChanges();

            GVSize.DataSource = Data.DB.PSizes.Where(p => p.PID.Equals(Pid)).ToList();
            GVSize.DataBind();
            MvSize.ActiveViewIndex = 0;


        }

        #endregion

        #region Color Area
        protected void btnAddColorClick(object sender, EventArgs e)
        {
            clblh.Text = "ایجاد تکه";


            if (GVSize.Rows.Count == 0)
            {
                Message.MessageGen(lblMessageColor, "برای ایجاد تکه ابتدا نوع را ایجاد نمایید", Color.Red);
                return;
            }
            //var dv = USize.AsDataView();
            //dv.Sort = "SizeName";
            //var drptb = dv.ToTable();
            //drptb.Select().ToList().ForEach(p => drpSize.Items.Add(p.Field<string>("SizeName")));
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);

            var Sizes = Data.DB.PSizes.Where(p => p.PID.Equals(PID)).ToList();
            drpSize.DataSource = Sizes;
            drpSize.DataBind();


            txtColorName.Text = "";
            txtPrice.Text = "";
            txtRealPrice.Text = "";
            txtCoPrice.Text = "";
            txtDisPrice.Text = "";
            txtGift.Text = "";
            dpSizeDis.Text = "";
            txtCountS.Text = "";
            imgColor.ImageUrl = "";
            BtnInsertColor.Visible = true;
            BtnEditColor.Visible = false;
            MvColor.ActiveViewIndex = 1;
        }

        protected void btnBackColorClick(object sender, EventArgs e)
        {
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);
            MvColor.ActiveViewIndex = 0;
            var Gridsrc = from siz in Data.DB.PSizes
                          join color in Data.DB.PColors
                          on siz.Id equals color.SID
                          let Name = color.Name
                          let SizeName = siz.SizeName
                          let Image = color.Image
                          let Id = color.Id
                          where color.PID == PID
                          select new { Name, SizeName, Image, Id };

            //UColor = Data.DB.PColors;
            GVColor.DataSource = Gridsrc;
            GVColor.DataBind();
        }


        protected void GVColor_OnRowCommand(object sender, GridViewCommandEventArgs e)
        {
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);

            Message.EmptyMessage(lblMessageColor);
            var ID = Convert.ToInt32(e.CommandArgument.ToString());
            if (e.CommandName.Equals("change"))
            {
                var CheckSize = Data.DB.PSizes.Where(p => p.Id.Equals(PID));
                var r = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(ID));
                clblh.Text = "ویرایش تکه";
                //if (USize != null)
                //{

                //var dv = USize.AsDataView();
                //dv.Sort = "SizeName";
                //var drptb = dv.ToTable();

                //drptb.Select().ToList().ForEach(p => drpSize.Items.Add(p.Field<string>("SizeName")));

                //drpSize.SelectedValue = r.Field<string>("SizeName");


                var Sizes = Data.DB.PSizes.Where(p => p.PID.Equals(PID)).ToList();
                drpSize.DataSource = Sizes;
                drpSize.DataBind();
                //drpSize.DataTextField = Sizes[0];
                //drpSize.DataValueField = Sizes[0];
                //}
                txtColorName.Text = r.Name;
                txtPrice.Text = r.Price.ToString();
                txtRealPrice.Text = r.RealPrice.ToString();
                txtCoPrice.Text = r.CoPrice.ToString();
                int? disPrice;
                disPrice = r.DisPrice.GetValueOrDefault();
                txtDisPrice.Text = disPrice.HasValue ? disPrice.Value.ToString() : "";
                int? charPrice;
                charPrice = r.CharPrice;
                txtGift.Text = charPrice.HasValue ? charPrice.Value.ToString() : "";
                dpSizeDis.Date = r.DateDis;
                int? count;
                count = r.Count;

                txtCountS.Text = count.HasValue ? count.Value.ToString() : "";
                try
                {
                    imgColor.ImageUrl = "uploadimage/color/" + r.Image;
                }
                catch { }
                hdfcid.Value = ID.ToString();

                BtnInsertColor.Visible = false;
                BtnEditColor.Visible = true;
                MvColor.ActiveViewIndex = 1;
            }
            else
            {
                var r = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(ID));
                //var PID = Convert.ToInt32(hdfcpid.Value.ToString());
                //if (PID > 0)
                //{
                //var Col = Data.UDTColor(PID).Select("Id='" + Id + "'").First();

                //if (Col != null)
                //{
                var sid = r.SID;

                if (
                    Data.DB.OrderDetails.Any(
                        p => p.CID.GetValueOrDefault(0).Equals(ID) && p.SID.GetValueOrDefault(0).Equals(sid)))
                {
                    Message.MessageGen(lblMessageColor,
                        "امکان حذف تکه وجود ندارد برای مشاهده سفارش <a href=\"Order.aspx?pid=" + PID.ToString() +
                        "\">کلیک</a>نمایید", Color.Red);
                    return;
                }
                //}
                //}
                try
                {
                    if (r.Image != "defColor.jpg")
                        FileJob.DeleteFile(Server.MapPath("uploadimage/color/" + r.Image));
                }
                catch { }
                //UColor.Rows.Remove(UColor.Select().FirstOrDefault(p => p.Field<int>("Id").Equals(Id)));
                var del = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(ID));
                Data.DB.PColors.DeleteOnSubmit(del);
                Data.DB.SubmitChanges();


                MvColor.ActiveViewIndex = 0;
                var Gridsrc = from siz in Data.DB.PSizes
                              join color in Data.DB.PColors
                              on siz.Id equals color.SID
                              let Name = color.Name
                              let SizeName = siz.SizeName
                              let Image = color.Image
                              let Id = color.Id
                              where color.PID == PID
                              select new { Name, SizeName, Image, Id };

                //UColor = Data.DB.PColors;
                GVColor.DataSource = Gridsrc;
                GVColor.DataBind();
            }
        }
        protected void BtnEditColorClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessageColor);
            var ID = Convert.ToInt32(hdfcid.Value.ToString());
            //var PID = Convert.ToInt32(hdfcpid.Value.ToString());
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);

            var r = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(ID));
            //var ind = UColor.Rows.IndexOf(r);

            string filename = r.Image;

            if (FileUpload3.HasFile)
            {
                filename =
                    Number.ConvertToLatin(
                        Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" +
                    DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload3.FileName;


                if (!FileJob.SaveFile(FileUpload3, Server.MapPath("~/uploadimage/color/") + filename)
                    || !FileJob.ThumbImage(Server.MapPath("~/uploadimage/color/"), Server.MapPath("~/uploadimage/color/50/"),
                        filename, 50, 50))
                {
                    Message.MessageGen(lblMessageColor, "مشکل در ذخیره تصویر نوع لطفا دوباره تصویر را وارد نمایید",
                        Color.Red);
                    return;
                }
            }
            var sizeName = Server.HtmlEncode(drpSize.SelectedItem.Text);
            var ColorName = Server.HtmlEncode(txtColorName.Text);
            var price = Convert.ToInt32(Server.HtmlEncode(txtPrice.Text));
            var realPrice = Convert.ToInt32(Server.HtmlEncode(txtRealPrice.Text));
            var coPrice = Convert.ToInt32(Server.HtmlEncode(txtCoPrice.Text));
            int? charPrice = null;
            try
            {
                charPrice = Convert.ToInt32(Server.HtmlEncode(txtGift.Text));
            }
            catch
            {
            }
            int? disPrice = null;
            try
            {
                disPrice = Convert.ToInt32(Server.HtmlEncode(txtDisPrice.Text));
            }
            catch
            {
            }
            DateTime? dateDis;
            dateDis = dpSizeDis.Date;
            int? Count = null;
            int? InitCount = null;
            try
            {
                Count = Convert.ToInt32(Server.HtmlEncode(txtCountS.Text));
                InitCount = Convert.ToInt32(Server.HtmlEncode(txtCountS.Text));
            }
            catch
            {
            }
            //var ch = UColor.Rows[ind];

            //if (PID > 0)
            //{
            //var Col = Data.UDTColor(PID).Select("Id='" + Id + "'").First();

            //if (Col != null)
            //{
            var sid = r.SID;

            if (
                Data.DB.OrderDetails.Any(
                    p => p.CID.GetValueOrDefault(0).Equals(ID) && p.SID.GetValueOrDefault(0).Equals(sid)))
            {
                Message.MessageGen(lblMessageColor, "امکان تغییر تکه وجود ندارد برای مشاهده سفارش <a href=\"Order.aspx?pid=" + PID.ToString() + "\">کلیک</a>نمایید",
                Color.Red);
                return;
            }
            //        else
            //        {
            //            ch["SizeName"] = sizeName;
            //            ch["SID"] = 0;
            //        }
            //    //}
            ////}
            //ch["Name"] = ColorName;
            //ch["Image"] = filename;
            //ch.AcceptChanges();

            var SizeId = Data.DB.PSizes.FirstOrDefault(p => p.SizeName.Equals(sizeName) && p.PID.Equals(PID)).Id;
            var q = Data.DB.PColors.FirstOrDefault(p => p.Id.Equals(ID));
            q.Image = filename;
            q.Name = ColorName;
            q.SID = SizeId;
            q.CharPrice = charPrice;
            q.CoPrice = coPrice;
            q.Count = Count;
            q.InitCount = Count;
            q.DateDis = dateDis;
            q.DisPrice = disPrice;
            q.Image = filename;
            q.Price = price;
            q.RealPrice = realPrice;
            Data.DB.SubmitChanges();

            var Gridsrc = from siz in Data.DB.PSizes
                          join color in Data.DB.PColors
                          on siz.Id equals color.SID
                          let Name = color.Name
                          let SizeName = siz.SizeName
                          let Image = color.Image
                          let Id = color.Id
                          where color.PID == PID
                          select new { Name, SizeName, Image, Id };

            //UColor = Data.DB.PColors;
            GVColor.DataSource = Gridsrc;
            GVColor.DataBind();
            MvColor.ActiveViewIndex = 0;
        }
        protected void BtnInsertColorClick(object sender, EventArgs e)
        {
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);

            Message.EmptyMessage(lblMessageSize);
            var FlieName = "";
            if (FileUpload3.HasFile)
            {
                FlieName =
                    Number.ConvertToLatin(
                        Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" +
                    DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload3.FileName;
            }
            else
            {
                if (txtColorName.Text.Contains("بدون تکه"))
                    FlieName = "defColor.jpg";
                else
                {
                    Message.MessageGen(lblMessageSize, "درج تصویر برای تکه (بغیر از حالت درج بدون تکه) الزامی می باشد", Color.Red);
                    return;
                }
            }
            var size = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(drpSize.SelectedValue) && p.PID.Equals(PID));
            //var pid = Convert.ToInt32(hdfspid.Value);

            var price = Convert.ToInt32(Server.HtmlEncode(txtPrice.Text));
            var realPrice = Convert.ToInt32(Server.HtmlEncode(txtRealPrice.Text));
            var coPrice = Convert.ToInt32(Server.HtmlEncode(txtCoPrice.Text));
            int? charPrice = null;
            try
            {
                charPrice = Convert.ToInt32(Server.HtmlEncode(txtGift.Text));
            }
            catch
            {
            }
            int? disPrice = null;
            try
            {
                disPrice = Convert.ToInt32(Server.HtmlEncode(txtDisPrice.Text));
            }
            catch
            {
            }
            DateTime? dateDis;
            dateDis = dpSizeDis.Date;
            int? Count = null;
            try
            {
                Count = Convert.ToInt32(Server.HtmlEncode(txtCountS.Text));
            }
            catch
            {
            }
            PColor NewColor = new PColor
            {
                PID = PID,
                SID = size.Id,
                Name = txtColorName.Text,
                Image = FlieName,
                CharPrice = charPrice,
                CoPrice = coPrice,
                Count = Count,
                InitCount = Count,
                DateDis = dateDis,
                DisPrice = disPrice,
                RealPrice = realPrice,
                Price = price
            };
            Data.DB.PColors.InsertOnSubmit(NewColor);
            Data.DB.SubmitChanges();

            if (FlieName != "defColor.jpg")
            {
                if (!FileJob.SaveFile(FileUpload3, Server.MapPath("~/uploadimage/color/") + FlieName) ||
                !FileJob.ThumbImage(Server.MapPath("~/uploadimage/color/"), Server.MapPath("~/uploadimage/color/50/"),
                    FlieName, 50, 50))
                {
                    Message.MessageGen(lblMessageColor, "مشکل در ذخیره تصویر تکه لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
            }


            var Gridsrc = from siz in Data.DB.PSizes
                          join color in Data.DB.PColors
                          on siz.Id equals color.SID
                          let Name = color.Name
                          let SizeName = siz.SizeName
                          let Image = color.Image
                          let Id = color.Id
                          where color.PID == PID
                          select new { Name, SizeName, Image, Id };

            //UColor = Data.DB.PColors;
            GVColor.DataSource = Gridsrc;
            //GVColor.DataSource = Gridsrc;
            GVColor.DataBind();
            MvColor.ActiveViewIndex = 0;


        }
        #endregion

        public object GetAttrValue(int PID, int AID)
        {
            return Data.GetProductAttrValue(PID, AID).ToList();
        }

        public static bool Active(int Id)
        {
            if (Id == 0)
                return false;
            else
                return true;
        }


        protected void chkNoSize_CheckedChanged(object sender, EventArgs e)
        {
            int PID = 0;
            if (!string.IsNullOrEmpty(hdfId.Value))
                PID = int.Parse(hdfId.Value);

            var image = "";
            if (!string.IsNullOrEmpty(hdfFile.Value))
                image = hdfFile.Value;

            if (chkNoSize.Checked)
            {
                var curSize = Data.DB.PSizes.Where(p => p.PID.Equals(PID));
                if (curSize.Count() > 0)
                {
                    Message.MessageGen(lblMessage, "برای درج بدون نوع ابتدا نوع های موجود را حذف نمایید", Color.Red);
                    return;
                }
                else
                {
                    var NoSize = Data.DB.PSizes.FirstOrDefault(p => p.PID.Equals(PID) && p.SizeName.Contains("بدون تکه"));
                    if (NoSize == null)
                    {
                        InsertNoSize(image, PID);
                        GVSize.DataSource = Data.DB.PSizes.Where(p => p.PID.Equals(PID)).ToList();
                        GVSize.DataBind();
                    }
                }

            }
        }

        private void InsertNoSize(string Image, int pid)
        {
            var newNoSize = new PSize { SizeName = "بدون نوع", Image = Image, PID = pid };
            Data.DB.PSizes.InsertOnSubmit(newNoSize);
            Data.DB.SubmitChanges();
        }
        private void DeleteUnsavedData()
        {
            try
            {
                var UnsavedColors = Data.DB.PColors.Where(p => p.PID.Equals(0));
                if (UnsavedColors != null)
                {
                    Data.DB.PColors.DeleteAllOnSubmit(UnsavedColors);
                    Data.DB.SubmitChanges();
                }
                var UnsavedSizes = Data.DB.PSizes.Where(p => p.PID.Equals(0));
                if (UnsavedSizes != null)
                {
                    Data.DB.PSizes.DeleteAllOnSubmit(UnsavedSizes);
                    Data.DB.SubmitChanges();
                }
            }
            catch { }
        }
        protected void drplevel0_SelectedIndexChanged(object sender, EventArgs e)
        {

            var droplevel11 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel0.SelectedValue));
            drplevel11.DataSource = droplevel11;
            drplevel11.DataTextField = "Name";
            drplevel11.DataValueField = "Id";
            drplevel11.DataBind();
            level2 = int.Parse(drplevel11.SelectedValue);

            var brand = Data.Getbran(int.Parse(drplevel11.SelectedValue));
            dropBrand.DataSource = brand;
            dropBrand.DataBind();
            dropBrand.DataTextField = "Name";
            dropBrand.DataValueField = "Id";

            var droplevel2 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel11.SelectedValue));
            if (drplevel2.Visible && droplevel2.Any())
            {
                
                drplevel2.DataSource = droplevel2;
                drplevel2.DataTextField = "Name";
                drplevel2.DataValueField = "Id";
                drplevel2.DataBind();
                if (droplevel2.Count() > 0)
                    level3 = int.Parse(drplevel2.SelectedValue);

            }
            else level3 = 0;

            var droplevel3 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel2.SelectedValue));
            if (drplevel3.Visible && droplevel3.Any())
            {
                
                drplevel3.DataSource = droplevel3;
                drplevel3.DataTextField = "Name";
                drplevel3.DataValueField = "Id";
                drplevel3.DataBind();
                if (droplevel3.Count() > 0)
                    level4 = int.Parse(drplevel3.SelectedValue);

            }
            else level4 = 0;
        }
        protected void drplevel11_SelectedIndexChanged(object sender, EventArgs e)
        {

            var brand = Data.Getbran(int.Parse(drplevel11.SelectedValue));
            dropBrand.DataSource = brand;
            dropBrand.DataBind();
            dropBrand.DataTextField = "Name";
            dropBrand.DataValueField = "Id";

            level2 = int.Parse(drplevel11.SelectedValue);

            if (drplevel2.Visible)
            {
                var droplevel2 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel11.SelectedValue));
                drplevel2.DataSource = droplevel2;
                drplevel2.DataTextField = "Name";
                drplevel2.DataValueField = "Id";
                drplevel2.DataBind();
                if (droplevel2.Count() > 0)
                    level3 = int.Parse(drplevel2.SelectedValue);

            }
            else level3 = 0;
            if (drplevel3.Visible)
            {
                var droplevel3 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel2.SelectedValue));
                drplevel3.DataSource = droplevel3;
                drplevel3.DataTextField = "Name";
                drplevel3.DataValueField = "Id";
                drplevel3.DataBind();
                if (droplevel3.Count() > 0)
                    level4 = int.Parse(drplevel3.SelectedValue);

            }
            else level4 = 0;
        }
        protected void drplevel2_SelectedIndexChanged(object sender, EventArgs e)
        {
            level3 = int.Parse(drplevel2.SelectedValue);
            if (drplevel3.Visible)
            {
                var droplevel3 = Data.DB.CatProducts.Where(p => p.Parent.Equals(drplevel2.SelectedValue));
                drplevel3.DataSource = droplevel3;
                drplevel3.DataTextField = "Name";
                drplevel3.DataValueField = "Id";
                drplevel3.DataBind();
                if (droplevel3.Count() > 0)
                    level4 = int.Parse(drplevel3.SelectedValue);

            }
            else level4 = 0;
        }
    }
}