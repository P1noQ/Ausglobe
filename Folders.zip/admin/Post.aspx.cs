﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using Persia;


namespace admin
{
    public partial class AdminPost : System.Web.UI.Page
    {
        public const string SrcImage = "~/uploadimage/post/";

        public Data dt = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadDate();
        }


        private void LoadDate()
        {

            var item = dt.GetPosts();
            gvList.DataSource = item;
            gvList.DataBind();
            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "Edit":
                        EditRecord(Convert.ToInt32(e.CommandArgument));
                        break;

                    case "delete":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        break;
                }
            }
            catch
            {

                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                if (id.Equals(1))
                {
                    Message.MessageGen(lblMessage, "امکان حذف رکورد مورد نظر نمی باشد این رکورد برای سیستم تعریف پیش فرض شده است", Color.Red);
                    return;
                }
                if (dt.DB.Orders.Any(p=>p.PostId.Equals(id)))
                {
                    Message.MessageGen(lblMessage, "امکان حذف رکورد مورد نظر نمی باشد این رکورد درسفارش محصولات ثبت شده است می توانید برای نمایش نشدن این رکورد وضعیت نمایش آن را غیر فعال کنید یا تمام سفارش های مرتبط به این رکورد را حذف کرده بعد اقدام به حذف رکورد مورد نظر نمایید ", Color.Red);
                    return;
                }
                var item = dt.GetPosts().FirstOrDefault(p => p.Id == id);

                if (item != null && !string.IsNullOrEmpty(item.Image))

                    FileJob.DeleteFile(Server.MapPath(SrcImage) + item.Image);
                if (dt.DeletePost(id))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void EditRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                Img.Visible = true;
                btnEdit.Visible = true;
                btnInsert.Visible = false;
                MultuViewItem.ActiveViewIndex = 1;
                var item = dt.GetPosts().FirstOrDefault(p => p.Id.Equals(id));
                if (item == null)
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                    return;
                }
                idhiden.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtTitle.Text = item.Title;
                txtBrief.Text = item.Breif;
                txtPrice.Text = item.Price.ToString(CultureInfo.InvariantCulture);
                txtPriceFree.Text = item.priceFree.ToString(CultureInfo.InvariantCulture);
                Img.ImageUrl = SrcImage + item.Image;
                himage1.Value = item.Image;
                ckActive.Checked = item.Active;
                lblhm.InnerText = "ویرایش شیوه ارسال";
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string savePaths;
                if (FileUpload1.HasFile)
                {
                    savePaths = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    FileJob.SaveFile(FileUpload1, Server.MapPath(SrcImage) + savePaths);
                }
                else
                {
                    savePaths = himage1.Value;
                }

                var item = dt.GetPosts().FirstOrDefault(p => p.Id == int.Parse(idhiden.Value));
                if (!string.IsNullOrEmpty(savePaths))
                {
                    
                    if (FileUpload1.HasFile)
                        if (item != null && !string.IsNullOrEmpty(item.Image))
                            FileJob.DeleteFile(Server.MapPath(SrcImage) + item.Image);
                }
                if (dt.EditPost(int.Parse(idhiden.Value), txtTitle.Text, txtBrief.Text, int.Parse(txtPrice.Text), int.Parse(txtPriceFree.Text), savePaths, ckActive.Checked))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                MultuViewItem.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 1;
            }
        }

        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                var savePaths = "";
                if (FileUpload1.HasFile)
                {
                    savePaths = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر نوع ارسال را انتخاب نمایید", Color.Red);
                    return;
                }
                
                if (string.IsNullOrEmpty(savePaths))
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر  را انتخاب نمایید", Color.Red);
                    return;
                }
                if (txtTitle.Text == null)
                {
                    Message.MessageGen(lblMessage, "لطفا عنوان  را وارد نمایید", Color.Red);
                    return;
                }
                if (txtBrief.Text == null)
                {
                    Message.MessageGen(lblMessage, "لطفا خلاصه متن  را وارد نمایید", Color.Red);
                    return;
                }

                if (!FileJob.SaveFile(FileUpload1, Server.MapPath(SrcImage) + savePaths))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر لطفا دوباره تصویر را وار نمایید", Color.Red);
                    return;
                }

                if (dt.InsertPost(txtTitle.Text, txtBrief.Text, int.Parse(txtPrice.Text), int.Parse(txtPriceFree.Text), savePaths, ckActive.Checked))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                MultuViewItem.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 1;
            }
        }

        protected void GvListDataBound(object sender, EventArgs e)
        {
            lblMessage.Text = string.Empty;
        }

        protected void GvListRowEditing(object sender, GridViewEditEventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 1;
        }

        protected void GvListRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            LoadDate();
        }
        
        protected void BtnBackClick(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 0;
            Message.EmptyMessage(lblMessage);
            LoadDate();
        }

        protected void BtnAddClick(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 1;
            btnInsert.Visible = true;
            btnEdit.Visible = false;
            Img.Visible = false;
            txtTitle.Text = string.Empty;
            txtBrief.Text = string.Empty;
            txtPrice.Text = string.Empty;
            txtPriceFree.Text = string.Empty;
            ckActive.Checked = true;
            lblhm.InnerText = "ایجاد شیوه ارسال";
            Message.EmptyMessage(lblMessage);
        }


    }
}