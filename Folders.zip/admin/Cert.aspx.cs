﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;

namespace admin
{
    public partial class Cert : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            
            LoadDate();
        }
        private void LoadDate()
        {
            var item = Data.GetCert().ToList();
            gvList.DataSource = item;
            gvList.DataBind();

            txtTitle.Text = Data.GetDescription(2, "t");
            txtDescription.Text = Data.GetDescription(2, "d");
            txtKeyword.Text = Data.GetDescription(2, "k");

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void EditKey(object sender, EventArgs e)
        {
            try
            {

                var Title = Server.HtmlEncode(txtTitle.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Des = Server.HtmlEncode(txtDescription.Text);
                Data.EditDescription(2, Title, Keyword, Des);
                Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            LoadDate();
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                Message.EmptyMessage(lblMessage1);
                lblh.InnerText = "ویرایش تاییدیه";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                var item = Data.GetCert(id).First();
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Title;
                txtBrief.Text = item.Brief;
                txtBody.Value = item.Body;
                hdfFile.Value = item.Image;
                imgMenu.ImageUrl = "uploadimage/cert/" + item.Image;
                MultiView1.ActiveViewIndex = 1;

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                Message.EmptyMessage(lblMessage1);
                var item = Data.GetCert(id).First();

                if (item != null && !string.IsNullOrEmpty(item.Image))
                {
                    switch (Data.DeleteCert(id, Server.MapPath("~/uploadimage/cert/")))
                    {
                        case true:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                            break;
                        case false:
                            Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                            break;
                    }
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر تاییدیه را انتخاب نمایید", Color.Red);
                    return;
                }
                if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/cert/") + filename))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر تاییدیه لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;
                var Body = txtBody.Value;
                
                var p = Data.InsertCert(Name, Image, Body,"");
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            lblh.InnerText = "ایجاد تاییدیه";
            txtName.Text = "";
            txtBrief.Text = "";
            txtBody.Value = "";
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 1;
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    FileJob.DeleteFile(Server.MapPath("~/uploadimage/cert/") + hdfFile.Value);
                    FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/cert/") + filename);
                }
                else
                {
                    filename = hdfFile.Value;
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;

                
                var Brief = Server.HtmlEncode(txtBrief.Text);
                var Body = txtBody.Value;

                try
                {
                    Data.EditCert(int.Parse(hdfId.Value), Name,Image, Body,"");
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
    }
}