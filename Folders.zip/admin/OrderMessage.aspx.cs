﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.Security;

namespace admin
{
    public partial class OrderMessage : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            var userd = Data.UserDataAdmin(Membership.ApplicationName);
            var ae = new List<spGetUserDataAdminResult>();

            var n = new spGetUserDataAdminResult
            {
                UserName = "انتخاب نمایید",
                CreateDate = DateTime.Now,
                Email = ""
            };
            ae.Add(n);
            ae.AddRange(userd.AsEnumerable<spGetUserDataAdminResult>());

            df.DataSource = ae;
            df.DataBind();

            LoadUnitS();
        }
        private void LoadUnitS()
        {
            var item = Data.GetUnit().Where(p => p.Type.Equals(3));
            GridView2.DataSource = item;
            GridView2.DataBind();
        }
        
        protected void GrRowCommand2(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteUnit(Convert.ToInt32(e.CommandArgument));
                        LoadUnitS();
                        break;
                    case "change":
                        ChangeShop(Convert.ToInt32(e.CommandArgument));
                        LoadUnitS();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteUnit(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                if (Data.DeleteUnit(id))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeShop(int Id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                txtuMail.Text = "";
                txtsMail.Text = "";
                var item = Data.GetUnit().FirstOrDefault(p => p.Id.Equals(Id));
                if (item.User.Length > 0)
                {
                    if (item.Mail.Length > 0)
                    {
                        ckMail.Checked = true;
                        txtuMail.Text = item.Mail;
                    }
                    else
                        ckMail.Checked = false;
                    if (item.Tel.Length > 0)
                        ckMob.Checked = true;
                    else
                        ckMob.Checked = false;
                    
                    ckPan.Checked = item.InPanel.GetValueOrDefault(false);
                    df.SelectedValue = item.User;

                    rbUser.Checked = true;
                    rbMail.Checked = false;
                    btnAddPart.CommandName = "Edit";
                    btnAddPart.CssClass = "form-control m-xs btn btn-primary btne1 text-center";
                    btnAddPart.CommandArgument = item.Id.ToString();
                }
                else
                {
                    df.SelectedIndex = 0;
                    rbMail.Checked = true;
                    rbUser.Checked = false;
                    ckMob.Checked = false;
                    ckMail.Checked = false;
                    ckPan.Checked = false;
                    txtsMail.Text = item.Mail;
                    txtsMob.Text = item.Tel;
                    btnAddPart.CssClass = "form-control m-xs btn btn-primary btne2 text-center";
                    btnAddPart.CommandName = "EditW";
                    btnAddPart.CommandArgument = item.Id.ToString();
                }
                Message.EmptyMessage(lblMessage);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void CheckedChanged(object sender, EventArgs e)
        {
            if (ckMail.Checked)
            {
                if (btnAddPart.CommandName.Contains("Edit"))
                {
                    var i = Convert.ToInt32(btnAddPart.CommandArgument);
                    var us = Data.GetPart(0).FirstOrDefault(p => p.Id.Equals(i)).User;
                    df.SelectedValue = us;
                    rbUser.Checked = true;
                }
                var userd = Data.UserDataAdmin(Membership.ApplicationName);
                var mail = userd.FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;
                txtuMail.Text = mail;
                txtuMail.ToolTip = mail;
            }
            else
            {
                txtuMail.Text = "";
                txtuMail.ToolTip = "";
                if (btnAddPart.CommandName.Contains("Edit"))
                {
                    var i = Convert.ToInt32(btnAddPart.CommandArgument);
                    var us = Data.GetPart(0).FirstOrDefault(p => p.Id.Equals(i)).User;
                    df.SelectedValue = us;
                    rbUser.Checked = true;
                }
            }
        }
        protected void btnAddOrder_Command(object sender, CommandEventArgs e)
        {
            if (e.CommandName.Equals("Add"))
            {
                try
                {
                    var userd = Data.UserDataAdmin(Membership.ApplicationName);

                    var Mail = "";
                    var Tel = "";
                    if (rbMail.Checked)
                    {
                        Mail = Server.HtmlEncode(txtsMail.Text);
                        Tel = Server.HtmlEncode(txtsMob.Text);
                    }
                    else
                    {
                        if (ckMail.Checked)
                            Mail = userd.FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;
                        if (ckMob.Checked)
                            Tel = Profile.GetProfile(df.SelectedValue).Mobile;
                    }
                    //Data.UserDataAdmin(Membership.ApplicationName).FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;
                    
                    var User = "";
                    if (df.SelectedIndex > 0) User = df.SelectedValue;
                    bool? act;
                    if (User.Length.Equals(0))
                        act = null;
                    else
                        act = ckPan.Checked;

                    var res = Data.InsertUnit(Mail, Tel, 3, User, act);
                    switch (res)
                    {
                        case 0:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                            break;
                        case 1:
                            Message.MessageGen(lblMessage, "پست الکترونیکی قبلا درج شده است", Color.Red);
                            break;
                        case 2:
                            Message.MessageGen(lblMessage, "شماره موبایل قبلا درج شده است", Color.Red);
                            break;
                        case 3:
                            Message.MessageGen(lblMessage, "نام کاربری قبلا درج شده است", Color.Red);
                            break;
                        case 4:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                            txtsMail.Text = string.Empty;
                            txtsMob.Text = string.Empty;
                            txtuMail.Text = string.Empty;
                            rbUser.Checked = false;
                            rbMail.Checked = false;
                            ckMob.Checked = false;
                            ckMail.Checked = false;
                            ckPan.Checked = false;
                            df.SelectedIndex = 0;
                            break;
                    }
                }
                catch
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                }
            }
            else
            {
                var i = Convert.ToInt32(e.CommandArgument.ToString());
                var user = Data.GetUnit().FirstOrDefault(p => p.Id.Equals(i));
                var Mail = "";
                var Tel = "";
                bool? act;
                act = null;
                if (e.CommandName.Equals("Edit"))
                {
                    if (ckMob.Checked)
                        Tel = Profile.GetProfile(user.User).Mobile;

                    if (ckMail.Checked)
                        Mail = Data.UserDataAdmin(Membership.ApplicationName).FirstOrDefault(p => p.UserName.Equals(user.User)).Email;

                    if (ckPan.Checked)
                        act = true;
                    else
                        act = null;

                    if (Data.EditUnit(i, Mail, Tel, act))
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    else
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                else
                {
                    Mail = Server.HtmlEncode(txtsMail.Text);
                    Tel = Server.HtmlEncode(txtsMob.Text);
                    if (Data.EditUnit(i, Mail, Tel, act))
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    else
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                txtsMail.Text = string.Empty;
                txtsMob.Text = string.Empty;
                txtuMail.Text = string.Empty;
                rbUser.Checked = false;
                rbMail.Checked = false;
                ckMob.Checked = false;
                ckMail.Checked = false;
                ckPan.Checked = false;
                rbUser.Checked = false;
                rbMail.Checked = false;
                
                df.SelectedIndex = 0;
            }
            btnAddPart.CssClass = "form-control m-xs btn btn-primary text-center";
            btnAddPart.CommandName = "Add";
            LoadUnitS();
        }
        public static bool IsAct(bool? Act)
        {
            return Act.GetValueOrDefault(false);
        }
        public static bool IsAct(string Val)
        {
            var res = Val.Length > 0 ? true : false;
            return res;
        }
        public static string Act(string Type)
        {
            var res = "";
            switch (Type)
            {
                case "1":
                    res = "ثبت نام";
                    break;
                case "2":
                    res = "امتیاز دهی";
                    break;
                case "3":
                    res = "صدور فاکتور";
                    break;
                default:
                    res = "";
                    break;
            }
            return res;
        }
    }
}