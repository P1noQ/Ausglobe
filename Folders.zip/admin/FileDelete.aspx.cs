﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
namespace admin
{
    public partial class FileDelete : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadData();
        }
        private void LoadData()
        {
            var size = Server.MapPath("uploadimage/size");

            var color = Server.MapPath("uploadimage/color");

            var FinS = Directory.EnumerateFiles(size);

            var FinC = Directory.EnumerateFiles(color);



            var f = Data.CFile(); ;

            foreach (string a in FinS)
            {
                var r = f.NewRow();
                r["Id"] = f.Rows.Count + 1;
                r["Name"] = a.Replace(size + "\\", "");
                r["Path"] = "size";
                f.Rows.Add(r);
            }
            foreach (string a in FinC)
            {
                var r = f.NewRow();
                r["Id"] = f.Rows.Count + 1;
                r["Name"] = a.Replace(color + "\\", "");
                r["Path"] = "color";
                f.Rows.Add(r);
            }

            var res = Data.GetUnused(f).DefaultView;

            gvList.DataSource = res;
            gvList.DataBind();
            if (res.Count > 0)
            {
                gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvList.FooterRow.TableSection = TableRowSection.TableFooter;
            }
        }
        public static string Path(string Path, string Name)
        {
            var res = "";
            if (Path.Equals("size"))
                res = "uploadimage/size/" + Name;
            else if (Path.Equals("color"))
                res = "uploadimage/color/" + Name;

            return res;
        }
        protected void gvList_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            var file = e.CommandArgument.ToString();
            var thumb = "";
            if (file.Contains("/size/"))
                thumb = file.Replace("/size/", "/size/50/");
            FileJob.DeleteFile(Server.MapPath(file));

            if (thumb.Length > 0)
                FileJob.DeleteFile(Server.MapPath(thumb));

            LoadData();
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Success();", true);
        }
    }
}