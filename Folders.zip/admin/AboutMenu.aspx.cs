﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;

namespace admin
{
    public partial class AboutMenu : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
        }
        private void LoadDate()
        {
            
            var item = Data.GetAboutMenu(1);
            dropLevel.Items.Clear();
            dropLevel.Items.Add(new ListItem("سطح 1", "0"));
            if (item.Count(p => p.Level0.Length > 0) > 0)
            {
                dropLevel.Items.Add(new ListItem("سطح 2", "1"));
            }
            gvList.DataSource = item;
            gvList.DataBind();

            var menu = Data.GetInfoMenuDrop(1);
            rpDropLevel.DataSource = menu;
            rpDropLevel.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "removeMenu":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "changeMenu":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument), false);
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument), false);
                        LoadDate();
                        break;

                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeRecord(int id, bool menu = true)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش منو درباره ما";
                BtnEditM.Visible = true;
                BtnInsertM.Visible = false;
                if (menu)
                {
                    var item = Data.GetInfoMenuDrop(1).FirstOrDefault(p => p.Id.Equals(id));
                    if (item == null) return;

                    hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                    hdfFile.Value = item.Image;
                    imgMenuM.ImageUrl = "uploadimage/cata/" + item.Image;
                    txtNameM.Text = item.Name;
                    txtBodyM.Value = item.Body;
                    MultiView1.ActiveViewIndex = 1;
                }
                else
                {
                    lblh.InnerText = "ویرایش منو درباره ما";
                    BtnEdit.Visible = true;
                    BtnInsert.Visible = false;
                    var item = Data.GetInfo(id).First();
                    if (item == null) return;
                    hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                    hdfFile.Value = item.Image;
                    imgMenu.ImageUrl = "uploadimage/info/" + item.Image;
                    rpDropLevel.SelectedValue = item.Cat.ToString();
                    txtName.Text = item.Name;
                    txtBody.Value = item.Body;

                    txtURL.Text = item.URL;
                    txtBody.Value = item.Body;

                    MultiView1.ActiveViewIndex = 2;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id, bool menu = true)
        {
            try
            {
                Message.EmptyMessage(lblMessage);

                if (menu)
                {
                    var item = Data.GetInfoMenuDrop(1).FirstOrDefault(p => p.Id.Equals(id));
                    if (item != null && !string.IsNullOrEmpty(item.Image))
                    {
                        switch (Data.DeleteInfoMenu(id, Server.MapPath("~/uploadimage/cata/")))
                        {
                            case 2:
                                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                                break;
                            case 1:
                                Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                                break;
                            case 0:
                                Message.MessageGen(lblMessage, "منو سطح دوم با این رکورد درج شده است ", Color.Red);
                                break;
                        }
                    }
                }
                else
                {
                    var item = Data.GetInfo(id).First();
                    if (item != null && !string.IsNullOrEmpty(item.Image))
                    {
                        if (Data.DeleteInfo(id, Server.MapPath("~/uploadimage/info/")))
                        {
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                        }
                        else
                        {
                            Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                        }
                    }
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        protected void BtnInsertMClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1M.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1M.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر منو را انتخاب نمایید", Color.Red);
                    return;
                }
                if (!FileJob.SaveFile(FileUpload1M, Server.MapPath("~/uploadimage/cata/") + filename))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر منو لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
                var Name = Server.HtmlEncode(txtNameM.Text);
                var Body = txtBodyM.Value;
                var Image = filename;

                if (Data.InsertInfoMenu(Name, 1, Body, Image))
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر صفحه درباره ما را انتخاب نمایید", Color.Red);
                    return;
                }
                if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/info/") + filename))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر صفحه درباره ما لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }

                var Cat = Convert.ToInt32(rpDropLevel.SelectedValue.ToString());
                var Name = Server.HtmlEncode(txtName.Text);
                var Body = txtBody.Value;
                var URL = Server.HtmlEncode(txtURL.Text);
                var Image = filename;
                var ret = false;
                if (URL.Length > 0)
                {
                    ret = Data.InsertInfo(Name, Cat, Image, Body, URL);
                }
                else
                {
                    ret = Data.InsertInfo(Name, Cat, Body, Image);
                }
                if (ret)
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            
            if (dropLevel.SelectedValue == "0")
            {
                BtnEditM.Visible = false;
                BtnInsertM.Visible = true;
                lblhm.InnerText = "ایجاد منو درباره ما";
                txtName.Text = "";
                txtBodyM.Value = "";
                imgMenuM.ImageUrl = "";
                MultiView1.ActiveViewIndex = 1;
            }
            else
            {
                BtnEdit.Visible = false;
                BtnInsert.Visible = true;
                lblh.InnerText = "ایجاد منو درباره ما";
                txtName.Text = "";
                txtBody.Value = "";
                imgMenu.ImageUrl = "";
                MultiView1.ActiveViewIndex = 2;
            }
            Message.EmptyMessage(lblMessage);

            
        }
        protected void BtnEditMClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1M.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1M.FileName;
                    FileJob.DeleteFile(Server.MapPath("~/uploadimage/cata/") + hdfFile.Value);
                    FileJob.SaveFile(FileUpload1M, Server.MapPath("~/uploadimage/cata/") + filename);
                }
                else
                {
                    filename = hdfFile.Value;
                }
                var Name = Server.HtmlEncode(txtNameM.Text);
                var Body = txtBodyM.Value;
                var Image = filename;

                try
                {
                    Data.EditInfoMenu(int.Parse(hdfId.Value), Name, Body, Image);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    FileJob.DeleteFile(Server.MapPath("~/uploadimage/info/") + hdfFile.Value);
                    FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/info/") + filename);
                }
                else
                {
                    filename = hdfFile.Value;
                }
                var Cat = Convert.ToInt32(rpDropLevel.SelectedValue.ToString());
                var Name = Server.HtmlEncode(txtName.Text);

                var URL = Server.HtmlEncode((txtURL.Text));

                var Body = txtBody.Value;
                if (URL.Length == 0)
                    URL = null;
                

                var Image = filename;
                try
                {
                    Data.EditInfo(int.Parse(hdfId.Value), Cat, Name, Body, Image, URL);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 2;
            }
        }
        public static string Command(string Command, bool? menu)
        {
            if (menu.GetValueOrDefault(false))
                return Command + "Menu";
            else
                return Command;

        }
    }
}