﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PointToRial : System.Web.UI.Page
{
    public Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        Pricetxt.Text = dt.DB.P2Rs.FirstOrDefault(p => p.Id.Equals(1)).Price.ToString();
        Pointtxt.Text = dt.DB.P2Rs.FirstOrDefault(p => p.Id.Equals(1)).Point.ToString();
    }
    protected void BtnInsert_Click(object sender, EventArgs e)
    {
        try
        {
            var item = dt.DB.P2Rs.FirstOrDefault(p => p.Id.Equals(1));
            item.Price = Convert.ToInt32(Server.HtmlEncode(Pricetxt.Text));
            item.Point = Convert.ToInt32(Server.HtmlEncode(Pointtxt.Text));
            dt.DB.SubmitChanges();
        }
        catch (Exception)
        {

            throw;
        }

    }
}