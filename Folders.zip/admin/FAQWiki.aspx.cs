﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
namespace admin
{
    public partial class FAQ : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadData();
        }
        private void LoadData()
        {
            txtBody.Value = Data.FAQWiki;
            txtTitle.Text = Data.GetDescription(7, "t");
            txtDescription.Text = Data.GetDescription(7, "d");
            txtKeyword.Text = Data.GetDescription(7, "k");
        }
        protected void EditKey(object sender, EventArgs e)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var Title = Server.HtmlEncode(txtTitle.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Des = Server.HtmlEncode(txtDescription.Text);
                Data.EditDescription(7, Title, Keyword, Des);
                Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            LoadData();
        }

        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                Message.EmptyMessage(lblMessage1);
                var text = txtBody.Value;
                Data.FAQWiki = text;
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
    }
}