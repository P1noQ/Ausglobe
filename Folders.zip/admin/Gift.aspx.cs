﻿using Persia;
using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;

namespace admin
{
    public partial class AdminGift : System.Web.UI.Page
    {
        public const string Type = "gift";
        public const int Level = 0;
        public const int DescId = 24;
        public const int Width = 200;
        public const int Height = 200;
        public const string SrcImage = "~/uploadimage/gift/";
        public const string SrcImageThumb = "~/uploadimage/gift/200/";

        public Data dt = new Data();
        protected void Page_Load(object sender, EventArgs e) 
        {
            if (IsPostBack) return;
            
            LoadDate();
        }

        private void LoadDate()
        {
            var item = dt.GetGift();
            gvList.DataSource = item;
            gvList.DataBind();
            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "Edit":
                        EditRecord(Convert.ToInt32(e.CommandArgument));
                        break;

                    case "delete":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var res = dt.DeleteGift(id,SrcImage,SrcImageThumb);
                if (res.Equals(1))
                {
                    Message.MessageGen(lblMessage, "این تصویر کادو در سفارش محصولات وجود دارد برا حذف آن باید تمام سفارش محصولات این تصویر کادو را حذف کرده یا" + "<br/>" + "گزینه وضعیت نمایش کارت پستال را غیر فعال کنید تا در سایت نمایش داده نشود", Color.OrangeRed);
                    return;
                }
                else if(res.Equals(2))
                {
                    Message.MessageGen(lblMessage, "حذف تصویر کادو امکانپذیر نمی باشد", Color.Red);
                    return;
                }
                else if (res.Equals(3))
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void EditRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                imgMenu.Visible = true;
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                lblh.InnerText = "ویرایش تصویر کادو";
                MultuViewItem.ActiveViewIndex = 1;
                var item = dt.GetGift().FirstOrDefault(p => p.id.Equals(id));
                if (item == null)
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                    return;
                }
                hdfId.Value = item.id.ToString(CultureInfo.InvariantCulture);
                imgMenu.ImageUrl = SrcImage + item.Image;
                hdfFile.Value = item.Image;

                lblCreateDate.Text = Data.PersianDate(item.Date);
                chkView.Checked = item.Active;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    FileJob.DeleteFile(Server.MapPath(SrcImage) + hdfFile.Value);
                    FileJob.DeleteFile(Server.MapPath(SrcImageThumb) + hdfFile.Value);
                    FileJob.SaveFile(FileUpload1, Server.MapPath(SrcImage) + filename);
                    FileJob.ThumbImage(SrcImage, SrcImageThumb, filename, Width, Height);
                }
                else
                {
                    filename = hdfFile.Value;
                }

                if (dt.EditGift(int.Parse(hdfId.Value), filename, chkView.Checked))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                MultuViewItem.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 1;
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultuViewItem.ActiveViewIndex = 0;
            LoadDate();
        }

        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {


                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر کادو را انتخاب نمایید", Color.Red);
                    return;
                }
                if (!FileJob.SaveFile(FileUpload1, Server.MapPath(SrcImage) + filename))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر کادو لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
                if (!FileJob.ThumbImage(Server.MapPath(SrcImage), Server.MapPath(SrcImageThumb), filename, Width, Height))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر کادو لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
                if (dt.InsertGift(filename, chkView.Checked))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                MultuViewItem.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 1;
            }
        }

        protected void GvListDataBound(object sender, EventArgs e)
        {
            lblMessage.Text = string.Empty;
        }

        protected void GvListRowEditing(object sender, GridViewEditEventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 1;
        }

        protected void GvListRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            LoadDate();
        }

        protected void BtnCancelClick(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 0;
            Message.EmptyMessage(lblMessage);
            LoadDate();
        }

        protected void BtnAddClick(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 1;
            BtnInsert.Visible = true;
            BtnEdit.Visible = false;
            imgMenu.Visible = false;
            lblh.InnerText = "ایجاد تصویر کادو";
            chkView.Checked = true;
            Message.EmptyMessage(lblMessage);
            lblCreateDate.Text = Data.PersianDate(DateTime.Now);
        }
    }
}