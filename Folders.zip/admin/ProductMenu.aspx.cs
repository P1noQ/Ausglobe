﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Threading;
using System.Threading.Tasks;
using System.Web.UI;

namespace admin
{
    public partial class ProductMenu : System.Web.UI.Page
    {
        public static int gc;
        public static bool edit;
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
        }
        private void LoadDate()
        {
            var max = Data.MaxLevel();
            dropLevel.Items.Clear();
            if (max == -1)
            {
                dropLevel.Visible = false;
            }
            else
            {
                dropLevel.Items.Add(new ListItem("سطح 1", "0"));
                dropLevel.Items.Add(new ListItem("سطح 2", "1"));
            }
            if (max >= 1)
            {
                dropLevel.Items.Add(new ListItem("سطح 3", "2"));
            }
            if (max >= 2)
            {
                dropLevel.Items.Add(new ListItem("سطح 4", "3"));
            }

            //var page = Library.Db.tblPages.FirstOrDefault(p => p.id.Equals(9));
            //if (page != null)
            //{
            //    ltrMain.Text = page.main; ;
            //}
            var item = Data.GetProductMenuA().ToList();
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));

                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش سطوح محصولات";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                btnSave.Visible = false;
                var item = Data.CatProductData(id);
                int selectedCatId = selectCatCommentById(id);
                if (selectedCatId != 0)
                {
                    var item2 = Data.catCommentData(id);
                    hdfCatId.Value = item2.id.ToString(CultureInfo.InvariantCulture);
                    txtBody.Value = item2.comment;
                }
                else
                {
                    hdfCatId.Value = "";
                    txtBody.Value = "";
                }
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Name;
                hdfFile.Value = item.Image;
                var list = new ListItemCollection();
                imgMenu.ImageUrl = "uploadimage/catp/" + item.Image;


                var brand = Data.GetBrand().OrderBy(p => p.Name).ToList();
                var brand2 = Data.GetBrandMenu(item.Id);
                if (item.Level.Equals(1))
                {
                    rpBrand.DataSource = brand;
                    rpBrand.DataBind();
                    rpBrand.Visible = true;
                    CheckBox chkValue;
                    Label lblBId;

                    foreach (RepeaterItem ritem in rpBrand.Items)
                    {
                        chkValue = (CheckBox)ritem.FindControl("chkValue");
                        lblBId = (Label)ritem.FindControl("lblBId");
                        try
                        {

                            var q = Data.DB.CatBrands.Where(p => p.BrandId.Equals(int.Parse(lblBId.Text)) && p.CatId.Equals(item.Id));
                            if (q.Count() > 0)
                                chkValue.Checked = true;


                        }
                        catch { }
                    }

                }
                else
                {
                    rpBrand.Visible = false;
                }
                if (item.Level > 0)
                {
                    for (int i = 0; i <= item.Level - 1; i++)
                    {
                        list.Add(new ListItem("0", item.Level.ToString()));
                    }
                    if (list.Count > 1)
                    {
                        var par = item.Parent.GetValueOrDefault(0);
                        for (int i = list.Count - 1; i > 0; i--)
                        {
                            par = Data.CatProductData(par).Parent.GetValueOrDefault(0);
                            list[i].Text = par.ToString();
                        }
                    }
                }
                edit = true;
                rpDropMenu.DataSource = list;
                rpDropMenu.DataBind();
                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            string thumbpath = Server.MapPath("~/uploadimage/catp/40/");
            string thumbpath2 = Server.MapPath("~/uploadimage/catp/185/");
            try
            {
                Data.DeleteCatComment(id);
            }
            catch
            {
                Message.MessageGen(lblMessage, "توضیح درباره این سزح داده نشده بود", Color.Blue);
            }
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.CatProductData(id);
                if (item != null && !string.IsNullOrEmpty(item.Image))
                {
                    var path = "";
                    if (item.Image != "def.jpg")
                    {
                        path = Server.MapPath("~/uploadimage/catp/");
                        thumbpath = Server.MapPath("~/uploadimage/catp/40/");
                        thumbpath2 = Server.MapPath("~/uploadimage/catp/185/");
                    }

                    switch (Data.DeleteProductMenu(id, path, thumbpath, thumbpath2))

                    {
                        case 2:
                            {
                                //FileJob.DeleteFile(System.IO.Path.Combine(thumbpath,item.Image2));
                                //FileJob.DeleteFile(System.IO.Path.Combine(thumbpath2, item.Image3));
                                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                                break;
                            }
                        case 1:
                            Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                            break;
                        case 0:
                            Message.MessageGen(lblMessage, "سطح یا محصول با این رکورد درج شده است ", Color.Red);
                            break;
                    }
                }

            }
            catch(Exception Ex)
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        private int selectCatByName(string name)
        {
            var catId = Data.GetProductMenu().FirstOrDefault(p => p.Name.Equals(name));
            return catId.Id;
        }
        private int selectCatCommentById(int id)
        {
            var catId = Data.GetCatComment().Where(p => p.catId.Equals(id));
            if (catId.Count() == 0)
            {
                return 0;
            }
            else
            {
                return 1;
            }
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    filename = "def.jpg";
                }
                if (!filename.Equals("def.jpg"))
                {
                    if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/catp/") + filename)

                       || !FileJob.ThumbImage(Server.MapPath("~/uploadimage/catp/"), Server.MapPath("~/uploadimage/catp/40/")
                        , filename, 40, 40)

                        || !FileJob.ThumbImage(Server.MapPath("~/uploadimage/catp/"), Server.MapPath("~/uploadimage/catp/185/")
                        , filename, 185, 185)
                        )
                    {
                        Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر سطح لطفا دوباره تصویر را وارد نمایید", Color.Red);
                        return;
                    }
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;
                var comment = txtBody.Value;
                var Level = rpDropMenu.Items.Count;
                int? Parent;

                if (Level.Equals(0))
                {
                    Parent = null;
                }
                else
                {
                    var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    Parent = Convert.ToInt32(drop.SelectedValue.ToString());
                }
                var er = false;
                var p = Data.InsertMenuProduct(Name, Image, Level, Parent, null);
                int selectCat = selectCatByName(Name);
                Data.InsertCatComment(selectCat, comment, Image);
                if (p > 0)
                {
                    if (Level.Equals(1))
                    {
                        CheckBox chkValue;
                        Label lblBId;
                        var BID = 0;
                        int j = 0;
                        foreach (RepeaterItem ritem in rpBrand.Items)
                        {
                            chkValue = (CheckBox)ritem.FindControl("chkValue");
                            lblBId = (Label)ritem.FindControl("lblBId");
                            try
                            {
                                if (chkValue.Checked)
                                {
                                    BID = Convert.ToInt32(lblBId.Text);
                                    Data.InsertBrandCat(p, BID);
                                }
                                else
                                {
                                    j++;
                                }
                                if (j == rpBrand.Items.Count)
                                {
                                    Message.MessageGen(lblMessage, "ویژگی سطح را انتخاب کنید", Color.Green);
                                    er = true;
                                    return;
                                }
                            }
                            catch
                            {
                                er = true;
                            }
                        }
                    }
                }
                if (p > 0 && !er)
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else if (p > 0 && er)
                {
                    Message.MessageGen(lblMessage, "درج برند با مشکل مواجه شد", Color.Red);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                var btn = (Button)sender;
                if (btn.CommandName.Equals("Save"))
                {
                    MultiView1.ActiveViewIndex = 0;
                }
                LoadDate();
                txtName.Text = "";
                imgMenu.ImageUrl = "";
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            btnSave.Visible = true;
            txtBody.Value = "";
            lblh.InnerText = "ایجاد سطوح محصولات";
            txtName.Text = "";
            rpBrand.Visible = false;
            edit = false;
            gc = 0;
            Message.EmptyMessage(lblMessage);
            if (dropLevel.Visible)
            {
                var List = new ListItemCollection();
                var brand = Data.GetBrand().OrderBy(p => p.Name).ToList();
                var brand2 = Data.GetBrandMenu(0);
                if (dropLevel.SelectedIndex.Equals(1))
                {
                    rpBrand.DataSource = brand;
                    rpBrand.Visible = true;
                }
                rpBrand.DataBind();
                if (dropLevel.SelectedIndex > 0)
                {

                    var j = 0;
                    for (int i = 1; i <= dropLevel.SelectedIndex; i++)
                    {
                        if (i == 1)
                        {
                            j = 0;
                        }
                        else
                        {
                            j = Data.GetProductChildMenu(dropLevel.SelectedIndex, j).First().Id;
                        }
                        List.Add(new ListItem(j.ToString(), dropLevel.SelectedIndex.ToString()));
                    }
                }
                rpDropMenu.DataSource = List;
                rpDropMenu.DataBind();

            }
            //txtName.Text = string.Empty;
            //txtNameStore.Text = string.Empty;
            //txtTel.Text = string.Empty;
            //txtZipCode.Text = string.Empty;
            //txtAddress.Text = string.Empty;
            //txtDescription.Text = string.Empty;
            //ViewProvince();
            //ViewFristCity();
            MultiView1.ActiveViewIndex = 1;
        }
        //public void ViewProvince()
        //{
        //    ddlProvince.DataSource = Library.Db.tblCities.OrderBy(p => p.name).Where(p => p.parentId.Equals(null));
        //    ddlProvince.DataBind();
        //}
        //public void ViewFristCity()
        //{
        //    var province = Library.Db.tblCities.OrderBy(p => p.name).FirstOrDefault(p => p.parentId.Equals(null));
        //    var city = Library.Db.tblCities.Where(p => p.parentId.Equals(province.id)).OrderBy(p => p.name);
        //    ddlCity.DataSource = city;
        //    ddlCity.DataBind();
        //}
        protected void rpDropMenu_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {

        }
        private String _taskprogress;
        private AsyncTaskDelegate _dlgt;
        private object _param;

        // Create delegate. 
        protected delegate void AsyncTaskDelegate();

        public String GetAsyncTaskProgress()
        {
            return _taskprogress;
        }
        public void DoTheAsyncTask()
        {
            var d = (DropDownList)_param;
            var param = Data.CatProductData(Convert.ToInt32(d.SelectedValue.ToString())).Level;
            for (int I = param + 1; I < rpDropMenu.Items.Count; I++)
            {
                var pdrop = (DropDownList)rpDropMenu.Items[I - 1].FindControl("rpDropLevel");

                var drop = (DropDownList)rpDropMenu.Items[I].FindControl("rpDropLevel");
                try
                {
                    gc = Convert.ToInt32(pdrop.SelectedValue.ToString());
                    var lvl = rpDropMenu.Items.Count;
                    var data = Data.GetProductChildMenu(lvl, gc);
                    drop.DataSource = data;
                    drop.DataTextField = "Name";
                    drop.DataValueField = "Id";
                    drop.DataBind();
                }
                catch
                {
                    drop.Items.Clear();
                }
            }

            Thread.Sleep(TimeSpan.FromSeconds(5.0));
        }

        // Define the method that will get called to 
        // start the asynchronous task. 
        public IAsyncResult OnBegin(object sender, EventArgs e,
            AsyncCallback cb, object extraData)
        {

            _taskprogress = "Beginning async task.";
            _param = extraData;
            _dlgt = new AsyncTaskDelegate(DoTheAsyncTask);
            IAsyncResult result = _dlgt.BeginInvoke(cb, extraData);

            return result;
        }

        // Define the method that will get called when 
        // the asynchronous task is ended. 
        public void OnEnd(IAsyncResult ar)
        {
            _taskprogress = "Asynchronous task completed.";
            _dlgt.EndInvoke(ar);
        }

        // Define the method that will get called if the task 
        // is not completed within the asynchronous timeout interval. 
        public void OnTimeout(IAsyncResult ar)
        {
            _taskprogress = "Ansynchronous task failed to complete " +
                "because it exceeded the AsyncTimeout parameter.";
        }

        protected void rpDropMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

            var async = new PageAsyncTask(OnBegin, OnEnd, OnTimeout, sender, true);
            Page.RegisterAsyncTask(async);
            Page.ExecuteRegisteredAsyncTasks();

            //for (int I = line + 1; I < rpDropMenu.Items.Count; I++)
            //{
            //    var pdrop = (DropDownList)rpDropMenu.Items[I - 1].FindControl("rpDropLevel");

            //    var drop = (DropDownList)rpDropMenu.Items[I].FindControl("rpDropLevel");
            //    try
            //    {
            //        gc = Convert.ToInt32(pdrop.SelectedValue.ToString());
            //        var lvl = rpDropMenu.Items.Count;
            //        var data = Data.GetProductChildMenu(lvl, gc);
            //        drop.DataSource = data;
            //        drop.DataTextField = "Name";
            //        drop.DataValueField = "Id";
            //        drop.DataBind();
            //    }
            //    catch
            //    {
            //        drop.Items.Clear();
            //    }
            //}

            //var city = Library.Db.tblCities.OrderBy(q => q.name).Where(p => p.parentId.Equals(int.Parse(ddlProvince.SelectedValue)));
            //ddlCity.DataSource = city;
            //ddlCity.DataBind();
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    if (hdfFile.Value != "def.jpg")
                    {
                        if (FileJob.CheckFileExisted(Server.MapPath("~/uploadimage/catp/") + hdfFile.Value))
                            FileJob.DeleteFile(Server.MapPath("~/uploadimage/catp/") + hdfFile.Value);
                        if (FileJob.CheckFileExisted(Server.MapPath("~/uploadimage/catp/40") + hdfFile.Value))
                            FileJob.DeleteFile(Server.MapPath("~/uploadimage/catp/40") + hdfFile.Value);
                        if (FileJob.CheckFileExisted(Server.MapPath("~/uploadimage/catp/185") + hdfFile.Value))
                            FileJob.DeleteFile(Server.MapPath("~/uploadimage/catp/185") + hdfFile.Value);
                    }
                    FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/catp/") + filename);
                    FileJob.ThumbImage(Server.MapPath("~/uploadimage/catp/") + filename, Server.MapPath("~/uploadimage/catp/40/") + filename
                             , FileUpload1.PostedFile.FileName, 40, 40);
                    FileJob.ThumbImage(Server.MapPath("~/uploadimage/catp/") + filename, Server.MapPath("~/uploadimage/catp/185/") + filename
                        , FileUpload1.PostedFile.FileName, 185, 185);
                }
                else
                {
                    filename = hdfFile.Value;
                }
                var Name = Server.HtmlEncode(txtName.Text);
                var Image = filename;
                bool isBodyNull = false;
                string Body = txtBody.Value;
                int? Parent;
                if (rpDropMenu.Items.Count > 0)
                {
                    var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    Parent = Convert.ToInt32(drop.SelectedValue.ToString());
                }
                else
                {
                    Parent = null;
                }


                try
                {
                    var CID = int.Parse(hdfId.Value);
                    if (selectCatCommentById(CID) == 0)
                    {
                        isBodyNull = true;
                    }
                    var er = false;
                    Data.EditMenuProduct(CID, Name, Image, Parent, null);
                    if (isBodyNull)
                    {
                        Data.InsertCatComment(CID, Body, Image);
                    }
                    else
                    {
                        Data.EditCategoryComment(CID, Body, Image);
                    }
                    if (rpBrand.Visible)
                    {
                        CheckBox chkValue;
                        Label lblBId;
                        var BID = 0;
                        foreach (RepeaterItem ritem in rpBrand.Items)
                        {
                            chkValue = (CheckBox)ritem.FindControl("chkValue");
                            lblBId = (Label)ritem.FindControl("lblBId");
                            try
                            {
                                BID = Convert.ToInt32(lblBId.Text);
                                if (chkValue.Checked)
                                {
                                    Data.InsertBrandCat(CID, BID);
                                }
                                else
                                {
                                    Data.DeleteBrandCat(BID, CID);
                                }
                            }
                            catch
                            {
                                er = true;
                            }
                        }
                    }



                    if (er)
                    {
                        Message.MessageGen(lblMessage, "مشکل در درج یا حذف برند", Color.Orange);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                    }

                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
        protected void rpDropMenu_ItemCreted(object sender, RepeaterItemEventArgs e)
        {
            try
            {
                var ind = e.Item.ItemIndex;
                if (ind != -1)
                {
                    var drop = (DropDownList)e.Item.FindControl("rpDropLevel");

                    var DT = (ListItem)e.Item.DataItem;
                    if (DT != null)
                    {

                        gc = Convert.ToInt32(DT.Text.ToString());
                        var lvl = Convert.ToInt32(DT.Value.ToString());
                        var data = Data.GetProductChildMenu(lvl, gc);
                        drop.DataSource = data;
                        drop.DataTextField = "Name";
                        drop.DataValueField = "Id";
                        drop.DataBind();
                        if (edit)
                        {
                            var par = Data.GetProductMenuDrop(Convert.ToInt32(hdfId.Value), e.Item.ItemIndex);
                            drop.SelectedIndex = drop.Items.IndexOf(drop.Items.FindByText(par));
                        }
                    }
                }
                else
                {
                    var last = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    last.AutoPostBack = false;
                    gc = 0;
                    rpDropMenu.Visible = true;
                }
            }
            catch
            {
                if (rpDropMenu.Items.Count == 0)
                {
                    rpDropMenu.Visible = false;
                }
            }

        }
    }
}