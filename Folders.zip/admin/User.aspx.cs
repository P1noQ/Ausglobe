﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//using System.Windows.Forms;
using System.Collections;
using System.Threading;
using System.Data;
using System.Web.Security;
using System.Web.Profile;
using System.Globalization;
using System.Drawing;
using System.Xml;
using System.Xml.Xsl;
using System.IO;
using System.Collections.Generic;

public partial class admin_User : System.Web.UI.Page
{
    public Data Data = new Data();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        //ProfileManager.ApplicationName = "/";
        //var pd = Profile.GetProfile("Test");
        //pd.SetPropertyValue("Mobile", "");
        //pd.Save();
        //ProfileManager.ApplicationName = "/admin";
        this.Session["CaptchaImageText"] = Data.GenerateRandomCode();
        var st = Data.State();
        var edu = Data.Education();
        var act = Data.Active();
        var met = Data.Meet();
        dropState.Items.Add(new ListItem("استان", "0"));
        dropCity.Items.Add(new ListItem("شهر", "0"));
        dropMeet.Items.Add(new ListItem("طریقه عضویت", "0"));

        dropVREducation.Items.Add(new ListItem("انتخاب نمایید", "0"));
        dropEduAgent.Items.Add(new ListItem("انتخاب نمایید", "0"));
        dropVMeet.Items.Add(new ListItem("سایر موارد", "0"));

        foreach (DataRow D in st.Rows)
        {
            dropState.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
            dropVRState.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
            dropStateAgent.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
        }
        foreach (DataRow D in met.Rows)
        {
            dropMeet.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
            dropVMeet.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
        }
        foreach (DataRow D in edu.Rows)
        {
            dropVREducation.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
            dropEduAgent.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
        }

        var comment = Data.UserData("/").AsEnumerable();
        var t = comment.AsDataView();
        gvList.DataSource = t;
        gvList.DataBind();
        if (comment.Count() > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    //protected void Grid1_Select(object sender, Obout.Grid.GridRecordEventArgs e)
    //{
    //    Hashtable g = new Hashtable();
    //    g = Grid1.SelectedRecords[0] as Hashtable;
    //    MessageBox.Show(g["UserName"].ToString());
    //}
    private String _taskprogress;
    private AsyncTaskDelegate _dlgt;
    // Create delegate. 
    protected delegate void AsyncTaskDelegate();

    public String GetAsyncTaskProgress()
    {
        return _taskprogress;
    }
    public void DoTheAsyncTask()
    {
        // Introduce an artificial delay to simulate a delayed  
        // asynchronous task. Make this greater than the  
        // AsyncTimeout property.

        var sid = Convert.ToInt32(dropState.SelectedValue.ToString());
        var ct = Data.City(sid);
        dropState.Enabled = false;
        dropCity.Items.Clear();
        dropCity.Items.Add(new ListItem("شهر", "0"));
        foreach (DataRow D in ct.Rows)
        {
            dropCity.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
        }
        dropState.Enabled = true;

        Thread.Sleep(TimeSpan.FromSeconds(5.0));
    }

    // Define the method that will get called to 
    // start the asynchronous task. 
    public IAsyncResult OnBegin(object sender, EventArgs e,
        AsyncCallback cb, object extraData)
    {

        _taskprogress = "Beginning async task.";
        _dlgt = new AsyncTaskDelegate(DoTheAsyncTask);
        IAsyncResult result = _dlgt.BeginInvoke(cb, extraData);

        return result;
    }

    // Define the method that will get called when 
    // the asynchronous task is ended. 
    public void OnEnd(IAsyncResult ar)
    {
        _taskprogress = "Asynchronous task completed.";
        _dlgt.EndInvoke(ar);
    }

    // Define the method that will get called if the task 
    // is not completed within the asynchronous timeout interval. 
    public void OnTimeout(IAsyncResult ar)
    {
        _taskprogress = "Ansynchronous task failed to complete " +
            "because it exceeded the AsyncTimeout parameter.";
    }
    protected void dropState_SelectedIndexChanged(object sender, EventArgs e)
    {
        var async = new PageAsyncTask(OnBegin, OnEnd, OnTimeout, null, true);
        Page.RegisterAsyncTask(async);
        Page.ExecuteRegisteredAsyncTasks();
        //var ct = Data.City(sid);
        //dropCity.Items.Clear();
        //dropCity.Items.Add(new ListItem("شهر", "0"));
        //foreach (DataRow D in ct.Rows)
        //{
        //    dropCity.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
        //}

        //gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        //gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected void UserStateSelect(object sender, EventArgs e)
    {
        var sid = 0;
        if (multType.ActiveViewIndex.Equals(0))
        {

            sid = Convert.ToInt32(dropVRState.SelectedValue.ToString());
            var ct = Data.City(sid);
            dropVRCity.Items.Clear();

            foreach (DataRow D in ct.Rows)
            {
                dropVRCity.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
            }

        }
        else
        {
            sid = Convert.ToInt32(dropStateAgent.SelectedValue.ToString());
            var ct = Data.City(sid);
            dropCityAgent.Items.Clear();

            foreach (DataRow D in ct.Rows)
            {
                dropCityAgent.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
            }
        }
    }
    private string AddFilter(string Add, string Filter, bool And = true)
    {
        var fil = Filter;
        if (fil.Length > 0)
        {
            fil = And ? fil + "And " + Add : fil + "Or " + Add;
        }
        else
        {
            fil = Add;
        }
        return fil;
    }
    protected void FilterAll(object sender, EventArgs e)
    {

        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "AddPlace();", true);
        var Key = Server.HtmlEncode(txtAll.Text);
        var filter = "";
        filter = AddFilter("UserName like '%" + Key + "%'", filter, false);
        filter = AddFilter("Name like '%" + Key + "%'", filter, false);
        filter = AddFilter("Family like '%" + Key + "%'", filter, false);
        filter = AddFilter("Meet like '%" + Key + "%'", filter, false);
        filter = AddFilter("News like '%" + Key + "%'", filter, false);
        filter = AddFilter("Type like '%" + Key + "%'", filter, false);
        filter = AddFilter("State like '%" + Key + "%'", filter, false);
        filter = AddFilter("City like '%" + Key + "%'", filter, false);
        filter = AddFilter("BirthDate like '%" + Key + "%'", filter, false);
        filter = AddFilter("Tel like '%" + Key + "%'", filter, false);
        filter = AddFilter("Mobile like '%" + Key + "%'", filter, false);
        filter = AddFilter("Job like '%" + Key + "%'", filter, false);
        filter = AddFilter("Education like '%" + Key + "%'", filter, false);
        filter = AddFilter("Activity like '%" + Key + "%'", filter, false);
        filter = AddFilter("LType like '%" + Key + "%'", filter, false);
        filter = AddFilter("CorpName like '%" + Key + "%'", filter, false);
        filter = AddFilter("EconomicCode like '%" + Key + "%'", filter, false);
        var comment = Data.UserData("/");
        var t = comment.AsDataView();
        t.RowFilter = filter;
        gvList.DataSource = t;
        gvList.DataBind();
        if (comment.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    protected void filter_Click(object sender, EventArgs e)
    {
        var pars = new PersianCalendar();
        var filter = "";
        string Approved;
        if (dropIsApproved.SelectedIndex == 0)
            Approved = "";
        else if (dropIsApproved.SelectedIndex == 1)
            Approved = "True";
        else
            Approved = "False";
        var startd = Server.HtmlEncode(dpDateStart.Text.ToString());
        var endd = Server.HtmlEncode(dpDateEnd.Text.ToString());
        var Type = Server.HtmlEncode(dropType.SelectedItem.Text.ToString());
        var Name = Server.HtmlEncode(txtName.Text.ToString());
        var Family = Server.HtmlEncode(txtFamily.Text.ToString());
        var State = Server.HtmlEncode(dropState.SelectedItem.Text.ToString());
        var City = Server.HtmlEncode(dropCity.SelectedItem.Text.ToString());
        var Meet = Server.HtmlEncode(dropMeet.SelectedItem.Text.ToString());
        var News = dropNews.SelectedIndex == 0 ? "" : Server.HtmlEncode(dropNews.SelectedItem.Text.ToString());
        bool? Sex;
        if (dropSex.SelectedIndex == 0)
            Sex = null;
        else if (dropSex.SelectedIndex == 1)
            Sex = true;
        else
            Sex = false;
        var births = Server.HtmlEncode(dpDateBirthStart.Text.ToString());
        var birthe = Server.HtmlEncode(dpDateBirthEnd.Text.ToString());
        var CorpType = Server.HtmlEncode(dropCorpType.SelectedItem.Text.ToString());
        var CorpName = Server.HtmlEncode(txtCorpName.Text.ToString());
        var Agent = dropAgent.SelectedIndex == 0 ? "" : Server.HtmlEncode(dropAgent.SelectedItem.Value.ToString());
        var bsd = births.Split("/".ToArray());
        var bed = birthe.Split("/".ToArray());
        var sd = startd.Split("/".ToArray());
        var ed = endd.Split("/".ToArray());
        var Sda = new DateTime();
        var Eda = new DateTime();

        if (sd.Count() == 3)
        {
            Sda = new DateTime(Convert.ToInt32(sd[0].ToString()), Convert.ToInt32(sd[1].ToString()), Convert.ToInt32(sd[2].ToString()), pars);
            startd = Sda.Year.ToString() + "/" + Sda.Month.ToString("00") + "/" + Sda.Day.ToString("00");
            filter = "CreateDate >= '" + startd + "'";
        }
        if (ed.Count() == 3)
        {
            Eda = new DateTime(Convert.ToInt32(ed[0].ToString()), Convert.ToInt32(ed[1].ToString()), Convert.ToInt32(ed[2].ToString()), pars);
            endd = Eda.Year.ToString() + "/" + Eda.Month.ToString("00") + "/" + Eda.Day.ToString("00");
            filter = "CreateDate <= '" + endd + "'";
        }
        if (startd.Length.Equals(10) && endd.Length.Equals(10))
        {
            if (Sda > Eda)
            {
                filter = "CreateDate >= '" + endd + "' And CreateDate <= '" + startd + "'";
            }
            else
            {
                filter = "CreateDate >= '" + startd + "' And CreateDate <= '" + endd + "'";
            }
        }
        if (Approved.Length > 0)
        {
            filter = AddFilter("IsApproved = '" + Approved + "'", filter);
        }
        if (dropType.SelectedIndex > 0)
        {
            filter = AddFilter("Type = '" + Type + "'", filter);
        }
        //if (birth.Length.Equals(10))
        //{
        //    birth = birth.Remove(0, 4);
        //    filter = AddFilter("BirthDate like '%" + birth + "'", filter);
        //}
        if (Name.Length > 0)
        {
            filter = AddFilter("Name like '%" + Name + "%'", filter);
        }
        if (Family.Length > 0)
        {
            filter = AddFilter("Family like '%" + Family + "%'", filter);
        }
        if (dropMeet.SelectedIndex > 0)
        {
            filter = AddFilter("Meet = '" + Meet + "'", filter);
        }
        if (dropNews.SelectedIndex > 0)
        {
            filter = AddFilter("News = '" + News + "'", filter);
        }
        if (birthe.Length > 0 || births.Length > 0)
        {
            if (birthe.Length > 0 && births.Length > 0)
            {
                Sda = new DateTime(Convert.ToInt32(bsd[0].ToString()), Convert.ToInt32(bsd[1].ToString()), Convert.ToInt32(bsd[2].ToString()), pars);
                Eda = new DateTime(Convert.ToInt32(bed[0].ToString()), Convert.ToInt32(bed[1].ToString()), Convert.ToInt32(bed[2].ToString()), pars);
                if (Sda > Eda)
                {
                    filter = AddFilter("BirthDate >= '" + birthe + "' And BirthDate <= '" + births + "'", filter);
                }
                else
                {
                    filter = AddFilter("BirthDate >= '" + births + "' And BirthDate <= '" + birthe + "'", filter);
                }
            }
            else if (births.Length > 0)
            {
                filter = AddFilter("BirthDate >= '" + births + "'", filter);
            }
            else
            {
                filter = AddFilter("BirthDate <= '" + birthe + "'", filter);
            }
        }
        //if (Tel.Length > 0)
        //{
        //    filter = AddFilter("Tel like '%" + Name + "%'", filter);
        //}
        //if (Mobile.Length > 0)
        //{
        //    filter = AddFilter("Mobile like '%" + Name + "%'", filter);
        //}
        //if (job.Length > 0)
        //{
        //    filter = AddFilter("Job like '%" + job + "%'", filter);
        //}
        if (CorpName.Length > 0)
        {
            filter = AddFilter("CorpName like '%" + CorpName + "%'", filter);
        }
        if (State != "استان")
        {
            filter = AddFilter("State = '" + State + "'", filter);
        }
        if (City != "شهر")
        {
            filter = AddFilter("City = '" + City + "'", filter);
        }
        //if (Education != "تحصیلات")
        //{
        //    filter = AddFilter("Education = '" + Education + "'", filter);
        //}
        if (CorpType != "نوع شرکت")
        {
            filter = AddFilter("Ltype = '" + CorpType + "'", filter);
        }
        if (dropAgent.SelectedIndex > 0)
        {
            filter = AddFilter("Agent = '" + Agent + "'", filter);
        }
        //if (Activity != "زمینه فعالیت")
        //{
        //    filter = AddFilter("Activity = '" + Activity + "'", filter);
        //}

        var comment = Data.UserData("/");
        var t = comment.AsDataView();
        t.RowFilter = filter;
        gvList.DataSource = t;
        gvList.DataBind();
        if (comment.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    protected void bntDeactive_Click(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        foreach (GridViewRow row in gvList.Rows)
        {
            System.Web.UI.WebControls.CheckBox myCheckBox = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkSelect");
            System.Web.UI.WebControls.Label myLabel = (System.Web.UI.WebControls.Label)row.FindControl("LabelUser");
            if (myCheckBox.Checked)
            {
                Data.ActiveUser(myLabel.Text.ToString(), false);
            }
        }
        BindUser();
    }
    protected void btnActive_Click(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        foreach (GridViewRow row in gvList.Rows)
        {
            System.Web.UI.WebControls.CheckBox myCheckBox = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkSelect");
            System.Web.UI.WebControls.Label myLabel = (System.Web.UI.WebControls.Label)row.FindControl("LabelUser");
            if (myCheckBox.Checked)
            {
                Data.ActiveUser(myLabel.Text.ToString(), true);
            }
        }
        BindUser();
    }
    protected void bntRemove_Click(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        foreach (GridViewRow row in gvList.Rows)
        {
            System.Web.UI.WebControls.CheckBox myCheckBox = (System.Web.UI.WebControls.CheckBox)row.FindControl("chkSelect");
            System.Web.UI.WebControls.Label myLabel = (System.Web.UI.WebControls.Label)row.FindControl("LabelUser");
            if (myCheckBox.Checked)
            {
                try
                {
                    Membership.ApplicationName = "/";
                    Data.DeleteUser(myLabel.Text.ToString());
                    Membership.DeleteUser(myLabel.Text.ToString());
                    Membership.ApplicationName = "/admin";
                    BindUser();
                }
                catch (Exception)
                {
                    Membership.ApplicationName = "/admin";
                    Message.MessageGen(lblMessage, "این کاربر سفارش و یا پرداختی تمام نشده دارد.حذف امکان پذیر نیست", Color.Red);
                }

            }

        }
        BindUser();
    }
    private void BindUser()
    {
        var comment = Data.UserData("/").AsDataView();
        gvList.DataSource = comment;
        gvList.DataBind();
        if (comment.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter; ;
        }
    }
    protected void bntRefresh_Click(object sender, EventArgs e)
    {
        BindUser();
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        mview1.Attributes["class"] = "";
        mview2.Attributes["class"] = "hide";
        if (gvList.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    protected void ShowOrder(object sender, EventArgs e)
    {

    }
    protected void ShowUser(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        var btnShow = (LinkButton)sender;
        var User = btnShow.CommandArgument;

        Membership.ApplicationName = "/";
        var u = Membership.GetUser(User);
        txtVMail.Text = u.Email;
        txtRegard.Text = u.Comment;
        lblDate.Text = Data.PersianDate(u.CreationDate);
        lblUser.Text = User;
        ProfileManager.ApplicationName = "/";
        var p = Profile.GetProfile(User);
        lblType.Text = p.Legal.CorpName.Length > 0 ? "حقوقی" : "حقیقی";
        txtVName.Text = p.Name;
        txtVFName.Text = p.Family;
        if (p.Sex)
        {
            rbVMale.Checked = true;
            rbVFemale.Checked = false;
        }
        else
        {
            rbVFemale.Checked = true;
            rbVMale.Checked = false;
        }
        dpVBirth.Text = p.BirthDate;
        txtVNationalCode.Text = p.NationalCode;
        txtIdNo.Text = p.IdNo;
        txtVMob.Text = p.Mobile;
        if (p.Meet.Length > 0)
            dropVMeet.SelectedIndex = dropVMeet.Items.IndexOf(dropVMeet.Items.FindByText(p.Meet));
        else
            dropVMeet.SelectedIndex = 0;
        if (p.News.Equals("بله"))
        {
            rbNewsY.Checked = true;
            rbNewsN.Checked = false;
        }
        else
        {
            rbNewsN.Checked = true;
            rbNewsY.Checked = false;
        }
        if (p.Legal.CorpName.Length > 0)
        {
            dropVCorpType.SelectedIndex = dropVCorpType.Items.IndexOf(dropVCorpType.Items.FindByText(p.Legal.Type));
            txtVCorpName.Text = p.Legal.CorpName;

            dropVAct.Text = p.Legal.Activity;
            txtEcoCode.Text = p.Legal.EconomicCode;
            txtNatianId.Text = p.Legal.NationalId;
            if (p.Legal.Agent)
            {
                rbAgentY.Checked = true;
                rbAgentN.Checked = false;
            }
            else
            {
                rbAgentN.Checked = true;
                rbAgentY.Checked = false;
            }
            dropStateAgent.SelectedIndex = dropStateAgent.Items.IndexOf(dropStateAgent.Items.FindByText(p.State));
            var sid = Convert.ToInt32(dropStateAgent.SelectedValue.ToString());
            var ct = Data.City(sid);
            dropCityAgent.Items.Clear();

            foreach (DataRow D in ct.Rows)
            {
                dropCityAgent.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
            }
            dropCityAgent.SelectedIndex = dropCityAgent.Items.IndexOf(dropCityAgent.Items.FindByText(p.City));

            if (p.Education.Length > 0)
                dropEduAgent.SelectedIndex = dropEduAgent.Items.IndexOf(dropEduAgent.Items.FindByText(p.Education));
            txtCorpAddress.Text = p.Address;
            txtPCodeCorp.Text = p.PostalCode;
            txtCorpCodeTel.Text = p.CodeTel;
            txtCorpTel.Text = p.Tel;
            txtFaxCorp.Text = p.Fax;
            txtPosition.Text = p.Legal.Position;
            txtTelD.Text = p.Legal.DirectPhone;
            Grant.Visible = true;
            multType.ActiveViewIndex = 1;
        }
        else
        {
            txtVRAddress.Text = p.Address;
            txtVRFax.Text = p.Fax;
            txtVRJob.Text = p.Real.Job;
            txtVRPCode.Text = p.PostalCode;
            txtVRTel.Text = p.Tel;
            txtVRCodeTel.Text = p.CodeTel;
            dropVRState.SelectedIndex = dropVRState.Items.IndexOf(dropVRState.Items.FindByText(p.State));
            var sid = Convert.ToInt32(dropVRState.SelectedValue.ToString());
            var ct = Data.City(sid);
            if (p.Education.Length > 0)
                dropVREducation.SelectedIndex = dropEduAgent.Items.IndexOf(dropVREducation.Items.FindByText(p.Education));
            dropVRCity.Items.Clear();
            foreach (DataRow D in ct.Rows)
            {
                dropVRCity.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
            }
            dropVRCity.SelectedIndex = dropVRCity.Items.IndexOf(dropVRCity.Items.FindByText(p.City));
            Grant.Visible = false;
            multType.ActiveViewIndex = 0;
        }
        ProfileDataUser.SetAdmin();
        mview1.Attributes["class"] = "hide";
        mview2.Attributes["class"] = "";
        ProfileManager.ApplicationName = "/admin";
        Membership.ApplicationName = "/admin";
        var comment = Data.UserData("/").AsEnumerable();
        var t = comment.AsDataView();
        gvList.DataSource = t;
        gvList.DataBind();
        if (comment.Count() > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

    }
    protected void EditUser(object sender, EventArgs e)
    {
        lblMessage.Text = "";
        var User = lblUser.Text;
        var NewPass = Server.HtmlEncode(txtVPass.Text);

        Membership.ApplicationName = "/";


        var u = Membership.GetUser(User);
        if (NewPass.Length > 5)
        {
            var oldPass = u.ResetPassword();
            u.ChangePassword(oldPass, NewPass);
        }
        var Email = Server.HtmlEncode(txtVMail.Text);
        var Comment = Server.HtmlEncode(txtRegard.Text);
        var findmail = Membership.GetUserNameByEmail(Email);
        if (Email != u.Email && findmail != null)
        {
            Message.MessageGen(lblMessage, "این ایمیل قبلا ثبت شده است", Color.Red);
            return;
        }
        u.Email = Email;
        u.Comment = Comment;
        Membership.UpdateUser(u);
        Membership.ApplicationName = "/admin";
        ProfileManager.ApplicationName = "/";
        var p = Profile.GetProfile(User);
        var Name = Server.HtmlEncode(txtVName.Text);
        var Family = Server.HtmlEncode(txtVFName.Text);
        var Sex = rbVMale.Checked;
        var BirthDate = Server.HtmlEncode(dpVBirth.Text);
        var NationalCode = Server.HtmlEncode(txtVNationalCode.Text);
        var idNo = Server.HtmlEncode(txtIdNo.Text);
        var Mobile = Server.HtmlEncode(txtVMob.Text);
        var Meet = dropVMeet.SelectedItem.Text;
        var News = rbNewsY.Checked ? "بله" : "خیر";
        var State = "";
        var City = "";
        var Education = "";
        var PostalCode = "";
        var Tel = "";
        var CodeTel = "";
        var Fax = "";
        var Address = "";
        p.SetPropertyValue("Name", Name);
        p.SetPropertyValue("Family", Family);
        p.SetPropertyValue("Sex", Sex);
        p.SetPropertyValue("BirthDate", BirthDate);
        p.SetPropertyValue("NationalCode", NationalCode);
        p.SetPropertyValue("IdNo", idNo);
        p.SetPropertyValue("Mobile", Mobile);
        p.SetPropertyValue("Meet", Meet);
        p.SetPropertyValue("News", News);

        //var 
        if (p.Legal.CorpName.Length > 0)
        {
            var CorpType = dropVCorpType.SelectedItem.Text;
            var CorpName = Server.HtmlEncode(txtVCorpName.Text);
            var Act = dropVAct.Text;
            var EcoCode = Server.HtmlEncode(txtEcoCode.Text);
            var NationalId = Server.HtmlEncode(txtNatianId.Text);
            var Agent = rbAgentY.Checked;
            var Position = Server.HtmlEncode(txtPosition.Text);
            var DirectPhone = Server.HtmlEncode(txtTelD.Text);
            p.SetPropertyValue("Legal.Type", CorpType);
            p.SetPropertyValue("Legal.CorpName", CorpName);
            p.SetPropertyValue("Legal.Activity", Act);
            p.SetPropertyValue("Legal.EconomicCode", EcoCode);
            p.SetPropertyValue("Legal.NationalId", NationalId);
            p.SetPropertyValue("Legal.Agent", Agent);
            p.SetPropertyValue("Legal.Position", Position);
            p.SetPropertyValue("Legal.DirectPhone", DirectPhone);
            State = dropStateAgent.SelectedItem.Text;
            City = dropCityAgent.SelectedItem.Text;
            if (dropEduAgent.SelectedIndex > 0) Education = dropEduAgent.SelectedItem.Text;
            Address = Server.HtmlEncode(txtCorpAddress.Text);
            PostalCode = Server.HtmlEncode(txtPCodeCorp.Text);
            Tel = Server.HtmlEncode(txtCorpTel.Text);
            CodeTel = Server.HtmlEncode(txtCorpCodeTel.Text);
            Fax = Server.HtmlEncode(txtFaxCorp.Text);
        }
        else
        {
            var Job = Server.HtmlEncode(txtVRJob.Text);
            Address = Server.HtmlEncode(txtVRAddress.Text);
            Fax = Server.HtmlEncode(txtVRFax.Text);
            PostalCode = Server.HtmlEncode(txtVRPCode.Text);
            CodeTel = Server.HtmlEncode(txtVRCodeTel.Text);
            Tel = Server.HtmlEncode(txtVRTel.Text);
            State = dropVRState.SelectedItem.Text;
            City = dropVRCity.SelectedItem.Text;
            if (dropVREducation.SelectedIndex > 0) Education = dropVREducation.SelectedItem.Text;
            p.SetPropertyValue("Real.Job", Job);
        }

        p.SetPropertyValue("Address", Address);
        p.SetPropertyValue("State", State);
        p.SetPropertyValue("City", City);
        p.SetPropertyValue("Education", Education);
        p.SetPropertyValue("CodeTel", CodeTel);
        p.SetPropertyValue("Tel", Tel);
        p.SetPropertyValue("Fax", Fax);
        p.SetPropertyValue("PostalCode", PostalCode);

        p.Save();
        Message.MessageGen(lblMessage, "ویرایش با موفقیت انجام شد", Color.Green);
        mview1.Attributes["class"] = "";
        mview2.Attributes["class"] = "hide";
        ProfileManager.ApplicationName = "/admin";
        Membership.ApplicationName = "/admin";
        var t = Data.UserData("/").AsDataView();

        gvList.DataSource = t;
        gvList.DataBind();
        //if (t.Count > 0)

        //{
        try
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        catch { }
        //}
    }
    protected void btnImportClick(object sender, EventArgs e)
    {
        try
        {
            string procInfo = "type='text/xsl' href='" + "\\transform3.xslt" + "'";//Processing info for XSLT
            string TempPath = Server.MapPath("~/");
            string XMLPath = TempPath + "\\Products.xml"; //temp path to store the XML file
            string XLSPath = TempPath + "\\Products.xls";//temp path to store the XLS file


            //Write the dataset as XML file with some XSLT processing information
            using (XmlTextWriter tw = new XmlTextWriter(XMLPath,
                       null))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();

                if (drpdownload.SelectedIndex == 0)
                {
                    var dt = Data.UserExcell("/");
                    dt.TableName = "اطلاعات_کاربران";
                    var ds = new DataSet();
                    ds.Tables.Add(dt);
                    //ds.WriteXml(Server.MapPath("~/data.xml"));
                    //ds.WriteXmlSchema(Server.MapPath("~/schema.xml"));
                    tw.WriteProcessingInstruction("xml-stylesheet", procInfo);
                    ds.WriteXml(tw);
                }
                else if (drpdownload.SelectedIndex == 1)
                {
                    DataTable c = null;
                    //var seldt = (gvList.DataSource as DataTable).AsDataView();
                    DataTable dt = new DataTable();
                    var dtv = Data.UserExcell("/").AsDataView();
                    c = dtv.ToTable();
                    var a = c.AsEnumerable();

                    //dt.Columns.Add()
                    dt = c.Clone();
                    foreach (GridViewRow r in gvList.Rows)
                    {

                        var chkSelect = (CheckBox)r.FindControl("chkSelect");
                        var LabelUser = (Label)r.FindControl("LabelUser");


                        //dtv.RowFilter = filter;

                        if (chkSelect.Checked)
                        {
                            var q = Data.GetUserSel().FirstOrDefault(p => p.UserName.Equals(LabelUser.Text));

                            dt.Rows.Add(q.UserName, q.Date, q.UserType, q.Email, q.Sex, q.Name, q.Family, q.Birth, q.NationalCode, q.IdNo, q.Job, q.Education, q.State, q.City, q.Address, q.PostalCode, q.CodeTel, q.Tel, q.Fax, q.Mobile, q.Meet, q.News, q.Comment, q.Agent, q.CorpType, q.CorpName, q.Activity, q.EconomicCode, q.NationalId, q.Position, q.DirectPhone);

                            //query = Data.DB.spGetOrderListByIndex(index);
                            //listRes.Add(query);
                            //filter = AddFilter("Id = '" + LabelUser.Text + "'", filter, true);
                            //c.Rows.RemoveAt(gvList.SelectedIndex);
                        }
                    }
                    //var dt1 = dt;
                    dt.TableName = "اطلاعات_کاربران";
                    var ds = new DataSet();
                    ds.Tables.Add(dt);
                    //ds.WriteXml(Server.MapPath("~/data.xml"));
                    //ds.WriteXmlSchema(Server.MapPath("~/schema.xml"));
                    tw.WriteProcessingInstruction("xml-stylesheet", procInfo);
                    ds.WriteXml(tw);
                }

            }


            XmlDataDocument xmldoc = new XmlDataDocument();
            xmldoc.Load(XMLPath);
            XslCompiledTransform xsl = new XslCompiledTransform();
            xsl.Load(Server.MapPath(".") + "\\excell\\Transform3.xslt");



            using (XmlTextWriter tw = new XmlTextWriter(XLSPath, System.Text.Encoding.UTF8))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                xsl.Transform(xmldoc, null, tw);//Performa XSLT transformation.
            }



            //Streams the generated XLS file to the user
            byte[] Buffer = null;
            using (FileStream MyFileStream = new FileStream(XLSPath, FileMode.Open))
            {
                // Total bytes to read: 
                long size;
                size = MyFileStream.Length;
                Buffer = new byte[size];
                MyFileStream.Read(Buffer, 0, int.Parse(MyFileStream.Length.ToString()));
            }
            Response.ContentType = "application/xls";
            string header = "attachment; filename=" + "User" + DateTime.Now.Ticks.ToString() + ".xls";
            Response.AddHeader("content-disposition", header);
            Response.BinaryWrite(Buffer);
            Response.Flush();
            Response.End();
        }
        catch
        {

        }
    }
    protected void btnImportSelClick(object sender, EventArgs e)
    {
        try
        {
            //var comment = Data.UserData("/").AsEnumerable().Where(p => p.Field<DateTime>("CreateDate") != p.Field<DateTime>("LastLoginDate") || p.Field<bool>("IsApproved") == true);
            //var item = comment.AsDataView().Table;
            //var ExcelApp = new ApplicationClass();

            //ExcelApp.Application.Workbooks.Add(System.Type.Missing);
            //var ind = 1;
            //ExcelApp.Cells[1, 1] = "نام کاربر";
            //ExcelApp.Cells[1, 2] = "تاریخ ایجاد";
            //ExcelApp.Cells[1, 3] = "نوع کاربر";
            //ExcelApp.Cells[1, 4] = "نام و نام خانوادگی";
            //ExcelApp.Cells[1, 5] = "استان";
            //ExcelApp.Cells[1, 6] = "شهر";
            //ExcelApp.Cells[1, 7] = "تلفن";
            //ExcelApp.Cells[1, 8] = "موبایل";
            //ExcelApp.Cells[1, 9] = "فعال";
            //var i = 1;
            //foreach (GridViewRow r in gvList.Rows)
            //{
            //    var chkSelect = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkSelect");
            //    if (chkSelect.Checked.Equals(true))
            //    {
            //        ind = ind + 1;
            //        var LabelUser = (System.Web.UI.WebControls.Label)r.FindControl("LabelUser");
            //        var it = item.Select("UserName = '" + LabelUser.Text + "'");
            //        ExcelApp.Cells[ind, 1] = it[0].Field<string>("UserName");

            //        ExcelApp.Cells[i, 2] = Data.PersianDate(it[0].Field<DateTime>("CreateDate"));
            //        ExcelApp.Cells[i, 3] = it[0].Field<string>("Type");
            //        ExcelApp.Cells[i, 4] = it[0].Field<string>("Name");
            //        ExcelApp.Cells[i, 5] = it[0].Field<string>("State");
            //        ExcelApp.Cells[i, 6] = it[0].Field<string>("City");
            //        ExcelApp.Cells[i, 7] = it[0].Field<string>("Tel");
            //        ExcelApp.Cells[i, 8] = it[0].Field<string>("Moblie");
            //        ExcelApp.Cells[i, 9] = it[0].Field<bool>("IsApproved");
            //    }
            //}
            //ExcelApp.ActiveWindow.DisplayRightToLeft = false;
            //ExcelApp.ActiveWorkbook.SaveAs(Server.MapPath("~/uploadimage/excel/excelu.xls"));
            //ExcelApp.ActiveWorkbook.Saved = true;
            //ExcelApp.Quit();
            //Downhl.NavigateUrl = "~/uploadimage/excel/excelu.xls";
            //Downhl.Visible = true;
        }
        catch
        {

        }
    }
}