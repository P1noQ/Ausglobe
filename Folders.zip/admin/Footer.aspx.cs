﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using Persia;

public partial class admin_Footer : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        var fm = Data.GetFooterName();
        txtTitle1.Text = fm.FirstOrDefault(p => p.Id.Equals(1)).Name;
        txtTitle2.Text = fm.FirstOrDefault(p => p.Id.Equals(2)).Name;
        txtTitle3.Text = fm.FirstOrDefault(p => p.Id.Equals(3)).Name;
        txtTitle4.Text = fm.FirstOrDefault(p => p.Id.Equals(4)).Name;
    }
    protected void btnEditCommand(object sender, CommandEventArgs e)
    {

        if (e.CommandName.ToString().Equals("Edit"))
        {
            var id = Convert.ToInt32(e.CommandArgument.ToString());
            TextBox txtTitle;
            Label lblMes;
            switch (id)
            {
                case 1:
                    txtTitle = txtTitle1;
                    lblMes = lblMes1;
                    break;
                case 2:
                    txtTitle = txtTitle2;
                    lblMes = lblMes2;
                    break;
                case 3:
                    txtTitle = txtTitle3;
                    lblMes = lblMes3;
                    break;
                default:
                    txtTitle = txtTitle4;
                    lblMes = lblMes4;
                    break;
            }
            try
            {
                Message.EmptyMessage(lblMes1);
                Message.EmptyMessage(lblMes2);
                Message.EmptyMessage(lblMes3);
                Message.EmptyMessage(lblMes4);
                Message.EmptyMessage(lblMes5);
                var Name = Server.HtmlEncode(txtTitle.Text);
                Data.EditFooterName(id, Name);

                Message.MessageGen(lblMes, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
    }

    protected void GvLink1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (Data.EditFooterLink(Convert.ToInt32(e.NewValues[0].ToString()), e.NewValues[1].ToString(), e.NewValues[2].ToString(), (bool)e.NewValues[3])) Message.MessageGen(lblMes1, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMes1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            e.Cancel = true;
            GvLink1.EditIndex = -1;
        }
    }
    protected void GvLink2_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (Data.EditFooterLink(Convert.ToInt32(e.NewValues[0].ToString()), e.NewValues[1].ToString(), e.NewValues[2].ToString(), (bool)e.NewValues[3])) Message.MessageGen(lblMes2, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMes2, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            e.Cancel = true;
            GvLink2.EditIndex = -1;
        }
    }
    protected void GvLink3_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (Data.EditFooterLink(Convert.ToInt32(e.NewValues[0].ToString()), e.NewValues[1].ToString(), e.NewValues[2].ToString(), (bool)e.NewValues[3])) Message.MessageGen(lblMes3, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMes3, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            e.Cancel = true;
            GvLink3.EditIndex = -1;
        }
    }
    protected void GvLink4_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            if (Data.EditFooterLink(Convert.ToInt32(e.NewValues[0].ToString()), e.NewValues[1].ToString(), e.NewValues[2].ToString(), (bool)e.NewValues[3])) Message.MessageGen(lblMes3, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMes4, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            e.Cancel = true;
            GvLink4.EditIndex = -1;
        }
    }
    protected void GvLink1RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Up"))
        {
            try
            {
                var ind = Convert.ToInt32(e.CommandArgument.ToString());
                var row = GvLink1.Rows[ind];
                var lbl = (Label)row.FindControl("lbl");
                var Id = Convert.ToInt32(lbl.Text);
                var TextBox2 = (TextBox)row.FindControl("TextBox2");
                var Name = Server.HtmlEncode(TextBox2.Text);
                var TextBox3 = (TextBox)row.FindControl("TextBox3");
                var Link = Server.HtmlEncode(TextBox3.Text);
                var chkView = (CheckBox)row.FindControl("chkView");
                var view = chkView.Checked;
                if (Data.EditFooterLink(Id, Name, Link, view)) Message.MessageGen(lblMes1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            finally
            {
                GvLink1.EditIndex = -1;
            }
        }
    }

    protected void GvLink2RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Up"))
        {
            try
            {
                var ind = Convert.ToInt32(e.CommandArgument.ToString());
                var row = GvLink2.Rows[ind];
                var lbl = (Label)row.FindControl("lbl");
                var Id = Convert.ToInt32(lbl.Text);
                var TextBox2 = (TextBox)row.FindControl("TextBox2");
                var Name = Server.HtmlEncode(TextBox2.Text);
                var TextBox3 = (TextBox)row.FindControl("TextBox3");
                var Link = Server.HtmlEncode(TextBox3.Text);
                var chkView = (CheckBox)row.FindControl("chkView");
                var view = chkView.Checked;
                if (Data.EditFooterLink(Id, Name, Link, view)) Message.MessageGen(lblMes2, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes2, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            finally
            {
                GvLink2.EditIndex = -1;
            }
        }
    }

    protected void GvLink3RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Up"))
        {
            try
            {
                var ind = Convert.ToInt32(e.CommandArgument.ToString());
                var row = GvLink3.Rows[ind];
                var lbl = (Label)row.FindControl("lbl");
                var Id = Convert.ToInt32(lbl.Text);
                var TextBox2 = (TextBox)row.FindControl("TextBox2");
                var Name = Server.HtmlEncode(TextBox2.Text);
                var TextBox3 = (TextBox)row.FindControl("TextBox3");
                var Link = Server.HtmlEncode(TextBox3.Text);
                var chkView = (CheckBox)row.FindControl("chkView");
                var view = chkView.Checked;
                if (Data.EditFooterLink(Id, Name, Link, view)) Message.MessageGen(lblMes3, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes3, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            finally
            {
                GvLink3.EditIndex = -1;
            }
        }
    }
    protected void GvLink4RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Up"))
        {
            try
            {
                var ind = Convert.ToInt32(e.CommandArgument.ToString());
                var row = GvLink4.Rows[ind];
                var lbl = (Label)row.FindControl("lbl");
                var Id = Convert.ToInt32(lbl.Text);
                var TextBox2 = (TextBox)row.FindControl("TextBox2");
                var Name = Server.HtmlEncode(TextBox2.Text);
                var TextBox3 = (TextBox)row.FindControl("TextBox3");
                var Link = Server.HtmlEncode(TextBox3.Text);
                var chkView = (CheckBox)row.FindControl("chkView");
                var view = chkView.Checked;
                if (Data.EditFooterLink(Id, Name, Link, view)) Message.MessageGen(lblMes4, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes4, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            finally
            {
                GvLink4.EditIndex = -1;
            }
        }
    }
    protected void GvLink5_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            var FUSocial = (FileUpload)GvLink5.Rows[e.RowIndex].FindControl("FUSocial");
            var hdfile = (HiddenField)GvLink5.Rows[e.RowIndex].FindControl("hdfile");
            var show = (CheckBox)GvLink5.Rows[e.RowIndex].FindControl("chkView");
            var filename = "";
            if (FUSocial.HasFile)
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FUSocial.FileName;
                FileJob.DeleteFile(Server.MapPath("~/uploadimage/icon/") + hdfile.Value);
                if (!FileJob.SaveFile(FUSocial, Server.MapPath("~/uploadimage/icon/") + filename))
                {
                    Message.MessageGen(lblMes5, "مشکل در ذخیره تصویر لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    e.Cancel = true;
                    return;
                }
            }
            else
            {
                filename = hdfile.Value.ToString();
            }
            e.NewValues.Add("Image", filename);
            if (Data.EditSocialLink(Convert.ToInt32(e.NewValues[0].ToString()), e.NewValues[1].ToString(), e.NewValues[2].ToString(), e.NewValues[3].ToString(), Convert.ToBoolean(e.NewValues[3]))) Message.MessageGen(lblMes5, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMes5, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            e.Cancel = true;
            GvLink5.EditIndex = -1;
        }
    }
}