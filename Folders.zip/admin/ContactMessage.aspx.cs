﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Threading;

namespace admin
{
    public partial class ContactMessage : System.Web.UI.Page
    {
        public Data Data = new Data();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadDate();
        }
        private void LoadDate()
        {
            var item = Data.GetContact(User.Identity.Name);
            
            gvList.DataSource = item;
            gvList.DataBind();
            if (item.Count() > 0)
            {
                gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvList.FooterRow.TableSection = TableRowSection.TableFooter;

            }
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToString().Equals("remove"))
                {
                    DeleteRecord(Convert.ToInt32(e.CommandArgument));

                    LoadDate();
                    //mod1.Visible = false;
                }
                else if (e.CommandName.ToString().Equals("Read"))
                {

                    var item = Data.GetContact(Convert.ToInt32(e.CommandArgument)); ;
                    Data.ReadContact(Convert.ToInt32(e.CommandArgument));
                    
                    mod1.Attributes["class"] = "modal-open";
                    txtMessage.Text = item.First().Message;

                    LoadDate();

                }
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Data();", true);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.GetContact(id).FirstOrDefault(p => p.Id.Equals(id));
                if (item != null && Data.DeleteContact(id))
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ReadRecord(int id)
        {
            try
            {
                
                //mod1.Visible = true;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void Close(object sender, EventArgs e)
        {
            mod1.Attributes["class"] = "modal-open hidden";
            txtMessage.Text = "";

            LoadDate();
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Data();", true);
        }
        public static string GetIcon(bool Read)
        {
            if (!Read)
                return "i i-mail2 pull-left";
            else
                return "i i-file pull-left";
        }
        public static string GetBold(bool Read, bool Mes = false)
        {
            var ret = Mes ? "text-ellipsis " : "";
            if (!Read)
                ret = ret + "h5";
            return ret;
        }
        public static string Func(int id)
        {
            return "return ShowMes(" + id.ToString() + ")";
        }

    }
}