﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class OnlineConsult : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindCatDocGrid();
            BindDescriptions();
            int Id;
            if (MultiView1.ActiveViewIndex == 1)
            {
                Id = int.Parse(hdfId.Value);
                BindDocGridByCatID(Id);
            }
        }
    }
    Data db = new Data();

    protected void BtnAddGroup_Click(object sender, EventArgs e)
    {
        if (txtGroup.Text.Length == 0)
        {
            lblMessage.Text = "لطفا یک مقدار وارد نمایید.";
            return;
        }

        try
        {
            db.InsertDoctorGroup(txtGroup.Text);
            BindCatDocGrid();
        }
        catch
        {
            lblMessage.Text = "خطا در درج اطالاعات.";
        }
    }

   



    protected void CheckedChanged(object sender, EventArgs e)
    {
        if (ckMail.Checked)
        {
            if (btnAddPart.CommandName.Contains("Edit"))
            {
                var i = Convert.ToInt32(btnAddPart.CommandArgument);
                var us = db.GetDoctors(int.Parse(hdfId.Value)).FirstOrDefault(p => p.Id.Equals(i)).User;
                df.SelectedValue = us;
               
            }
            var userd = db.UserDataAdmin(Membership.ApplicationName);
            var mail = userd.FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;
            txtuMail.Text = mail;
            txtuMail.ToolTip = mail;
        }
        else
        {
            txtuMail.Text = "";
            txtuMail.ToolTip = "";
            if (btnAddPart.CommandName.Contains("Edit"))
            {
                var i = Convert.ToInt32(btnAddPart.CommandArgument);
                var us = db.GetDoctors(int.Parse(hdfId.Value)).FirstOrDefault(p => p.Id.Equals(i)).User;
                df.SelectedValue = us;
             
            }
        }
    }

    protected void btnAddPart_Command(object sender, CommandEventArgs e)
    {
        int Id = int.Parse(hdfId.Value);
        if (e.CommandName.Equals("Add"))
        {
            try
            {
                var userd = db.UserDataAdmin(Membership.ApplicationName);

                var Mail = "";
                var Tel = "";

              if (ckMail.Checked)
                    Mail = userd.FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;

                if (ckMob.Checked)
                {
                    Tel = Profile.GetProfile(df.SelectedValue).Mobile;
                }


                //Data.UserDataAdmin(Membership.ApplicationName).FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;

                var User = "";
                if (df.SelectedIndex > 0) User = df.SelectedValue.ToString();
                //if (User == "" && ViewState["UserName"].ToString() != null)
                //    User = ViewState["UserName"].ToString();
                bool? act;
                if (User.Length.Equals(0))
                    act = null;
                else
                    act = ckPan.Checked;

                var res = db.InsertDoctor(Id, Mail, Tel, User, act);
                switch (res)
                {
                    case 0:
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                        break;
                    case 1:
                        Message.MessageGen(lblMessage, "دکتر قبلا در این تخصص درج شده است", Color.Red);
                        break;
                    case 2:
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);

                    
                        txtuMail.Text = string.Empty;
                        ckMob.Checked = false;
                        ckMail.Checked = false;
                        ckPan.Checked = false;
                        df.SelectedIndex = 0;
                        break;
                }


            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        else
        {
            var i = Convert.ToInt32(e.CommandArgument.ToString());
            var user = db.GetDoctors(Id).FirstOrDefault(p => p.Id.Equals(i));
            var Mail = "";
            var Tel = "";
            bool? act;
            act = null;
            if (e.CommandName.Equals("Edit"))
            {

                if (ckMail.Checked)
                    Mail = db.UserDataAdmin(Membership.ApplicationName).FirstOrDefault(p => p.UserName.Equals(user.User)).Email;

                if (ckMob.Checked)
                    Tel = Profile.GetProfile(user.User).Mobile;

                if (ckPan.Checked)
                    act = true;
                else
                    act = null;

                if (db.EditDoctor(i, Mail, Tel, act))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
            else
            {
             
                if (db.EditPart(i, Mail, Tel, act))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
         
            txtuMail.Text = string.Empty;
           
            ckMob.Checked = false;
            ckMail.Checked = false;
            ckPan.Checked = false;
           
            df.SelectedIndex = 0;
        }
        btnAddPart.CssClass = "form-control m-xs btn btn-primary text-center";
        btnAddPart.CommandName = "Add";
        BindDocGridByCatID(Id);
    }
    protected void btnManage_Click(object sender, EventArgs e)
    {
        int id = int.Parse(ViewState["ID"].ToString());
       
    }

    public void BindCatDocGrid()
    {
        var item = db.GetCatDoctors().OrderByDescending(p => p.Id);
        gvCatDoc.DataSource = item;
        gvCatDoc.DataBind();
    }

    public void BindCatDocTxt()
    {
        var item = (db.GetCatDoctors().OrderByDescending(p => p.Id))
            .First(p => p.Id == int.Parse(hdfId.Value));
        txtGroup2.Text = item.Group;
      
    }

    public void BindCatDoctorsDrop()
    {
        List<spGetUserDataDoctorResult> CatList = new List<spGetUserDataDoctorResult>();
        var sell = new spGetUserDataDoctorResult
        {
            UserName = "", CreateDate = DateTime.Now,Email="a@a.com",
            Name = " انتخاب", Family ="نمایید"
        };

        CatList.Add(sell);
        var Names = db.GetUserDataDoctor(null).AsEnumerable();
        CatList.AddRange(Names);

        df.DataSource = CatList.Select(p => new { Name = p.Name + " "+ p.Family, p.UserName });
        df.DataBind();
       
       

 
    }

    public void BindDescriptions()
    {
        txtTitle.Text = db.GetDescription(8, "t");
        txtDescription.Text = db.GetDescription(8, "d");
        txtKeyword.Text = db.GetDescription(8, "k");
    }
    private void BindDocGridByCatID(int Id)
    {
        var item = db.GetDoctors(Id).OrderByDescending(p => p.Id);
        GridView1.DataSource = item;
        GridView1.DataBind();
    }


    public static bool IsAct(bool? Act)
    {
        return Act.GetValueOrDefault(false);
    }
    public static bool IsAct(string Val)
    {
        var res = Val.Length > 0 ? true : false;
        return res;
    }

    protected void DeletePart(int id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            if (db.DeleteDoctor(id))
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
            else
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void ChangeDoctor(int Id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            txtuMail.Text = "";
       
            var item = db.GetDoctors(Id).FirstOrDefault(p => p.Id.Equals(Id));
            if (item.User.Length > 0)
            {
                if (item.Mail.Length > 0)
                {
                    ckMail.Checked = true;
                    txtuMail.Text = item.Mail;
                }
                else
                    ckMail.Checked = false;

                if (item.Tel.Length > 0)
                    ckMob.Checked = true;
                else
                    ckMob.Checked = false;


                ckPan.Checked = item.InPanel.GetValueOrDefault(false);
                df.SelectedValue = item.User;

         
                btnAddPart.CommandName = "Edit";
                btnAddPart.CssClass = "form-control m-xs btn btn-primary btne1 text-center";
                btnAddPart.CommandArgument = item.Id.ToString();
            }
            else
            {
                df.SelectedIndex = 0;
    
                ckMob.Checked = false;
                ckMail.Checked = false;
                ckPan.Checked = false;
    
                btnAddPart.CssClass = "form-control m-xs btn btn-primary btne2 text-center";
                btnAddPart.CommandName = "EditW";
                btnAddPart.CommandArgument = item.Id.ToString();
            }
            Message.EmptyMessage(lblMessage);
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }

    protected void GrRowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            var Id = Convert.ToInt32(hdfId.Value.ToString());
            switch (e.CommandName)
            {
                case "remove":
                    DeletePart(Convert.ToInt32(e.CommandArgument));
                    BindDocGridByCatID(Id);
                    break;
                case "change":
                    ChangeDoctor(Convert.ToInt32(e.CommandArgument));
                    BindDocGridByCatID(Id);
                    break;
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 0;
        BindCatDocGrid();
    }

    protected void gvCatDoc_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        int id = Convert.ToInt32(e.CommandArgument);
        if (e.CommandName == "Manage")
        {
            hdfId.Value = id.ToString();
            BindCatDocTxt();
            BindCatDoctorsDrop();
            MultiView1.ActiveViewIndex = 1;

        }
        if (e.CommandName == "Remove")
        {

            if (!db.DeleteCatDoctor(id))
                Message.MessageGen(lblMessage, "در این تخصص قبلا سوال درج شده است", System.Drawing.Color.Red);
            else
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد.", System.Drawing.Color.Green);
            BindCatDocGrid();
        }
    }

    //protected void EditKey(object sender, EventArgs e)
    //{
    //    try
    //    {

    //        var Title = txtTitle.Text;
    //        var Keyword = txtKeyword.Text;
    //        var Des = txtDescription.Text;
    //        db.EditDescription(8, Title, Keyword, Des);
    //        Message.MessageGen(lblMessage2, "عملیات با موفقیت انجام شد", Color.Green);
    //        BindDescriptions();
    //    }
    //    catch
    //    {
    //        Message.MessageGen(lblMessage2, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
    //    }
       
    //}
    protected void btnEditGroup_Click(object sender, EventArgs e)
    {
        int id = int.Parse(hdfId.Value);
        string GroupName = txtGroup2.Text;
        try
        {
            db.EditCatDoctor(id, GroupName);
            lblMessage.Text = "عملیات با موفقیت انجام شد.";
        }
        catch

        { lblMessage.Text = "عملیات با مشکل مواجه شد."; }
    }



    protected void btnEditDes_Click(object sender, EventArgs e)
    {
        try
        {

            var Title = txtTitle.Text;
            var Keyword = txtKeyword.Text;
            var Des = txtDescription.Text;
            db.EditDescription(8, Title, Keyword, Des);
            Message.MessageGen(lblMessage2, "عملیات با موفقیت انجام شد", Color.Green);
            BindDescriptions();
        }
        catch
        {
            Message.MessageGen(lblMessage2, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
}
