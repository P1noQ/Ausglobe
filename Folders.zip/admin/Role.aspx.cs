﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Drawing;
using System.Web.Security;

namespace admin
{
    public partial class Role : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadData();
        }
        private void LoadData()
        {
            var item = Data.GetRole().OrderByDescending(p => p.PersianRoleName);
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord((e.CommandArgument.ToString()));
                        LoadData();
                        break;
                    case "change":
                        ChangeRecord((e.CommandArgument.ToString()));
                        LoadData();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(string RoleName )
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                
                if (Roles.GetUsersInRole(RoleName).Count() == 0)
                {
                    Data.DeleteRole(RoleName);
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }
                LoadData();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }

        }
        protected void ChangeRecord(string RoleName)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lbRoleName.Text = RoleName;
                rpRoleMan.DataSource = Data.Access();
                rpRoleMan.DataBind();
                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadData();
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            var RoleName = Server.HtmlEncode(txtRoleName.Text);
            var PRoleName = Server.HtmlEncode(txtPersianRoleName.Text);
            if (RoleName.Length == 0 || PRoleName.Length == 0)
            {
                if (RoleName.Length == 0)
                    role.Attributes["class"] = "input-group-addon has-error";
                else
                    role.Attributes["class"] = "input-group-addon";
                if (PRoleName.Length == 0)
                    prole.Attributes["class"] = "input-group-addon has-error";
                else 
                    prole.Attributes["class"] = "input-group-addon";
                return;
            }
            try
            {
                if(Data.CreateRole(RoleName, PRoleName))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                LoadData();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                MultiView1.ActiveViewIndex = 0;
                HtmlInputCheckBox chk;
                var Role = lbRoleName.Text;
                var RoleId = Data.GetRole().FirstOrDefault(p => p.RoleName.Equals(Role)).RoleId;
                var PageId = 0;
                for (int i = 0; i <= rpRoleMan.Controls.Count - 1; i++)
                {
                    chk = (HtmlInputCheckBox)rpRoleMan.Controls[i].FindControl("chkSelect");
                    PageId = Data.Access().FirstOrDefault(p => p.PagesName.Equals(chk.Value)).Id;

                    if (chk.Checked == true)
                    {
                        Data.CreateRoleData(RoleId, PageId);
                    }
                    if (chk.Checked == false)
                    {
                        Data.DeleteRoleData(RoleId, PageId);
                    }
                }
                LoadData();
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                MultiView1.ActiveViewIndex = 0;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);

                MultiView1.ActiveViewIndex = 1;
            }
        }
        protected void ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            var DT = (AdminPageAccess)e.Item.DataItem;
            if (DT != null)
            {
                var Role = lbRoleName.Text;
                var RoleId = Data.GetRole().FirstOrDefault(p => p.RoleName.Equals(Role)).RoleId;
                var PageId = DT.Id;
                var chk = (HtmlInputCheckBox)e.Item.FindControl("chkSelect");
                if (Data.DB.RoleDatas.Count(p => p.RoleId.Equals(RoleId) && p.PageId.Equals(PageId)) > 0)
                {
                    chk.Checked = true;
                }
                else
                {
                    chk.Checked = false;
                }
            }
        }
    }
}