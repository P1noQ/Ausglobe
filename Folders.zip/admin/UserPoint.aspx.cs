﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.Security;

namespace admin
{
    public partial class UserPoint : System.Web.UI.Page
    {
        Club Club = new Club();
        Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            LoadData();
        }
        private void LoadData()
        {
            var Item = Club.GetClub();
            gvList.DataSource = Item;
            gvList.DataBind();
            if (Item.Any())
            {
                gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvList.FooterRow.TableSection = TableRowSection.TableFooter;
            }
        }
        private void LoadUserData(Guid UserId)
        {
            Membership.ApplicationName = "/";
            var User= Membership.GetUser(UserId);
            
            strUser.InnerText = "امتیازات " + User.UserName.ToString();
            
            Membership.ApplicationName = "/admin";
            //lblUser.Text = Data.GetUserName(UserId.ToString());
            var Item = Club.GetClubUser(UserId.ToString());
            gvList2.DataSource = Item;
            gvList2.DataBind();

            if (Item.Any())
            {
                gvList2.HeaderRow.TableSection = TableRowSection.TableHeader;
                gvList2.FooterRow.TableSection = TableRowSection.TableFooter;
            }

            MultiView1.ActiveViewIndex = 1;
            //gvPoint.DataSource = Item;
            //gvPoint.DataBind();
        }
        protected void gvListRowCommand(object sender, GridViewCommandEventArgs e)
        {

            if (e.CommandName.ToString().Equals("Change"))
            {
                try
                {

                    var UserId = new Guid(e.CommandArgument.ToString());
                    LoadUserData(UserId);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                    MultiView1.ActiveViewIndex = 0;
                }
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            LoadData();
        }
        protected void gvList2RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName.Equals("Change"))
            {
                var ed = Convert.ToInt32(e.CommandArgument.ToString());
                updateP.Visible = true;
                btnUpdate.CommandArgument = e.CommandArgument.ToString();
                var item = Data.DB.Scores.FirstOrDefault(p => p.ID.Equals(ed));
                try
                {
                    txtSub.Text = item.Sub.ToString();
                    gvList2.HeaderRow.TableSection = TableRowSection.TableHeader;
                    gvList2.FooterRow.TableSection = TableRowSection.TableFooter;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetUserPointDataTable();", true);
                }
                catch
                {

                }

            }
            else if (e.CommandName.Equals("UP"))
            {
                gvList2.EditIndex = -1;
            }
            else
            {
                gvList2.EditIndex = -1;
            }
        }
        protected void Back(object sender, EventArgs e)
        {
            updateP.Visible = false;
            gvList2.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList2.FooterRow.TableSection = TableRowSection.TableFooter;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetUserPointDataTable();", true);
        }
        protected void UpdateSub(object sender, EventArgs e)
        {
            var id = Convert.ToInt32(btnUpdate.CommandArgument.ToString());
            var item = Data.DB.Scores.FirstOrDefault(p => p.ID.Equals(id));
            try
            {
                var sub = Convert.ToInt32(Server.HtmlEncode(txtSub.Text.ToString()));
                if (sub <= item.Value)
                {
                    item.Sub = sub;
                    Data.DB.SubmitChanges();
                    
                    updateP.Visible = false;
                    var Item2 = Club.GetClubUser(item.UserId.ToString());
                    gvList2.DataSource = Item2;
                    gvList2.DataBind();

                    if (Item2.Any())
                    {
                        gvList2.HeaderRow.TableSection = TableRowSection.TableHeader;
                        gvList2.FooterRow.TableSection = TableRowSection.TableFooter;
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetUserPointDataTable();", true);
                    }
                }
            }
            catch
            {
                
            }
        }
    }
}