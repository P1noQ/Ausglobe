﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

namespace admin
{
    public partial class Ratio : System.Web.UI.Page
    {
        Club Club = new Club();
        protected void Page_Load(object sender, EventArgs e)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
            if (IsPostBack) return;
        }
        public string GetPrice()
        {
            var dt = new Data();
            return dt.DB.ScoreRoles.FirstOrDefault(p => p.Id.Equals(10)).Price.GetValueOrDefault(0).ToString();
        }
        public static bool ISPrice(string Id ,bool T) 
        {
            var res = false;

            if (T && Id.Equals("10"))
            {
                res = true;
            }
            else if (!T && !Id.Equals("10"))
            {
                res = true;
            }
            return res;
        }
        protected void gvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            
            if (e.CommandName.ToString().Equals("Up"))
            {
                try
                {

                    var row = Convert.ToInt32(e.CommandArgument.ToString());
                    var lbl = (Label)gvList.Rows[row].FindControl("lbl");
                    var txtValue = (TextBox)gvList.Rows[row].FindControl("txtValue");
                    var id = Convert.ToInt32(lbl.Text);
                    var val = Server.HtmlEncode(txtValue.Text);
                    float Value;
                    long? Price;
                    Price = null;
                    if (id == 10 )
                    {
                        var txtPrice = (TextBox)gvList.Rows[row].FindControl("txtPr");
                        var pr = Server.HtmlEncode(txtPrice.Text);
                        Value = Convert.ToSingle(val);
                        Price = Convert.ToInt64(pr);
                    }
                    else
                    {
                        Value = Convert.ToSingle(val);
                    }
                    if (Club.EditRatio(id, Value,Price))
                        Message.MessageGen(lblMessage, "تغییر ضریب با موفقیت انجام شد", Color.Green);
                    else
                        Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                }
                finally
                {
                    gvList.EditIndex = -1;
                }
            }
        }
    }
}