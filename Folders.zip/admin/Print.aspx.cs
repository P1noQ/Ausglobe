﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;

namespace admin
{
    public partial class Print : System.Web.UI.Page
    {
        public static int gc;
        public static bool edit;
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            var da = Data.GetPrintMenu().Where(p => p.LEVEL0.Length == 0).ToList();
            foreach (spGetCatPrintResult m in da)
            {
                DropLevelM.Items.Add(new ListItem(m.Name, m.Id.ToString()));
            }
            //LoadDate();
            //LoadMenuDate();
        }
        private void LoadDate()
        {
            MultiView1.ActiveViewIndex = 1;
            var item = Data.GetPrint().ToList();
            gvList.DataSource = item;
            gvList.DataBind();

            Button1.CssClass = "btn btn-info btn-rounded";
            Button2.CssClass = "btn btn-info btn-rounded";
            Button3.CssClass = "btn btn-info btn-rounded";
            Button4.CssClass = "btn btn-primary btn-rounded";

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        private void LoadMenuDate()
        {
            var item = Data.GetPrintMenu().Where(p => p.LEVEL0.Length > 0).ToList();
            gvList2.DataSource = item;
            gvList2.DataBind();
            Button1.CssClass = "btn btn-info btn-rounded";
            Button2.CssClass = "btn btn-primary btn-rounded";
            Button3.CssClass = "btn btn-info btn-rounded";
            Button4.CssClass = "btn btn-info btn-rounded";
            if (!item.Any()) return;
            gvList2.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList2.FooterRow.TableSection = TableRowSection.TableFooter;
            MultiView1.ActiveViewIndex = 0;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        break;
                    case "remove_":
                        DeleteMenu(Convert.ToInt32(e.CommandArgument));
                        LoadMenuDate();
                        break;
                    case "change_":
                        ChangeMenu(Convert.ToInt32(e.CommandArgument));
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش پرینترها";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                LinkButtonBack.CommandName = "View";
                var item = Data.GetPrint(id).First();
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Model;
                var list = new ListItemCollection();
                list.Add(new ListItem("0", "2"));
                list.Add(new ListItem(item.Level0.ToString(), "2"));
                edit = true;
                rpDropMenu.DataSource = list;
                rpDropMenu.DataBind();
                MultiView1.ActiveViewIndex = 3;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                if (Data.DeletePrint(id))
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "محصول با این رکورد مرتبط شده است", Color.Red);
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeMenu(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblhm.InnerText = "ویرایش برندها";
                BtnEditM.Visible = true;
                BtnInsertM.Visible = false;
                LinkButtonBackm.CommandName = "ViewMenu";
                var item = Data.CatPrintData(id);
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtNameM.Text = item.Name;
                DropLevelM.SelectedValue = item.Parent.GetValueOrDefault(0).ToString();
                
                MultiView1.ActiveViewIndex = 2;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteMenu(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.CatPrintData(id);
                if (item != null)
                {
                    if (Data.DeletePrintMenu(id))
                    {
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "سطح یا پرینتر با این رکورد درج شده است ", Color.Red);
                    }
                }

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnInsertMClick(object sender, EventArgs e)
        {
            try
            {
                var Name = Server.HtmlEncode(txtNameM.Text);
                var Level = 1;
                var Parent = Convert.ToInt32(DropLevelM.SelectedValue.ToString());
                
                if (Data.InsertMenuPrint(Name, Level, Parent))
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                MultiView1.ActiveViewIndex = -1;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
                MultiView1.ActiveViewIndex = 2;
            }
        }
        protected void InsertMenuPrint()
        {
            BtnEditM.Visible = false;
            BtnInsertM.Visible = true;
            Button1.CssClass = "btn btn-primary btn-rounded";
            Button2.CssClass = "btn btn-info btn-rounded";
            Button3.CssClass = "btn btn-info btn-rounded";
            Button4.CssClass = "btn btn-info btn-rounded";
            LinkButtonBackm.CommandName = "Go";
            lblhm.InnerText = "ایجاد برند پرینتر";
            txtNameM.Text = "";
            Message.EmptyMessage(lblMessage);
            DropLevelM.SelectedIndex = 0;
            MultiView1.ActiveViewIndex = 2;
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                var Model = Server.HtmlEncode(txtName.Text);
                int Cat;
                var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                Cat = Convert.ToInt32(drop.SelectedValue.ToString());
                Data.InsertPrint(Model, Cat);
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                MultiView1.ActiveViewIndex = -1;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
                MultiView1.ActiveViewIndex = 3;
            }
        }
        protected void InsertPrint()
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            Button1.CssClass = "btn btn-info btn-rounded";
            Button2.CssClass = "btn btn-info btn-rounded";
            Button3.CssClass = "btn btn-primary btn-rounded";
            Button4.CssClass = "btn btn-info btn-rounded";
            LinkButtonBack.CommandName = "View";
            lblh.InnerText = "ایجاد پرینترها";
            txtName.Text = "";
            edit = false;
            gc = 0;
            Message.EmptyMessage(lblMessage);
            var List = new ListItemCollection();
            var j = 0;
            for (int i = 1; i <= 2; i++)
            {
                if (i == 1)
                {
                    j = 0;
                }
                else
                {
                    j = Data.GetPrintChildMenu(2, j).First().Id;
                }
                List.Add(new ListItem(j.ToString(), "2"));
            }
            rpDropMenu.DataSource = List;
            rpDropMenu.DataBind();
            MultiView1.ActiveViewIndex = 3;
        }
        protected void rpDropMenu_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {

        }
        protected void rpDropMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            var d = (DropDownList)sender;

            var line = Data.CatPrintData(Convert.ToInt32(d.SelectedValue.ToString())).Level;
            for (int I = line + 1; I < rpDropMenu.Items.Count; I++)
            {

                var pdrop = (DropDownList)rpDropMenu.Items[I - 1].FindControl("rpDropLevel");

                var drop = (DropDownList)rpDropMenu.Items[I].FindControl("rpDropLevel");
                try
                {
                    gc = Convert.ToInt32(pdrop.SelectedValue.ToString());
                    var lvl = rpDropMenu.Items.Count;
                    var data = Data.GetPrintChildMenu(lvl, gc);
                    drop.DataSource = data;
                    drop.DataTextField = "Name";
                    drop.DataValueField = "Id";
                    drop.DataBind();

                }
                catch
                {
                    drop.Items.Clear();
                }
            }
            //var city = Library.Db.tblCities.OrderBy(q => q.name).Where(p => p.parentId.Equals(int.Parse(ddlProvince.SelectedValue)));
            //ddlCity.DataSource = city;
            //ddlCity.DataBind();
        }
        protected void BtnEditMClick(object sender, EventArgs e)
        {
            try
            {
                var Name = Server.HtmlEncode(txtNameM.Text);
                
                var Parent = Convert.ToInt32(DropLevelM.SelectedValue.ToString());
                

                try
                {
                    if (Data.EditMenuPrint(int.Parse(hdfId.Value), Name, Parent))
                    {
                        Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                    }


                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                LoadMenuDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 2;
            }
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                var Model = Server.HtmlEncode(txtName.Text);

                var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                var Cat = Convert.ToInt32(drop.SelectedValue.ToString());

                try
                {
                    if (Data.EditPrint(int.Parse(hdfId.Value), Model, Cat))


                    {
                        Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                    }
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 3;
            }
        }
        protected void rpDropMenu_ItemCreated(object sender, RepeaterItemEventArgs e)
        {
            try
            {
                var ind = e.Item.ItemIndex;
                if (ind != -1)
                {
                    var drop = (DropDownList)e.Item.FindControl("rpDropLevel");

                    var DT = (ListItem)e.Item.DataItem;
                    if (DT != null)
                    {
                        gc = Convert.ToInt32(DT.Text.ToString());
                        var lvl = Convert.ToInt32(DT.Value.ToString());
                        var data = Data.GetPrintChildMenu(lvl, gc);
                        drop.DataSource = data;
                        drop.DataTextField = "Name";
                        drop.DataValueField = "Id";
                        drop.DataBind();
                        if (edit)
                        {
                            var par = Data.GetPrintDrop(Convert.ToInt32(hdfId.Value), e.Item.ItemIndex);
                            drop.SelectedIndex = drop.Items.IndexOf(drop.Items.FindByValue(par.ToString()));
                        }
                    }
                }
                else
                {
                    var last = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    last.AutoPostBack = false;
                    gc = 0;
                    rpDropMenu.Visible = true;
                }
            }
            catch
            {
                if (rpDropMenu.Items.Count == 0)
                {
                    rpDropMenu.Visible = false;
                }
            }

        }
        protected void ViewCommand(object sender, CommandEventArgs e)
        {

            if (e.CommandName.Equals("InsertMenu")) //InsertMenu
                InsertMenuPrint();
            else if (e.CommandName.Equals("ViewMenu")) //ViewMenu
                LoadMenuDate();
            else if (e.CommandName.Equals("Insert")) //Insert
                InsertPrint();
            else if (e.CommandName.Equals("View")) //View
                LoadDate();
            else
                MultiView1.ActiveViewIndex = -1;
        }
    }
}