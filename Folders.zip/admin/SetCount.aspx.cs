﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SetCount : System.Web.UI.Page
{
    public Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        Bind();
    }

    private void Bind()
    {
        var item = dt.DB.Counts.FirstOrDefault(p => p.Id.Equals(2));
try {
        Newtxt.Text = item.New.ToString();
        Visittxt.Text = item.VisitC.ToString();
        Saletxt.Text = item.SaleC.ToString();
}
catch { }
    }
    protected void BtnAdd_Click(object sender, EventArgs e)
    {
        try
        {
            var item = dt.DB.Counts.FirstOrDefault(p => p.Id.Equals(2));
            item.New = Convert.ToInt32(Newtxt.Text);
            item.VisitC = Convert.ToInt32(Visittxt.Text);
            item.SaleC = Convert.ToInt32(Saletxt.Text);
dt.DB.SubmitChanges();
            Message.MessageGen(Label1, "عملیات با موفقیت انجام شد", System.Drawing.Color.Green);
        }
        catch(Exception ex) {
            Message.MessageGen(Label1, "عملیات با خطا انجام شد", System.Drawing.Color.Red);
        }

    }
}