﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;

public partial class GalleryManage : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        LoadDate();
    }
    private void LoadDate()
    {
        var item = Data.GetGalleryData();
        gvList.DataSource = item;
        gvList.DataBind();
        if (!item.Any()) return;
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            switch (e.CommandName)
            {
                case "remove":
                    DeleteRecord(Convert.ToInt32(e.CommandArgument));
                    LoadDate();
                    break;
                case "change":
                    ChangeRecord(Convert.ToInt32(e.CommandArgument));
                    LoadDate();
                    break;
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }

    protected void ChangeRecord(int id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            lblh.InnerText = "ویرایش گالری";
            BtnEdit.Visible = true;
            BtnInsert.Visible = false;
            var item = Data.GetGalleryData().FirstOrDefault(p => p.Id.Equals(id));
            if (item == null) return;
            hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
            hdfFile.Value = item.Image;
            imgMenu.ImageUrl = "uploadimage/gallery/" + item.Image;
            MultiView1.ActiveViewIndex = 1;
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void DeleteRecord(int id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            var item = Data.GetGalleryData().FirstOrDefault(p => p.Id.Equals(id));

            if (item != null && !string.IsNullOrEmpty(item.Image))
            {
                if (Data.DeleteGallery(id, Server.MapPath("~/uploadimage/gallery/")))
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                }
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 0;
        LoadDate();
    }

    protected void BtnInsertClick(object sender, EventArgs e)
    {
        try
        {
            string filename;
            if (FileUpload1.HasFile)
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
            }
            else
            {
                Message.MessageGen(lblMessage, "لطفا تصویر اسلاید شو را انتخاب نمایید", Color.Red);
                return;
            }
            if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/gallery/") + filename))
            {
                Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر اسلایدشو لطفا دوباره تصویر را وارد نمایید", Color.Red);
                return;
            }
            var Name = Server.HtmlEncode(txtName.Text);
            var Image = filename;

            var p = Data.InsertGallery(Image, Name);
            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
            LoadDate();
            MultiView1.ActiveViewIndex = 0;
        }
        catch (Exception)
        {
            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
        }
    }
    protected void BtnAddClick(object sender, EventArgs e)
    {
        BtnEdit.Visible = false;
        BtnInsert.Visible = true;
        lblh.InnerText = "ایجاد گالری";
        txtName.Text = "";
        imgMenu.ImageUrl = "";
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 1;
    }
    protected void BtnEditClick(object sender, EventArgs e)
    {
        try
        {
            string filename;
            if (FileUpload1.HasFile)
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                FileJob.DeleteFile(Server.MapPath("~/uploadimage/gallery/") + hdfFile.Value);
                FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/gallery/") + filename);
            }
            else
            {
                filename = hdfFile.Value;
            }
            var Name = Server.HtmlEncode(txtName.Text);
            var Image = filename;


            try
            {
                Data.EditGallery(int.Parse(hdfId.Value), Image, Name);
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            MultiView1.ActiveViewIndex = 1;
        }
    }
}