﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using Persia;
namespace admin
{
    public partial class Frame : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            txtBody.Value = Data.FFrame;
            chkShow1.Checked = Data.FShow;
            txtBody2.Value = Data.LFrame;
            chkShow2.Checked = Data.LShow;
        }
        protected void btnEdit1Click(object sender, EventArgs e)
        {
            try
            {
                Data.FFrame = txtBody.Value;
                Data.FShow = chkShow1.Checked;
                Message.MessageGen(lblMes1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void btnEdit2Click(object sender, EventArgs e)
        {
            try
            {
                Data.LFrame = txtBody.Value;
                Data.LShow = chkShow2.Checked;
                Message.MessageGen(lblMes1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMes1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
    }
}