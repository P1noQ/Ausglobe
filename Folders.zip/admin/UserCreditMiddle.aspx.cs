﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserCreditMiddle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        if (Session["props"] == null)
            return;
        else
        {
            Data dt = new Data();
            List<object> props = new List<object>();
            try
            {
               
                props = (List<object>)Session["props"];
                Guid UserId = (Guid)props[0];
                long price = (long)props[1];
                string type = props[2].ToString();
                string des = props[3].ToString();
                if (dt.AddCash(UserId, price, type, des))
                    Session.Add("Success", 1);
               
            }

            catch {
                Response.Redirect("~/UserCredit.aspx?e=1");
            }
            Response.Redirect("~/UserCredit.aspx");

        }
    }
}