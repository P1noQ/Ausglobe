﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;

namespace admin
{
    public partial class PrintBrands : System.Web.UI.Page
    {
        public static int gc;
        public static bool edit;
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
        }

        private void LoadDate()
        {
            var max = Data.MaxLevelP();
            dropLevel.Items.Clear();
            if (max == -1)
            {
                dropLevel.Visible = false;
            }
            else
            {
                dropLevel.Items.Add(new ListItem("سطح اول", "0"));
                dropLevel.Items.Add(new ListItem("سطح دوم", "1"));
            }
            //var page = Library.Db.tblPages.FirstOrDefault(p => p.id.Equals(9));
            //if (page != null)
            //{
            //    ltrMain.Text = page.main; ;
            //}
            var item = Data.GetPrintMenu().ToList();
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }

        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش منو پرینترها";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                var item = Data.CatPrintData(id);
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                txtName.Text = item.Name;
                var list = new ListItemCollection();
                if (item.Level > 0)
                {
                    for (int i = 0; i <= item.Level - 1; i++)
                    {
                        list.Add(new ListItem("0", item.Level.ToString()));
                    }
                    if (list.Count > 1)
                    {
                        var par = item.Parent.GetValueOrDefault(0);
                        for (int i = list.Count - 1; i > 0; i--)
                        {
                            par = Data.CatPrintData(par).Parent.GetValueOrDefault(0);
                            list[i].Text = par.ToString();
                        }
                    }
                }
                edit = true;
                rpDropMenu.DataSource = list;
                rpDropMenu.DataBind();
                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.CatPrintData(id);
                if (item != null)
                {
                    if (Data.DeletePrintMenu(id))
                    {
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "منو یا پرینتر با این رکورد درج شده است ", Color.Red);
                    }
                }

            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }

        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                var Name = Server.HtmlEncode(txtName.Text);
                var Level = rpDropMenu.Items.Count;
                int? Parent;
                if (Level.Equals(0))
                {
                    Parent = null;
                }
                else
                {
                    var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    Parent = Convert.ToInt32(drop.SelectedValue.ToString());
                }
                if (Data.InsertMenuPrint(Name, Level, Parent))
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            lblh.InnerText = "ایجاد منو پرینتر";
            txtName.Text = "";
            edit = false;
            gc = 0;
            Message.EmptyMessage(lblMessage);
            if (dropLevel.Visible)
            {
                var List = new ListItemCollection();
                if (dropLevel.SelectedIndex > 0)
                {

                    var j = 0;
                    for (int i = 1; i <= dropLevel.SelectedIndex; i++)
                    {
                        if (i == 1)
                        {
                            j = 0;
                        }
                        else
                        {
                            j = Data.GetPrintChildMenu(dropLevel.SelectedIndex, j).First().Id;
                        }
                        List.Add(new ListItem(j.ToString(), dropLevel.SelectedIndex.ToString()));
                    }
                }
                rpDropMenu.DataSource = List;
                rpDropMenu.DataBind();

            }
            //txtName.Text = string.Empty;
            //txtNameStore.Text = string.Empty;
            //txtTel.Text = string.Empty;
            //txtZipCode.Text = string.Empty;
            //txtAddress.Text = string.Empty;
            //txtDescription.Text = string.Empty;
            //ViewProvince();
            //ViewFristCity();
            MultiView1.ActiveViewIndex = 1;
        }
        //public void ViewProvince()
        //{
        //    ddlProvince.DataSource = Library.Db.tblCities.OrderBy(p => p.name).Where(p => p.parentId.Equals(null));
        //    ddlProvince.DataBind();
        //}
        //public void ViewFristCity()
        //{
        //    var province = Library.Db.tblCities.OrderBy(p => p.name).FirstOrDefault(p => p.parentId.Equals(null));
        //    var city = Library.Db.tblCities.Where(p => p.parentId.Equals(province.id)).OrderBy(p => p.name);
        //    ddlCity.DataSource = city;
        //    ddlCity.DataBind();
        //}
        protected void rpDropMenu_ItemCommand(object sender, RepeaterCommandEventArgs e)
        {

        }
        protected void rpDropMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            var d = (DropDownList)sender;
            var lineS = d.ClientID.Split(("_").ToArray());

            var line = Convert.ToInt32(lineS[lineS.Count() - 1]);
            for (int I = line + 1; I < rpDropMenu.Items.Count; I++)
            {

                var pdrop = (DropDownList)rpDropMenu.Items[I - 1].FindControl("rpDropLevel");

                var drop = (DropDownList)rpDropMenu.Items[I].FindControl("rpDropLevel");
                try
                {
                    gc = Convert.ToInt32(pdrop.SelectedValue.ToString());
                    var lvl = rpDropMenu.Items.Count;
                    var data = Data.GetPrintChildMenu(lvl, gc);
                    drop.DataSource = data;
                    drop.DataTextField = "Name";
                    drop.DataValueField = "Id";
                    drop.DataBind();

                }
                catch
                {
                    drop.Items.Clear();
                }
            }
            //var city = Library.Db.tblCities.OrderBy(q => q.name).Where(p => p.parentId.Equals(int.Parse(ddlProvince.SelectedValue)));
            //ddlCity.DataSource = city;
            //ddlCity.DataBind();
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                var Name = Server.HtmlEncode(txtName.Text);
                int? Parent;
                if (rpDropMenu.Items.Count > 0)
                {
                    var drop = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    Parent = Convert.ToInt32(drop.SelectedValue.ToString());
                }
                else
                {
                    Parent = null;
                }


                try
                {
                    Data.EditMenuPrint(int.Parse(hdfId.Value), Name, Parent);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
        protected void rpDropMenu_ItemCreted(object sender, RepeaterItemEventArgs e)
        {
            try
            {
                var ind = e.Item.ItemIndex;
                if (ind != -1)
                {
                    var drop = (DropDownList)e.Item.FindControl("rpDropLevel");

                    var DT = (ListItem)e.Item.DataItem;
                    if (DT != null)
                    {

                        gc = Convert.ToInt32(DT.Text.ToString());
                        var lvl = Convert.ToInt32(DT.Value.ToString());
                        var data = Data.GetPrintChildMenu(lvl, gc);
                        drop.DataSource = data;
                        drop.DataTextField = "Name";
                        drop.DataValueField = "Id";
                        drop.DataBind();
                        if (edit)
                        {
                            var par = Data.GetPrintMenuDrop(Convert.ToInt32(hdfId.Value), e.Item.ItemIndex);
                            drop.SelectedIndex = drop.Items.IndexOf(drop.Items.FindByText(par));
                        }
                    }
                }
                else
                {
                    var last = (DropDownList)rpDropMenu.Items[rpDropMenu.Items.Count - 1].FindControl("rpDropLevel");
                    last.AutoPostBack = false;
                    gc = 0;
                    rpDropMenu.Visible = true;
                }
            }
            catch
            {
                if (rpDropMenu.Items.Count == 0)
                {
                    rpDropMenu.Visible = false;
                }
            }

        }
    }
}