﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;

public partial class WArticle : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack) return;

        LoadDate();
    }
    private void LoadDate()
    {
        var item = Data.GetWikiArticle().ToList();
        gvList.DataSource = item;
        gvList.DataBind();

        drpCat.DataSource = Data.DB.Cats.Where(p => p.Type.Equals("art")).AsQueryable();
        drpCat.DataBind();
        drpCat.DataTextField = "Name";
        drpCat.DataValueField = "Id";

        if (!item.Any()) return;
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            switch (e.CommandName)
            {
                case "remove":
                    DeleteRecord(Convert.ToInt32(e.CommandArgument));
                    LoadDate();
                    break;
                case "change":
                    ChangeRecord(Convert.ToInt32(e.CommandArgument));
                    LoadDate();
                    break;
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void ChangeRecord(int id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            lblh.InnerText = "ویرایش مقاله";
            BtnEdit.Visible = true;
            BtnInsert.Visible = false;
            var item = Data.GetWikiArticle(id).First();
            if (item == null) return;
            hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
            txtName.Text = item.Title;
            txtBrief.Text = item.Brief;
            lblCreateDate.Text = Data.PersianDate((DateTime)item.Date);
            txtBody.Value = item.Body;
            hdfFile.Value = item.Image;
            imgMenu.ImageUrl = "uploadimage/Article/" + item.Image;
            Image1.ImageUrl = "uploadimage/BArticle/" + item.BImage;
            MultiView1.ActiveViewIndex = 1;

        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void DeleteRecord(int id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            var item = Data.GetWikiArticle(id).First();

            if (item != null && !string.IsNullOrEmpty(item.Image))
            {
                switch (Data.DeleteWArticle(id, Server.MapPath("~/uploadimage/Article/"), Server.MapPath("~/uploadimage/BArticle/")))
                {
                    case true:
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                        break;
                    case false:
                        Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                        break;
                }
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 0;
        LoadDate();
    }
    protected void BtnInsertClick(object sender, EventArgs e)
    {
        try
        {
            string filename;
            string filename2;
            if (FileUpload1.HasFile && FileUpload2.HasFile)
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                filename2 = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload2.FileName;
            }
            else
            {
                Message.MessageGen(lblMessage, "لطفا تصویر اخبار را انتخاب نمایید", Color.Red);
                return;
            }
            if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/Article/") + filename) || !FileJob.SaveFile(FileUpload2, Server.MapPath("~/uploadimage/BArticle/") + filename2))
            {
                Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر اخبار لطفا دوباره تصویر را وارد نمایید", Color.Red);
                return;
            }
            var Name = Server.HtmlEncode(txtName.Text);
            var Image = filename;
            var bimage = filename2;
            var Body = txtBody.Value;
            var Brief = Server.HtmlEncode(txtBrief.Text);
            var cat = drpCat.SelectedValue;
            var p = Data.InsertWArticle(Name, Brief, Convert.ToInt32(cat), Body, Image, bimage);
            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
            LoadDate();
            MultiView1.ActiveViewIndex = 0;
        }
        catch (Exception)
        {
            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
        }
    }
    protected void BtnAddClick(object sender, EventArgs e)
    {
        BtnEdit.Visible = false;
        BtnInsert.Visible = true;
        lblh.InnerText = "ایجاد مقاله";
        txtName.Text = "";
        txtBrief.Text = "";
        txtBody.Value = "";
        lblCreateDate.Text = Data.PersianDate(DateTime.Now);
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 1;
    }
    protected void BtnEditClick(object sender, EventArgs e)
    {
        try
        {
            string filename;
            string filename2;
            if (FileUpload1.HasFile || FileUpload2.HasFile)
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                FileJob.DeleteFile(Server.MapPath("~/uploadimage/Article/") + hdfFile.Value);
                FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/Article/") + filename);
                filename2 = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload2.FileName;
                FileJob.DeleteFile(Server.MapPath("~/uploadimage/BArticle/") + hdfFile2.Value);
                FileJob.SaveFile(FileUpload2, Server.MapPath("~/uploadimage/BArticle/") + filename2);
            }
            else
            {
                filename = hdfFile.Value;
                filename2 = hdfFile2.Value;
            }
            var Name = Server.HtmlEncode(txtName.Text);
            var Image = filename;
            var Bimage = filename2;
            var Brief = Server.HtmlEncode(txtBrief.Text);
            var Body = txtBody.Value;
            var cat = drpCat.SelectedValue;
            try
            {
                Data.EditWArticle(int.Parse(hdfId.Value), Name, Brief, Image,Bimage, Body, Convert.ToInt32(cat));
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            MultiView1.ActiveViewIndex = 1;
        }
    }
}