﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ShowGiftCards : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Title = "نمایش کارت های هدیه خریداری شده";
        if (IsPostBack) return;
        var item = dt.GetAllUserGiftCards();
        gvList.DataSource = item;
        gvList.DataBind();
        if (!item.Any()) return;
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
}