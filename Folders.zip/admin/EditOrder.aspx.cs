﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;

public partial class EditOrder : System.Web.UI.Page
{
    public Data Data = new Data();
    public clsShoppingCart Cart = new clsShoppingCart();

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (string.IsNullOrEmpty(Request.QueryString["id"]))
        //    Response.Redirect("~/Order.aspx");
        //var or = Data.DB.Orders.FirstOrDefault(p => p.Equals(int.Parse(Request.QueryString["id"])));
        //if (or == null)
        //    Response.Redirect("~/Order.aspx");
        if (IsPostBack) return;
        StF.Visible = true;
        btnViewState.CommandName = "View";
        btnViewState.CssClass = "glyphicon glyphicon-plus-sign pull-left";
        rpState.DataBind();
        if (rpState.Items.Count == 0)
            rpState.Visible = false;
        else
            rpState.Visible = true;
        UpdatePanel1.Update();

        Message.EmptyMessage(lblMessage1);
        lblMessage1.Visible = false;

        ViewState["id"] = Request.QueryString["id"];
        var Id = long.Parse(ViewState["id"].ToString());
        Selectecord(Id);
        if (rpState.Items.Count == 0)
        {
            rpState.Visible = false;
            UpdatePanel1.Update();
        }

        else
        {
            rpState.Visible = true;

            UpdatePanel1.Update();
        }
    }

    private void Selectecord(long codeTracking)
    {
        try
        {
            Message.EmptyMessage(lblMessage1);
            Membership.ApplicationName = "/";
            ProfileManager.ApplicationName = "/";
            Roles.ApplicationName = "/";
            //int id =int.Parse(Request.QueryString["id"]);
            //ViewState["id"] = id;

            //hfCodeTraking.Value = codeTracking.ToString(CultureInfo.InvariantCulture);
            txtFinal.Text = "";
            rbCancell.Checked = false;
            rbAccept.Checked = false;
            var fac = Data.GetOrderList().FirstOrDefault(p => p.Id == codeTracking);
            if (fac != null)
            {
                var mem = Membership.GetUser(fac.UserName);
                var vwUi = Profile.GetProfile(fac.UserName);
                if (vwUi != null)
                {
                    btnFactorV.PostBackUrl = "~/Factor.aspx?id=" + codeTracking.ToString();
                    lblfname.Text = vwUi.Name;
                    lblLname.Text = vwUi.Family;
                    lblNationalCode.Text = vwUi.NationalCode;
                    lblZipeCode.Text = vwUi.PostalCode;
                    lblTel.Text = vwUi.Tel;
                    lblMobile.Text = vwUi.Mobile;
                    lbladdress.Text = vwUi.Address;
                    lblEmail.Text = mem.Email;
                    lblCity.Text = vwUi.City;
                    lblCreateDate.Text = Data.PersianDate(mem.CreationDate);
                    if (!string.IsNullOrEmpty(vwUi.BirthDate)) lblDateBirth.Text = vwUi.BirthDate;
                    lblProvince.Text = vwUi.State;

                    if (vwUi.Legal.CorpName.ToString().Length > 0)
                    {
                        pnlLegal.Visible = true;
                        var legal = vwUi.Legal;
                        lblCorpType.Text = legal.Type;
                        lblCorpName.Text = legal.CorpName;
                        lblEcocode.Text = legal.EconomicCode;
                        lblNationalId.Text = legal.NationalId;
                        lblActive.Text = legal.Activity;
                        lblDTel.Text = legal.DirectPhone;
                    }
                }
                if (fac.Date != null) lbldateTime.Text = Data.PersianDate(fac.Date.Value);
                if (fac.Status.Contains("رسیدگی"))
                {
                    rbFollow.Checked = true;
                    rbFinal.Checked = false;
                    ////btnAddState.Visible = true;
                    findiv.Visible = false;
                    lblh.InnerText = "پیش فاکتور";
                }
                else
                {
                    rbFollow.Checked = false;
                    StF.Visible = false;
                    rbFinal.Checked = true;
                    //btnAddState.Visible = false;
                    findiv.Visible = true;
                    lblh.InnerText = "فاکتور";
                    if (fac.Status.Contains("لغو"))
                    {
                        rbCancell.Checked = true;
                    }
                    else if (fac.Status.Contains("اتمام"))
                    {
                        rbAccept.Checked = true;
                    }

                }
                if (Cart.GetState(codeTracking).Count() > 0)
                    btnViewState.Visible = true;
                else
                    btnViewState.Visible = false;
                btnViewState.CommandName = "View";
                btnViewState.CssClass = "glyphicon glyphicon-plus-sign pull-left";
                rpState.DataSource = Cart.GetState(codeTracking).OrderByDescending(p => p.Id).Take(1);
                rpState.DataBind();
                lblorderId.Text = Cart.GetCode(fac.Id).ToString(CultureInfo.InvariantCulture);
                lblTotal.Text = Data.PricePersian2(fac.Price.ToString());

                if (fac.Gift.Value)
                {
                    var item = Data.GetDetailsForOrder(codeTracking);
                    pnlGift.Visible = true;
                    lblIsGift.Text = "بله";
                    lblTextGift.Text = item.text;
                    ImageGift.ImageUrl = "~/uploadimage/gift/200/" + item.file;
                    try
                    {
                        bool IsfacSend = Data.DB.OrderGifts.FirstOrDefault(p => p.OId == codeTracking).stateFactor;
                        if (IsfacSend)
                            lblSendFactor.Text = "بله";
                        else
                            lblSendFactor.Text = "خیر";
                    }
                    catch { }
                }
                else
                {
                    pnlGift.Visible = false;
                }

                switch (fac.Pay)
                {
                    case "پرداخت در محل":
                        var typeLocal = Data.DB.PayPlaces.FirstOrDefault(p => p.OId == codeTracking);
                        if (typeLocal != null)
                        {
                            lbldescriptionLocal.Text = typeLocal.description;
                            //lblDesLoc.Text = "aaaaaaaaa";
                            MultiViewDetailsCart.SetActiveView(ViewLocal);
                        }
                        break;
                    case "کارت به کارت":
                        var typeCard = Data.DB.PayCards.FirstOrDefault(p => p.OId == codeTracking);
                        if (typeCard != null)
                        {
                            lblnamebake.Text = typeCard.BankName;
                            lblcard4.Text = typeCard.Card4;
                            lblprice.Text = Data.PricePersian(typeCard.Price.ToString());
                            lblcodeBank.Text = typeCard.CodeFish;
                            lbldescriptionCart.Text = typeCard.Description;
                            MultiViewDetailsCart.SetActiveView(ViewCart);
                        }
                        break;
                    case "آنلاین":
                        var typeOnline = Data.DB.PayOnlines.FirstOrDefault(p => p.orderId == codeTracking && p.state == true);
                        if (typeOnline != null)
                        {
                            //lblorderId.Text = typeOnline.saleReferenceId.ToString();
                            lbldescOnline.Text = typeOnline.description;
                        }
                        GVOnline.DataSource = Data.DB.PayOnlines.Where(p => p.orderId == codeTracking && p.state == false);
                        GVOnline.DataBind();
                        MultiViewDetailsCart.SetActiveView(ViewOnline);
                        break;


                }
            }

            //var q = from p in Data.DB.Products
            //    join o in Data.DB.OrderDetails on p.Id equals o.PId

            //    join s in Data.DB.PSizes on o.SID equals s.Id
            //    join c in Data.DB.PColors on o.SID equals c.SID
            //        where o.OId == codeTracking  
            //        let ColorImage = c.Image


            //    select new
            //    {
            //        o.Id,
            //        o.Price,
            //        o.Count,
            //        p.Name,
            //        p.Image,
            //        s.SizeName,
            //        ColorImage
            //    };
            var q = Data.DB.spFactor(codeTracking).ToList();
            gvPro.DataSource = q;

            //lblTotal.Text = q.Sum(p => p.Price * p.Count).ToString();
            //calcTotalPrice();
            gvPro.DataBind();


            var tbOrder = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(codeTracking));
            var tbCarts = Data.DB.OrderDetails.Where(p => p.OId.Equals(codeTracking));
        }
        catch { }
        finally
        {
            Membership.ApplicationName = "/admin";
            ProfileManager.ApplicationName = "/admin";
            Roles.ApplicationName = "/admin";
        }
        Membership.ApplicationName = "/admin";
        ProfileManager.ApplicationName = "/admin";
        Roles.ApplicationName = "/admin";

    }

    protected string StateQuery(Boolean state)
    {
        var query = "";
        if (state)
        {
            query = "ثبت شده";
        }
        if (!state)
        {
            query = "ثبت نشده";
        }
        return query;
    }

    protected string RequestBk(string pay)
    {
        string request;
        switch (pay)
        {
            case "-1":
                request = "ارسال نشده";
                break;

            case "0":
                request = "تایید شده سمت بانک";
                break;

            default:
                request = "خطا بانکی";
                break;
        }
        return request;
    }

    protected void ViewStateCommand(object sender, CommandEventArgs e)
    {
        ViewState["id"] = long.Parse(Request.QueryString["id"].ToString());
        var id = long.Parse(ViewState["id"].ToString());
        var st = Cart.GetState(id).OrderByDescending(p => p.Id);
        if (e.CommandName == "View")
        {
            btnViewState.CommandName = "Hide";

            rpState.DataSource = st;
            rpState.DataBind();
            btnViewState.CssClass = "glyphicon glyphicon-minus-sign pull-left";
        }
        else
        {
            btnViewState.CommandName = "View";
            btnViewState.CssClass = "glyphicon glyphicon-plus-sign pull-left";
            rpState.DataSource = st.Take(1);
            rpState.DataBind();
        }
    }

    //protected void btnstClick(object sender, EventArgs e)
    //{
    //    StF.Visible = false;
    //    //btnAddState.Visible = true;
    //}
    protected void btnFinalClick(object sender, EventArgs e)
    {
        var State = Server.HtmlEncode(txtFinal.Text);
        var STFactor = "";
        var sms = "";
        var locki = false;
        if (rbAccept.Checked.Equals(true))
        {
            STFactor = "به اتمام رسیده";
            sms = "تایید شد";
            locki = true;
        }
        else
        {
            STFactor = "لغو شده";
            sms = "لغو شد";
        }
        ViewState["id"] = long.Parse(Request.QueryString["id"].ToString());
        var Id = long.Parse(ViewState["id"].ToString());
        var item = Data.DB.Orders.FirstOrDefault(p => p.Id == Id);

        if (item == null) return;
        item.Status = STFactor;
        if (locki)
        {
            item.Lock = locki;
            Data.DB.spInsertScore(10, item.UserId, item.Price.Value);
            Data.DB.spChargeWithSale(Id);
        }
        Data.DB.SubmitChanges();
        rpState.Visible = true;
        var ID = long.Parse(ViewState["id"].ToString());
        var Item = Data.DB.Orders.FirstOrDefault(p => p.Id == Id);
        var Name = Data.GetUserData(item.UserId, 1);
        var userName = Data.GetUserData(item.UserId, 4);
        string msg = "کاربر گرامی " + Name + "فاکتور به شماره" + item.ConCode.Value.ToString() + sms;
        SendMes.InsertMessage(userName, "وضعیت فاکتور ثبت شده", msg);
        try
        {
            var name = Data.GetUserData(item.UserId, 1);
            sms = "کاربر گرامی " + name + "فاکتور به شماره" + item.ConCode.Value.ToString() + sms;
            var mo = Data.GetUserData(item.UserId, 2);
            SendMes.SendSMS(mo, sms);
        }
        catch
        {

        }

        string UN = "";
        if (!string.IsNullOrEmpty(Page.User.Identity.Name))
            UN = Page.User.Identity.Name;

        if (Cart.InsertOrderState(Id, State))
        {
            lblMessage1.Visible = true;
            Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
            txtFinal.Text = "";
            try
            {
                if (btnViewState.Visible == false)
                {
                    btnViewState.Visible = true;
                }
                var st = Cart.GetState(Id).OrderByDescending(p => p.Id);
                if (btnViewState.CssClass == "glyphicon glyphicon-minus-sign pull-left")
                {

                    rpState.DataSource = st;
                }
                else
                {
                    rpState.DataSource = st.Take(1);
                }
                rpState.DataBind();

            }
            catch
            {

            }

        }
        else
        {
            Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }

    }

    protected void AddStateClick(object sender, EventArgs e)
    {

        var State = Server.HtmlEncode(txtStateFac.Text);
        var STFactor = "";
        var sms = "";

        ViewState["id"] = long.Parse(Request.QueryString["id"].ToString());
        var Id = long.Parse(ViewState["id"].ToString());
        var item = Data.DB.Orders.FirstOrDefault(p => p.Id == Id);

        if (item == null) return;
        item.Status = "در حال رسیدگی";

        Data.DB.SubmitChanges();
        rpState.Visible = true;

        try
        {
            var ID = long.Parse(ViewState["id"].ToString());
            var Item = Data.DB.Orders.FirstOrDefault(p => p.Id == Id);
            var Name = Data.GetUserData(item.UserId, 1);
            var userName = Data.GetUserData(item.UserId, 4);
           string msg = "کاربر گرامی " + Name + " " + "فاکتور به شماره" + " " + item.ConCode.Value.ToString() +
                      "در حال رسیدگی می باشد.";
            SendMes.InsertMessage(userName, "وضعیت فاکتور ثبت شده", msg);
            if (chkSMS.Checked && item.ConCode.HasValue)
            {
                var name = Data.GetUserData(item.UserId, 1);
                sms = "کاربر گرامی " + name + " "+ "فاکتور به شماره" + " " + item.ConCode.Value.ToString() +
                      "در حال رسیدگی می باشد.";
                var mo = Data.GetUserData(item.UserId, 2);
                SendMes.SendSMS(mo, sms);
            }
        }
        catch
        {
            Message.MessageGen(lblMessage1, "درج وضعیت با مشکل مواجه شد.", Color.Green);

        }

        string UN = "";
        if (!string.IsNullOrEmpty(Page.User.Identity.Name))
            UN = Page.User.Identity.Name;
        if (Cart.InsertOrderState(Id, State))
        {
            lblMessage1.Visible = true;
            Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
            txtStateFac.Text = "";
            try
            {
                if (btnViewState.Visible == false)
                {
                    btnViewState.Visible = true;
                }
                var st = Cart.GetState(Id).OrderByDescending(p => p.Id);
                if (btnViewState.CssClass == "glyphicon glyphicon-minus-sign pull-left")
                {

                    rpState.DataSource = st;
                }
                else
                {
                    rpState.DataSource = st.Take(1);
                }
                rpState.DataBind();

            }
            catch
            {

            }

        }
        else
        {
            Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }

    //protected void ViewStateCommand(object sender, CommandEventArgs e)
    // {
    //     ViewState["id"] = long.Parse(Request.QueryString["id"].ToString());
    //     var Id = long.Parse(ViewState["id"].ToString());
    //     var st = Cart.GetState(Id).OrderByDescending(p => p.Id);
    //     if (e.CommandName == "View")
    //     {
    //         btnViewState.CommandName = "Hide";

    //         rpState.DataSource = st;
    //         rpState.DataBind();
    //         btnViewState.CssClass = "glyphicon glyphicon-minus-sign pull-left";
    //     }
    //     else
    //     {
    //         btnViewState.CommandName = "View";
    //         btnViewState.CssClass = "glyphicon glyphicon-plus-sign pull-left";
    //         rpState.DataSource = st.Take(1);
    //         rpState.DataBind();
    //     }
    // }
    //protected void btnstClick(object sender, EventArgs e)
    //{
    //    StF.Visible = false;
    //    //btnAddState.Visible = true;
    //}
    //protected void btnFinalClick(object sender, EventArgs e)
    //{
    //    var State = Server.HtmlEncode(txtFinal.Text);
    //    var STFactor = "";
    //    var sms = "";
    //    var locki = false;
    //    if (rbAccept.Checked.Equals(true))
    //    {
    //        STFactor = "به اتمام رسیده";
    //        sms = "تایید شد";
    //        locki = true;
    //    }
    //    else
    //    {
    //        STFactor = "لغو شده";
    //        sms = "لغو شد";
    //    }
    //    var Id = long.Parse(ViewState["id"].ToString());
    //    var st = Cart.GetState(Id).OrderByDescending(p => p.Id);
    //    var item = Data.DB.Orders.FirstOrDefault(p => p.Id == Id);

    //    if (item == null) return;
    //    item.Status = STFactor;
    //    if (locki)
    //    {
    //        item.Lock = locki;
    //        Data.DB.spInsertScore(10, item.UserId, item.Price.Value);
    //    }
    //    Data.DB.SubmitChanges();
    //    rpState.Visible = true;
    //    try
    //    {
    //        var name = Data.GetUserData(item.UserId, 1);
    //        sms = "کاربر گرامی " + name + "فاکتور به شماره" + item.ConCode.Value.ToString() + sms;
    //        var mo = Data.GetUserData(item.UserId, 2);
    //        SendMes.SendSMS(mo, sms);
    //    }
    //    catch
    //    {

    //    }


    //    if (Cart.InsertOrderState(Id, State))
    //    {
    //        lblMessage1.Visible = true;
    //        Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
    //        txtFinal.Text = "";
    //        try
    //        {
    //            if (btnViewState.Visible == false)
    //            {
    //                btnViewState.Visible = true;
    //            }
    //            var st = Cart.GetState(Id).OrderByDescending(p => p.Id);
    //            if (btnViewState.CssClass == "glyphicon glyphicon-minus-sign pull-left")
    //            {

    //                rpState.DataSource = st;
    //            }
    //            else
    //            {
    //                rpState.DataSource = st.Take(1);
    //            }
    //            rpState.DataBind();

    //        }
    //        catch
    //        {

    //        }

    //    }
    //    else
    //    {
    //        Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
    //    }

    //}
    //protected void AddStateClick(object sender, EventArgs e)
    //{

    //    var State = Server.HtmlEncode(txtStateFac.Text);
    //    var STFactor = "";
    //    var sms = "";

    //    var Id = long.Parse(ViewState["id"].ToString());
    //    var st = Cart.GetState(Id).OrderByDescending(p => p.Id);
    //    var item = Data.DB.Orders.FirstOrDefault(p => p.Id == Id);

    //    if (item == null) return;
    //    item.Status = "در حال رسیدگی";

    //    Data.DB.SubmitChanges();
    //    rpState.Visible = true;

    //    try
    //    {
    //        if (chkSMS.Checked && item.ConCode.HasValue)
    //        {
    //            var name = Data.GetUserData(item.UserId, 1);
    //            sms = "کاربر گرامی " + name + "فاکتور به شماره" + item.ConCode.Value.ToString() + sms;
    //            var mo = Data.GetUserData(item.UserId, 2);
    //            SendMes.SendSMS(mo, sms);
    //        }
    //    }
    //    catch
    //    {
    //        Message.MessageGen(lblMessage1, "درج وضعیت با مشکل مواجه شد.", Color.Green);

    //    }


    //    if (Cart.InsertOrderState(Id, State))
    //    {
    //        lblMessage1.Visible = true;
    //        Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
    //        txtStateFac.Text = "";
    //        try
    //        {
    //            if (btnViewState.Visible == false)
    //            {
    //                btnViewState.Visible = true;
    //            }
    //            var st2 = Cart.GetState(Id).OrderByDescending(p => p.Id);
    //            if (btnViewState.CssClass == "glyphicon glyphicon-minus-sign pull-left")
    //            {

    //                rpState.DataSource = st2;
    //            }
    //            else
    //            {
    //                rpState.DataSource = st2.Take(1);
    //            }
    //            rpState.DataBind();

    //        }
    //        catch
    //        {

    //        }

    //    }
    //    else
    //    {
    //        Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
    //    }


    //}

    protected void DeleteOrderItem(int id)
    {
        try
        {
            var OD = Data.DB.OrderDetails.FirstOrDefault(p => p.Id.Equals(id));
            var Price = OD.Count.GetValueOrDefault(0)*OD.Price.GetValueOrDefault(0);
            var ordId = OD.OId.GetValueOrDefault(0);
            Data.BackSize(OD.SID.GetValueOrDefault(0), OD.Count.GetValueOrDefault(0), 0);
            Data.DB.OrderDetails.DeleteOnSubmit(OD);
            var Ord = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(ordId));
            Ord.Price = Ord.Price - Price;
            Data.DB.SubmitChanges();
            Selectecord(ordId);
        }
        catch
        {
            Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }

    protected void CheckedChangedState(object sender, EventArgs e)
    {
        StF.Visible = false;
        if (rbFollow.Checked)
        {
            //btnAddState.Visible = true;
            findiv.Visible = false;
            StF.Visible = true;

        }
        else
        {
            //btnAddState.Visible = false;
            findiv.Visible = true;
        }
    }

    protected void gvPro_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvPro.EditIndex = e.NewEditIndex;
        gvPro.Rows[e.NewEditIndex].RowState = DataControlRowState.Edit;
        long id = long.Parse(ViewState["id"].ToString());
        Selectecord(id);
    }

    protected void gvPro_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        TextBox t = (TextBox) gvPro.Rows[e.RowIndex].FindControl("txtCount");
        Label l = (Label) gvPro.Rows[e.RowIndex].FindControl("lblID2");
        var id = Convert.ToInt32(l.Text);
        try
        {
            //List<object> props = new List<object>();
            // props.Add(id);
            // props.Add(int.Parse(t.Text));
            ViewOrderItem(id, int.Parse(t.Text), true);
        }
        catch
        {
            Message.MessageGen(lblMessage1, "عملیات با مشکل مواجه شد.", System.Drawing.Color.Red);
            e.Cancel = true;
            gvPro.EditIndex = -1;
        }
        //gvPro.Rows[gvPro.EditIndex].RowState = DataControlRowState.Normal;
        gvPro.EditIndex = -1;
        long iD = long.Parse(ViewState["id"].ToString());

        Selectecord(iD);
        //calcTotalPrice();

    }

    private void ViewOrderItem(int id, int count, bool Save = false)
    {
        var OD = Data.DB.OrderDetails.FirstOrDefault(p => p.Id.Equals(id));
        if (Save)
        {
            var c = count;

            if (count > 0 && Data.BackSize(OD.SID.GetValueOrDefault(0), count, OD.Id))
            {
                OD.Count = count;
                Data.DB.SubmitChanges();
               
            }
            else 
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('تعداد وارد شده بیش از تعداد موجود در انبار است')", true);


            var ordId = OD.OId.GetValueOrDefault(0);
            var ord = Data.DB.Orders.FirstOrDefault(p => p.Id.Equals(ordId));
            long Total;
            Total = 0;
            foreach (OrderDetail item in Data.DB.OrderDetails.Where(p => p.OId.Equals(ordId)))
            {
                Total = Total + item.Price.GetValueOrDefault(0)*item.Count.GetValueOrDefault(0);
            }
            ord.Price = Total;
            Data.DB.SubmitChanges();
            lblTotal.Text = Data.PricePersian2(Total.ToString());
            //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "GetPrice('" + Total.ToString() + "')",true);
        }

    }

    protected void gvPro_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        //gvPro.Rows[gvPro.EditIndex].RowState = DataControlRowState.Normal;

        gvPro.EditIndex = -1;
        long iD = long.Parse(ViewState["id"].ToString());

        Selectecord(iD);
        //LoadDate();
    }

    protected void gvPro_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {

        Label l = (Label) gvPro.Rows[e.RowIndex].FindControl("lblID1");
        var id = Convert.ToInt32(l.Text);
        if (gvPro.Rows.Count == 1)
        {
            Response.Write(
                "<script>alert('قادر به خالی کردن فاکتور سفارش نمیباشید در صورت تمایل کل سفارش را پاک نمائید')</script>");
            return;
        }
        DeleteOrderItem(id);

        //gvPro.Rows[gvPro.EditIndex].RowState = DataControlRowState.Normal;
        gvPro.EditIndex = -1;
        //LoadDate();
    }

    protected void BtnBackClick(object sender, EventArgs e)
    {
        Response.Redirect("~/Order.aspx");
    }

    protected void gvProRowCommand(object sender, GridViewCommandEventArgs e)
    {

    }
}