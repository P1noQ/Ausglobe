﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.Security;

public partial class admin_Index : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!User.Identity.IsAuthenticated) return;
        if (!IsPostBack) LoadData();
        var Dt = new Data();
        //var NewUser = Membership.GetAllUsers().OfType<MembershipUser>().Count(p => p.CreationDate.Equals(p.LastLoginDate) && p.IsApproved.Equals(false) && (Roles.IsUserInRole(p.UserName, "Real") || Roles.IsUserInRole(p.UserName, "Legal")));

        //if (NewUser > 0)
        //    lblUser.Text = NewUser.ToString();
        //else
        //    iuser.Visible = false;

        iwar.Visible = false;

        var COrd = Dt.GetOrderList().Count(p => p.Status.Equals("در حال رسیدگی") && string.IsNullOrWhiteSpace(p.Status1));

        if (COrd > 0 && Dt.AllowPage(User.Identity.Name, "Order"))
            lblOrd.Text = COrd.ToString();
        else
            iord.Visible = false;

        var NewMes = Dt.GetContact(Membership.GetUser().UserName).Where(p => !p.Read).ToList().Count();

        if (NewMes > 0)
            lblMes.Text = NewMes.ToString();
        else
            imes.Visible = false;
    }
    private void LoadData()
    {
        txtTitle.Text = Data.GetDescription(1, "t");
        txtDescription.Text = Data.GetDescription(1, "d");
        txtKeyword.Text = Data.GetDescription(1, "k");
    }
    protected void EditKey(object sender, EventArgs e)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            var Title = Server.HtmlEncode(txtTitle.Text);
            var Keyword = Server.HtmlEncode(txtKeyword.Text);
            var Des = Server.HtmlEncode(txtDescription.Text);
            Data.EditDescription(1, Title, Keyword, Des);
            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
        LoadData();
    }
}