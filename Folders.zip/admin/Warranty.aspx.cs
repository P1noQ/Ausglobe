﻿using LinqToExcel;
using System;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Security.Cryptography;
using System.Text;
using System.Collections.Generic;
using System.Data;
using System.Xml;
using System.Xml.Xsl;

namespace admin
{
    public partial class Warranties : System.Web.UI.Page
    {
        public const string Type = "warranty";
        public const int Level = 0;
        public Data Data = new Data();
        private void ExportGridToExcel()
        {
            string procInfo = "type='text/xsl' href='" + "\\transform.xslt" + "'";//Processing info for XSLT
            string TempPath = Environment.GetFolderPath(Environment.SpecialFolder.InternetCache);
            string XMLPath = TempPath + "\\Products.xml"; //temp path to store the XML file
            string XLSPath = TempPath + "\\Products.xls";//temp path to store the XLS file


            //Write the dataset as XML file with some XSLT processing information
            using (XmlTextWriter tw = new XmlTextWriter(XMLPath,
                       null))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                var dt = Data.WarrantyExcell();
                foreach (DataRow dr in dt.Rows)
                {
                    dr.SetField<string>("Serial", Hash.DecryptStringFromBytes_Des(dr.Field<string>("Serial")));
                }
                dt.TableName = "گارانتی";
                var ds = new DataSet();
                ds.Tables.Add(dt);
                //ds.WriteXml(Server.MapPath("~/data.xml"));
                //ds.WriteXmlSchema(Server.MapPath("~/schema.xml"));
                tw.WriteProcessingInstruction("xml-stylesheet", procInfo);
                ds.WriteXml(tw);
            }


            XmlDataDocument xmldoc = new XmlDataDocument();
            xmldoc.Load(XMLPath);
            XslCompiledTransform xsl = new XslCompiledTransform();
            xsl.Load(Server.MapPath(".") + "\\excell\\Transform2.xslt");



            using (XmlTextWriter tw = new XmlTextWriter(XLSPath, System.Text.Encoding.UTF8))
            {
                tw.Formatting = Formatting.Indented;
                tw.Indentation = 3;
                tw.WriteStartDocument();
                xsl.Transform(xmldoc, null, tw);//Performa XSLT transformation.
            }



            //Streams the generated XLS file to the user
            byte[] Buffer = null;
            using (FileStream MyFileStream = new FileStream(XLSPath, FileMode.Open))
            {
                // Total bytes to read: 
                long size;
                size = MyFileStream.Length;
                Buffer = new byte[size];
                MyFileStream.Read(Buffer, 0, int.Parse(MyFileStream.Length.ToString()));
            }
            Response.ContentType = "application/xls";
            string header = "attachment; filename=" + "warranty" + DateTime.Now.Ticks.ToString() + ".xls";
            Response.AddHeader("content-disposition", header);
            Response.BinaryWrite(Buffer);
            Response.Flush();
            Response.End();

        }
        private bool IsRegister(Guid War)
        {
            if (Data.DB.WarrantyRegisters.Count(p => p.Warranty == War) > 0)
                return true;
            else
                return false;
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LoadDate();
                //GetFail();
            }
        }
        protected void ViewWarC(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 0;
            btnWarView.Enabled = false;
            btnWarUserView.Enabled = true;
            btnAddView.Enabled = true;
            LoadDate();
            gvList.Columns[6].Visible = false;
            gvList.Columns[7].Visible = false;
            gvList.Columns[9].Visible = false;
        }
        protected void ViewWarUserC(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 0;
            btnWarView.Enabled = true;
            btnWarUserView.Enabled = false;
            btnAddView.Enabled = true;
            LoadDate();
            gvList.Columns[6].Visible = false;
            gvList.Columns[7].Visible = false;
            gvList.Columns[9].Visible = false;
        }
        //protected void ViewFailC(object sender, EventArgs e)
        //{
        //    MultuViewItem.ActiveViewIndex = 1;
        //    btnWarView.Enabled = true;
        //    btnErrView.Enabled = false;
        //    btnAddView.Enabled = true;
        //    GetFail();
        //}
        protected void ViewAddC(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 2;
            btnWarView.Enabled = true;
            btnWarUserView.Enabled = true;
            //btnErrView.Enabled = true;
            btnAddView.Enabled = false;
        }
        private void LoadDate()
        {
            var item = Data.GetWarranty().OrderByDescending(w => w.date);
            if (btnWarView.Enabled)
            {
                item = item.Where(p => IsRegister(p.WarrantyId)).OrderByDescending(w => w.date);
            }
            gvList.DataSource = item;
            gvList.DataBind();
            
            
            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "Edit":
                        EditRecord(e.CommandArgument.ToString());
                        break;
                    case "EditReg":
                        EditRegister(new Guid(e.CommandArgument.ToString()));
                        break;
                    case "delete":
                        DeleteRecord(e.CommandArgument.ToString());
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(string code)
        {
            try
            {
                Message.EmptyMessage(lblMessage);

                if (Data.DeleteWarranty(code))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void EditRecord(string code)
        {
            try
            {

                var warranty = Data.GetWarranty().FirstOrDefault(p => p.code3.Equals(code));
                if (warranty == null)
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                    return;
                }
                Message.EmptyMessage(lblMessage);
                lbl.Text = "آرشیو گارانتی ها";
                lblh.InnerText = "ویرایش گارانتی";
                btnEdit.Visible = true;
                btnInsert.Visible = false;
                MultuViewItem.ActiveViewIndex = 3;
                idhiden.Value = code;
                txtCode.Text = Hash.DecryptStringFromBytes_Des(warranty.code3);
                txtSubject.Text = warranty.subject.ToString(CultureInfo.InvariantCulture);
                dpStartDate.Date = warranty.startDate;
                dpExpiryDate.Date = warranty.expiryDate;
                ckActive.Checked = warranty.active;
                var UserId = warranty.UserId;
                var UserName = Membership.GetUser(UserId).UserName;
                ManCreate.Text = Data.GetUserNameAdmin(UserName);
                if (warranty.date != null) lblDateRegister.Text =Data.PersianDate((DateTime)warranty.date);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void EditRegister(Guid WarrantyId)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var warranty = Data.GetWarranty().FirstOrDefault(p => p.WarrantyId.Equals(WarrantyId));
                if (warranty == null)
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                    return;
                }
                if (warranty.WarrantyRegisters.Any())
                {
                    var Reg = warranty.WarrantyRegisters.First();
                    var User = Membership.GetUser(Reg.User);
                    var pr = Profile.GetProfile(User.UserName);
                    lblUser.Text = User.UserName;
                    lblName.Text = pr.Name + " " + pr.Family;
                    lblMobile.Text = pr.Mobile;
                    lblMail.Text = User.Email;
                    lblCode.Text = Hash.DecryptStringFromBytes_Des(warranty.code3);
                    lblDateWarRegister.Text = Data.PersianDate(Reg.date);
                    ckActiveReg.Checked = Reg.active;
                    MultuViewItem.ActiveViewIndex = 5;
                    idhiden.Value = warranty.WarrantyId.ToString();
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                var id = idhiden.Value.ToString();
                

                var myDes = DES.Create();

                var code = "";
                var enc = Hash.EncryptStringToBytes_Des(txtCode.Text);
                if (Hash.DecryptStringFromBytes_Des(id).Equals(txtCode.Text))
                {
                    code = id;
                }
                else
                {
                    code = Hash.GetString(myDes.Key) + char.ConvertFromUtf32(300) + Hash.GetString(myDes.IV) + char.ConvertFromUtf32(300) + Hash.GetString(enc);
                }
                myDes.Clear();

                var UserId = new Guid(Membership.GetUser().ProviderUserKey.ToString());
                if (Data.EditWarranty(UserId,idhiden.Value, code , dpStartDate.Date, dpExpiryDate.Date, txtSubject.Text, ckActive.Checked))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                MultuViewItem.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 3;
            }
        }
        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                var myDes = DES.Create();
                var enc = Hash.EncryptStringToBytes_Des(txtCode.Text);
                var code = Hash.GetString(enc);
                var code1 = Hash.GetString(myDes.Key);
                var code2 = Hash.GetString(myDes.IV);
                code = code1 + char.ConvertFromUtf32(300) + code2 + char.ConvertFromUtf32(300) + code;
                myDes.Clear();
                var UserId = new Guid(Membership.GetUser().ProviderUserKey.ToString());
                if (!Data.InsertWarranty(UserId, code, dpStartDate.Date, dpExpiryDate.Date, txtSubject.Text, ckActive.Checked))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                MultuViewItem.ActiveViewIndex = 2;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 3;
            }
        }
        protected void BtnEditRegClick(object sender, EventArgs e)
        {
            try
            {
                var id = idhiden.Value.ToString();
                var g=new Guid (id);
                if (Data.DB.WarrantyRegisters.Count(p => p.Warranty.Equals(g)) == 1)
                {
                    var item = Data.DB.WarrantyRegisters.FirstOrDefault(p => p.Warranty.Equals(g));
                    item.active = ckActiveReg.Checked;
                    if (!item.@lock.GetValueOrDefault(false))
                    {
                        item.@lock = true;
                        if (ckActiveReg.Checked)
                        {
                            Data.DB.spInsertScore(16, item.User, 1);
                        }
                    }
                    Data.DB.SubmitChanges();
                    LoadDate();
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    MultuViewItem.ActiveViewIndex = 0;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 5;
            }
        }
        protected void GvListDataBound(object sender, EventArgs e)
        {
            lblMessage.Text = string.Empty;
        }

        protected void GvListRowEditing(object sender, GridViewEditEventArgs e)
        {
            
        }

        protected void GvListRowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            LoadDate();
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            if (!btnWarView.Enabled)
                MultuViewItem.ActiveViewIndex = 0;
            //else if (!btnErrView.Enabled)
            //    MultuViewItem.ActiveViewIndex = 1;
            else
                MultuViewItem.ActiveViewIndex = 2;
            Message.EmptyMessage(lblMessage);
            LoadDate();
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 3;
            lbl.Text = "ایجاد گارانتی";
            lblh.InnerText = "ایجاد گارانتی تکی";
            btnInsert.Visible = true;
            btnEdit.Visible = false;
            txtSubject.Text = string.Empty;
            txtCode.Text = string.Empty;
            ManCreate.Text = Profile.Name + " " + Profile.Family;
            Message.EmptyMessage(lblMessage);
            lblDateRegister.Text = Data.PersianDate(DateTime.Now);
            dpStartDate.Text = string.Empty;
            dpExpiryDate.Text = string.Empty;
            ckActive.Checked = true;
            Message.EmptyMessage(lblMessage);
        }
        protected void BtnAddExcelClick(object sender, EventArgs e)
        {
            MultuViewItem.ActiveViewIndex = 4;
        }
        protected void BtnInsertExcelClick(object sender, EventArgs e)
        {
            try
            {
                if (!FileUpload1.HasFile) return;
                var fileExt = Path.GetExtension(FileUpload1.FileName);
                var path = Server.MapPath("~/uploadimage/excel/Excel" + fileExt);
                FileUpload1.SaveAs(path);

                var book = new ExcelQueryFactory(path);
                var australia = from x in book.Worksheet()
                                select new
                                {
                                    code = x[0],
                                    subject = x[1],
                                    description = x[2],
                                    startDate = x[3],
                                    expiryDate = x[4]
                                };
                var persianCalendar = new PersianCalendar();
                foreach (var i in australia)
                {
                    var startDate = persianCalendar.ToDateTime(Convert.ToInt32(i.startDate.ToString().Substring(0, 4)), Convert.ToInt32(i.startDate.ToString().Substring(5, 2)), Convert.ToInt32(i.startDate.ToString().Substring(8, 2)), 0, 0, 0, 0);
                    var expiryDate = persianCalendar.ToDateTime(Convert.ToInt32(i.expiryDate.ToString().Substring(0, 4)), Convert.ToInt32(i.expiryDate.ToString().Substring(5, 2)), Convert.ToInt32(i.expiryDate.ToString().Substring(8, 2)), 0, 0, 0, 0);
                    var myDes = DES.Create();
                    var enc = Hash.EncryptStringToBytes_Des(i.code.ToString());
                    var code = Hash.GetString(myDes.Key) + char.ConvertFromUtf32(300) + Hash.GetString(myDes.IV) + char.ConvertFromUtf32(300) + Hash.GetString(enc);
                    var UserId = new Guid(Membership.GetUser().ProviderUserKey.ToString());
                    Data.InsertWarranty(UserId, code, startDate, expiryDate, i.subject);
                    myDes.Clear();
                }
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                MultuViewItem.ActiveViewIndex = 2;
                LoadDate();
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultuViewItem.ActiveViewIndex = 4;
            }
        }
        protected void BtnImportClick(object sender, EventArgs e)
        {
            try
            {
                ExportGridToExcel();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            finally
            {
                LoadDate();
            }
        }
        protected void BtnImportSelClick(object sender, EventArgs e)
        {
            try
            {
                //Message.EmptyMessage(lblMessage);
                //var item = Data.GetWarranty().OrderByDescending(w => w.date);
                //var ExcelApp = new ApplicationClass();

                //ExcelApp.Application.Workbooks.Add(System.Type.Missing);
                //var ind = 1;
                //ExcelApp.Cells[1, 1] = "code";
                //ExcelApp.Cells[1, 2] = "subject";
                //ExcelApp.Cells[1, 3] = "description";
                //ExcelApp.Cells[1, 4] = "startDate";
                //ExcelApp.Cells[1, 5] = "expiryDate";
                //foreach (GridViewRow r in gvList.Rows)
                //{
                //    var chkSelect = (System.Web.UI.WebControls.CheckBox)r.FindControl("chkSelect");
                //    if (chkSelect.Checked.Equals(true))
                //    {
                //        ind = ind + 1;
                //        var lkbtnId = (LinkButton)r.FindControl("lkbtnId");
                //        var c = Hash.GetString(Hash.EncryptStringToBytes_Des(lkbtnId.Text));
                //        var it = item.FirstOrDefault(i => i.code3.Equals(c));
                //        ExcelApp.Cells[ind, 1] = lkbtnId.Text;
                //        ExcelApp.Cells[ind, 2] = it.subject;
                        
                //        ExcelApp.Cells[ind, 4] = Data.PersianDate(it.startDate.GetValueOrDefault(DateTime.Now));
                //        ExcelApp.Cells[ind, 5] = Data.PersianDate(it.expiryDate.GetValueOrDefault(DateTime.Now));
                //    }
                //}
                //ExcelApp.ActiveWindow.DisplayRightToLeft = false;
                //ExcelApp.ActiveWorkbook.SaveAs(Server.MapPath("~/uploadimage/excel/excelw.xls"));
                //ExcelApp.ActiveWorkbook.Saved = true;
                //ExcelApp.Quit();
                //Downhl.NavigateUrl = "~/uploadimage/excel/excelw.xls";
                //Downhl.Visible = true;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            finally
            {
                LoadDate();
            }
        }
        protected void BtnFilterClick(object sender, EventArgs e)
        {
            try
            {
                var code = txtSCode.Text;

                var item = Data.GetWarranty();
                if (code.Length > 0)
                {
                    code = Hash.GetString(Hash.EncryptStringToBytes_Des(code));
                    item = item.Where(i => i.code3 == code);
                }
                if (dpFStart.Text.Length > 0)
                {
                    item = item.Where(p => p.expiryDate >= dpFStart.Date);
                }

                if (dpFExpire.Text.Length > 0)
                {
                    item = item.Where(p => p.startDate <= dpFExpire.Date);
                }
                gvList.DataSource = item.ToList();
                gvList.DataBind();
                if (item.Any())
                {
                    gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
                    gvList.FooterRow.TableSection = TableRowSection.TableFooter;
                }
            }
            catch
            {

            }
        }
        public void GetFail()
        {
            var f = Data.GetFailture();
            GVFail.DataSource = f;
            GVFail.DataBind();

        }
        protected void GVFailRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.ToString().Equals("View"))
                {
                    ViewFails(Convert.ToInt32(e.CommandArgument.ToString()));
                    GetFail();
                    LoadDate();
                }
                else if (e.CommandName.ToString().Equals("Remove"))
                {
                    DeleteFail(Convert.ToInt32(e.CommandArgument.ToString()));
                    GetFail();
                    LoadDate();
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteFail(int Id)
        {
            try
            {
                var Item = Data.GetFailture(Id).First();
                Data.DeleteFailture(Item.Warranty, Item.User);
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ViewFails(int Id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.GetFailture(Id).First();
                var item2 = Data.GetWarranty().FirstOrDefault(p => p.WarrantyId.Equals(item.Warranty));
                lblFDes.Text = item.Description;
                lblFCode.Text = Hash.DecryptStringFromBytes_Des(item2.code3);
                lblFUser.Text = Data.GetUserData(item.User, 1);
                var pc = new PersianCalendar();
                var cd = item.CreateDate;
                var c2 = pc.GetYear(cd).ToString() + "/" + pc.GetMonth(cd).ToString() + "/" + pc.GetDayOfMonth(cd);
                lblfCreate.Text = c2;
                MultuViewItem.ActiveViewIndex = 6;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        public static string GetCode(Guid WID)
        {
            var Dt = new Data();
            var item = Dt.GetWarranty().FirstOrDefault(p => p.WarrantyId.Equals(WID));
            var ret = Hash.DecryptStringFromBytes_Des(item.code3);
            return ret;
        }
    }
}