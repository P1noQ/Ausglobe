﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Net.Mail;
using System.Web.Profile;

namespace admin
{
    public partial class ResetPassword : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage.Width = 283;
            CaptchaImage.Height = 75;
            CaptchaImage.Text = imgcode;
            if (Membership.ApplicationName == "/")
            {
                var rd = false;
                if (Page.User.Identity.IsAuthenticated)
                {
                    FormsAuthentication.SignOut();
                    rd = true;
                }
                Membership.ApplicationName = "/admin";
                Roles.ApplicationName = "/admin";
                ProfileManager.ApplicationName = "/admin";
                if (rd)
                {
                    Page.Response.Redirect(Page.Request.Url.OriginalString);
                }
            }
            try
            {
                var g = new Guid(Request.QueryString["UserId"].ToString());
                var User = Membership.GetUser(g);
                if (Request.Cookies[User.UserName] == null)
                {

                    lblMessage.Text = "زمان بازیابی رمز عبور به اتمام رسیده است";
                    lblMessage.CssClass = "text-danger input-lg";
                    lblMessage.Visible = true;
                }
            }
            catch
            {
                lblMessage.Text = "دستیابی غیر مجاز به صفحه بازیابی رمز عبور";
                lblMessage.CssClass = "text-danger input-lg";
                lblMessage.Visible = true;
                return;
            }
        }
        protected void GetCaptcha(object sender, EventArgs e)
        {
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage.Width = 283;
            CaptchaImage.Height = 75;
            CaptchaImage.Text = imgcode;
        }

        protected void btnResetClick(object sender, EventArgs e)
        {
            try
            {
                var code = Server.HtmlEncode(txtCode.Text);
                if (code.ToLower() != CaptchaImage.Text.ToLower())
                {
                    lblMessage.Text = "کد امنیتی را درست وارد نمایید";
                    lblMessage.CssClass = "text-danger input-lg";
                    lblMessage.Visible = true;
                    var imgcode = Data.GenerateRandomCode();
                    CaptchaImage.Width = 283;
                    CaptchaImage.Height = 75;
                    CaptchaImage.Text = imgcode;
                    return;
                }
                var g = new Guid(Request.QueryString["UserId"].ToString());
                var User = Membership.GetUser(g);
                if (Request.Cookies[User.UserName] == null)
                {
                    lblMessage.Text = "زمان بازیابی رمز عبور به اتمام رسیده است";
                    lblMessage.CssClass = "text-danger input-lg";
                    lblMessage.Visible = true;
                    return;
                }
                else
                {
                    var oldPass = User.ResetPassword();
                    var newPass = Server.HtmlEncode(txtPassword.Text);
                    var newPassRep = Server.HtmlEncode(txtRepPass.Text);
                    if (newPassRep == newPass)
                    {
                        User.ChangePassword(oldPass, newPass);
                        lblMessage.Text = "رمز عبور تغییر  یافت.";
                        var cook = new HttpCookie(User.UserName, "t");
                        cook.Expires = DateTime.Now.AddDays(-1d);
                        Response.Cookies.Add(cook);
                    }
                    else
                    {
                        lblMessage.Text = "تکرار رمز عبور را درست وارد نمایید";
                        lblMessage.CssClass = "text-danger input-lg";
                        lblMessage.Visible = true;
                    }
                }
            }
            catch
            {
                lblMessage.Text = "دستیابی غیر مجاز به صفحه بازیابی رمز عبور";
                lblMessage.CssClass = "text-danger input-lg";
                lblMessage.Visible = true;
                return;
            }
        }
    }
}