﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;
using System.Data;

public partial class ManageMessage : System.Web.UI.Page
{
    public Data data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        drpintro.SelectedIndex = 0;
    }
    private void LoadDate(int id)
    {

        var item = data.GetMessage(id).ToList();
        txtSubject.Text = item.FirstOrDefault().Title;
        txtText.Text = item.FirstOrDefault().Text;
       
    }


   static int ID = 0;
    protected void BtnEditClick(object sender, EventArgs e)
    {
            try
            {
                var Sub=txtSubject.Text;
                var text=txtText.Text;
                int catid = Convert.ToInt32(drpintro.SelectedValue);
                if (ID == 0)
                {
                    Message.MessageGen(lblMessage, "لطفا یک مورد را انتخاب نمایید", Color.Red);
                    return;
                }
                data.EditMes(ID, Sub, text, catid);
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
           
            LoadDate(ID);
        }
    protected void drpintro_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpintro.SelectedIndex != 0)
        {
            if (drpintro.SelectedIndex == 1)
            {
                ID = 3;
                LoadDate(ID);
            }
            if (drpintro.SelectedIndex == 2)
            {
                ID = 2;
                LoadDate(ID);
            }
        }
    }
}