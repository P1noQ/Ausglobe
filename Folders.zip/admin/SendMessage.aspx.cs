﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Threading;
using System.Globalization;

public partial class admin_SendMessage : System.Web.UI.Page
{
    public Data Data = new Data();
    public static DataTable dt;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        MVSend.ActiveViewIndex = 0;
        try
        {
            dt.Rows.Clear();
        }
        catch 
        {
            
        }
        var st = Data.State();
        var edu = Data.Education();
        var act = Data.Active();
        var met = Data.Meet();
        dropState.Items.Add(new ListItem("استان", "0"));
        dropCity.Items.Add(new ListItem("شهر", "0"));
        dropMeet.Items.Add(new ListItem("طریقه عضویت", "0"));


        foreach (DataRow D in st.Rows)
        {
            dropState.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
        }

        foreach (DataRow D in met.Rows)
        {
            dropMeet.Items.Add(new ListItem(D[1].ToString(), D[0].ToString()));
        }
        var comment = Data.UserData("/");

        var t = comment.AsDataView();
        gvList.DataSource = t;
        gvList.DataBind();
        if (comment.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    private String _taskprogress;
    private AsyncTaskDelegate _dlgt;
    private String _taskprogress2;
    private AsyncTaskDelegate _dlgt2;
    private String _taskprogress3;
    private AsyncTaskDelegate _dlgt3;
    private string User;

    // Create delegate. 
    protected delegate void AsyncTaskDelegate();
    protected delegate void AsyncTaskDelegate2();
    protected delegate void AsyncTaskDelegate3();
    public String GetAsyncTaskProgress()
    {
        return _taskprogress;
    }
    public String GetAsyncTaskProgress2()
    {
        return _taskprogress2;
    }
    public String GetAsyncTaskProgress3()
    {
        return _taskprogress3;
    }
    public void DoTheAsyncTask()
    {
        // Introduce an artificial delay to simulate a delayed  
        // asynchronous task. Make this greater than the  
        // AsyncTimeout property.

        var sid = Convert.ToInt32(dropState.SelectedValue.ToString());
        var ct = Data.City(sid);
        dropState.Enabled = false;
        dropCity.Items.Clear();
        dropCity.Items.Add(new ListItem("شهر", "0"));
        foreach (DataRow D in ct.Rows)
        {
            dropCity.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
        }
        dropState.Enabled = true;
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        Thread.Sleep(TimeSpan.FromSeconds(5.0));
    }

    public void DoTheAsyncTask2()
    {
        // Introduce an artificial delay to simulate a delayed  
        // asynchronous task. Make this greater than the  
        // AsyncTimeout property.
        var comment = Data.UserData("/");
        var t = comment.AsDataView();
        gvList.DataSource = t;
        gvList.DataBind();
        if (comment.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        btnSel.Visible = true;
        btnFilter.Visible = true;
        btnNews.Visible = true;
        MVSend.ActiveViewIndex = 0;
        lblMes.Visible = false;
        Thread.Sleep(TimeSpan.FromSeconds(5.0));
    }

    public void DoTheAsyncTask3()
    {
        // Introduce an artificial delay to simulate a delayed  
        // asynchronous task. Make this greater than the  
        // AsyncTimeout property.
        
    }
    // Define the method that will get called to 
    // start the asynchronous task. 
    public IAsyncResult OnBegin(object sender, EventArgs e,
        AsyncCallback cb, object extraData)
    {

        _taskprogress = "Beginning async task.";

        _dlgt = new AsyncTaskDelegate(DoTheAsyncTask);
        IAsyncResult result = _dlgt.BeginInvoke(cb, extraData);
        return result;
    }
    public IAsyncResult OnBegin2(object sender, EventArgs e,
        AsyncCallback cb, object extraData)
    {

        _taskprogress2 = "Beginning async task.";

        _dlgt2 = new AsyncTaskDelegate(DoTheAsyncTask2);
        IAsyncResult result = _dlgt2.BeginInvoke(cb, extraData);

        return result;
    }
    public IAsyncResult OnBegin3(object sender, EventArgs e,
        AsyncCallback cb, object extraData)
    {

        _taskprogress3 = "Beginning async task.";

        _dlgt3 = new AsyncTaskDelegate(DoTheAsyncTask3);
        IAsyncResult result = _dlgt3.BeginInvoke(cb, extraData);
        
        return result;
    }
    // Define the method that will get called when 
    // the asynchronous task is ended. 
    public void OnEnd(IAsyncResult ar)
    {
        _taskprogress = "Asynchronous task completed.";
        _dlgt.EndInvoke(ar);
    }
    public void OnEnd2(IAsyncResult ar)
    {
        _taskprogress2 = "Asynchronous task completed.";
        _dlgt2.EndInvoke(ar);
    }

    // Define the method that will get called if the task 
    // is not completed within the asynchronous timeout interval. 
    public void OnTimeout(IAsyncResult ar)
    {
        _taskprogress = "Ansynchronous task failed to complete " +
            "because it exceeded the AsyncTimeout parameter.";
    }
    public void OnTimeout2(IAsyncResult ar)
    {
        _taskprogress2 = "Ansynchronous task failed to complete " +
            "because it exceeded the AsyncTimeout parameter.";
    }
    protected void dropState_SelectedIndexChanged(object sender, EventArgs e)
    {
        var async = new PageAsyncTask(OnBegin, OnEnd, OnTimeout, null, true);
        Page.RegisterAsyncTask(async);
        Page.ExecuteRegisteredAsyncTasks();
        //var ct = Data.City(sid);
        //dropCity.Items.Clear();
        //dropCity.Items.Add(new ListItem("شهر", "0"));
        //foreach (DataRow D in ct.Rows)
        //{
        //    dropCity.Items.Add(new ListItem(D[2].ToString(), D[0].ToString()));
        //}

        //gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        //gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    private string AddFilter(string Add, string Filter, bool And = true)
    {
        var fil = Filter;
        if (fil.Length > 0)
        {

            if (And)
                fil = fil + "And " + Add;
            else
                fil = fil + "Or " + Add;
        }
        else
        {
            fil = Add;
        }
        return fil;
    }

    protected void filter_Click(object sender, EventArgs e)
    {
        var pars = new PersianCalendar();
        var filter = "";
        string Approved;
        if (dropIsApproved.SelectedIndex == 0)
            Approved = "";
        else if (dropIsApproved.SelectedIndex == 1)
            Approved = "True";
        else
            Approved = "False";
        var startd = Server.HtmlEncode(dpDateStart.Text.ToString());
        var endd = Server.HtmlEncode(dpDateEnd.Text.ToString());
        var Type = Server.HtmlEncode(dropType.SelectedItem.Text.ToString());
        var Name = Server.HtmlEncode(txtName.Text.ToString());
        var Family = Server.HtmlEncode(txtFamily.Text.ToString());
        var State = Server.HtmlEncode(dropState.SelectedItem.Text.ToString());
        var City = Server.HtmlEncode(dropCity.SelectedItem.Text.ToString());
        var Meet = Server.HtmlEncode(dropMeet.SelectedItem.Text.ToString());
        var News = dropNews.SelectedIndex == 0 ? "" : Server.HtmlEncode(dropNews.SelectedItem.Text.ToString());
        bool? Sex;
        if (dropSex.SelectedIndex == 0)
            Sex = null;
        else if (dropSex.SelectedIndex == 1)
            Sex = true;
        else
            Sex = false;
        var births = Server.HtmlEncode(dpDateBirthStart.Text.ToString());
        var birthe = Server.HtmlEncode(dpDateBirthEnd.Text.ToString());
        var CorpType = Server.HtmlEncode(dropCorpType.SelectedItem.Text.ToString());
        var CorpName = Server.HtmlEncode(txtCorpName.Text.ToString());
        var Agent = dropAgent.SelectedIndex == 0 ? "" : Server.HtmlEncode(dropAgent.SelectedItem.Value.ToString());
        var bsd = births.Split("/".ToArray());
        var bed = birthe.Split("/".ToArray());
        var sd = startd.Split("/".ToArray());
        var ed = endd.Split("/".ToArray());
        var Sda = new DateTime();
        var Eda = new DateTime();
        if (Approved.Length > 0)
        {
            filter = AddFilter("IsApproves= '" + Approved + "'", filter);
        }
        if (Sex.HasValue)
        {
            filter = AddFilter("Sex = '" + Sex.ToString() + "'", filter);
        }
        if (Name.Length > 0)
        {
            filter = AddFilter("Name like '%" + Name + "%'", filter);
        }
        if (Family.Length > 0)
        {
            filter = AddFilter("Family like '%" + Family + "%'", filter);
        }
        if (dropMeet.SelectedIndex > 0)
        {
            filter = AddFilter("Meet = '" + Meet + "'", filter);
        }
        if (dropNews.SelectedIndex > 0)
        {
            filter = AddFilter("News = '" + News + "'", filter);
        }
        if (birthe.Length > 0 || births.Length > 0)
        {
            if (birthe.Length > 0 && births.Length > 0)
            {
                Sda = new DateTime(Convert.ToInt32(bsd[0].ToString()), Convert.ToInt32(bsd[1].ToString()), Convert.ToInt32(bsd[2].ToString()), pars);
                Eda = new DateTime(Convert.ToInt32(bed[0].ToString()), Convert.ToInt32(bed[1].ToString()), Convert.ToInt32(bed[2].ToString()), pars);
                if (Sda > Eda)
                {
                    filter = AddFilter("BirthDate >= '" + birthe + "' And BirthDate <= '" + births + "'", filter);
                }
                else
                {
                    filter = AddFilter("BirthDate >= '" + births + "' And BirthDate <= '" + birthe + "'", filter);
                }
            }
            else if (births.Length > 0)
            {
                filter = AddFilter("BirthDate >= '" + births + "'", filter);
            }
            else
            {
                filter = AddFilter("BirthDate <= '" + birthe + "'", filter);
            }
        }
        //if (Tel.Length > 0)
        //{
        //    filter = AddFilter("Tel like '%" + Name + "%'", filter);
        //}
        //if (Mobile.Length > 0)
        //{
        //    filter = AddFilter("Mobile like '%" + Name + "%'", filter);
        //}
        //if (job.Length > 0)
        //{
        //    filter = AddFilter("Job like '%" + job + "%'", filter);
        //}
        if (CorpName.Length > 0)
        {
            filter = AddFilter("CorpName like '%" + CorpName + "%'", filter);
        }
        if (State != "استان")
        {
            filter = AddFilter("State = '" + State + "'", filter);
        }
        if (City != "شهر")
        {
            filter = AddFilter("City = '" + City + "'", filter);
        }
        //if (Education != "تحصیلات")
        //{
        //    filter = AddFilter("Education = '" + Education + "'", filter);
        //}
        if (CorpType != "نوع شرکت")
        {
            filter = AddFilter("Ltype = '" + CorpType + "'", filter);
        }
        if (dropAgent.SelectedIndex > 0)
        {
            filter = AddFilter("Agent = '" + Agent + "'", filter);
        }
        var comment = Data.UserData("/");
        var t = comment.AsDataView();
        t.RowFilter = filter;
        try
        {
            if (dt.Rows.Count.Equals(0))
                dt = t.ToTable();
            else
            {
                foreach (DataRow d in t.ToTable().Rows)
                {
                    if (dt.Select("UserName = '" + d.Field<string>("UserName") + "'").Count() == 0)
                        dt.Rows.Add(d);
                }
            }

        }
        catch
        {
            dt = t.ToTable();
        }
        gvList.DataSource = dt;
        gvList.DataBind();
        if (dt.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    protected void btnRefreshClick(object sender, EventArgs e)
    {
        var async = new PageAsyncTask(OnBegin2, OnEnd2, OnTimeout2, null, true);
        Page.RegisterAsyncTask(async);
        Page.ExecuteRegisteredAsyncTasks();
        
        //var comment = Data.UserDataNews("/");
        //var t = comment.AsDataView();
        //gvList.DataSource = t;
        //gvList.DataBind();
        //if (comment.Rows.Count > 0)
        //{
        //    gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        //    gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        //}
        //btnSel.Visible = true;
        //btnFilter.Visible = true;
        //MVSend.ActiveViewIndex = 0;
    }
    protected void btnAll_Click(object sender, EventArgs e)
    {
        dt = Data.UserData("/");
        
        GVUser.DataSource = dt;
        GVUser.DataBind();
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        btnNews.Visible = false;
        btnSel.Visible = false;
        btnFilter.Visible = false;
        lblMes.Visible = false;
        btnNews.Visible = false;
        btnBack.CssClass = "btn btn-sm btn-default";
        if (dt.Select().Any(p => p.Field<string>("News").Equals("خیر")))
        {
            rbSend1.Enabled = true;
            rbSend2.InputAttributes.Add("disabled", "");
            rbSend3.InputAttributes.Add("disabled", "");
        }
        else
        {
            rbSend1.Enabled = true;
            rbSend2.InputAttributes.Remove("disabled");
            rbSend3.InputAttributes.Remove("disabled");
        }
        MVSend.ActiveViewIndex = 1;
    }
    protected void btnSelClick(object sender, EventArgs e)
    {
        var dtv = Data.UserData("/").AsDataView();
        var filter = "";
        foreach (GridViewRow r in gvList.Rows)
        {
            var chkSelect = (CheckBox)r.FindControl("chkSelect");
            var LabelUser = (Label)r.FindControl("LabelUser");
            if (chkSelect.Checked)
            {
                filter = AddFilter("UserName = '" + LabelUser.Text + "'", filter, false);
            }
        }
        dtv.RowFilter = filter;
        dt = dtv.ToTable();
        GVUser.DataSource = dt;
        GVUser.DataBind();
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        btnSel.Visible = false;
        btnFilter.Visible = false;
        lblMes.Visible = false;
        btnNews.Visible = false;
        btnBack.CssClass = "btn btn-sm btn-default";
        if (dt.Select().Any(p => p.Field<string>("News").Equals("خیر")))
        {
            rbSend1.Enabled = true;
            rbSend2.InputAttributes.Add("disabled", "");
            rbSend3.InputAttributes.Add("disabled", "");
        }
        else
        {
            rbSend1.Enabled = true;
            rbSend2.InputAttributes.Remove("disabled");
            rbSend3.InputAttributes.Remove("disabled");
        }
        MVSend.ActiveViewIndex = 1;
    }
    protected void btnFilterClick(object sender, EventArgs e)
    {
        GVUser.DataSource = dt;
        GVUser.DataBind();
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        btnSel.Visible = false;
        btnFilter.Visible = false;
        lblMes.Visible = false;
        btnNews.Visible = false;
        btnBack.CssClass = "btn btn-sm btn-default";
        if (dt.Select().Any(p => p.Field<string>("News").Equals("خیر")))
        {
            rbSend1.Enabled = true;
            rbSend2.InputAttributes.Add("disabled", "");
            rbSend3.InputAttributes.Add("disabled", "");
        }
        else
        {
            rbSend1.Enabled = true;
            rbSend2.InputAttributes.Remove("disabled");
            rbSend3.InputAttributes.Remove("disabled");
        }
        MVSend.ActiveViewIndex = 1;

    }

    protected void btnNewsClick(object sender, EventArgs e)
    {
        var comment = Data.NewsLetterData();
        MVSend.ActiveViewIndex = 2;
        var t = comment.AsDataView();
        gvList2.DataSource = t;
        gvList2.DataBind();
        btnUser.Visible = true;
        btnNews.Visible = false;
        if (comment.Rows.Count > 0)
        {
            gvList2.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList2.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    protected void btnBackClick(object sender, EventArgs e)
    {
        MVSend.ActiveViewIndex = 0;
        if (gvList.Rows.Count > 0)
        {
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        btnBack.CssClass = "btn btn-sm btn-default hidden";
        btnSel.Visible = true;
        btnFilter.Visible = true;
        btnNews.Visible = true;
        btnUser.Visible = false;

    }
    protected void GVUserRowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Remove"))
        {
            
            var User = e.CommandArgument.ToString();
            var r = dt.Select().Where(p => p["UserName"].ToString().Equals(User)).First();
            dt.Rows.Remove(r);
            GVUser.DataSource = dt;
            GVUser.DataBind();
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
    }
    protected void btnSendClick(object sender, EventArgs e)
    {
        var Subject = Server.HtmlEncode(txtSubject.Text);
        var Body = txtBody.Value;
        var filterm = "";
        var filteri = "";
        if (rbSend2.Checked || rbSend3.Checked)
        {
            var dtv = dt.AsDataView();
            
            foreach (DataRow r in dt.Rows)
            {
                var res = SendMes.SendEmail(r["Email"].ToString(), Subject, Body);
                if (!res)
                {
                    filterm = AddFilter("UserName = '" + r["UserName"].ToString() + "'", filterm, false);
                }
            }
            if (filterm.Length > 0)
            {
                dtv.RowFilter = filterm;
                var dtEr = dtv.ToTable();
                GVUserEr.DataSource = dtEr;
                GVUserEr.DataBind();
                GVUserEr.Visible = true;
            }
            else
            {
                GVUserEr.Visible = false;
            }
        }
        if (rbSend1.Checked || rbSend3.Checked)
        {
            var dtv = dt.AsDataView();
            foreach (DataRow r in dt.Rows)
            {
                try
                {
                    SendMes.InsertMessage(r["UserName"].ToString(), Subject, Body);
                }
                catch
                {
                    filteri = AddFilter("UserName = '" + r["UserName"].ToString() + "'", filteri, false);
                }
            }
            if (filteri.Length > 0)
            {
                
                dtv.RowFilter = filteri;
                var dtdEr = dtv.ToTable();
                GVUserDEr.DataSource = dtdEr;
                GVUserDEr.DataBind();
                GVUserDEr.Visible = true;
            }
            else
            {
                GVUserDEr.Visible = false;
            }
            if (filterm.Length.Equals(0) && filteri.Length.Equals(0))
            {
                MVSend.ActiveViewIndex = 0;
                lblMes.Visible = true;
            }
        }
    }
    protected void GVUser_DataBound(object sender, EventArgs e)
    {
        lc.Text = "تعداد :" + GVUser.Rows.Count.ToString();
    }
    protected void UpdatePanel2_PreRender(object sender, EventArgs e)
    {

    }
}