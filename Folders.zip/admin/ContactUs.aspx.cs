﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Web.Security;

namespace admin
{
    public partial class ContactUs : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            txtBody.Value = Data.Contact;
            LoadData();
        }
        protected void BtnEditCClick(object sender, EventArgs e)
        {
            try
            {
                Message.EmptyMessage(lblMessage2);
                var text = txtBody.Value;
                Data.Contact = text;
                Message.MessageGen(lblMessage1, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage1, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        private void LoadData()
        {

            txtTitle.Text = Data.GetDescription(11, "t");
            txtDescription.Text = Data.GetDescription(11, "d");
            txtKeyword.Text = Data.GetDescription(11, "k");

            var userd = Data.UserDataAdmin(Membership.ApplicationName);
            var ae = new List<spGetUserDataAdminResult>();

            var n = new spGetUserDataAdminResult
            {
                UserName = "انتخاب نمایید",
                CreateDate = DateTime.Now,
                Email = ""
            };
            ae.Add(n);
            ae.AddRange(userd.AsEnumerable<spGetUserDataAdminResult>());

            df.DataSource = ae;
            df.DataBind();
            
            var item = Data.GetCatPart().OrderByDescending(p => p.Id);
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        private void LoadPart(int Id)
        {
            var item = Data.GetPart(Id).OrderByDescending(p => p.Id);
            GridView1.DataSource = item;
            GridView1.DataBind();
        }
        protected void EditKey(object sender, EventArgs e)
        {
            try
            {

                var Title = Server.HtmlEncode(txtTitle.Text);
                var Keyword = Server.HtmlEncode(txtKeyword.Text);
                var Des = Server.HtmlEncode(txtDescription.Text);
                Data.EditDescription(11, Title, Keyword, Des);
                Message.MessageGen(lblMessage2, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch(Exception ex)
            {
                Message.MessageGen(lblMessage2, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
            LoadData();
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            try
            {
                var Part = Server.HtmlEncode(txtPart.Text);
                if (Part.Length < 1)
                {
                    part.Attributes["class"] = "input-group-addon has-error";
                    return;
                }
                else
                {
                    part.Attributes["class"] = "input-group-addon";
                    if (Data.InsertPartMenu(Part))
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    else
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                    LoadData();
                    txtPart.Text = string.Empty;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadData();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadData();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                Message.EmptyMessage(lblMessage1);
                Message.EmptyMessage(lblMessage2);

                if (Data.DeletePartMenu(id))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                LoadData();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage1);
                Message.EmptyMessage(lblMessage);
                hdfId.Value = id.ToString();
                var PartMenu = Data.GetCatPart().FirstOrDefault(p => p.Id.Equals(id));
                txtName.Text = PartMenu.Part;
                LoadPart(id);

                rbUser.Checked = false;
                rbMail.Checked = false;
                txtsMail.Text = "";
                txtuMail.Text = "";
                txtuMail.ToolTip = "";

                ckMail.Checked = false;
                ckPan.Checked = false;

                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadData();
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {

                Message.EmptyMessage(lblMessage);
                var Part = txtName.Text;
                var Id = Convert.ToInt32(hdfId.Value.ToString());
                if (Data.EditCatPart(Id, Part))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                LoadData();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void GrRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                var Id = Convert.ToInt32(hdfId.Value.ToString());
                switch (e.CommandName)
                {
                    case "remove":
                        DeletePart(Convert.ToInt32(e.CommandArgument));
                        LoadPart(Id);
                        break;
                    case "change":
                        ChangePart(Convert.ToInt32(e.CommandArgument));
                        LoadPart(Id);
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeletePart(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                if (Data.DeletePart(id))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                else
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangePart(int Id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                txtuMail.Text = "";
                txtsMail.Text = "";
                txtsMob.Text = "";
                var item = Data.GetPart(0).FirstOrDefault(p => p.Id.Equals(Id));
                if (item.User.Length > 0)
                {
                    if (item.Mail.Length > 0)
                    {
                        ckMail.Checked = true;
                        txtuMail.Text = item.Mail;
                    }
                    else
                        ckMail.Checked = false;

                    if (item.Tel.Length > 0)
                        ckMob.Checked = true;
                    else
                        ckMob.Checked = false;


                    ckPan.Checked = item.InPanel.GetValueOrDefault(false);
                    df.SelectedValue = item.User;

                    rbUser.Checked = true;
                    rbMail.Checked = false;
                    btnAddPart.CommandName = "Edit";
                    btnAddPart.CssClass = "form-control m-xs btn btn-primary btne1 text-center";
                    btnAddPart.CommandArgument = item.Id.ToString();
                }
                else
                {
                    df.SelectedIndex = 0;
                    rbMail.Checked = true;
                    rbUser.Checked = false;
                    ckMob.Checked = false;
                    ckMail.Checked = false;
                    ckPan.Checked = false;
                    txtsMail.Text = item.Mail;
                    txtsMob.Text = item.Tel;
                    btnAddPart.CssClass = "form-control m-xs btn btn-primary btne2 text-center";
                    btnAddPart.CommandName = "EditW";
                    btnAddPart.CommandArgument = item.Id.ToString();
                }
                Message.EmptyMessage(lblMessage);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        public static bool IsAct(bool? Act)
        {
            return Act.GetValueOrDefault(false);
        }
        public static bool IsAct(string Val)
        {
            var res = Val.Length > 0 ? true : false;
            return res;
        }
        protected void CheckedChanged(object sender, EventArgs e)
        {
            if (ckMail.Checked)
            {
                if (btnAddPart.CommandName.Contains("Edit"))
                {
                    var i = Convert.ToInt32(btnAddPart.CommandArgument);
                    var us = Data.GetPart(0).FirstOrDefault(p => p.Id.Equals(i)).User;
                    df.SelectedValue = us;
                    rbUser.Checked = true;
                }
                var userd = Data.UserDataAdmin(Membership.ApplicationName);
                var mail = userd.FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;
                txtuMail.Text = mail;
                txtuMail.ToolTip = mail;
            }
            else
            {
                txtuMail.Text = "";
                txtuMail.ToolTip = "";
                if (btnAddPart.CommandName.Contains("Edit"))
                {
                    var i = Convert.ToInt32(btnAddPart.CommandArgument);
                    var us = Data.GetPart(0).FirstOrDefault(p => p.Id.Equals(i)).User;
                    df.SelectedValue = us;
                    rbUser.Checked = true;
                }
            }
        }
        protected void btnAddPart_Command(object sender, CommandEventArgs e)
        {
            var Id = Convert.ToInt32(hdfId.Value.ToString());
            if (e.CommandName.Equals("Add"))
            {
                try
                {
                    var userd = Data.UserDataAdmin(Membership.ApplicationName);
                    
                    var Mail = "";
                    var Tel = "";
                    if (rbMail.Checked)
                    {
                        Mail = Server.HtmlEncode(txtsMail.Text);
                        Tel = Server.HtmlEncode(txtsMob.Text);
                    }
                    else if (ckMail.Checked)
                        Mail = userd.FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;

                    if (ckMob.Checked)
                    {
                        Tel = Profile.GetProfile(df.SelectedValue).Mobile;
                    }


                    //Data.UserDataAdmin(Membership.ApplicationName).FirstOrDefault(p => p.UserName.Equals(df.SelectedValue)).Email;
                    
                    var User = "";
                    if (df.SelectedIndex > 0) User = df.SelectedValue;
                    bool? act;
                    if (User.Length.Equals(0))
                        act = null;
                    else
                        act = ckPan.Checked;

                    var res = Data.InsertPart(Id, Mail, Tel, User, act);
                    switch (res)
                    {
                        case 0:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                            break;
                        case 1:
                            Message.MessageGen(lblMessage, "پست الکترونیکی قبلا درج شده است", Color.Red);
                            break;
                        case 2:
                            Message.MessageGen(lblMessage, "شماره موبایل قبلا درج شده است", Color.Red);
                            break;
                        case 3:
                            Message.MessageGen(lblMessage, "نام کاربری قبلا درج شده است", Color.Red);
                            break;
                        case 4:
                            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                            txtsMail.Text = string.Empty;
                            txtsMob.Text = string.Empty;
                            txtuMail.Text = string.Empty;
                            rbUser.Checked = false;
                            rbMail.Checked = false;
                            ckMob.Checked = false;
                            ckMail.Checked = false;
                            ckPan.Checked = false;
                            df.SelectedIndex = 0;
                            break;
                    }
                    

                }
                catch
                {
                    Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                }
            }
            else 
            {
                var i = Convert.ToInt32(e.CommandArgument.ToString());
                var user = Data.GetPart(Id).FirstOrDefault(p => p.Id.Equals(i));
                var Mail = "";
                var Tel = "";
                bool? act;
                act = null;
                if (e.CommandName.Equals("Edit"))
                {

                    if (ckMail.Checked)
                        Mail = Data.UserDataAdmin(Membership.ApplicationName).FirstOrDefault(p => p.UserName.Equals(user.User)).Email;

                    if (ckMob.Checked)
                        Tel = Profile.GetProfile(user.User).Mobile;

                    if (ckPan.Checked)
                        act = true;
                    else
                        act = null;

                    if (Data.EditPart(i, Mail, Tel, act))
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    else
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                else
                {
                    Mail = Server.HtmlEncode(txtsMail.Text);
                    Tel = Server.HtmlEncode(txtsMob.Text);
                    if (Data.EditPart(i, Mail, Tel, act))
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    else
                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                txtsMail.Text = string.Empty;
                txtsMob.Text = string.Empty;
                txtuMail.Text = string.Empty;
                rbUser.Checked = false;
                rbMail.Checked = false;
                ckMob.Checked = false;
                ckMail.Checked = false;
                ckPan.Checked = false;
                rbUser.Checked = false;
                rbMail.Checked = false;
                df.SelectedIndex = 0;
            }
            btnAddPart.CssClass = "form-control m-xs btn btn-primary text-center";
            btnAddPart.CommandName = "Add";
            LoadPart(Id);
        }
    }
}