﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;
using System.Drawing;

public partial class Logo : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

    }
    protected void BtnInsert_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile)
            {
                string FileName1 = "logo1.png";
                FileUpload1.SaveAs(Server.MapPath("~/uploadimage/logo/" + FileName1));
            }
            else
            {
                Message.MessageGen(lblMessage, "لطفا تصویر لوگو را انتخاب نمایید", Color.Red);
                return;
            }
        }
        catch
        {

        }
        loaddata();

    }
    public void loaddata(){
        Image1.ImageUrl = "~/uploadimage/logo/logo1.png";
    }
}