﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Drawing;

public partial class Profiles : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        
        var U=Membership.GetUser();
        txtName.Text = Profile.Name;
        txtFamily.Text = Profile.Family;
        txtMail.Text = U.Email;
        txtMob.Text = Profile.Mobile;
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 280;
        CaptchaImage1.Height = 75;
        CaptchaImage1.Text = imgcode;
    }
    protected void GetCaptcha(object sender, EventArgs e)
    {
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 280;
        CaptchaImage1.Height = 75;
        CaptchaImage1.Text = imgcode;
    }
    protected void EditUser(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        var code = Server.HtmlEncode(txtCode.Text);
        if (code.ToLower() != CaptchaImage1.Text.ToLower())
        {
            lblMessage.Text = "کد امنیتی را درست وارد نمایید";
            lblMessage.CssClass = "text-danger input-lg";
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage1.Width = 280;
            CaptchaImage1.Height = 75;
            CaptchaImage1.Text = imgcode;
            return;
        }
        var mes = "";
        var Name = Server.HtmlEncode(txtName.Text);
        var Family = Server.HtmlEncode(txtFamily.Text);
        var Mobile = Server.HtmlEncode(txtMob.Text);
        var Email = Server.HtmlEncode(txtMail.Text);

        var Pass = Server.HtmlEncode(txtPassword.Text);
        var NewPass = Server.HtmlEncode(txtNewPass.Text);
        var Us = Membership.GetUser();
        if (Us.Email != Email)
        {
            if (Membership.FindUsersByEmail(Email).Count == 0)
            {
                Us.Email = Email;
                Membership.UpdateUser(Us);
                mes = "<label class=\"text-success text-lg\">آدرس ایمیل با موفقیت تغییر یافت</label>";
            }
            else
            {
                mes = "<label class=\"text-danger text-lg\">نام کاربری با این آدرس ایمیل وجود دارد</label>";
                return;
            }
        }
        var PC = false;
        if (Profile.Name != Name)
        {
            Profile.SetPropertyValue("Name", Name);
            PC = true;
        }
        if (Profile.Family != Family)
        {
            Profile.SetPropertyValue("Family", Family);
            PC = true;
        }

        if (Profile.Mobile != Mobile)
        {
            Profile.SetPropertyValue("Mobile", Mobile);
            PC = true;
        }
        if (PC)
        {
            Profile.Save();
            if (mes.Length > 0)
                mes += "<br><label id=\"spec\" class=\"text-success text-lg\">مشخصات با موفقیت تغییر یافت</label>";
            else
                mes += "<label id=\"spec\" class=\"text-success text-lg\">مشخصات با موفقیت تغییر یافت</label>";
        }
        if (Pass.Length > 0)
        {
            if (Membership.ValidateUser(Us.UserName, Pass))
            {
                Us.ChangePassword(Pass, NewPass);
                Membership.UpdateUser(Us);
                if (mes.Length > 0)
                    mes += "<br><label class=\"text-success text-lg\">رمز عبور با موفقیت تغییر یافت</label>";
                else
                    mes += "<label class=\"text-success text-lg\">رمز عبور با موفقیت تغییر یافت</label>";
            }
            else
            {
                if (mes.Length > 0)
                    mes += "<br><label class=\"text-danger text-lg\">رمز عبور را درست وارد نمایید</label>";
                else
                    mes += "<label class=\"text-danger text-lg\">رمز عبور را درست وارد نمایید</label>";
            }
        }
        lblMessage.Text = mes;
    }
}