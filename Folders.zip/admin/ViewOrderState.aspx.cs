﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ViewOrderState : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(Request.QueryString["id"]))
            Response.Redirect("~/Order.aspx");
        if (IsPostBack) return;
        ViewState["id"] = Request.QueryString["id"];
        var Id = long.Parse(ViewState["id"].ToString());
        ViewRecord(Id);
    }
    public Data Data = new Data();
    public clsShoppingCart Cart = new clsShoppingCart();
    public static string GetTime(DateTime dt)
    {
        return dt.Hour.ToString() + ":" + dt.Minute.ToString("00") + ":" + dt.Second.ToString("00");
    }
    public static bool IsState(string State)
    {
        if (String.IsNullOrWhiteSpace(State))
            return false;
        else
            return true;
    }
    private void ViewRecord(long codeTracking)
    {
        

            var item = Cart.GetState(codeTracking).OrderByDescending(p => p.Date);
            lblSCode.Text = "";
            if (item.Count() > 0)
            {
                
                lblSCode.Text = Cart.GetCode(codeTracking);

                GVState.DataSource = item;
                GVState.DataBind();
            }
        



    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Response.Redirect("~/Order.aspx");
    }
}