﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.Security;
using System.Web.Profile;
using System.Web.Configuration;
using System.Linq;

public partial class User : MasterPage
{
    protected override void OnInit(EventArgs e)
    {
        //string BrowserName = Request.Browser.Browser;
        //string BrowserVersion = Request.Browser.Version.Replace(".", "");
        //if (BrowserName.Equals("IE"))
        //{
        //    if (int.Parse(BrowserVersion) <= 100)
        //        Response.Redirect("~/OutDatedBrowser.aspx");

        //}
        if (Page.IsPostBack)
        {

            if (Request.Cookies["Time"] == null)
            {
                FormsAuthentication.SignOut();

                var Fn = Request.Url.LocalPath;
                Response.Redirect("~/Login.aspx?page=" + Fn);
            }
        }
        var t = DateTime.Now.Ticks.ToString();
        HttpCookie timer = new HttpCookie("Time", t);
        timer.HttpOnly = true;
        timer.Expires = DateTime.Now.AddMinutes(30);
        Response.Cookies.Add(timer);
        base.OnInit(e);
    }
    Data Dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        var u = "";
        
        if (Page.User.Identity.IsAuthenticated || u.Length > 0)
        {
            if (u.Length == 0)
            {
                u = Page.User.Identity.Name;
            }

            var Data = new Data();
            var f = Request.Url.LocalPath.Split("/".ToCharArray());
            var File = f[f.GetLength(0) - 1].Replace(".aspx", "");
             if (!Data.AllowPage(u, File))
            {
                ContentPlaceHolder1.Visible = false;
                lblFullName.Text = File;
            }
            else
            {
                var NewMes = Dt.GetContact(Membership.GetUser().UserName).Where(p => !p.Read).ToList().Count();
             
                var COrd = Dt.GetOrderList().Count(p => p.Status.Equals("در حال رسیدگی") && string.IsNullOrWhiteSpace(p.Status1));
                var lnew =  NewMes + COrd;
                if (lnew > 0)
                {
                    lblNewWM.Text = lnew.ToString();
                }
                if (NewMes > 0)
                {
                    lblNewCon.Text = NewMes.ToString();
                    if (!Data.AllowPage(u, "ContactMessage"))
                    {
                        HLCon.Attributes["onclick"] = "return Deny()";
                    }
                    divMes.Visible = true;
                    divMes2.Visible = true;
                }
                else
                {
                    divMes.Visible = false;
                    divMes2.Visible = false;
                }
               
                if (COrd > 0)
                {
                    lblNewOrd.Text = COrd.ToString();
                    if (!Data.AllowPage(u, "Order"))
                    {
                        HLOrd.Attributes["onclick"] = "return Deny()";
                    }
                    divOrd.Visible = true;
                    divOrd2.Visible = true;
                }
                else
                {
                    divOrd.Visible = false;
                    divOrd2.Visible = false;
                }
                ContentPlaceHolder1.Visible = true;
                var name = Data.GetUserNameAdmin(u);
                lblFullName.Text = name;
                lblTop.Text = name;
            }

        }
        else
        {
            Response.Redirect("~/Login.aspx");
        }
    }
    protected void Logout(object sender, EventArgs e)
    {
        if (Page.User.Identity.IsAuthenticated)
        {
            FormsAuthentication.SignOut();
            if (Request.Cookies["UserA"] != null)
            {
                var cd = Request.Cookies["UserA"];
                cd.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(cd);
            }
            Response.Redirect("~/Login.aspx");
        }
    }
}
