﻿using Persia;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UpFile : System.Web.UI.Page
{
    Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        LoadDate();
    }
    private void LoadDate()
    {
        var item = Data.GetUpFile();
        gvList.DataSource = item;
        gvList.DataBind();
        if (!item.Any()) return;
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            switch (e.CommandName)
            {
                case "remove":
                    DeleteRecord(Convert.ToInt32(e.CommandArgument));
                    LoadDate();
                    break;
                case "change":
                    LoadDate();
                    break;
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void DeleteRecord(int id)
    {
        try
        {
            Message.EmptyMessage(lblMessage);
            var item = Data.GetUpFile().FirstOrDefault(p => p.Id.Equals(id));

            if (item != null && !string.IsNullOrEmpty(item.FileName))
            {
                if (Data.DeleteUpFile(id, Server.MapPath("~/UploadFile/")))
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                }
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 0;
        LoadDate();
    }
    protected void BtnInsertClick(object sender, EventArgs e)
    {
        try
        {
            string filename;
            if (FileUpload1.HasFile)
            {
                filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
            }
            else
            {
                Message.MessageGen(lblMessage, "لطفا تصویر منو را انتخاب نمایید", Color.Red);
                return;
            }
            if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/UploadFile/") + filename))
            {
                Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر منو لطفا دوباره تصویر را وارد نمایید", Color.Red);
                return;
            }
            var item = new UploadFile
            {
                FileName = filename
            };
            Data.DB.UploadFiles.InsertOnSubmit(item);
            Data.DB.SubmitChanges();
            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
            LoadDate();
            MultiView1.ActiveViewIndex = 0;
        }
        catch
        {
            Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
        }
    }
    protected void BtnAddClick(object sender, EventArgs e)
    {

        BtnInsert.Visible = true;
        lblh.InnerText = "ایجاد ";

        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 1;
    }
}