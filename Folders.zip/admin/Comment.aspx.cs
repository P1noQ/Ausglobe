﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace admin
{
    public partial class Comment : System.Web.UI.Page
    {
        public Data Data = new Data();
        public  Club Club=new Club();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
        }
        private void LoadDate()
        {
            var item = Club.GetComment();
            gvList.DataSource = item;
            gvList.DataBind();

            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش نظرات کاربران";
                BtnEdit.Visible = true;
                var item = Club.GetComment().FirstOrDefault(p => p.Id.Equals(id));
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                lblName.Text = item.Name;
                lblUserName.Text = item.UserName;
                lblType.Text = item.Cat;
                lblPageTitle.Text = item.InfoName;
                lblCreateDate.Text = Data.PersianDate(item.DateI);
                lblReplyDate.Text = Data.PersianDate(!item.DateI.Equals(item.DateR) ? item.DateR : DateTime.Now);
                txtSubject.Text = item.Subject;
                txtBody.Text = item.Body;
                txtReply.Text = item.Reply;
                MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                if (Club.DeleteComment(id))
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }
        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                var Subject = Server.HtmlEncode(txtSubject.Text);
                var Body = Server.HtmlEncode(txtBody.Text);
                var Reply = Server.HtmlEncode(txtReply.Text);
                var Show = chkView.Checked;
                try
                {
                    var Id = int.Parse(hdfId.Value);
                    Club.EditInfoComment(Id , Subject, Body, Reply, Show);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);

                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                    try
                    {
                        var item = Club.GetComment().FirstOrDefault(p => p.Id.Equals(Id));

                        try
                        {
                            var UserName = item.UserName;
                            var mes = "متن پیام برای تایید نظرات";
                            if (Data.GetUserSet(UserName, "اطلاع رسانی تایید نظر") && chkView.Checked)
                            {
                                var ma = Data.GetUserData(item.UserId, 3);
                                SendMes.SendEmail(ma, "تایید نظر", mes);
                            }
                            if (Data.GetUserSet(UserName, "اطلاع رسانی تایید نظر")==false && chkView.Checked)
                            {
                                var mo = Data.GetUserData(item.UserId, 2);
                                SendMes.SendSMS(mo, mes);
                            }
                        }
                        catch
                        {

                        }
                    }
                    catch
                    {

                    }

                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
    }
}