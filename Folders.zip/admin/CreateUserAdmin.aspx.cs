﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using System.Drawing;

public partial class admin_CreateUserAdmin : System.Web.UI.Page
{
    public Data Data = new Data();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        LoadDate();
        rblRoleC.Items.Clear();
        var role = Data.GetRole();
        rblRoleC.Items.Add(new ListItem("انتخاب نمایید", ""));
        foreach (Role r in role)
        {
            rblRoleC.Items.Add(new ListItem(r.PersianRoleName, r.RoleName));
        }
        //this.Session["CaptchaImageText"] = Data.GenerateRandomCode();
        //Image1.ImageUrl = "../CImage.aspx";
    }
    private void LoadDate()
    {
        var item = Data.UserDataAdmin(Membership.ApplicationName);
        gvList.DataSource = item;
        gvList.DataBind();
        
        if (!item.Any()) return;
        gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
        gvList.FooterRow.TableSection = TableRowSection.TableFooter;
    }
    protected void Create(object sender, EventArgs e)
    {
        lblh.InnerText = "ایجاد کاربر مدیر";
        btnNew.Visible = true;
        BtnEdit.Visible = false;
        newpass.Visible = false;
        txtRepPass.Attributes["placeholder"] = "تکرار رمز عبور";
        txtNewUser.Text = "";
        txtNewUser.Visible = true;
        lblUser.Text = "";
        txtName.Text = "";
        txtFName.Text = "";
        txtMail.Text = "";
        txtPass.Text = "";
        txtRepPass.Text = "";
        txtMobile.Text = "";
        rpPageAccess.DataBind();
        chkPrivate.Checked = false;
        rblRoleC.SelectedIndex = 0;
        //mod3img.Text = "";
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 2;
    }
    protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
    {
        try
        {
            switch (e.CommandName)
            {
                case "remove":
                    DeleteRecord(e.CommandArgument.ToString());
                    LoadDate();
                    break;
                case "change":
                    ChangeRecord(e.CommandArgument.ToString());
                    LoadDate();
                    break;
            }
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void ChangeRecord(string UserName)
    {
        Message.EmptyMessage(lblMessage);
        try
        {
            lblh.InnerText = "ویرایش کاربر مدیر";
            lblUser.Text = "نام کاربری: " + UserName;
            txtNewUser.Visible = false;
            newpass.Visible = true;
            txtRepPass.Attributes["placeholder"] = "رمز عبور جدید";
            var usr = Membership.GetUser(UserName);
            var UserId = new Guid(usr.ProviderUserKey.ToString());
            var pr = Profile.GetProfile(UserName);
            txtName.Text = pr.Name;
            txtFName.Text = pr.Family;
            chkActive.Checked = !usr.IsApproved;
            txtMail.Text = usr.Email;
            txtMobile.Text = pr.Mobile;
            rblRoleC.SelectedIndex = 0;
            if (Roles.GetRolesForUser(UserName).Count() == 1)
            {
                var role = Roles.GetRolesForUser(UserName)[0];
                rblRoleC.SelectedValue = role;
                var roled = Data.AccessPageRole(UserId, role, null);
                chkPrivate.Checked = false;
                if (roled.Count(p => p.PageEn.GetValueOrDefault(false).Equals(true)) > 1)
                {
                    rpPageAccess.DataSource = roled;
                    chkPrivate.Checked = true;
                }
                rpPageAccess.DataBind();
            }
            MultiView1.ActiveViewIndex = 2;
            btnNew.Visible = false;
            BtnEdit.Visible = true;
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void DeleteRecord(string UserName)
    {
        try
        {
            Membership.DeleteUser(UserName);
            Message.MessageGen(lblMessage, "حذف کاربر با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
    }
    protected void BtnBackClick(object sender, EventArgs e)
    {
        Message.EmptyMessage(lblMessage);
        MultiView1.ActiveViewIndex = 0;
        LoadDate();
    }
    protected void btnNew_Click(object sender, EventArgs e)
    {
        try
        {
            var User = Server.HtmlEncode(txtNewUser.Text);
            var Name = Server.HtmlEncode(txtName.Text);
            var Family = Server.HtmlEncode(txtFName.Text);
            var Mobile = Server.HtmlEncode(txtMobile.Text);
            if (Membership.FindUsersByName(User).Count > 0)
            {
                Message.MessageGen(lblMessage, "نام کاربری موجود است", Color.Red);
                return;
            }
            if (Membership.FindUsersByEmail(User).Count > 0)
            {
                Message.MessageGen(lblMessage, "نام کاربری با آدرس پست الکترونیکی موجود است", Color.Red);
                return;
            }
            var role = rblRoleC.SelectedValue.ToString();
            var Pass = Server.HtmlEncode(txtPass.Text);
            var Mail = Server.HtmlEncode(txtMail.Text);

            var Usr = Membership.CreateUser(User, Pass, Mail);
            var pr = Profile.GetProfile(User);
            pr.SetPropertyValue("Name", Name);
            pr.SetPropertyValue("Family", Family);
            pr.SetPropertyValue("Mobile", Mobile);
            pr.Save();
            if (chkActive.Checked)
            {
                Usr.IsApproved = false;
                Membership.UpdateUser(Usr);
            }
            Roles.AddUserToRole(User, role);
            if (chkPrivate.Checked)
            {
                var pa = Data.AccessPageRole(new Guid(), role, null);
                var UserId = new Guid(Usr.ProviderUserKey.ToString());
                foreach (RepeaterItem r in rpPageAccess.Items)
                {
                    var pan = ((Label)r.FindControl("lblPage")).Text;
                    var chkAllow = (CheckBox)r.FindControl("chkAllow");
                    var chkDeny = (CheckBox)r.FindControl("chkDeny");
                    var pn = Data.DB.AdminPageAccesses.FirstOrDefault(p => p.PersianPagename.Equals(pan));
                    var eq = pa.FirstOrDefault(p => p.PersianPagename.Equals(pan));
                    if (chkAllow.Checked || chkDeny.Checked)
                    {
                        var it = new AllowPage
                        {
                            PageId = eq.Id,
                            UserId = UserId
                        };
                        Data.DB.AllowPages.InsertOnSubmit(it);
                        Data.DB.SubmitChanges();
                    }
                }
            }

            //ارسال پیام به ایمیل کاربر ایجاد شده
            SendMes.SendEmail(Usr.Email, "ایجاد کاربر مدیر در سایت هورا", "");

            //ارسال پیام به موبایل کاربر ایجاد شده
            SendMes.SendSMS(Mobile, "");



            Message.MessageGen(lblMessage, "نام کاربری ایجاد گردید", Color.Green);
            //FormsAuthentication
            


            LoadDate();
            txtNewUser.Text = "";
            txtName.Text = "";
            txtFName.Text = "";
            txtMail.Text = "";
            txtPass.Text = "";
            txtRepPass.Text = "";
            txtMobile.Text = "";
            rbRole.DataBind();
            rblRoleC.SelectedIndex = 0;            
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
        MultiView1.ActiveViewIndex = 0;
    }
    protected void BtnEditClick(object sender, EventArgs e)
    {
        try
        {
            var User = lblUser.Text.Replace("نام کاربری: ","");
            var usr = Membership.GetUser(User);
            var UserId = new Guid(usr.ProviderUserKey.ToString());
            var Name = Server.HtmlEncode(txtName.Text);
            var Family = Server.HtmlEncode(txtFName.Text);
            var Mobile = Server.HtmlEncode(txtMobile.Text);
            var Mail = Server.HtmlEncode(txtMail.Text);
            var Pass = Server.HtmlEncode(txtPass.Text);
            var NewPass = Server.HtmlEncode(txtNewPass.Text);
            var DeActive = !chkActive.Checked;
            var pr = Profile.GetProfile(User);
            var cp = false;
            if (pr.Name != Name && Name.Length > 0)
            {
                pr.SetPropertyValue("Name", Name);
                cp = true;
            }
            if (pr.Family != Family && Family.Length > 0)
            {
                pr.SetPropertyValue("Family", Family);
                cp = true;
            }
            if (pr.Mobile != Mobile && Mobile.Length > 0)
            {
                pr.SetPropertyValue("Mobile", Mobile);
                cp = true;
            }

            if (cp) pr.Save();
            cp = false;
            if (Mail.Length > 0 && Mail != usr.Email)
            {
                usr.Email = Mail;
                cp = true;

            }
            if (Pass.Length > 0)
            {
                if (Membership.ValidateUser(User, Pass))
                {
                    Message.MessageGen(lblMessage, "رمز عبور اشتباه است", Color.Red);

                    
                }
                else
                {
                    usr.ChangePassword(Pass, NewPass);
                    Membership.UpdateUser(usr);
                    Message.MessageGen(lblMessage, "رمز عبور تغییر یافت", Color.Green);
                }
                MultiView1.ActiveViewIndex = 0;
                return;
            }
            if (DeActive != usr.IsApproved)
            {
                usr.IsApproved = DeActive;
                cp = true;
            }
            if (cp) Membership.UpdateUser(usr);
            cp = false;
            var role = rblRoleC.SelectedValue.ToString();
            var CRole = Roles.GetRolesForUser(User)[0];
            if (CRole != role)
            {
                Roles.RemoveUserFromRole(User, CRole);
                Roles.AddUserToRole(User, role);
            }
            var roledata = Data.AccessPageRole(UserId, role, null);
            if (chkPrivate.Checked)
            {
                foreach (RepeaterItem r in rpPageAccess.Items)
                {
                    var pan = ((Label)r.FindControl("lblPage")).Text;
                    var chkAllow = (CheckBox)r.FindControl("chkAllow");
                    var chkDeny = (CheckBox)r.FindControl("chkDeny");
                    var pn = Data.DB.AdminPageAccesses.FirstOrDefault(p => p.PersianPagename.Equals(pan));
                    var eq = roledata.FirstOrDefault(p => p.PersianPagename.Equals(pan));
                    if ((chkAllow.Checked && eq.RoleEn.GetValueOrDefault(false).Equals(false)) || (chkDeny.Checked && eq.RoleEn.GetValueOrDefault(false).Equals(true)))
                    {
                        var it = new AllowPage
                        {
                            PageId = eq.Id,
                            UserId = UserId
                        };
                        Data.DB.AllowPages.InsertOnSubmit(it);
                        Data.DB.SubmitChanges();
                    }
                    else if ((chkAllow.Checked && eq.RoleEn.GetValueOrDefault(false).Equals(true)) || (chkDeny.Checked && eq.RoleEn.GetValueOrDefault(false).Equals(false)))
                    {
                        var del = Data.DB.AllowPages.FirstOrDefault(p => p.PageId.Equals(eq.Id) && p.UserId.Equals(UserId));
                        Data.DB.AllowPages.DeleteOnSubmit(del);
                        Data.DB.SubmitChanges();
                    }
                }
            }
            else
            {
                if (roledata.Count(p => p.PageEn.GetValueOrDefault(false).Equals(true)) > 0)
                {
                    var del = Data.DB.AllowPages.Where(p => p.UserId.Equals(UserId));
                    Data.DB.AllowPages.DeleteAllOnSubmit(del);
                    Data.DB.SubmitChanges();
                }
            }
            LoadDate();
            Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
        }
        catch
        {
            Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
        }
        MultiView1.ActiveViewIndex = 0;
    }
    protected void ItemCreated(object sender, RepeaterItemEventArgs e)
    {
        var DT = (spUserAccessResult)e.Item.DataItem;
        if (DT != null)
        {
            var chk = (HtmlInputCheckBox)e.Item.FindControl("chkSelect");
            chk.Checked = DT.PageEn.GetValueOrDefault(false);
        }
    }
    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        var UserName=Server.HtmlEncode(lbName.Text);

        var UserId = new Guid(Membership.GetUser(UserName).ProviderUserKey.ToString());
        var role = rbRole.SelectedValue;
        rpByRoleMan.DataSource = Data.AccessPageRole(UserId, role, true);
        rpByRoleMan.DataBind();
        rpRoleMan.DataSource = Data.AccessPageRole(UserId, role, false);
        rpRoleMan.DataBind();
    }
    protected void chkPrivate_CheckedChanged(object sender, EventArgs e)
    {
        
        if (chkPrivate.Checked)
        {
            IList<spUserAccessResult> ro;
            Guid UserId;
            if (txtNewUser.Visible.Equals(true))
                UserId = new Guid();
            else
                UserId = new Guid(Membership.GetUser(lblUser.Text.Replace("نام کاربری: ", "")).ProviderUserKey.ToString());
            if (rblRoleC.SelectedIndex == 0)
                ro = Data.AccessPageRole(UserId, "", null);
            else
                ro = Data.AccessPageRole(UserId, rblRoleC.SelectedValue, null);

            rpPageAccess.DataSource = ro;
        }
        rpPageAccess.DataBind();
        
    }
    protected void rpPageAccess_ItemCreated(object sender, RepeaterItemEventArgs e)
    {

        var res = (spUserAccessResult)e.Item.DataItem;
        var chkDeny = (CheckBox)e.Item.FindControl("chkDeny");
        var chkAllow = (CheckBox)e.Item.FindControl("chkAllow");
        if (res != null)
        {
            if (res.PageEn.GetValueOrDefault(false).Equals(res.RoleEn.GetValueOrDefault(false)))
            {
                
                chkDeny.InputAttributes["disabled"] = "disabled";
            }
            else
            {
                chkAllow.Checked = true;
                chkAllow.InputAttributes["disabled"] = "disabled";
            }
        }
    }
}