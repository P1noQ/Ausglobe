﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;
using System.Collections;
using Persia;

namespace admin
{
    public partial class Service : System.Web.UI.Page
    {
        public Data Data = new Data();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack) return;
            LoadDate();
        }
        private void LoadDate()
        {
            var item = Data.GetService();
            gvList.DataSource = item;
            gvList.DataBind();
            var menu = Data.GetInfoMenuDrop(2);
            rpDropLevel.DataSource = menu;
            rpDropLevel.DataBind();
            if (!item.Any()) return;
            gvList.HeaderRow.TableSection = TableRowSection.TableHeader;
            gvList.FooterRow.TableSection = TableRowSection.TableFooter;
        }
        protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                switch (e.CommandName)
                {
                    case "remove":
                        DeleteRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                    case "change":
                        ChangeRecord(Convert.ToInt32(e.CommandArgument));
                        LoadDate();
                        break;
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }

        protected void ChangeRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                lblh.InnerText = "ویرایش صفحات خدمات";
                BtnEdit.Visible = true;
                BtnInsert.Visible = false;
                var item = Data.GetService(id).First();
                if (item == null) return;
                hdfId.Value = item.Id.ToString(CultureInfo.InvariantCulture);
                hdfFile.Value = item.Image;
                imgMenu.ImageUrl = "uploadimage/service/" + item.Image;
                rpDropLevel.SelectedValue = item.Cat.ToString();
                txtName.Text = item.Name;
                URL.Visible = false;
                if (string.IsNullOrEmpty(item.URL))
                {
                    txtBody.Value = item.Body;
                }
                else
                {
                    URL.Visible = true;
                    txtURL.Text = item.URL.ToString();
                    txtBody.Value = item.Body;
                }
                    MultiView1.ActiveViewIndex = 1;
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void DeleteRecord(int id)
        {
            try
            {
                Message.EmptyMessage(lblMessage);
                var item = Data.GetService(id).First();
                if (item != null && !string.IsNullOrEmpty(item.Image))
                {
                    if (Data.DeleteService(id, Server.MapPath("~/uploadimage/service/")))
                    {

                        Message.MessageGen(lblMessage, "عملیات با موفقیت انجام شد", Color.Green);
                    }
                    else
                    {
                        Message.MessageGen(lblMessage, "حذف تصویر امکانپذیر نمی باشد", Color.Red);
                    }
                }
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
            }
        }
        protected void BtnBackClick(object sender, EventArgs e)
        {
            Message.EmptyMessage(lblMessage);
            MultiView1.ActiveViewIndex = 0;
            LoadDate();
        }

        protected void BtnInsertClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                }
                else
                {
                    Message.MessageGen(lblMessage, "لطفا تصویر صفحه خدمات را انتخاب نمایید", Color.Red);
                    return;
                }
                if (!FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/service/") + filename))
                {
                    Message.MessageGen(lblMessage, "مشکل در ذخیره تصویر صفحه خدمات لطفا دوباره تصویر را وارد نمایید", Color.Red);
                    return;
                }
                
                var Cat = Convert.ToInt32(rpDropLevel.SelectedValue.ToString());
                var Name = Server.HtmlEncode(txtName.Text);
                var Body = txtBody.Value;
                var URL = Server.HtmlEncode(txtURL.Text);
                var Image = filename;
                var ret = false;
                if (URL.Length > 0)
                {
                    ret = Data.InsertService(Name, Cat, Image, Body, URL);
                }
                else
                {
                    ret = Data.InsertService(Cat, Name, Image, Body);
                }
                if (ret)
                {
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                else
                {
                    Message.MessageGen(lblMessage, "عنوان وارد شده وجود دارد", Color.Red);
                }
                LoadDate();
                MultiView1.ActiveViewIndex = 0;
            }
            catch (Exception)
            {
                Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت نشد لطفا دوباره سعی نمایید", Color.Red);
            }
        }
        protected void BtnAddClick(object sender, EventArgs e)
        {
            BtnEdit.Visible = false;
            BtnInsert.Visible = true;
            lblh.InnerText = "ایجاد صفحات خدمات";
            txtName.Text = "";
            txtBody.Value = "";
            txtURL.Text = "";
            Body.Visible = true;
            URL.Visible = true;
            imgMenu.ImageUrl = "";
            Message.EmptyMessage(lblMessage);

            MultiView1.ActiveViewIndex = 1;
        }

        protected void BtnEditClick(object sender, EventArgs e)
        {
            try
            {
                string filename;
                if (FileUpload1.HasFile)
                {
                    filename = Number.ConvertToLatin(Persia.Calendar.ConvertToPersian(DateTime.Now).Simple.Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                    FileJob.DeleteFile(Server.MapPath("~/uploadimage/service/") + hdfFile.Value);
                    FileJob.SaveFile(FileUpload1, Server.MapPath("~/uploadimage/service/") + filename);
                }
                else
                {
                    filename = hdfFile.Value;
                }
                var Cat = Convert.ToInt32(rpDropLevel.SelectedValue.ToString());
                var Name = Server.HtmlEncode(txtName.Text);
                var Bodies = txtBody.Value;
                var Image = filename;
                try
                {
                    Data.EditService(int.Parse(hdfId.Value), Cat, Name, Image, Bodies);
                    Message.MessageGen(lblMessage, "درخواست شما با موفقیت ثبت شد", Color.Green);
                }
                catch
                {
                    Message.MessageGen(lblMessage, "عملیات با موفقیت انجام نشد", Color.Red);
                }
                MultiView1.ActiveViewIndex = 0;
                LoadDate();
            }
            catch
            {
                Message.MessageGen(lblMessage, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
                MultiView1.ActiveViewIndex = 1;
            }
        }
    }
}