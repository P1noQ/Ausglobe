﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Drawing;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Net.Mail;
using System.Web.Profile;
using System.IO;
using System.Web.Configuration;

namespace admin
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string BrowserName = Request.Browser.Browser;
            string BrowserVersion = Request.Browser.Version.Replace(".", "");
            if (BrowserName.Equals("IE"))
            {
                if (int.Parse(BrowserVersion) <= 100)
                    Response.Redirect("~/OutDatedBrowser.aspx");

            }
            FormsAuthentication.SignOut();
            if (IsPostBack) return;



            //if (Membership.ApplicationName == "/")
            //{
            //    var rd = false;

            //    FormsAuthentication.SignOut();
            //    Response.Redirect(Page.Request.Url.OriginalString);

            //    rd = true;
            //    if (Page.User.Identity.IsAuthenticated)
            //    {

            //    }
            //    Membership.ApplicationName = "/admin";
            //    Roles.ApplicationName = "/admin";
            //    ProfileManager.ApplicationName = "/admin";
            //    if (rd)
            //    {
            //        if (Request.Cookies["UserA"] != null)
            //        {
            //            var user = Request.Cookies["UserA"].Value;
            //            if (user.Contains("@t"))
            //            {
            //                FormsAuthentication.SetAuthCookie(user.Replace("@t", ""), true);
            //            }
            //            else
            //            {
            //                FormsAuthentication.SetAuthCookie(user.Replace("@f", ""), false);
            //            }
            //        }

            //        Page.Response.Redirect(Page.Request.Url.OriginalString);
            //    }
            //}
            this.Session["CaptchaImageText"] = Data.GenerateRandomCode();
            if (!User.IsInRole("Real") && !User.IsInRole("Legal"))
            {
                if (User.Identity.IsAuthenticated) Response.Redirect("~/Index.aspx");
            }
        }

        protected void btnLoginClick(object sender, EventArgs e)
        {
            //    FormsAuthentication.SetAuthCookie("admin", chkRemember.Checked);
            //    Response.Redirect("~/admin/Index.aspx");
            //var code = txtCode.Text;
            //if (code.Length == 0)
            //{
            //    lblMessage.Text = "کد تصویر را وارد نمایید";
            //    lblMessage.CssClass = "text-lg text-danger";
            //    return;
            //}
            //else if (code.ToLower() != this.Session["CaptchaImageText"].ToString().ToLower())
            //{
            //    lblMessage.Text = "کد تصویر را درست وارد نمایید";
            //    lblMessage.CssClass = "text-lg text-danger";
            //    return;
            //}
            //else




            var mail = txtName.Text;
            var user = "";
            try
            {
                var ma = new MailAddress(mail);
                if (ma.Address.Length > 0)
                {
                    if (Membership.FindUsersByEmail(mail).Count == 1)
                        user = Membership.GetUserNameByEmail(mail);
                }
            }
            catch
            {
                user = mail;
            }
            if (string.IsNullOrEmpty(null))
            {
                lblMessage.Text = "نام کاربری وارد شده در سیستم وجود ندارد";
                lblMessage.CssClass = "text-lg text-danger";
            }
            if (Membership.FindUsersByName(user).Count == 1)
            {
                if (Roles.IsUserInRole(user, "Real") || Roles.IsUserInRole(user, "Legal"))
                {
                    Response.Redirect("~/Default.aspx");
                }
                else
                {
                    var pass = txtPass.Text;
                    var us = Membership.GetUser(user);
                    if (us.IsLockedOut)
                    {
                        us.UnlockUser();
                        Membership.UpdateUser(us);
                    }
                    if (Membership.ValidateUser(user, pass))
                    {
                        FormsAuthentication.SetAuthCookie(user, chkRemember.Checked);
                        var r = chkRemember.Checked ? "@t" : "@f";
                        var UsC = new HttpCookie("UserA", user + r);
                        UsC.Expires = DateTime.Now.AddDays(1);
                        UsC.HttpOnly = true;
                        Response.Cookies.Add(UsC);
                        if (Request.QueryString["page"] != null)
                            Response.Redirect(Request.QueryString["page"].ToString());
                        else
                            Response.Redirect("~/Index.aspx");
                        lblMessage.Text = "ورود با موفقیت انجام شد";
                        lblMessage.CssClass = "text-lg text-success";
                    }
                    else
                    {
                        lblMessage.Text = "رمز عبور را درست وارد نمایید";
                        lblMessage.CssClass = "text-lg text-danger";
                    }
                }
            }

        }
    }
}