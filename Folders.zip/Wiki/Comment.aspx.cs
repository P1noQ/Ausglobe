﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.Security;
using System.Web.UI.WebControls;

namespace Wiki
{
    public partial class WikiComment : System.Web.UI.Page
    {
        public string Type = "comment";
        public int Level = 0;
        public Data dt = new Data();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack) return;
            var item = dt.DB.Articles.OrderByDescending(p => p.Id).Take(6);
            rpLastArticles.DataSource = item.ToList();
            rpLastArticles.DataBind();
            rpcm.DataSource = dt.DB.Comments.Where(p => p.catId.Equals(8));
            rpcm.DataBind();
            rpAds.DataSource = dt.DB.Baners.OrderByDescending(p => p.Id).Take(2);
            rpAds.DataBind();
            var info = dt.DB.Descriptions.FirstOrDefault(p => p.Id.Equals(13));
            if (info == null) return;
            Page.Title = info.Title;
            Page.MetaDescription = info.Description1;
            Page.MetaKeywords = info.Keywords;

            LoadData();
        }

        private void LoadData()
        {
            var item = dt.DB.Comments.Where(p => p.active).OrderByDescending(p => p.id).ToList();
            var pgitems = new PagedDataSource
            {
                DataSource = item,
                AllowPaging = true,
                PageSize = 6,
                CurrentPageIndex = PageNumber
            };
            if (pgitems.PageCount > 1)
            {
                rptPages.Visible = true;
                var pages = new System.Collections.ArrayList();

                for (var i = 0; i < pgitems.PageCount; i++)
                    pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
                rptPages.DataSource = pages;
                rptPages.DataBind();
            }
            else
                rptPages.Visible = false;
            rpComment.DataSource = pgitems;
            rpComment.DataBind();
        }

        private int PageNumber
        {
            get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
            set { ViewState["PageNumber"] = value; }
        }

        protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
        {
            PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
            LoadData();
        }

        protected void BtnSendClick(object sender, EventArgs e)
        {
            if (Session["comment"] != null)
            {
                if (Convert.ToString(Session["comment"]) == "send")
                {
                    Panel3.Visible = true;
                    lblMessage3.Text = "شما قبلا نظر خودرا ارسال نموده اید";
                    lblMessage3.ForeColor = Color.Red;
                }
            }
            else
            {
                var error = string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtEmail.Text) ||
                            string.IsNullOrEmpty(txtMessage.Text) || string.IsNullOrEmpty(txtsubject.Text);
                if (error)
                {
                    Panel2.Visible = false;
                    Panel3.Visible = false;
                    Panel4.Visible = true;
                    lblMessage4.Text = "لطفا در تکمیل کردن فرم دقت کنید";
                    lblMessage4.ForeColor = Color.Red;
                    return;
                }
                try
                {
                    string UserName = User.Identity.Name.ToString();
                    Guid UserID = Guid.Parse(Membership.GetUser(UserName).ProviderUserKey.ToString());
                    var catId = dt.getCatId(Type);
                    var ntable = new Comment
                    {
                        fullName = Server.HtmlEncode(txtName.Text),
                        subject = Server.HtmlEncode(txtsubject.Text),
                        mail = Server.HtmlEncode(txtEmail.Text),
                        message = Server.HtmlEncode(txtMessage.Text),
                        active = false,
                        date = DateTime.Now,
                        catId = catId,
                        userId = UserID
                    };
                    dt.DB.Comments.InsertOnSubmit(ntable);
                    dt.DB.SubmitChanges();
                    Panel4.Visible = false;
                    Panel2.Visible = true;
                    lblMessage2.Text = "نظر شما با موفقیت ارسال شد";
                    lblMessage2.ForeColor = Color.Green;
                    pnl.Visible = false;
                    btnResend.Visible = true;
                    Session["comment"] = "send";
                }
                catch (Exception)
                {
                    Panel2.Visible = false;
                    Panel5.Visible = true;
                    lblMessage5.Text = "متاسفانه ارسال نظر با مشکل موجه شد";
                    lblMessage5.ForeColor = Color.Red;
                    pnl.Visible = false;
                    btnResend.Visible = true;
                    return;
                }
                Panel5.Visible = false;
                Panel2.Visible = true;
                lblMessage2.Text = "نظر شما ارسال شد";
                lblMessage2.ForeColor = Color.Green;
            }
        }

        protected void BtnResendClick(object sender, EventArgs e)
        {
            pnl.Visible = true;
            txtMessage.Text = "";
            txtEmail.Text = "";
            txtName.Text = "";
            txtsubject.Text = "";
            Panel2.Visible = false;
            btnResend.Visible = false;
            LoadData();
        }
    }
}