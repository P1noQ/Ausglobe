﻿using System;
using System.Linq;

namespace Wiki
{
    public partial class WikiCategory : System.Web.UI.Page
    {
        public Data dt = new Data();
        protected void Page_Load(object sender, EventArgs e) 
        {
            if (IsPostBack) return;
            var item = dt.DB.Articles.OrderByDescending(p => p.Id).Take(6);
            rpLastArticles.DataSource = item.ToList();
            rpLastArticles.DataBind();
            rpcm.DataSource = dt.DB.spGetComment().Where(p => p.Cat.Contains("دانشنامه") && p.Show);
            rpcm.DataBind();
            rpAds.DataSource = dt.DB.Baners.OrderByDescending(p => p.Id).Take(2);
            rpAds.DataBind();
            if (Request.QueryString["type"] != null)
            {
                var type = Request.QueryString["type"];
                rpCategory.DataSource = dt.DB.Cats.Where(p => p.Type.Equals(type));
                rpCategory.DataBind();
                DescType(type);
            }
        }
        private void Desc(int id)
        {
            var info = dt.DB.Cats.FirstOrDefault(p => p.Id.Equals(id));
            if (info == null) return;
            Page.Title = info.Name;
            Page.MetaDescription = info.Name;
            Page.MetaKeywords = info.Name;
            ltrTitle.Text = info.Name;
        }

        private void DescType(string type)
        {
            var id = 0;
            switch (type)
            {
                case "news":
                    {
                        id = 9;
                        break;
                    }
                case "art":
                    {
                        id = 10;
                        break;
                    }
            }
            var info = dt.DB.Descriptions.FirstOrDefault(p => p.Id.Equals(id));
            if (info == null) return;
            Page.Title = info.Title;
            Page.MetaDescription = info.Description1;
            Page.MetaKeywords = info.Keywords;
            ltrTitle.Text = info.Title;
        }

        //public  string Url(string id)
        //{
        //    var item = dt.DB.Cats.FirstOrDefault(p =>p.Id.Equals(int.Parse(id)));
        //    if (item == null) return "";
        //    switch (item.Type)
        //    {
        //        case "product":
        //            {
        //                if (item.level.Equals(3))
        //                {
        //                    return "Product.aspx?id=" + item.Id;
        //                }
        //                return "Category.aspx?id=" + item.Id;
        //            }
        //        case "gallery":
        //            {
        //                return "Galley.aspx?id=" + item.Id;
        //            }
        //        default:
        //            {
        //                return "Info.aspx?id=" + item.d;
        //            }
        //    }
        //}
    }
}