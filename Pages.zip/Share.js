﻿    function bal() { window.open('http://balatarin.com/links/submit?phase=2&url=' + window.location + '&title=' + document.title); }

    function clo() { window.open('http://www.cloob.com/share/link/add?url=' + window.location + '&title=' + document.title); }

    function gpl() { window.open('https://m.google.com/app/plus/x/?v=compose&content=' + document.title + '%20-%20' + window.location); }

    function fac() { window.open('http://www.facebook.com/sharer.php?u=' + window.location + '&t=' + document.title); }
    ;
    function twi() { window.open('http://twitter.com/home?status=' + document.title + '%20-%20' + window.location); }

    function lin() { window.open('http://www.linkedin.com/shareArticle?mini=true&url=' + window.location + '&summary=' + document.title + '&source=' + document.title); }

    function can() {
        alert("Ok");
        return(true);

    }
    function chickletsClick(social) {
        var usResult1 = $("#ContentPlaceHolder2_hfUser").val();
        var usResult2 = $("#ContentPlaceHolder2_hfId").val();
        var usResult3 = $("#ContentPlaceHolder2_hfPage").val();
        var myData = "{'user': '" + usResult1 + "','id': '" + usResult2 + "','page': '" + usResult3 + "','social': '" + social + "'}";
        $.ajax
        ({
            data: myData,
            type: "POST",
            dataType: "json",
            url: "Share.aspx/ShareSo",
            contentType: "application/json; charset=utf-8"
        });
    }

    $(document).ready(function() {
        $(".chicklets").click(function() {
            var s = this.class();
            alert(s);
        });
    });