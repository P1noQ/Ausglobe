﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class About : System.Web.UI.Page
{
    Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        var dataAbout = Data.GetAbout().FirstOrDefault(p => p.Id.Equals(28));
        if (Request.QueryString["Id"] == null)
        {
            rpAbout.DataSource = Data.GetAbout().OrderBy(p => p.Id).Take(2);
            rpAbout.DataBind();
        }
        else
        {
            int id = 0;
            try
            {
                id = Convert.ToInt32(Request.QueryString["Id"].ToString());
            }
            catch (Exception)
            {
                return;
            }
            rpAbout.DataSource = Data.GetAbout().Where(p=>p.Id.Equals(id));
            rpAbout.DataBind();
        }
        Page.Title = dataAbout.Name;
        Page.MetaKeywords = dataAbout.Name;
        Page.MetaDescription = dataAbout.Name;
        ltAbout.Text = dataAbout.Body;
        imgAbout.ImageUrl = "admin/uploadimage/cata/" + dataAbout.Image;
    }
}