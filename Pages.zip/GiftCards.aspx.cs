﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Drawing;

public partial class GiftCards : System.Web.UI.Page
{
    clsShoppingCart carts = new clsShoppingCart();
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        LoadRep();
        carts.AddGiftList();
        if (!User.Identity.IsAuthenticated)
        {
            HpLogin.NavigateUrl = "Login.aspx";
        }
        else
        {
            HpLogin.Visible = false;
            Userlab.Text = User.Identity.Name;
        }
    }

    private void LoadRep()
    {
        if (carts.GiftListData.Rows.Count < 1)
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "محصولی در سبد خرید موجود نمی باشد ";
            basketrepeat.DataBind();
            MultiView1.ActiveViewIndex = -1;
            return;
        }
        lblMessage.Text = "";
        var rec = carts.GiftListData;



        basketrepeat.DataSource = rec;
        basketrepeat.DataBind();
        MultiView1.ActiveViewIndex = 0;
    }
    protected void basketrepeat_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "delete")
        {
            var Gid = e.CommandArgument.ToString();
            var item = dt.GetCurrentGiftCard(Gid.ToString());
            carts.DeleteShoppingGiftCart(item.ToString());
            Session.Remove("Giftbuy");
            Response.Redirect("GiftCards.aspx");
        }
    }
    protected void btnNextStep1_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 1;
    }

    protected void btnAvailClick(object sender, EventArgs e)
    {
        var DB = new db_atrDataContext();
        string Email = Server.HtmlEncode(txtEmail.Text);
        //string UserName = (from mem in DB.aspnet_Memberships where mem.Email.Equals(Email) select mem.Email).FirstOrDefault();

        string UserName = Membership.GetUserNameByEmail(Email);

        string Name = Profile.GetProfile(UserName).Name + " " + Profile.GetProfile(UserName).Family;
        if (!string.IsNullOrEmpty(UserName))
        {
            string msg = string.Format(" کاربری با ایمیل وارد شده بنام " + "{0}" + " قبلا ثبت شده است ", Name);
            string ques = string.Format("آیا مایلید برای همین کاربر شارژ شود؟");
            lblAvile.Text = msg;
            lblAvile.Text += ques;
            lblAvile.CssClass = "warning";
            resultbtn.Visible = true;

            //btnAvail.CssClass = "btn btn_green";
        }
        else
        {
            lblAvile.Font.Size = 12;
            lblAvile.Text = "آزاد می باشد .اکانت در حالت غیر فعال ساخته می شود. پس از تکمیل فرآیند یک ایمیل فعالسازی به کاربر فوق ارسال می شود";
            lblAvile.CssClass = "success";
         //   signUpinfo.Visible = true;
        }
    }

    protected void NoBtn_Click(object sender, EventArgs e)
    {
        //signUpinfo.Visible = true;
        resultbtn.Visible = false;
        lblAvile.Text = "";
        lblAvile.CssClass = "";
    }
    protected void YesBtn_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(User.Identity.Name))
            Response.Redirect("login.aspx?retURL=" + HttpContext.Current.Request.Url.PathAndQuery);

        Guid GiftID = Guid.Parse(carts.GiftListData.Rows[0]["GiftId"].ToString());
        string GiftCode = carts.GiftListData.Rows[0]["GiftCode"].ToString();
        long Price = long.Parse(carts.GiftListData.Rows[0]["Price"].ToString());
        long Balance = long.Parse(carts.GiftListData.Rows[0]["Balance"].ToString());
        int discount = int.Parse((Balance - Price).ToString());

        string UserName = User.Identity.Name.ToString();
        Guid UserID = Guid.Parse(Membership.GetUser(UserName).ProviderUserKey.ToString());
        string Name = Profile.GetProfile(UserName).Name.ToString();
        string Family = Profile.GetProfile(UserName).Family.ToString();
        string NAme = Name + " " + Family;


        long codeTracking = dt.InsertOrderGiftCard(Price, UserName, discount);


        List<object> props = new List<object>();
        props.Add(GiftID);
        props.Add(GiftCode);
        props.Add(NAme);
        props.Add(UserID);
        props.Add(Balance);
        props.Add(txtSendSms.Text);
        props.Add(txtSendEmail.Text);
        props.Add(Price);



        if (codeTracking < 1)
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "به علت تاخیر در انجام عملیات ثبت از سیستم سبد خرید شما پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
            MultiView1.ActiveViewIndex = 1;
            return;
        }



        Session["Props"] = props;
        Session["gifttype"] = GetGiftType();
        Session.Add("codeTracking", codeTracking);
        Response.Redirect("~/PayGift.aspx");
    }
    //protected void rdReg_CheckedChanged(object sender, EventArgs e)
    //{
    //    //if (rdReg.Checked)
    //    //{
    //    //    PreSignUp.Visible = true;
    //    //}
    //    //else
    //    //{
    //    //    PreSignUp.Visible = false;
    //    //}
    //}
    protected void btnCompelete_Click(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(User.Identity.Name))
            Response.Redirect("login.aspx?retURL=" + HttpContext.Current.Request.Url.PathAndQuery);

        Guid GiftID = Guid.Parse(carts.GiftListData.Rows[0]["GiftId"].ToString());
        string GiftCode = carts.GiftListData.Rows[0]["GiftCode"].ToString();
        long Price = long.Parse(carts.GiftListData.Rows[0]["Price"].ToString());
        long Balance = long.Parse(carts.GiftListData.Rows[0]["Balance"].ToString());
        int discount = int.Parse((Balance - Price).ToString());

        string UserName = User.Identity.Name.ToString();
        Guid UserID = Guid.Parse(Membership.GetUser(UserName).ProviderUserKey.ToString());
        string Name = Profile.GetProfile(UserName).Name.ToString();
        string Family = Profile.GetProfile(UserName).Family.ToString();
        string NAme = Name + " " + Family;

        Guid NewUserID = new Guid();
        string NewName = "";
        string NewFamily = "";
        string NewNAme = "";

        long codeTracking = dt.InsertOrderGiftCard(Price, UserName, discount);




        if (rdReg.Checked)
        {
            string pass = Membership.GeneratePassword(8, 8);
            var mem = Membership.CreateUser(txtEmail.Text, pass, txtEmail.Text);
            var pr = Profile.GetProfile(mem.UserName);
            pr.SetPropertyValue("Name", txtName.Text);
            pr.SetPropertyValue("Family", txtLastName.Text);
            pr.SetPropertyValue("Mobile", txtMob.Text);

            Membership.UpdateUser(mem);
            pr.Save();
            string sub = "ثبت نام در سایت هورا";
 string body = " کاربر گرامی کلمه عبور پشفرض شما " + "<strong>11111111</strong>" + "می باشد" + "<br />";
            body += "لطفا در اولین فرصت نسبت به تغییر کلمه عبور خود اقدام فرمایید" + "<br />";
             body += "جهت فعال سازی حساب خود روی لینک زیر کلیک نمایید";
            var l = "http://hooraa.com/Login.aspx?user=" + mem.ProviderUserKey.ToString();
            SendMes.SendEmail(txtEmail.Text, sub, body + "<br><a href=\"" + l + "\">فعالسازی حساب کاربری</a>");

            NewUserID = Guid.Parse(Membership.GetUser(mem.UserName).ProviderUserKey.ToString());
            NewName = txtName.Text;
            NewFamily = txtLastName.Text;
            NewNAme = NewName + " " + NewFamily;
        }

        List<object> props = new List<object>();
        props.Add(GiftID);
        props.Add(GiftCode);
        props.Add(NAme);
        props.Add(NewNAme);
        props.Add(UserID);
        props.Add(NewUserID);
        props.Add(Balance);
        props.Add(txtSendSms.Text);
        props.Add(txtSendEmail.Text);
        props.Add(Price);



        if (codeTracking < 1)
        {
            lblMessage.ForeColor = Color.Red;
            lblMessage.Text = "به علت تاخیر در انجام عملیات ثبت از سیستم سبد خرید شما پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
            MultiView1.ActiveViewIndex = 1;
            return;
        }



        Session["Props"] = props;
        Session["gifttype"] = GetGiftType();
        Session.Add("codeTracking", codeTracking);
        Response.Redirect("~/PayGift.aspx");
    }

    public int GetGiftType()
    {
        if (rdPersonal.Checked)
            return 1;
        if (rdReg.Checked)
            return 2;
        if (rdSend.Checked)
        {
            if (chkSendMail.Checked && chkSendSms.Checked)
                return 30;
            else
            {
                if (chkSendMail.Checked)
                    return 40;
                if (chkSendSms.Checked)
                    return 50;
            }

        }

        return 0;
    }


}