﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;
using System.Text.RegularExpressions;

public partial class DetailsDownload : System.Web.UI.Page
{
    public Data Data = new Data();
    Club Club=new Club();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        var id = 0;
        
        var db = new db_atrDataContext();
        var pid = 0;
        try
        {
            pid = Data.GetDownload().Max(p => p.Id);
        }
        catch
        {

        }
        try
        {
            id = int.Parse(Request.QueryString["id"]);
        }
        catch
        {
            if (pid == 0)
            {
                Response.Redirect("~/Default.aspx");
            }
            else
            {
                Response.Redirect("~/DetailsDownload.aspx?id=" + pid);
            }
        }
        var pro = Data.GetDownload(id);
        if (pro.Count() > 0)
        {
            var data = pro.First();
            var title = data.Title.ToString();
            Page.Title = title;
            Page.MetaDescription = data.Description;
            Page.MetaKeywords = data.Keyword;
            linkdownload.Text = data.Title;
            rpDetail.DataSource = pro;
            rpDetail.DataBind();
            hfId.Value = id.ToString();
            if (User.Identity.IsAuthenticated)
                hfUser.Value = User.Identity.Name;
            CaptchaImage1.Width = 270;
            CaptchaImage1.Height = 60;


            var imgcode = Data.GenerateRandomCode();
            CaptchaImage1.Text = imgcode;


            var pcom = Club.GetInfoComment(id, "دانلودها").OrderByDescending(p => p.DateI).ToList();
            if (pcom.Count() > 10)
            {
                var co = Convert.ToDouble(pcom.Count());
                var pageComment = new List<Club.Paging>();
                var c = Math.Ceiling(co / 10);
                Club.Paging l;
                for (int i = 1; i <= c; i++)
                {
                    if (i.Equals(1))
                    {
                        l = new Club.Paging
                        {
                            Id = i,
                            Class = "a"
                        };
                    }
                    else
                    {
                        l = new Club.Paging
                        {
                            Id = i,
                            Class = "b"
                        };
                    }
                    pageComment.Add(l);
                }
                rpcommentPage.DataSource = pageComment.ToList();
                rpcommentPage.DataBind();
                rpcommentPage.Visible = true;

            }
            else
            {
                rpcommentPage.Visible = false;

            }
            rpComment.DataSource = pcom.Take(10).ToList();
            rpComment.DataBind();
        }
    }

    protected void GetCaptcha(object sender, EventArgs e)
    {
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;
        CaptchaImage1.Text = imgcode;
    }
    protected void Rating1Changed(object sender, AjaxControlToolkit.RatingEventArgs e)
    {
        Thread.Sleep(500);
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;

        if (!User.Identity.IsAuthenticated)
        {
            lblMsg.Text = " برای امتیاز دهی عضو شوید ";
            lblMsg.ForeColor = Color.Red;
            BindRatings();
            return;
        }
        var g = new Guid(Membership.GetUser().ProviderUserKey.ToString());
        if (Data.DB.InfoRatings.Any((p => p.UserId.Equals(g) && p.InfoId.Equals(id) && p.Cat.Equals(4))))
        {
            lblMsg.Text = " قبلا امتیاز ثبت نموده اید ";
            lblMsg.ForeColor = Color.Red;
            BindRatings();
            return;
        }
        Club.InsertInfoRate(id, g, RatingProduct.CurrentRating, 4, 8);
        try
        {
            if (Data.GetUnit().Count(p => p.Type.Equals(2)) > 0)
            {
                var item = Data.GetUnit().Where(p => p.Type.Equals(2));
                var Body = "<div dir=\"rtl\">" + Profile.Name + " " + Profile.Family + " به دانلود " + Page.Title + " در سایت هورا امتیاز داد.</div>";
                try
                {
                     
                    foreach (UnitMessage u in item)
                    {
                        if (u.Mail.Length > 0)
                        {
                            SendMes.SendEmail(u.Mail, "درج امتیاز", Body);
                        }
                    }
                }
                finally
                {

                }
            }
        }
        finally
        {

        }
        lblMsg.Text = "امتیاز شما ثبت شد ";
        lblMsg.ForeColor = Color.Green;
        BindRatings();
    }

    public void BindRatings()
    {
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
        lblRating.Text = Data.DB.InfoRatings.Count(p => p.InfoId.Equals(id) && p.Cat.Equals(4)).ToString(CultureInfo.InvariantCulture);
        var rating = Data.DB.InfoRatings.Where(p => p.InfoId.Equals(id) && p.Cat.Equals(4));
        int avg;
        if (!rating.Any())
        {
            avg = 0;
        }
        else
        {
            avg = (int)rating.Average(p => p.Rating);
            if (avg > 6)
            {
                avg = 6;
            }
        }
        RatingProduct.CurrentRating = avg;
    }
    protected void sendbtn_Click(object sender, EventArgs e)
    {
        int Nid;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out Nid)) return;
        var Cap = Server.HtmlEncode(txtimgcode.Text);
        if (CaptchaImage1.Text.ToLower() != Cap.ToLower())
        {
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage1.Width = 270;
            CaptchaImage1.Height = 60;
            CaptchaImage1.Text = imgcode;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('کد امنیتی را درست وارد نمایید');", true);
            return;
        }
        if (!User.Identity.IsAuthenticated)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('وارد شوید');", true);
            return;
        }
        else
        {
            var UserName = User.Identity.Name;
            var Subject = Server.HtmlEncode(txtsub.Text);
            var Text = Server.HtmlEncode(txtidea.Text);
            var res = Club.InsertDownloadComment(Nid, UserName, Subject, Text);
            if (res == 0)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('ثبت شد');", true);
            else if (res == -1)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                    "loginerror('شما قبلاٌ نظر ثبت نموده اید');", true);
        }
    }
    protected void PageComment(object sender, EventArgs e)
    {
        var btnPage = (LinkButton)sender;
        var Id = Convert.ToInt32(btnPage.CommandArgument.ToString());

        int id;

        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;

        var pcom = Club.GetInfoComment(id, "دانلودها").OrderByDescending(p => p.DateI).ToList();

        var co = Convert.ToDouble(pcom.Count());
        var pageComment = new List<Club.Paging>();
        var c = Math.Ceiling(co / 10);
        Club.Paging l;
        for (int i = 1; i <= c; i++)
        {
            if (i.Equals(Id))
            {
                l = new Club.Paging
                {
                    Id = i,
                    Class = "a"
                };
            }
            else
            {
                l = new Club.Paging
                {
                    Id = i,
                    Class = "b"
                };
            }
            pageComment.Add(l);
        }
        rpcommentPage.DataSource = pageComment.ToList();
        rpcommentPage.DataBind();

        rpComment.DataSource = pcom.Skip((Id - 1) * 10).Take(10).ToList();
        rpComment.DataBind();
    }
    //public static string GetCatName(int Id)
    //{
    //    return Data.DB.spGetCatProduct().First(p => p.Id == Id).Name;
    //}
}