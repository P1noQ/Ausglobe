﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;

public partial class ProductNew : System.Web.UI.Page
{
    public clsShoppingCart Lib = new clsShoppingCart();
    public Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack) return;

        Page.Title = "Aus globe Products";
        Page.MetaDescription = "Aus globe Products";
        Page.MetaKeywords = "Aus globe Products";

        //rpProducts.DataSource = dt.GetProduct().Where(p => p.IsAvalible.Equals(true)).OrderByDescending(p => p.Id);
        //rpProducts.DataBind();

        LoadData();
    }

    private void LoadData()
    {
        var dv = dt.GetProduct().Where(p => p.IsAvalible.Equals(true)).OrderByDescending(p => p.Id);
        var pgitems = new PagedDataSource
        {
            DataSource = dv.ToList(),
            AllowPaging = true,
            PageSize = 8,
            CurrentPageIndex = PageNumber
        };
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (var i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
            rptPages.Visible = false;
        rpProducts.DataSource = pgitems;
        rpProducts.DataBind();
    }

    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }
    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        LoadData();
    }

    //protected void RpProductItemCommand(object source, RepeaterCommandEventArgs e)
    //{
    //    switch (e.CommandName)
    //    {
    //        case "insertShoppingcart":
    //            {
    //                new ShoppingCart();
    //                if (ShoppingCart.Inser(Convert.ToInt32(e.CommandArgument)))
    //                    Response.Redirect("ProductNew.aspx");
    //                break;
    //            }
    //    }
    //}

    protected void AddtoCart_Click(object sender, EventArgs e)
    {

    }
}