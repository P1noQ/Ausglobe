﻿using System;
using System.Linq;

public partial class Category : System.Web.UI.Page
{
    public Library Lib = new Library();
    protected void Page_Load(object sender, EventArgs e) 
    {
        if (Request.QueryString["type"] == null)
        {
            int id;
            if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
            rpCategory.DataSource = Lib.SelectCategory(id).ToList();
            rpCategory.DataBind();
            Desc(id);
        }
        else
        {
            var type = Request.QueryString["type"];
            rpCategory.DataSource = Lib.SelectCategory(type, 0).ToList();
            rpCategory.DataBind();
            DescType(type);
        }
    }

    private void Desc(int id)
    {
        var info = Lib.SelectCategory().ToList().FirstOrDefault(p => p.id.Equals(id));
        if (info == null) return;
        Page.Title = info.name;
        Page.MetaDescription = info.name;
        Page.MetaKeywords = info.name;
        ltrTitle.Text = info.name;
    }

    private void DescType(string type)
    {
        var id = 0;
        switch (type)
        {
            case "product":
                {
                    id = 17;
                    break;
                }
            case "video":
                {
                    id = 8;
                    break;
                }
            case "articles":
                {
                    id = 5;
                    break;
                }
            case "certificat":
                {
                    id = 6;
                    break;
                }
            case "news":
                {
                    id = 4;
                    break;
                }
            case "slideShow":
                {
                    id = 10;
                    break;
                }
            case "gallery":
                {
                    id = 9;
                    break;
                }
            case "download":
                {
                    id = 7;
                    break;
                }
        }
        var info = Lib.SelectDescription(id).ToList().FirstOrDefault();
        if (info == null) return;
        Page.Title = info.title;
        Page.MetaDescription = info.description;
        Page.MetaKeywords = info.keyword;
        ltrTitle.Text = info.title;
    }

    public  string Url(string id)
    {
        var item = Lib.SelectCategory().ToList().FirstOrDefault(p => p.parentId.Equals(int.Parse(id)) || p.id.Equals(int.Parse(id)));
        if (item == null) return "";
        switch (item.type)
        {
            case "product":
                {
                    if (Lib.Db.tblProducts.Any(p => p.catId.Equals(item.id)))
                    {
                        return "Product.aspx?id=" + item.id;
                    }
                    return "Category.aspx?id=" + item.id;
                }
            case "gallery":
                {
                    return "Gallery.aspx?id=" + item.id;
                }
            default:
                {
                    return "Info.aspx?id=" + item.id;
                }
        }
    }
}