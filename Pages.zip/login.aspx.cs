﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Net.Mail;
using System.Drawing;
using System.Data;
using System.Data.SqlClient;

public partial class reg : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;


        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Text = imgcode;

        //var u = Membership.GetUser("Test");
        //var pas = u.ResetPassword();
        //u.ChangePassword(pas, "1234567");

    }

    protected void GetCaptcha(object sender, EventArgs e)
    {
        CaptchaImage1.ImageUrl = "icon/loading35.gif";
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;
        CaptchaImage1.Text = imgcode;
    }


    protected void btnRegister_Click(object sender, EventArgs e)
    {
        var usermail = Server.HtmlEncode(txtUser.Text.ToString());
        var pass = Server.HtmlEncode(txtPassowrd.Text.ToString());
        var cap = Server.HtmlEncode(txtimgcode.Text.ToString());
        if (cap.ToLower() != CaptchaImage1.Text.ToLower())
        {
            Message.MessageGen(lblMes, "کد امنیتی را درست وارد نمایید", Color.Red);
            CaptchaImage1.ImageUrl = "icon/loading35.gif";
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage1.Width = 270;
            CaptchaImage1.Height = 75;
            CaptchaImage1.Text = imgcode;
            return;
        }
        Data dt = new Data();
        var USER = Membership.GetUser(usermail);
        var usermail1 = Membership.GetUserNameByEmail(usermail);
        var UserId = "";
        if (USER == null)
        {
            Message.MessageGen(lblMes, "نام کاربری وارد شده در سیستم وجود ندارد", Color.Red);
            return;
        }
        if (!string.IsNullOrEmpty(Request.QueryString["user"]))
        {
            UserId = Request.QueryString["user"].ToString();
            if (!USER.ProviderUserKey.ToString().Equals(UserId))
                return;
            else
            {
                var item = dt.DB.aspnet_Memberships.FirstOrDefault(p => p.UserId.Equals(UserId));
                if (item != null)
                {
                    item.LastLoginDate = DateTime.Now;
                    dt.DB.SubmitChanges();
                    FormsAuthentication.SetAuthCookie(usermail, chkRemember.Checked);
                    Response.Redirect("User.aspx");
                }
            }
        }



        if (USER.LastLoginDate.Equals(USER.CreationDate))
        {
            try
            {
                Message.MessageGen(lblMes, "حساب کاربری شما فعال نشده است", Color.Red);
                return;
            }
            catch
            {

            }
        }
        try
        {
            MailAddress ma = new MailAddress(usermail);
            if (Membership.FindUsersByEmail(usermail).Count == 1)
            {
                usermail = Membership.GetUserNameByEmail(usermail);
            }
            else
            {
                Message.MessageGen(lblMes, "کاربر با پست الکترونیکی مورد نظر یافت نشد", Color.Red);
                return;
            }
        }
        catch
        {

        }
        if (Membership.FindUsersByName(usermail).Count == 0)
        {
            Message.MessageGen(lblMes, "نام کاربری مورد نظر یافت نشد", Color.Red);
            return;
        }
        var mu = Membership.GetUser(usermail);
        if (!mu.IsApproved)
        {
            Message.MessageGen(lblMes, "کاربر مورد نظر غیرفعال است", Color.Red);
            return;
        }
        if (mu.IsLockedOut)
            mu.UnlockUser();

        //var USER2 = Membership.GetUser(usermail);


        if (!Membership.ValidateUser(usermail, pass))
        {
            Message.MessageGen(lblMes, "رمز عبور را درست وارد نمایید", Color.Red);
            return;
        }
        FormsAuthentication.SetAuthCookie(usermail, chkRemember.Checked);
        if (!string.IsNullOrEmpty(Request.QueryString["retURL"]))
            Response.Redirect(Request.QueryString["retURL"]);
        Response.Redirect("User.aspx");
        //FormsAuthentication.RedirectFromLoginPage(usermail, chkRemember.Checked);


    }
}