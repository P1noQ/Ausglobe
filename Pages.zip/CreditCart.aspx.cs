﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class CreditCart : System.Web.UI.Page
{
    Data dt = new Data();
    private clsShoppingCart cart = new clsShoppingCart();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        var item = dt.GetGiftCart().OrderByDescending(p => p.Balance);
        cart.AddGiftList();

        rpin.DataSource = item;
        rpin.DataBind();


    }
    protected void AddCart(object sender, EventArgs e)
    {

        var AddCart = (LinkButton)sender;

        var Gid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        var item = dt.GetCurrentGiftCard(Gid.ToString());

        var ordid = cart.OrdId;
        var ins = cart.InsertShoppingGiftCart(item.GiftCode, ordid);

    }


    protected void rpProduct_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("AddToCart"))
        {

            DataTable data = new DataTable("ShoppingGiftCart");


            var Gid = e.CommandArgument.ToString();
            var item = dt.GetCurrentGiftCard(Gid.ToString());

            var ordid = cart.OrdId;
            if (Session["Giftbuy"] == null)
            {
                cart.InsertShoppingGiftCart(item.GiftCode, ordid);
              
            }
            else
            {
                data = (DataTable)Session["Giftbuy"];
                if (data.Rows.Count > 0)
                {
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "creditmsg('تا تکمیل فرآیند قبلی مجاز به خرید جدید نمی باشید');", true);
                }

                else
                {
                    cart.InsertShoppingGiftCart(item.GiftCode, ordid);
                    Response.Redirect("GiftCards.aspx");
                }
            }
        }
    }
    protected void addwish_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        if (User.Identity.IsAuthenticated)
        {
            var uname = User.Identity.Name;
            dt.insertFav(uname, pid);
            var rpwish = (Repeater)Master.FindControl("rpwish");
            rpwish.DataSource = dt.getFav(User.Identity.Name);
            rpwish.DataBind();

            var sabtsuc = "اضافه شد";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('" + sabtsuc + "');", true);


        }
        else
        {
            var erorrmes = " برای درج ابتدا باید ثبت نام کنید";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('" + erorrmes + "');", true);
        }

    }

    protected void addtocompare_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;
        Session["ComSes"] = Convert.ToInt32(AddCart.CommandArgument.ToString());
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('به مقایسه اضافه شد');", true);

    }
}