﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class ResetPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        try
        {
            var g =new Guid( Request.QueryString["UserId"].ToString());
            var User = Membership.GetUser(g);
            if (Request.Cookies[User.UserName] == null)
            {
                lblMes.Text = "زمان بازیابی رمز عبور به اتمام رسیده است";
                lblMes.CssClass = "text-danger";
                lblMes.Visible = true;
            }
        }
        catch
        {
            lblMes.Text = "دستیابی غیر مجاز به صفحه بازیابی رمز عبور";
            lblMes.CssClass = "text-danger";
            lblMes.Visible = true;
            return;
        }
    }
    protected void btnResetClick(object sender, EventArgs e)
    {
        try
        {
            var g = new Guid(Request.QueryString["UserId"].ToString());
            var User = Membership.GetUser(g);
            if (Request.Cookies[User.UserName] == null)
            {
                lblMes.Text = "زمان بازیابی رمز عبور به اتمام رسیده است";
                lblMes.CssClass = "text-danger";
                lblMes.Visible = true;
            }
            else
            {
                var oldPass = User.ResetPassword();
                var newPass = Server.HtmlEncode(txtPassword.Text);
                var newPassRep = Server.HtmlEncode(txtRepPass.Text);
                if (newPassRep == newPass)
                {
                    User.ChangePassword(oldPass, newPass);
                    lblMes.Text = "رمز عبور تغییر  یافت.";
                    var cook = new HttpCookie(User.UserName, "t");
                    cook.Expires = DateTime.Now.AddDays(-1d);
                    Response.Cookies.Add(cook);
                }
                else
                {
                    lblMes.Text = "تکرار رمز عبور را درست وارد نمایید";
                    lblMes.CssClass = "text-danger";
                    lblMes.Visible = true;
                }
            }
        }
        catch
        {
            lblMes.Text = "دستیابی غیر مجاز به صفحه بازیابی رمز عبور";
            lblMes.CssClass = "text-danger";
            lblMes.Visible = true;
        }
    }
}