﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Read : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        if (Request.QueryString["id"].ToString().Length > 0)
        {
            if (User.Identity.IsAuthenticated)
            {
                var Id = Convert.ToInt32(Request.QueryString["id"].ToString());
                var item = SendMes.GetSendMes(User.Identity.Name).First(p => p.Id.Equals(Id));
                if (item.Read.Equals(false))
                {
                    item.Read = true;
                    Data.DB.SubmitChanges();
                }
                Hl1.Text = item.Subject;
                //phead.InnerText = item.Subject;
                lblDate.Text = "تاریخ ارسال: " + Data.PersianDate(item.DateS);
                body.InnerHtml = item.Body;
                Page.Title = item.Subject;
                Page.MetaDescription = item.Subject;
                Page.MetaKeywords = item.Subject;
            }
            else
            {

                Hl1.Text = "وارد شوید";

                Page.Title = "وارد شوید";
                Page.MetaDescription = "وارد شوید";
                Page.MetaKeywords = "وارد شوید";
            }
        }
    }
}