﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Mail;
using System.Threading;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Cart : System.Web.UI.Page
{
    public int AddressId
    {
        get
        {
            if (hfAdd.Value == "")
                return 0;
            return Convert.ToInt32(hfAdd.Value);
        }
    }

    public int PostId
    {
        get
        {
            if (hfPost.Value == "")
                return 0;
            return Convert.ToInt32(hfPost.Value);
        }
    }
    clsShoppingCart carts = new clsShoppingCart();
    Data dt = new Data();



    protected void Page_Load(object sender, EventArgs e)
    {

        if (IsPostBack) return;

        carts.UpdatePrice(User.IsInRole("Job"));

        LoadRep();

        ViewProvince();
        ViewFristCity();
        ViewGiftImg();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;

        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Text = imgcode;

        //if (User.Identity.IsAuthenticated)
        //{
        //    Guid pvkey1 = Guid.Parse(Membership.GetUser(User.Identity.Name).ProviderUserKey.ToString());
        //    var balance = dt.GetUserCharge(pvkey1);
        //    if (balance>0)
        //    {
        //        chkCharge.Visible = true;
        //    }
        //    else
        //    {
        //        chkCharge.Visible = false;
        //    }
        //}



    }

    protected void GetCaptcha(object sender, EventArgs e)
    {
        CaptchaImage1.ImageUrl = "icon/loading35.gif";
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;
        CaptchaImage1.Text = imgcode;
    }
    private void LoadRep()
    {
        if (carts.ListData.Rows.Count < 1)
        {
            pmes.InnerText = "محصولی در سبد خرید موجود نمی باشد";
            basketrepeat.DataBind();
            MultiViewCard.ActiveViewIndex = -1;
            return;
        }
        var rec = carts.ListData;
        rpTotal.Visible = false;
        if (User.Identity.IsAuthenticated)
        {

            var uid = dt.GetUserId(User.Identity.Name);
            if (uid.ToString() != "00000000-0000-0000-0000-000000000000")
            {

                var to = new DataTable("Total");
                var p = to.Columns.Add("Name");
                to.Columns.Add("Price");
                DataColumn[] keys = new DataColumn[1];
                keys[0] = p;
                to.PrimaryKey = keys;

                var roleId = Roles.GetRolesForUser(User.Identity.Name);



                var price = (int)carts.SumPrice();

                to.Rows.Add(new object[] { "جمع کل خرید شما", carts.SumPrice().ToString(CultureInfo.InvariantCulture) });
                to.Rows.Add(new object[] { "مبلغ قابل پرداخت", price.ToString(CultureInfo.InvariantCulture) });
                rpTotal.DataSource = to;
                rpTotal.DataBind();
                rpTotal.Visible = true;

            }
        }


        basketrepeat.DataSource = rec;
        basketrepeat.DataBind();

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        var usermail = Server.HtmlEncode(txtUser.Text.ToString());
        var pass = Server.HtmlEncode(txtPassowrd.Text.ToString());
        var cap = Server.HtmlEncode(txtimgcode.Text.ToString());
        if (cap.ToLower() != CaptchaImage1.Text.ToLower())
        {
            Message.MessageGen(lblMes, "کد امنیتی را درست وارد نمایید", Color.Red);
            CaptchaImage1.ImageUrl = "icon/loading35.gif";
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage1.Width = 270;
            CaptchaImage1.Height = 75;
            CaptchaImage1.Text = imgcode;
            return;
        }
        try
        {
            MailAddress ma = new MailAddress(usermail);
            if (Membership.FindUsersByEmail(usermail).Count == 1)
            {
                usermail = Membership.GetUserNameByEmail(usermail);
            }
            else
            {
                Message.MessageGen(lblMes, "کاربر با پست الکترونیکی مورد نظر یافت نشد", Color.Red);
                return;
            }
        }
        catch
        {

        }
        if (Membership.FindUsersByName(usermail).Count == 0)
        {
            Message.MessageGen(lblMes, "نام کاربری مورد نظر یافت نشد", Color.Red);
            return;
        }
        var mu = Membership.GetUser(usermail);
        if (!mu.IsApproved)
        {
            Message.MessageGen(lblMes, "کاربر مورد نظر غیرفعال است", Color.Red);
            return;
        }
        if (mu.IsLockedOut)
            mu.UnlockUser();
        if (!Membership.ValidateUser(usermail, pass))
        {
            Message.MessageGen(lblMes, "رمز عبور را درست وارد نمایید", Color.Red);
            return;
        }
        var USER = Membership.GetUser(usermail);

        if (USER.LastLoginDate.Equals(USER.CreationDate))
        {
            var UserId = "";
            try
            {
                UserId = Request.QueryString["user"].ToString();

                if (!USER.ProviderUserKey.ToString().Equals(UserId))
                {
                    Message.MessageGen(lblMes, "حساب کاربری شما فعال نشده است", Color.Red);
                    return;
                }

            }
            catch
            {

            }
        }
        FormsAuthentication.SetAuthCookie(usermail, chkRemember.Checked);
        var pr = Profile.GetProfile(usermail);
        if (carts.ListData.Rows.Count > 0)
        {
            if (pr.Name.Length == 0)
            {
                Guid Uid = dt.GetUserId(usermail);
                Response.Redirect("reg.aspx?user=" + Uid.ToString() + "&?ReturnUrl=Cart.aspx");
            }
            Response.Redirect("Cart.aspx");
            //LoadRep();

            //MultiViewCard.ActiveViewIndex = 0;
            //pmes.InnerText = "";
            //AddressList();
            //PostList();

        }
        else
        {
            MultiViewCard.ActiveViewIndex = -1;

            pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت  سبد خرید شما از سیستم پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
        }
    }
    protected void basketrepeat_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        var pkeys = e.CommandArgument.ToString().Split("&&".ToArray());
        var pid = Convert.ToInt32(pkeys[0]);
        var sid = Convert.ToInt32(pkeys[2]);
        var cid = Convert.ToInt32(pkeys[4]);
        if (e.CommandName.ToString() == "delete")
        {

            carts.DeleteShoppingCart(pid, sid, cid);

            LoadRep();
        }

        else if (e.CommandName.ToString() == "update")
        {
            var Update = (LinkButton)e.CommandSource;
            var TextBox1 = (TextBox)Update.Parent.FindControl("TextBox1");

            var count = 0;
            try
            {
                count = int.Parse(TextBox1.Text);

            }
            catch
            {

            }
            if (count > 0)
            {
                carts.UpdateShoppingCart(pid, sid, cid, count);
            }
            LoadRep();
            string bent = Data.PricePersian(carts.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "benefite('" + bent + "');", true);
        }
    }
    protected void btnNextStep1_Click(object sender, EventArgs e)
    {
        if (carts.ListData.Rows.Count > 0)
        {

            if (User.Identity.IsAuthenticated)
            {
                var pr = Profile.GetProfile(User.Identity.Name);
                if (pr.Name.Length == 0)
                {
                    Guid Uid = dt.GetUserId(User.Identity.Name);
                    Response.Redirect("reg.aspx?user=" + Uid.ToString() + "&?ReturnUrl=Cart.aspx");
                }
                else
                {
                    MultiViewCard.ActiveViewIndex = 2;
                }


            }
            else
            {
                MultiViewCard.ActiveViewIndex =1;
            }

            AddressList();
            PostList();
            pmes.InnerText = "";


        }
        else
        {
            MultiViewCard.ActiveViewIndex = -1;
            pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت  سبد خرید شما از سیستم پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
        }
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
    }
    public void ViewGiftImg()
    {

        var gift = dt.GetGift();
        var i = 0;
        foreach (var g in gift)
        {
            var item = new ListItem("<img class='csGiftListImg' style='width:76px;' src='" + "admin/uploadimage/gift/200/" + g.Image + "' /><img src='image/paper_select.png' class='csSelect' />", g.id.ToString(CultureInfo.InvariantCulture))
            {
                Selected = i.Equals(0)
            };
            i++;
            RadioButtonListGift.Items.Add(item);
            RadioButtonListGift.CellPadding = 5;
            RadioButtonListGift.CellSpacing = 5;
        }
    }

    public void AddressList()
    {
        var item = dt.GetAddressUser(User.Identity.Name);

        lblAddress.Text = !item.Any() ? "لطفا آدرس مورد نظر را ثبت نمایید" : "";
        rpAddress.DataSource = item.ToList();
        rpAddress.DataBind();
    }

    public void PostList()
    {
        var item = dt.GetPost().Where(p => p.Active);
        rpPost.DataSource = item.ToList();
        rpPost.DataBind();
    }

    public void ViewProvince()
    {
        ddlProvince.DataSource = dt.StateQ().OrderBy(p => p.State1);
        ddlProvince.DataBind();
    }

    public void ViewFristCity()
    {

        var province = dt.StateQ().OrderBy(p => p.State1).FirstOrDefault();
        var city = dt.SelectCity().Where(p => p.SID.Equals(province.ID));
        ddlCity.DataSource = city;
        ddlCity.DataBind();
    }

    public string PriceFree(int id)
    {
        var post = carts.Db.Posts.FirstOrDefault(p => p.Id.Equals(id));
        if (post == null) return "ناموجود";
        var tp = Convert.ToInt64(carts.SumPrice());
        return post.priceFree < 1 ? post.Price.ToString(CultureInfo.InvariantCulture) : post.priceFree > tp ? post.Price.ToString(CultureInfo.InvariantCulture) : "رایگان";
    }

    protected void BtnNextstep3Click(object sender, EventArgs e)
    {
        MultiViewCard.ActiveViewIndex = 3;
        var AddrId = 0;
        foreach (RepeaterItem rdo in rpAddress.Items)
        {
            var rdoAddress = (RadioButton)rdo.FindControl("rdbSelectAddress");
            if (rdoAddress.Checked)
            {
                hfAdd.Value = rdoAddress.GroupName;
                AddrId = Convert.ToInt32(hfAdd.Value);
            }
        }
        if (AddrId < 1)
        {

            pmes.InnerText = "آدرس ارسال سفارش را لطفا انتخاب نمایید";
            MultiViewCard.ActiveViewIndex = 2;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
            return;
        }
        var address = dt.DB.UAddresses.FirstOrDefault(p => p.Id.Equals(AddrId));
        if (address == null)
        {

            pmes.InnerText =
                "آدرس ثبت شده شما از سیستم حذف شده است لطفا دوباره برای ثبت آدرس تلاش نمایید با تشکر";
            MultiViewCard.ActiveViewIndex = 2;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
            return;
        }
        var PosId = 0;
        foreach (RepeaterItem rdo in rpPost.Items)
        {
            var rdoPost = (RadioButton)rdo.FindControl("rdbSelectPost");
            if (rdoPost.Checked)
            {
                hfPost.Value = rdoPost.GroupName;
                PosId = Convert.ToInt32(rdoPost.GroupName);
            }
        }
        if (PosId < 1)
        {

            pmes.InnerText = "شیوه ارسال سفارش را لطفا انتخاب نمایید";
            MultiViewCard.ActiveViewIndex = 2;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
            return;
        }
        var post = carts.Db.Posts.FirstOrDefault(p => p.Id.Equals(PosId));
        if (post == null)
        {
            pmes.InnerText =
                "شیوه ارسال مورد نظر فعلا در دسترس نمی باشد لطفا از شیوه ارسال دیگری برای سفارش خود اقدام نمایید";
            MultiViewCard.ActiveViewIndex = 2;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true); ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
            return;
        }

        if (carts.ListData.Rows.Count < 1)
        {
            pmes.InnerText =
                "به علت تاخیر در عملیات ثبت ، سبد خرید شما  از سیستم حذف شده است لطفا دوباره برای ثبت سفارش اقدام نمایید";
            basketrepeat.DataBind();
            MultiViewCard.ActiveViewIndex = -1;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
            return;
        }
        pmes.InnerText = "";


        //change

        if (User.Identity.IsAuthenticated)
        {
            var uid = dt.GetUserId(User.Identity.Name);
            if (uid != null)
            {
                var pd = new List<PayDe>();
                pd.AddRange(carts.Db.PayDes);

                var balance = dt.GetUserCharge(uid);
                var pdt = new PayDe
                {
                    Id = 0,
                    Name = "کسر از اعتبار(" + Data.PricePersian(balance.ToString()) + ")"
                };
                if (balance > 0)
                {
                    pd.Add(pdt);
                }


                RadioButtonList1.DataSource = pd;
                RadioButtonList1.DataBind();
                RadioButtonList1.SelectedIndex = 0;

                if (carts.ListData.Rows.Count < 1)
                {
                    MultiViewCard.ActiveViewIndex = -1;

                    pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت  سبد خرید شما از سیستم پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
                    return;
                }

                //var roleId = Roles.GetRolesForUser(User.Identity.Name);

                //var disCount = carts.Db.Fn_discount(User.IsInRole("Job")).GetValueOrDefault(0);

                //int pricePost;


                //var city = dt.DB.Cities.FirstOrDefault(p => p.ID.Equals(address.CityId));

                //var province = dt.StateQ().Any(p => p.ID.Equals(city.SID) && p.State1.Contains("تهران"));
                //if (province && PostId.Equals(1))
                //{
                //    pricePost = post.priceFree > tp ? post.Price : 0;
                //}
                //else
                //{
                //    pricePost = post.Price;
                //}
                //UAddress s2 = new UAddress();
                //var price = (int)((((100 - disCount) * tp) / 100)) + pricePost;
                //var ppr = pricePost.Equals(0)
                //    ? "0"
                //    : Data.PricePersian(pricePost.ToString(CultureInfo.InvariantCulture), true);
                //var t = "";
                //if (ppr.Equals("0"))
                //    t = "بدون هزینه";
                //else
                //    t = "باهزینه " + ppr;
                //ltrPriceReView.Text = "<div class='items'><div class='item first alt'>" + "<span class='cssText'>جمع کل خرید شما :</span>" + Data.PricePersian(tp.ToString(CultureInfo.InvariantCulture), true) + "</div>" + "<div class='item '>" + "<span class='cssText'>هزینه ارسال سفارش:</span>" + ppr + "</div>" + "<div class='item red'>" + "<span class='cssText'>مجموع تخفیف :</span><span class='csPercent'>" + disCount + "درصد" + "</span></div>" + "<div class='item last alt'>" + "<span class='cssText'>مبلغ قابل پرداخت :</span>" + Data.PricePersian(price.ToString(CultureInfo.InvariantCulture), true) + "</div>" + "</div>";
                //ltrViewAddress.Text = string.Format("این سفارش به {0}  آدرس {1} و شماره تماس {2} تحویل می گیرد", s2.FullName, s2.Address, s2.Tel);
                //ltrViewPost.Text = string.Format(" این سفارش از طریق {0}  {1} به شما تحویل داده خواهد شد.", post.Title,
                //    t);
            }

        }
        else
        {
            pmes.InnerText = "به علت خروج شما از سایت عملیات ثبت سفارش از مرحله اول سرگیری می شود ";
            MultiViewCard.ActiveViewIndex = 0;

        }
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
        basketrepeat.DataSource = carts.ListData;
        basketrepeat.DataBind();

    }

    protected void BtnNextstep4Click(object sender, EventArgs e)
    {
        if (!ckbConditions.Checked)
        {
            pmes.InnerText = "درصورت نپذیرفتن قوانین امکان ثبت سفارش را ندارید";
            MultiViewCard.ActiveViewIndex = 3;
            return;
        }
        var Fraction = false;
        try
        {
            Fraction = RadioButtonList1.SelectedItem.Text.Contains("کسر");
        }
        catch
        {
            pmes.InnerText = "نحوه پرداخت را انتخاب نمایید";
            MultiViewCard.ActiveViewIndex = 3;
            return;
        }
        if (User.Identity.IsAuthenticated)
        {
            var uid = dt.GetUserId(User.Identity.Name);
            if (uid != null)
            {

                var AddrId = 0;
                foreach (RepeaterItem rdo in rpAddress.Items)
                {
                    var rdoAddress = (RadioButton)rdo.FindControl("rdbSelectAddress");
                    if (rdoAddress.Checked)
                    {
                        hfAdd.Value = rdoAddress.GroupName;
                        AddrId = Convert.ToInt32(hfAdd.Value);
                    }
                }
                if (AddrId < 1)
                {

                    pmes.InnerText = "آدرس ارسال سفارش را لطفا انتخاب نمایید";
                    MultiViewCard.ActiveViewIndex = 2;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
                    return;
                }
                var address = dt.DB.UAddresses.FirstOrDefault(p => p.Id.Equals(AddrId));
                if (address == null)
                {

                    pmes.InnerText =
                        "آدرس ثبت شده شما از سیستم حذف شده است لطفا دوباره برای ثبت آدرس تلاش نمایید با تشکر";
                    MultiViewCard.ActiveViewIndex = 2;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
                    return;
                }
                var PosId = 0;
                foreach (RepeaterItem rdo in rpPost.Items)
                {
                    var rdoPost = (RadioButton)rdo.FindControl("rdbSelectPost");
                    if (rdoPost.Checked)
                    {
                        hfPost.Value = rdoPost.GroupName;
                        PosId = Convert.ToInt32(rdoPost.GroupName);
                    }
                }
                if (PosId < 1)
                {

                    pmes.InnerText = "شیوه ارسال سفارش را لطفا انتخاب نمایید";
                    MultiViewCard.ActiveViewIndex = 2;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
                    return;
                }
                var post = carts.Db.Posts.FirstOrDefault(p => p.Id.Equals(PosId));
                if (post == null)
                {
                    pmes.InnerText =
                        "شیوه ارسال مورد نظر فعلا در دسترس نمی باشد لطفا از شیوه ارسال دیگری برای سفارش خود اقدام نمایید";
                    MultiViewCard.ActiveViewIndex = 2;
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true); ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
                    return;
                }
                var balance = dt.GetUserCharge(uid);
                if (carts.ListData.Rows.Count < 1)
                {
                    MultiViewCard.ActiveViewIndex = -1;

                    pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت  سبد خرید شما از سیستم پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
                    return;
                }

                var disCount = carts.Db.Fn_discount(User.IsInRole("Job")).GetValueOrDefault(0);

                int pricePost;

                var tp = carts.SumPrice();
                var city = dt.DB.Cities.FirstOrDefault(p => p.ID.Equals(address.CityId));

                var province = dt.StateQ().Any(p => p.ID.Equals(city.SID) && p.State1.Contains("تهران"));
                if (province && PostId.Equals(1))
                {
                    pricePost = post.priceFree > tp ? post.Price : 0;
                }
                else
                {
                    pricePost = post.Price;
                }
                UAddress s2 = new UAddress();
                long price = (int)tp + pricePost;
                if (Fraction)
                {
                    if (balance > price)
                        price = 0;
                    else
                        price = price - balance;
                }
                var ppr = pricePost.Equals(0)
                    ? "0"
                    : Data.PricePersian(pricePost.ToString(CultureInfo.InvariantCulture), true);
                var t = "";
                if (ppr.Equals("0"))
                    t = "بدون هزینه";
                else
                    t = "باهزینه " + ppr;
                var pricestr = "0";
                if (price > 0)
                {
                    pricestr = Data.PricePersian(price.ToString(CultureInfo.InvariantCulture), true);
                }
                ltrPriceReView.Text = "<div class='items'><div class='item first alt'>" + "<span class='cssText'>جمع کل خرید شما :</span>" + Data.PricePersian(tp.ToString(CultureInfo.InvariantCulture), true) + "</div>" + "<div class='item '>" + "<span class='cssText'>هزینه ارسال سفارش:</span>" + ppr + "</div>" + "<div class='item red'>" + "</div>" + "<div class='item last alt'>" + "<span class='cssText'>مبلغ قابل پرداخت :</span>" + pricestr + "</div>" + "</div>";
                ltrViewAddress.Text = string.Format("این سفارش به {0}  آدرس {1} و شماره تماس {2} تحویل می گیرد", s2.FullName, s2.Address, s2.Tel);
                ltrViewPost.Text = string.Format(" این سفارش از طریق {0}  {1} به شما تحویل داده خواهد شد.", post.Title,
                    t);
            }

        }
        else
        {
            pmes.InnerText = "به علت خروج شما از سایت عملیات ثبت سفارش از مرحله اول سرگیری می شود ";
            MultiViewCard.ActiveViewIndex = 0;
        }
        MultiViewCard.ActiveViewIndex = 4;
        pmes.InnerText = "";
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
        basketrepeat.DataSource = carts.ListData;
        basketrepeat.DataBind();
    }

    protected void DdlProvinceSelectedIndexChanged(object sender, EventArgs e)
    {

        var city = dt.CityQ(int.Parse(ddlProvince.SelectedValue));
        ddlCity.Items.Clear();
        ddlCity.DataSource = city;
        ddlCity.DataBind();
        MultiViewCard.ActiveViewIndex = 2;

    }

    protected void btnAddressAdd_Click(object sender, EventArgs e)
    {
        txtAddress.Text = string.Empty;
        txtFullName.Text = string.Empty;
        txtMobiles.Text = string.Empty;
        txtTel.Text = string.Empty;
        txtZipCode.Text = string.Empty;
        ltrMessageAddress.Text = string.Empty;
        pnlAddressAdd.Visible = true;
        pnlAddressView.Visible = false;
        MultiViewCard.ActiveViewIndex = 2;
        ltrMessageAddress.Text = string.Empty;
    }

    protected void btnAddressInsert_Click(object sender, EventArgs e)
    {

        db_atrDataContext db1 = new db_atrDataContext();


        carts.InsertAddress(int.Parse(ddlCity.SelectedValue), Server.HtmlEncode(txtFullName.Text),
            Server.HtmlEncode(txtMobiles.Text), Server.HtmlEncode(txtTel.Text), Server.HtmlEncode(txtAddress.Text),
            Server.HtmlEncode(txtZipCode.Text), dt.GetUserId(User.Identity.Name));
        pnlAddressAdd.Visible = false;
        pnlAddressView.Visible = true;
        MultiViewCard.ActiveViewIndex = 2;
        AddressList();
    }
    Data ds = new Data();
    protected void BtnDeleteClick(object sender, EventArgs e)
    {
        var gh = new db_atrDataContext();
        var btnDel = (LinkButton)sender;
        if (btnDel.CommandName.Equals("remove"))
        {
            var id = int.Parse(btnDel.CommandArgument);

            var query = gh.Orders.Where(p => p.AddressId.GetValueOrDefault(0).Equals(id));
            if (query.Count() != 0)
            {
                ltrMessageAddress.Text = "این آدرس در سفارشات دیگر شما ثبت شده است و امکان حذف وجود ندارد";
            }
            else
            {
                var item = gh.UAddresses.FirstOrDefault(p => p.Id.Equals(id));
                if (item != null) gh.UAddresses.DeleteOnSubmit(item);
                gh.SubmitChanges();
            }
        }
        AddressList();
        MultiViewCard.ActiveViewIndex = 2;
    }
    protected void BtnFinishClick(object sender, EventArgs e)
    {
        if (MultiViewCard.ActiveViewIndex == 0)
        {
            MultiViewCard.ActiveViewIndex = 4;
        }
        if (!Page.User.Identity.IsAuthenticated)
        {

            pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت از سیستم خارج شده اید دوباره ورود نمایید ";
            //MultiViewCard.ActiveViewIndex = 1;
            return;
        }

        if (carts.ListData.Rows.Count < 1)
        {
            //MultiViewCard.ActiveViewIndex = -1;
            pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت  سبد خرید شما از سیستم پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
            return;
        }
        if (!ckbConditions.Checked)
        {
            pmes.InnerText = "درصورت نپذیرفتن قوانین امکان ثبت سفارش را ندارید";
            //MultiViewCard.ActiveViewIndex = 4;
            return;
        }
        var gh = new db_atrDataContext();
        var AddrId = Convert.ToInt32(hfAdd.Value);
        var address = gh.UAddresses.FirstOrDefault(p => p.Id.Equals(AddrId));

        if (address == null)
        {

            pmes.InnerText = "آدرس ثبت شده شما از سیستم حذف شده است لطفا دوباره برای ثبت آدرس تلاش نمایید با تشکر";
            //MultiViewCard.ActiveViewIndex = 2;
            return;
        }
        var PosId = Convert.ToInt32(hfPost.Value);
        var post = gh.Posts.FirstOrDefault(p => p.Id.Equals(PosId));
        if (post == null)
        {
            pmes.InnerText =
                "شیوه ارسال مورد نظر فعلا در دسترس نمی باشد لطفا از شیوه ارسال دیگری برای سفارش خود اقدام نمایید";
            //MultiViewCard.ActiveViewIndex = 2;
            return;
        }
        long? disCount = 0;

        var totalprice = carts.SumPrice();

        if (User.Identity.IsAuthenticated)
        {

            var uid = dt.GetUserId(User.Identity.Name);
            if (uid != null)
            {
                var Gift = ckbGift.Checked;
                var Price = Int64.Parse(totalprice.ToString());
                //int pd = 0;
                //long chpr = 0;
                //foreach (DataRow p in carts.ListData.Rows)
                //{
                //    pd = p.Field<int>("PID");
                //    chpr = p.Field<long>("Price");
                //    p.SetField<long>("Price", 0);
                //}
                if (carts.Change())
                {
                    LoadRep();
                    //MultiViewCard.ActiveViewIndex = 0;
                    pmes.InnerText = "";
                    string bent = Data.PricePersian(carts.Benefit().ToString());
                    if (bent.Contains("تماس"))
                    {
                        bent = "0 ريال";
                    }
                    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top(),benefite('" + bent + "');", true);
                    return;
                }
                var pMet = RadioButtonList1.SelectedItem.Text;

                int pricePost;
                var city = dt.DB.Cities.FirstOrDefault(p => p.ID.Equals(address.CityId));
                //var PosId = Convert.ToInt32(hfPost.Value);
                //var post = dt.DB.Posts.FirstOrDefault(p => p.Id.Equals(PosId));
                var province = dt.StateQ().Any(p => p.ID.Equals(city.SID) && p.State1.Contains("تهران"));
                if (province && PostId.Equals(1))
                {
                    pricePost = post.priceFree > totalprice ? post.Price : 0;
                }
                else
                {
                    pricePost = post.Price;
                }
                var balance = dt.GetUserCharge(uid);
                var price = (int)((((100 - disCount) * totalprice) / 100)) + pricePost;
                if (pMet.Contains("کسر"))
                {
                    pMet = "کسر از اعتبار";
                }
                var codeTracking = carts.InsertOrder(Price, User.Identity.Name, pMet, User.IsInRole("Job"), post.Id, pricePost, address.Id, Gift);

                if (codeTracking < 1)
                {
                    pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت از سیستم سبد خرید شما پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
                    //MultiViewCard.ActiveViewIndex = 3;
                    return;
                }

                if (ckbGift.Checked)
                {
                    if (dt.DB.Gifts.Any(p => p.id.Equals(int.Parse(RadioButtonListGift.SelectedValue))))
                    {

                        var GID = int.Parse(RadioButtonListGift.SelectedValue);
                        var State = Convert.ToBoolean(rblFactor.SelectedValue);
                        carts.InsertOrderGift(codeTracking, GID, State);
                        int image = int.Parse(RadioButtonListGift.SelectedItem.Value.ToString());
                        string Image = dt.GetGiftImage(image);
                        carts.insertPayGift(codeTracking, address.CityId, txtmessagegift.Text, Image);

                    }
                }

                carts.InsertDetailOrder(Convert.ToInt64(codeTracking));

                Session.Add("codeTracking", codeTracking);
                pmes.InnerText = "";
                TicketAdmin();
                TicketUser();
                if (RadioButtonList1.SelectedIndex == 3)
                {
                    if (price > balance)
                    {
                        dt.RemoveCash(uid, balance);

                    }
                    else
                    {
                        Session.Add("ChargeReduce", 1);
                        dt.RemoveCash(uid, price);
                    }
                dt.DB.spChargeWithSale(Convert.ToInt64(codeTracking));
                }
                Session.Remove("buy");
                carts.AddList();
                Response.Redirect("Pay.aspx");
            }
        }
    }

    public void TicketAdmin()
    {
        var user = Membership.GetUser("admin");
        if (user != null)
        {
            var mail = user.Email;
            //var mobile = Profile.GetProfile("admin").mobile;
            var body = string.Format("کاربر {0} سفارش جدیدی در سایت ثبت کرد ", User.Identity.Name);
            //Sms.Send(mobile, body);
            const string subject = @"ثبت سفارش جدید درسایت هورا";
            SendMes.SendEmail(mail, subject, body);
        }
    }

    public void TicketUser()
    {
        var user = Membership.GetUser(User.Identity.Name);
        if (user != null)
        {
            var mail = user.Email;
            //var mobile = Profile.GetProfile(User.Identity.Name).mobile;
            var item = dt.getMes(2);
            string body2 = item.Text;
            var body = string.Format("کاربر {0}  سفارش شما در سیستم ثبت شد لطفا برای ثبت نهایی فرم مربوطه را تکمیل نمایید ", User.Identity.Name);
            //Sms.Send(mobile, body);
            const string subject = @"ثبت سفارش جدید فروشگاه اینترنتی هورا ";
            SendMes.SendEmail(mail, subject, body2 + body);

        }
    }
    protected void btnBackRoot_Click(object sender, EventArgs e)
    {
        Response.Redirect("Cart.aspx");
    }
    protected void deletealldata_Click(object sender, EventArgs e)
    {
        carts.ListData.Rows.Clear();
        LoadRep();
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top(),benefite('0 ريال');", true);
    }

    protected void BasketView(object sender, EventArgs e)
    {
        if (!User.Identity.IsAuthenticated)
        {
            rpTotal.DataBind();
        }
        pmes.InnerText = "";
        MultiViewCard.ActiveViewIndex = 0;
    }
    protected void LoginView(object sender, EventArgs e)
    {
        pmes.InnerText = "";
        MultiViewCard.ActiveViewIndex = 1;
    }
    protected void DeliveryView(object sender, EventArgs e)
    {
        pmes.InnerText = "";
        MultiViewCard.ActiveViewIndex = 2;
        if (ckbGift.Checked)
        {
            giftt.Attributes["style"] = "display:block";
        }
    }
    protected void PayView(object sender, EventArgs e)
    {
        pmes.InnerText = "";
        MultiViewCard.ActiveViewIndex = 3;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default.aspx");
    }
    protected void btncancelinsert_Click(object sender, EventArgs e)
    {
        AddressList();
        MultiViewCard.ActiveViewIndex = 2;
        pnlAddressAdd.Visible = false;
        pnlAddressView.Visible = true;
    }

    protected void BtnFinishCrClick(object sender, EventArgs e)
    {
        if (!Page.User.Identity.IsAuthenticated)
        {

            pmes.InnerText = "به علت تاخیر در انجام عملیات ثبت از سیستم خارج شده اید دوباره ورود نمایید ";
            MultiViewCard.ActiveViewIndex = 1;
            return;
        }
        if (carts.ListData.Rows.Count < 1)
        {
            MultiViewCard.ActiveViewIndex = -1;
            pmes.InnerText =
                "به علت تاخیر در انجام عملیات ثبت  سبد خرید شما از سیستم پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
            return;
        }

        var UserId = dt.GetUserId(User.Identity.Name);
        var balance = dt.GetUserCharge(UserId);


        var tp = carts.SumPrice();
        int pricePost;
        var AddrId = Convert.ToInt32(hfAdd.Value);
        var address = dt.DB.UAddresses.FirstOrDefault(p => p.Id.Equals(AddrId));

        var city = dt.DB.Cities.FirstOrDefault(p => p.ID.Equals(address.CityId));
        var PosId = Convert.ToInt32(hfPost.Value);
        var post = dt.DB.Posts.FirstOrDefault(p => p.Id.Equals(PosId));
        var province = dt.StateQ().Any(p => p.ID.Equals(city.SID) && p.State1.Contains("تهران"));
        if (province && PostId.Equals(1))
        {
            pricePost = post.priceFree > tp ? post.Price : 0;
        }
        else
        {
            pricePost = post.Price;
        }
        var price = (int)tp + pricePost;

        var Gift = ckbGift.Checked;
        if (carts.Change())
        {
            LoadRep();
            MultiViewCard.ActiveViewIndex = 0;
            pmes.InnerText = "";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "Top();", true);
            return;
        }
        var codeTracking = carts.InsertOrder(tp, User.Identity.Name, "کسر از اعتبار",
            User.IsInRole("Job"), post.Id, address.Id, pricePost, Gift);
        dt.RemoveCash(UserId, price);
        if (codeTracking < 1)
        {
            pmes.InnerText =
                "به علت تاخیر در انجام عملیات ثبت از سیستم سبد خرید شما پاک شده است دوباره محصولات را به سبد خرید اضافه نمایید ";
            MultiViewCard.ActiveViewIndex = 3;
            return;
        }
        if (ckbGift.Checked)
        {
            if (dt.DB.Gifts.Any(p => p.id.Equals(int.Parse(RadioButtonListGift.SelectedValue))))
            {

                var GID = int.Parse(RadioButtonListGift.SelectedValue);
                var State = Convert.ToBoolean(rblFactor.SelectedValue);
                carts.InsertOrderGift(codeTracking, GID, State);
            }
        }
        carts.InsertDetailOrder(Convert.ToInt64(codeTracking));
        dt.DB.spChargeWithSale(Convert.ToInt64(codeTracking));
        Session.Add("codeTracking", codeTracking);
        pmes.InnerText = "";
        TicketAdmin();
        TicketUser();
        Session.Remove("buy");
        carts.AddList();
        Response.Redirect("~/Pay.aspx");
    }

    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {



    }
    public string GetImgColor(int cid)
    {
        var ret = dt.DB.PColors.FirstOrDefault(p => p.Id.Equals(cid));
        return "admin/uploadimage/color/" + ret.Image;
    }
    public string GetSize(int Sid)
    {
        var ret = dt.DB.PSizes.FirstOrDefault(p => p.Id.Equals(Sid));
        return ret.SizeName;
    }
       public string ProductImg(string image)
    {
        try
        {
          string newp = "admin/uploadimage/size/" + image.Replace("Psize", "");
            return newp;
        }
        catch {
            return "";
        }

    }

    public string Max(int CID)
    {
        var cs = carts.SizeCount(CID);
        if (cs.HasValue)
        {
            return cs.ToString();
        }
        else
        {
            return "";
        }

    }

}