﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Drawing;
using System.Collections.Generic;

public partial class OnlineConsultation : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        if (!User.Identity.IsAuthenticated)
        {
            Response.Redirect("Login.aspx");
        }


        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 75;

        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Text = imgcode;

        List<CatDoctor> CatList = new List<CatDoctor>();
        var sell = new CatDoctor
        {
            Id = 0,
            Group = "انتخاب نمایید"
        };

        CatList.Add(sell);
        CatList.AddRange(dt.GetCatDoctor().OrderBy(p => p.Group));



        DrProfassion.DataSource = CatList;
        DrProfassion.DataBind();

      


        rpArchive.DataSource = dt.GetQAByUser(User.Identity.Name).OrderByDescending(p => p.DateR);
        rpArchive.DataBind();
        

    }

    protected void SendBtn_Click(object sender, EventArgs e)
    {
        int drpro = Convert.ToInt32(DrProfassion.SelectedValue.ToString());
        string drname = DrName.SelectedValue.ToString();
        string username = User.Identity.Name;
        string desc = Desctxt.Text;
        if (Desctxt.Text == "")
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('مشکل خود را شرح دهید');", true);
            return;
        }
        else
        {
            if (dt.DB.spInsertQA("/", drpro,Subtxt.Text, drname, username, desc).Equals(0))
            {

                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('ثبت شد');", true);
            }
            else
            {
            
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('شما قبلا پیام ثبت کرده اید');", true);
            }

        }


    }

    protected void GetCaptcha(object sender, EventArgs e)
    {
        CaptchaImage1.ImageUrl = "icon/loading35.gif";
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 75;
        CaptchaImage1.Text = imgcode;
    }
    protected void DrProfassion_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DrProfassion.SelectedValue == "0")
        {
            DrName.CssClass = "lo";

            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('نام تخصص را انتخاب کنید');", true);

            return;
        }
        else
        {
            DrName.CssClass = "";
            int drp = Convert.ToInt32(DrProfassion.SelectedValue);

            List<spGetUserDataDoctorResult> CatList = new List<spGetUserDataDoctorResult>();
            var sell = new spGetUserDataDoctorResult
            {
                UserName = "",
                CreateDate = DateTime.Now,
                Email = "",
                Name = " انتخاب",
                Family = "نماييد"
            };

            CatList.Add(sell);
            var Names = dt.GetDoctor(drp).AsEnumerable();
            CatList.AddRange(Names);

            DrName.DataSource = CatList.Select(p => new { Name = p.Name + " " + p.Family, p.UserName });
            DrName.DataBind();
       
       
        }
    }



    protected void LinkButton1_Click(object sender, EventArgs e)
    {

        sendtab.Visible = true;
        viewArchiveQA.Visible = false;
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        MultiView1.ActiveViewIndex = 0;
        viewArchiveQA.Visible = true;
        sendtab.Visible = false;
        Subtxt.Text = "";
        Desctxt.Text = "";
       
    }
}