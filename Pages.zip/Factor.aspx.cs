﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Factor : System.Web.UI.Page
{
    public Data D = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        
        var E = new clsShoppingCart();
        var item = D.DB.Orders.FirstOrDefault();
        if (Request.QueryString["Id"] != null)
        {
            if (User.Identity.IsAuthenticated)
            {
                Int64 Ord = 0;
                try
                {
                    Ord = Convert.ToInt64(Request.QueryString["Id"].ToString());
                }
                catch (Exception)
                {
                    return;
                }
                var order = D.DB.Orders.FirstOrDefault(p => p.Id.Equals(Ord));
                if (order == null) return;
                if (order.UserId.Equals(new Guid(Membership.GetUser().ProviderUserKey.ToString())))
                {
                    
                    lblMail.Text = "ایمیل: <span>" + Membership.GetUser().Email+"</span>";
                    if (order.Status.Equals("معلق"))
                    {
                        lblDate.Text = "تاریخ ثبت پیش فاکتور: " + Data.PersianDate(order.Date.GetValueOrDefault(DateTime.Now));
                        Page.Title = "پیش فاکتور";
                    }
                    else
                    {
                        if (order.ConCode.HasValue)
                        {
                            lblCode.Text = "کد پیگیری: " + order.ConCode.Value.ToString();
                            Page.Title = "فاکتور " + order.ConCode.Value.ToString();
                        }
                        else
                        {
                            Page.Title = "فاکتور ";
                        }
                        
                        lblDate.Text = "تاریخ ثبت فاکتور: " + Data.PersianDate(order.Date.GetValueOrDefault(DateTime.Now));
                    }
                    lblStat.Text = "وضعیت: " + order.Status;
                    lblName.Text = "نام و نام خانوادگی: " + Profile.Name + " " + Profile.Family;
                    
                    lblMobile.Text = "موبایل: " + Profile.Mobile;
                    lblTel.Text = "شماره تماس: " + Profile.CodeTel + Profile.Tel;
                    
                    lblAddress.Text = "آدرس: استان " + Profile.State + " شهر " + Profile.City + " " + Profile.Address;
                    lblEcoCode.Text = "کد اقتصادی: " + Profile.Legal.EconomicCode;

                    txtFoot.Text = D.Factor;

                    var fac = E.GetFactor(Ord);
                    rpFactor.DataSource = fac;
                    rpFactor.DataBind();
                }
            }
        }
    }
    public static string Total()
    {
        var res = "";
        var E= new clsShoppingCart();

        if (HttpContext.Current.Request.QueryString["Id"] != null)
        {
            var Ord = Convert.ToInt64(HttpContext.Current.Request.QueryString["Id"]);
            res = Data.PricePersian(E.GetFactor(Ord).Sum<spGetFactorResult>(p => p.TotalPrice.GetValueOrDefault(0)).ToString());
        }
        return res;
    }
}