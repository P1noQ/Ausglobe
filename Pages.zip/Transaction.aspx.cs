﻿using System;
using System.Activities.Statements;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Transaction : System.Web.UI.Page
{
    Data dt = new Data();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        LoadData();
    }

    private void LoadData()
    {
        if (User.Identity.IsAuthenticated)
        {
            var item = dt.DB.spGetPayList(User.Identity.Name);
            rpDetails.DataSource = item;
            rpDetails.DataBind();
            rpDetails.Visible = true;
        }
        else
        {
            rpDetails.Visible = false;
            lblEmpty.Visible = true;
        }
    }
}