﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Drawing;

public partial class ForgotPassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 75;

        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Text = imgcode;
    }
    protected void GetCaptcha(object sender, EventArgs e)
    {
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 75;
        CaptchaImage1.Text = imgcode;
    }
    protected void btnForgetClick(object sender, EventArgs e)
    {
        var text = Server.HtmlEncode(txtUser.Text);
        var cap = Server.HtmlEncode(txtimgcode.Text.ToString());
        Response.Write("<script>alert('" + cap.ToLower() + CaptchaImage1.Text.ToLower() + "');</script>");
        if (cap.ToLower() != CaptchaImage1.Text.ToLower())
        {
            Message.MessageGen(lblMes, "کد امنیتی را درست وارد نمایید", Color.Red);
            var imgcode = Data.GenerateRandomCode();
            CaptchaImage1.Width = 270;
            CaptchaImage1.Height = 75;
            CaptchaImage1.Text = imgcode;
            return;
        }
        var user = "";
        try
        {
            if (Membership.FindUsersByEmail(user).Count.Equals(1))
                user = Membership.GetUserNameByEmail(text);
            else if (Membership.FindUsersByName(text.ToLower()).Count.Equals(1))
                user = text;
            else
            {
                lblMes.Text = "نام کاربری یا پست الکترونیکی یاقت نشد";
                lblMes.CssClass = "text-danger";
                lblMes.Visible = true;
                return;
            }
            var US = Membership.GetUser(user);
            var cook = new HttpCookie(US.UserName, "t");
            cook.Expires = DateTime.Now.AddDays(1);
            cook.HttpOnly = true;
            Response.Cookies.Add(cook);
            var href = "";
            if (Request.Url.Query.Length > 0)
                href = Request.Url.OriginalString.Replace("Forgot", "Reset").Replace(Request.Url.Query, "?UserId=" + US.ProviderUserKey.ToString());
            else
                href = Request.Url.OriginalString.Replace("Forgot", "Reset") + "?UserId=" + US.ProviderUserKey.ToString();
            var body = "<div dir=\"rtl\">برای بازیابی روز عبور در سایت تارا " + "<a href=\"" + href + "\">کلیک</a>" + " نمایید</div>";
            SendMes.SendEmail(US.Email, "بازیابی رمز عبور", body);
            lblMes.Text = "درصورت موجود بودن ایمیل و نام کاربری وارد شده،ایمیل حاوی لینک تغییر رمز عبور برای شما ارسال می شود.لطفاٌ ایمیل خود را بررسی نمایید و در صورت عدم مشاهده پوشه اسپم را بررسی نمایید.";
            lblMes.CssClass = "text-success";
            lblMes.Visible = true;
        }
        catch
        {

        }
    }
}