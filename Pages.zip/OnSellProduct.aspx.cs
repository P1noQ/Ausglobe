﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OnSellProduct : System.Web.UI.Page
{
    public Data dt = new Data();
    public clsShoppingCart cart = new clsShoppingCart();
    clsCompare Comp = new clsCompare();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        var maxp = dt.MaxPrice().ToString();
        var maxa = dt.MaxAge().ToString();
        sc.InnerHtml = sc.InnerHtml.Replace("PMAX", maxp);
        sc.InnerHtml = sc.InnerHtml.Replace("AMAX", maxa);
        lblPrice_Rang.Text = "0 -" + maxp;
        lblAge_Range.Text = "0 -" + maxa;
        cart.AddList();
        var ProdMenu = dt.GetProductMenu().Where(p => p.Level.Equals(0)).ToList();
        LoadData1();
        LoadData();

    }
    private void LoadData1()
    {
        var pgitems = new PagedDataSource();
        var dv = dt.OnSell().AsDataView();

        pgitems.DataSource = dv;
        pgitems.AllowPaging = true;
        pgitems.PageSize = 6;
        pgitems.CurrentPageIndex = PageNumber;
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (int i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
        {
            rptPages.Visible = false;
            pagination.Attributes["class"] = "lo";
        }
        rpProduct.DataSource = pgitems;
        rpProduct.DataBind();
    }

    protected void AddCart(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        var pname = dt.GetProduct(pid).First().Name.ToString();
        var ordid = cart.OrdId;
        var bindsize = dt.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (bindsize.Count() != 0)
        {
            DrpSize.Items.Clear();
            DrpSize.Items.Add(new ListItem("انتخاب نمایید", "0"));
            bindsize.ToList().ForEach(p => DrpSize.Items.Add(new ListItem(p.SizeName, p.Id.ToString())));
            lnkaddtocart.CommandArgument = pid.ToString();
            RpColor.DataBind();
            lblprice.Text = "";
            lblprice.CssClass = "";
            imgsize.ImageUrl = "";
            lnkaddtocart.CommandArgument = pid.ToString();
            UpdatePanel5.Update();

        }
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loadpopup();", true);
      
    }
    private void LoadData()
    {
        var i = 0;
        try
        {
            i = Convert.ToInt32(Request.QueryString["id"]);
        }
        catch (Exception)
        {


        }
        var bid = 0;
        try
        {
            bid = Convert.ToInt32(Request.QueryString["bid"]);
        }
        catch (Exception)
        {


        }

        var br = dt.GetParentCat(i, bid);


        var Menu0 = dt.GetProductMenu().Where(p => p.Level.Equals(0)).ToList();
        chkCat0.DataSource = Menu0;
        chkCat0.DataBind();
        if (br.Any())
        {
            var Name0 = br.FirstOrDefault(p => p.Level.Equals(0)).Name;
            chkCat0.Items.FindByValue(Name0).Selected = true;
            var Id0 = br.FirstOrDefault(p => p.Level.Equals(0)).Id;
            var at = dt.GetCatAttr(Id0);
            rpAttr.DataSource = at;
            rpAttr.DataBind();

            var Menu1 = dt.GetChildName(Name0, "", 0);
            chkCat1.DataSource = Menu1;
            chkCat1.DataBind();

            if (br.Any(p => p.Level.Equals(1)))
            {
                var Name1 = br.FirstOrDefault(p => p.Level.Equals(1)).Name;
                chkCat1.Items.FindByValue(Name1).Selected = true;
                var Menu2 = dt.GetChildName(Name0, Name1, 0);
                chkCat2.DataSource = Menu2;
                chkCat2.DataBind();
                if (br.Any(p => p.Level.Equals(2)))
                {
                    var Name2 = br.FirstOrDefault(p => p.Level.Equals(2)).Name;
                    chkCat2.Items.FindByValue(Name2).Selected = true;
                }
            }
            else
            {

                var Menu2 = dt.GetProductMenu().Where(p => p.LEVEL0.Equals(Name0) && p.Level.Equals(1)).ToList();
                chkCat2.DataSource = Menu2;
                chkCat2.DataBind();
            }
        }
        //foreach (ListItem item in chkCat0.Items)
        //{
        //    item.Selected = Check(item.Value.ToString(), 0);

        //}

        int? n = null;
        var Item = dt.GetProductMenu().FirstOrDefault(p => p.Id.Equals(i));
        if (Item != null)
        {
            var Name = Item.Name;
            var Level = Item.Level;
            if (Level.Equals(0))
            {
                if (bid.Equals(0))
                {
                    var cat = from q in dt.Getbran(i).OrderByDescending(p => p.Name)
                              select new
                              {
                                  q.CId,
                                  q.Id,
                                  q.Image,
                                  q.Name,
                                  Level = 0
                              };


                    var pro = dt.GetProductByMenu(i, 0).FirstOrDefault(p => p.DateDis.HasValue && p.DisPrice.HasValue).ToString();
                    if (!pro.Any()) rpProduct.Visible = false;
                    rpProduct.DataSource = pro;
                    rpProduct.DataBind();
                }
                else
                {
                    var cat = from q in dt.DB.spGetCatProductLevel(2, i, bid).OrderBy(p => p.Name).AsEnumerable()
                              select new
                              {
                                  CID = q.Id,
                                  Id = bid,
                                  q.Name,
                                  q.Image,
                                  Level = q.Level + 1
                              };

                    var Brand = dt.Getbran(i).FirstOrDefault(p => p.Id.Equals(bid));
                    if (Brand != null)
                    {
                        var bname = Brand.Name;
                        var pro = dt.GetProductByMenu(i, 0).FirstOrDefault(p => p.DateDis.HasValue && p.DisPrice.HasValue).ToString();
                        if (!pro.Any()) rpProduct.Visible = false;
                        rpProduct.DataSource = pro;
                        rpProduct.DataBind();
                    }
                }
            }
            else
            {

                var pro = dt.GetProductByMenu(i, Level + 1, bid);
                if (!pro.Any()) rpProduct.Visible = false;
                rpProduct.DataSource = pro.FirstOrDefault(p => p.DateDis.HasValue && p.DisPrice.HasValue);
                rpProduct.DataBind();
                var cat = from q in dt.GetProductChildMenu(Level + 2, i).OrderBy(p => p.Name).AsEnumerable()
                          select new
                          {
                              CID = q.Id,
                              Id = bid,
                              q.Name,
                              q.Image,
                              Level = q.Level + 1
                          };
            }
        }
    }
    public string Active(string Name)
    {


        var i = 0;
        try
        {
            i = Convert.ToInt32(Request.QueryString["id"]);
        }
        catch (Exception)
        {


        }
        if (i == 0) return "";
        var item = dt.GetProductMenu().FirstOrDefault(p => p.Id.Equals(i));
        if (item != null)
        {
            if (item.LEVEL0.Equals(Name) || item.Name.Equals(Name))
            {
                return "active";
            }
            else
            {
                return "";
            }
        }
        return "";
    }
    public bool Check(string Name, int level)
    {


        var i = 0;
        try
        {
            i = Convert.ToInt32(Request.QueryString["id"]);
        }
        catch (Exception)
        {

            throw;
        }
        if (i == 0) return false;
        var item = dt.GetProductMenu().FirstOrDefault(p => p.Id.Equals(i));
        if (item != null)
        {
            var lv = "";
            switch (level)
            {
                case 0:
                    lv = item.LEVEL0;
                    break;
                case 1:
                    lv = item.LEVEL1;
                    break;
                case 2:
                    lv = item.LEVEL2;
                    break;
                case 3:
                    lv = item.Name;
                    break;
            }
            if (lv.Equals(Name) || item.Name.Equals(Name))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        return false;
    }

    public string GetUrl(int Id, int? bid)
    {
        var url = "CatProduct.aspx?id=" + Id.ToString();
        if (bid.GetValueOrDefault(0) != 0)
            url = url + "&bid=" + bid.Value.ToString();
        return url;
    }

    public string GetImage(string Image, int? bid, int level)
    {
        var ret = "";
        if (level.Equals(0))
            ret = "admin/uploadimage/brand/" + Image;
        else
            ret = "admin/uploadimage/catp/" + Image;
        return ret;
    }
    protected void chkCat0_SelectedIndexChanged(object sender, EventArgs e)
    {
        IEnumerable<spGetChildNameResult> menu;
        IEnumerable<spGetChildNameResult> menu2;
        IEnumerable<spGetCatAttrResult> AT;


        menu = dt.GetChildName(chkCat0.Items[0].Value.ToString(), "", 0).AsEnumerable();
        menu2 = dt.GetChildName(chkCat0.Items[0].Value.ToString(), "", 0).AsEnumerable();
        AT = dt.GetCatAttr(null);

        var m = 0;
        var m1 = 0;
        foreach (ListItem item in chkCat0.Items)
        {

            if (chkCat0.SelectedItem == null)
            {
                var menu1 = dt.GetChildName(item.Value.ToString(), "", 0).AsEnumerable();

                foreach (spGetChildNameResult ch1 in menu1.AsEnumerable())
                {
                    var menu3 = dt.GetChildName(item.Value.ToString(), ch1.Name, 1).AsEnumerable();
                    if (m1 == 0)
                    {
                        menu2 = menu3;
                    }
                    else
                    {
                        menu2 = menu2.Union(menu3.Where(p => !menu2.Any(q => q.Name.Equals(p.Name))));
                    }
                    m1 = m1 + 1;
                }
                if (m == 0)
                {
                    menu = menu1;
                }
                else
                {
                    menu = menu.Union(menu1.Where(p => !menu.Any(q => q.Name.Equals(p.Name))));

                }
                m = m + 1;
            }
            else
            {
                if (item.Selected)
                {
                    var menu1 = dt.GetChildName(item.Value.ToString(), "", 0).AsEnumerable();
                    var CID = dt.GetProductMenu().FirstOrDefault(p => p.Name.Equals(item.Text)).Id;
                    var AT1 = dt.GetCatAttr(CID);
                    foreach (spGetChildNameResult ch1 in menu1.AsEnumerable())
                    {
                        var menu3 = dt.GetChildName(item.Value.ToString(), ch1.Name, 1).AsEnumerable();

                        if (m1 == 0)
                        {
                            menu2 = menu3;
                        }
                        else
                        {
                            menu2 = menu2.Union(menu3.Where(p => !menu2.Any(q => q.Name.Equals(p.Name))));
                        }
                        m1 = m1 + 1;
                    }
                    if (m == 0)
                    {
                        menu = menu1;
                        AT = AT1;
                    }
                    else
                    {
                        menu = menu.Union(menu1.Where(p => !menu.Any(q => q.Name.Equals(p.Name))));
                        AT = AT.Union(AT1.Where(p => !AT.Any(q => q.Text.Equals(p.Text))));
                    }
                    m = m + 1;
                }
            }
        }

        chkCat1.DataSource = menu.Distinct();
        chkCat1.DataBind();
        chkCat2.DataSource = menu2.Distinct();
        chkCat2.DataBind();
        rpAttr.DataSource = AT.Distinct();
        rpAttr.DataBind();

    }
    protected void chkCat1_SelectedIndexChanged(object sender, EventArgs e)
    {
        var menu = dt.GetChildName(chkCat0.Items[0].Value.ToString(), "", 0).AsEnumerable();
        var m = 0;
        List<ListItem> Cat0 = new List<ListItem>();
        Cat0.AddRange(chkCat0.Items.Cast<ListItem>());

        List<ListItem> Cat1 = new List<ListItem>();
        Cat1.AddRange(chkCat1.Items.Cast<ListItem>());
        if (chkCat0.SelectedItem != null)
        {
            Cat0.RemoveAll(p => p.Selected.Equals(false));
        }
        if (chkCat1.SelectedItem != null)
        {
            Cat1.RemoveAll(p => p.Selected.Equals(false));
        }
        foreach (ListItem it in Cat0)
        {
            foreach (ListItem it2 in Cat1)
            {
                var menu1 = dt.GetChildName(it.Text.ToString(), it2.Text.ToString(), 1);

                if (m == 0)
                {
                    menu = menu1;
                }
                else
                {
                    menu = menu.Union(menu1.Where(p => !menu.Any(q => q.Name.Equals(p.Name))));
                }
                m = m + 1;
            }
        }
        chkCat2.DataSource = menu.Distinct();
        chkCat2.DataBind();
    }

    protected void SearchAd(object sender, EventArgs e)
    {
        List<string> list = new List<string>();
        var sel = "";
        if (chkCat0.SelectedItem != null)
        {
            foreach (ListItem it in chkCat0.Items)
            {
                if (it.Selected)
                {
                    sel = sel + it.Text + ",";
                }
            }
            sel = sel.Substring(0, sel.Length - 1);
            list.Add(sel);
        }
        else
        {
            list.Add("");
        }
        sel = "";
        if (chkCat1.SelectedItem != null)
        {
            foreach (ListItem it in chkCat1.Items)
            {
                if (it.Selected)
                {
                    sel = sel + it.Text + ",";
                }
            }
            sel = sel.Substring(0, sel.Length - 1);
            list.Add(sel);
        }
        else
        {
            list.Add("");
        }
        sel = "";
        if (chkCat2.SelectedItem != null)
        {
            foreach (ListItem it in chkCat2.Items)
            {
                if (it.Selected)
                {
                    sel = sel + it.Text + ",";
                }
            }
            sel = sel.Substring(0, sel.Length - 1);
            list.Add(sel);
        }
        else
        {
            list.Add("");
        }
        sel = "";
        foreach (RepeaterItem ri in rpAttr.Items)
        {
            var chkAttrVal = (CheckBoxList)ri.FindControl("chkAttrVal");

            foreach (ListItem it in chkAttrVal.Items)
            {
                if (it.Selected)
                {
                    sel = sel + it.Value + ",";
                }
            }

        }
        if (sel.Length > 0)
        {
            sel = sel.Substring(0, sel.Length - 1);
        }
        list.Add(sel);

        list.Add(Price_min.Text + "-" + Price_max.Text);
        list.Add(Age_min.Text + "-" + Age_max.Text);

        Session["AdSearch"] = list;
        Response.Redirect("Search.aspx");

    }

    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {

        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        LoadData1();
    }
    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }
    public string getd()
    {
        return "lo";
    }
   
    protected void addwish_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        if (User.Identity.IsAuthenticated)
        {
            var uname = User.Identity.Name;
            dt.insertFav(uname, pid);

            var sabtsuc = "اضافه شد";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('" + sabtsuc + "');", true);

        }
        else
        {
            var erorrmes = " برای درج ابتدا باید ثبت نام کنید";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('" + erorrmes + "');", true);
        }

    }

    protected void addtocompare_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;
        Comp.Add(Convert.ToInt32(AddCart.CommandArgument.ToString()));
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('به مقایسه اضافه شد');", true);
    }

    protected void DrpSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        var sid = Convert.ToInt32(DrpSize.SelectedValue);
        var bindcolor = dt.DB.PColors.Where(p => p.SID.Equals(sid));
        RpColor.DataSource = bindcolor;
        RpColor.DataBind();
        var getdetails = dt.DB.PSizes.FirstOrDefault(p => p.Id.Equals(sid));
        imgsize.ImageUrl = "admin/uploadimage/size/" + getdetails.Image;
    }
    protected void RpColor_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("addcolor"))
        {
            CLabel1.Save = e.CommandArgument.ToString();
            var sid = Convert.ToInt32(DrpSize.SelectedValue);
            for (int i = 0; i < RpColor.Items.Count; i++)
            {
                var lnkcolor = (LinkButton)RpColor.Items[i].FindControl("lnkcolor");

                lnkcolor.CssClass = "";
                if (lnkcolor.CommandArgument == CLabel1.Save)
                {
                    lnkcolor.CssClass = "active";

                    var getdetails = dt.DB.PColors.FirstOrDefault(p => p.SID.Equals(sid) && p.Id.Equals(lnkcolor.CommandArgument));
                    var pid = getdetails.PID;
                    var pr = 0;
                    if (
                        dt.DB.spGetProductPrio()
                            .Any(
                                p =>
                                    p.Id.Equals(pid) && p.IsSale.GetValueOrDefault(false) && p.DateDis.HasValue &&
                                    p.DateDis.Value >= DateTime.Now))
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else if (getdetails.DateDis.HasValue && getdetails.DateDis.Value >= DateTime.Now)
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else
                        pr = getdetails.Price.GetValueOrDefault(0);


                    lblprice.Text = "قیمت" + Data.PricePersian(pr.ToString());
                    if (dt.IsAvailSize(pid, Convert.ToInt32(CLabel1.Save)))
                    {
                        lblprice.CssClass = "";
                        lnkaddtocart.Enabled = true;
                    }
                    else
                    {
                        lblprice.CssClass = "noavail";
                        lnkaddtocart.Enabled = false;
                    }
                }
            }


            UpdatePanel5.Update();
        }
    }
    protected void lnkaddtocart_Command(object sender, CommandEventArgs e)
    {
        if (User.IsInRole("Job"))
        {

        }
        var pid = Convert.ToInt32(lnkaddtocart.CommandArgument);
        var sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
        var cid = Convert.ToInt32(CLabel1.Save);
        var ordid = cart.OrdId;
        var pname = dt.GetProduct(pid).First().Name.ToString();
        //if (!dt.IsAvailSize(pid, sid))
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "hidepopup(),loginerror('" + pname + " موجود نیست'),GoCarosel(),Addjust();", true);
        //    return;
        //}
        int count = Convert.ToInt32(txtCount.Text);
        var ins = cart.InsertShoppingCart(pid, sid, cid, count, ordid, User.IsInRole("Job"));
        var mes = "";
        if (ins.Equals(0))
        {
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),showbasket('" + pname + "'),benefite('" + bent + "'),GoCarosel(),Addjust();", true);

        }
        else
        {
            switch (ins)
            {
                case 2:
                    mes = "به علت عدم موجودی محصول " + pname + " حذف گردید";
                    break;
                case 3:
                    mes = "امکان درج بیشتر محصول " + pname + " وجود ندارد";
                    break;
                case 4:
                    mes = "محصول " + pname + " موجود نیست";
                    break;

            }
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),loginerror('" + mes + "'),GoCarosel(),benefite('" + bent + "'),Addjust();", true);
        }
    }
}