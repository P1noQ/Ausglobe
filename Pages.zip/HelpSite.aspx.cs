﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class HelpSite : System.Web.UI.Page
{
    public clsShoppingCart Lib = new clsShoppingCart();
    Data dt = new Data();
   
    protected void Page_Load(object sender, EventArgs e)
    {

        Page.Title = dt.GetDescription(6, "t");
        H.InnerText = Page.Title;
        Page.MetaDescription = dt.GetDescription(6, "d");
        Page.MetaKeywords = dt.GetDescription(6, "k");
        lblCon.Text = dt.Help;
    }
}