﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;

public partial class ProductSpecial : System.Web.UI.Page
{
    public Library Lib = new Library();protected void Page_Load(object sender, EventArgs e) 
    {
        Desc();
        if (Page.IsPostBack) return;
        LoadData();
    }

    private void LoadData()
    {
        var dv = Lib.SelectProduct().Where(p => p.active && p.special).OrderByDescending(p => p.id);
        var pgitems = new PagedDataSource
        {
            DataSource = dv.ToList(),
            AllowPaging = true,
            PageSize = 12,
            CurrentPageIndex = PageNumber
        };
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (var i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
            rptPages.Visible = false;
        rpProduct.DataSource = pgitems;
        rpProduct.DataBind();
    }

    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }

    private void Desc()
    {
        Page.Title = " محصولات ویژه";
        Page.MetaDescription = " محصولات ویژه";
        Page.MetaKeywords = " محصولات ویژه";
        lblTitle.Text = " محصولات ویژه";
    }

    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        LoadData();
    }

    protected void RpProductItemCommand(object source, RepeaterCommandEventArgs e)
    {
        switch (e.CommandName)
        {
            case "insertShoppingcart":
                {
                    new ShoppingCart();
                    if (ShoppingCart.Inser(Convert.ToInt32(e.CommandArgument)))
                        Response.Redirect("ProductNew.aspx");
                    break;
                }
        }
    }
}