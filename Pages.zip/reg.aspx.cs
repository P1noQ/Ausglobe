﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Data;
using System.Drawing;

public partial class reg : System.Web.UI.Page
{
    Data Data = new Data();
    clsShoppingCart cart = new clsShoppingCart();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;
        CaptchaImage1.Text = imgcode;

        addrement.InnerHtml = Data.Agreement;


        var l = new ListItem("انتخاب نمایید", "0");
        dropAct.Items.Add(l);
        dropMeet.Items.Add(l);
        //  dropStateAgent.Items.Add(l);
        drpStates.Items.Add(l);
        dropCity.Items.Add(l);
        //dropCityAgent.Items.Add(l);
        //dropEducation.Items.Add(l);
        //dropEduAgent.Items.Add(l);
        //var active = Data.ActiveQ();
        //foreach (Active ac in active)
        //{
        //    l = new ListItem(ac.Active1, ac.ID.ToString());
        //    dropAct.Items.Add(l);
        //}


        var edu = Data.Education();

        foreach (DataRow d in edu.Rows)
        {
            dropEducation.Items.Add(new ListItem(d["Education"].ToString(), d["ID"].ToString()));
            dropEduAgent.Items.Add(new ListItem(d["Education"].ToString(), d["ID"].ToString()));
        }
        var state = Data.StateQ();

        foreach (State i in state)
        {
            l = new ListItem(i.State1, i.ID.ToString());
            // dropStateAgent.Items.Add(l);
            drpStates.Items.Add(l);
        }
        var meet = Data.MeetQ();
        foreach (Meet mt in meet)
        {
            l = new ListItem(mt.Meet1, mt.ID.ToString());
            dropMeet.Items.Add(l);
        }
        l = new ListItem("سایر موارد", (dropMeet.Items.Count).ToString());
        dropMeet.Items.Add(l);
    }
    protected void GetCaptcha(object sender, EventArgs e)
    {
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 60;
        CaptchaImage1.Text = imgcode;
    }
    protected void CheckBtn_Click(object sender, EventArgs e)
    {
        Random rnd = new Random();
        int rndnumber = rnd.Next(1000, 10000);
        Session["random"] = rndnumber.ToString();
        //txtCheck.Text = Session["random"].ToString();
        string mob = Server.HtmlEncode(txtMob.Text);
        SendMes.SendSMS(mob, rndnumber.ToString());
        txtCheck.Visible = true;
        Timer1.Enabled = true;
        for (int i = 0; i <= Timer1.Interval; i++)
        {
            remind.Visible = true;
            CheckBtn.Enabled = false;
            CheckBtn.Visible = false;
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "timer();", true);
        }

    }
    protected void Timer1_Tick(object sender, EventArgs e)
    {
        CheckBtn.Visible = true;
        CheckBtn.Enabled = true;
        CheckBtn.CssClass = "button";
        remind.Visible = false;

    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        lblInfo.Text = "";
        var code = Server.HtmlEncode(txtimgcode.Text.ToString());
        var UserId = "";

        try
        {
            UserId = Request.QueryString["user"].ToString();
        }
        catch
        {
            Message.MessageGen(lblmsg, "خطا در ورود به صفحه ثبت نام", Color.Red);
            return;
        }
        if (code.ToLower() != CaptchaImage1.Text.ToLower())
        {
            Message.MessageGen(lblmsg, "کد امنیتی را درست وارد نمایید", Color.Red);
            return;
        }



        var Name = Server.HtmlEncode(txtFirst_Name.Text.ToString());
        var Family = Server.HtmlEncode(txtLastName.Text.ToString());
        var Sex = true;
        if (rblSex.SelectedIndex == 1)
        {
            Sex = true;
        }
        else
        {
            Sex = false;
        }
        var Birth = Server.HtmlEncode(txtBirth.Text.ToString());

        var National = Server.HtmlEncode(txtNational.Text.ToString());
        var IdNo = Server.HtmlEncode(txtIdNo.Text.ToString());
        var State = "";
        var City = "";

        var Meet = Server.HtmlEncode(dropMeet.SelectedItem.Text.ToString());
        if (dropMeet.SelectedIndex == dropMeet.Items.Count - 1)
            Meet = Server.HtmlEncode(txtMeet.Text);
        var News = Server.HtmlEncode(rblNews.SelectedItem.Text.ToString());
        var Regard = Server.HtmlEncode(txtRegard.Text.ToString());
        var mob = Server.HtmlEncode(txtMob.Text);
        var Req = rbReq.SelectedIndex.Equals(1) ? true : false;
        var mem = Membership.GetUser(new Guid(UserId.ToString()));
        mem.Comment = Regard;
        if (News.Equals("بله")) Data.UpdateUserSetting(mem.UserName, "دریافت خبرنامه", true, true);
        var pr = Profile.GetProfile(mem.UserName);
        pr.SetPropertyValue("Name", Name);
        pr.SetPropertyValue("Family", Family);
        pr.SetPropertyValue("Sex", Sex);
        pr.SetPropertyValue("BirthDate", Birth);
        pr.SetPropertyValue("NationalCode", National);
        pr.SetPropertyValue("IdNo", IdNo);
        pr.SetPropertyValue("Meet", Meet);
        pr.SetPropertyValue("News", News);
        pr.SetPropertyValue("Req", Req);

        if (txtCheck.Text == Session["random"].ToString())
        {
            pr.SetPropertyValue("Mobile", mob);
        }
        Membership.UpdateUser(mem);
        var Role = "Real";
        if (rblType.SelectedIndex == 2) //l
        {
            Role = "Legal";
            Roles.AddUserToRole(mem.UserName, Role);
            var CorpType = Server.HtmlEncode(dropCorpType.SelectedItem.Text.ToString());
            var CorpName = Server.HtmlEncode(txtCorpName.Text.ToString());
            var Act = Server.HtmlEncode(dropAct.SelectedItem.Text.ToString());
            if (dropAct.SelectedIndex == 0)
                Act = "";
            var EcoCode = Server.HtmlEncode(txtEcoCode.Text.ToString());
            var NationalID = Server.HtmlEncode(txtNatianId.Text.ToString());
            State = Server.HtmlEncode(dropStateAgent.SelectedItem.Text.ToString());
            City = Server.HtmlEncode(dropCityAgent.SelectedItem.Text.ToString());
            var CorpAddress = Server.HtmlEncode(txtCorpAddress.Text.ToString());
            var PCodeCorp = Server.HtmlEncode(txtPCodeCorp.Text.ToString());
            var CorpTel = Server.HtmlEncode(txtTelCorp.Text.ToString());
            var CorpCodeTel = Server.HtmlEncode(txtCodeTelCorp.Text.ToString());
            var CorpFax = Server.HtmlEncode(txtFaxCorp.Text.ToString());
            var Position = Server.HtmlEncode(txtPosition.Text.ToString());
            var Education = Server.HtmlEncode(dropEduAgent.SelectedItem.Text.ToString());
            if (dropEduAgent.SelectedIndex == 0)
                Education = "";
            var TelD = Server.HtmlEncode(txtTelD.Text.ToString());
            pr.SetPropertyValue("Legal.Type", CorpType);
            pr.SetPropertyValue("Legal.CorpName", CorpName);
            pr.SetPropertyValue("Legal.Activity", Act);
            pr.SetPropertyValue("Legal.EconomicCode", EcoCode);
            pr.SetPropertyValue("Legal.NationalId", NationalID);
            pr.SetPropertyValue("State", State);
            pr.SetPropertyValue("City", City);
            pr.SetPropertyValue("Address", CorpAddress);
            pr.SetPropertyValue("PostalCode", PCodeCorp);
            pr.SetPropertyValue("Tel", CorpTel);
            pr.SetPropertyValue("CodeTel", CorpCodeTel);
            pr.SetPropertyValue("Fax", CorpFax);
            pr.SetPropertyValue("Education", Education);
            pr.SetPropertyValue("Legal.Position", Position);
            try
            {

                cart.InsertAddress(int.Parse(dropCity.SelectedValue), Name + " " + Family,
                    pr.Mobile, CorpCodeTel + CorpTel, CorpAddress,
                    PCodeCorp, new Guid(UserId));
            }
            catch
            {

            }
        }
        else //r
        {
            Roles.AddUserToRole(mem.UserName, Role);
            State = Server.HtmlEncode(drpStates.SelectedItem.Text.ToString());
            City = Server.HtmlEncode(dropCity.SelectedItem.Text.ToString());
            var Address = Server.HtmlEncode(txtAddress.Text.ToString());
            var PCode = Server.HtmlEncode(txtPCode.Text.ToString());
            var Tel = Server.HtmlEncode(txtTel.Text.ToString());
            var CodeTel = Server.HtmlEncode(txtCodeTel.Text.ToString());
            var Fax = Server.HtmlEncode(txtFax.Text.ToString());
            var Job = Server.HtmlEncode(txtJob.Text.ToString());
            var Education = Server.HtmlEncode(dropEducation.SelectedItem.Text.ToString());
            if (dropEducation.SelectedIndex == 0)
                Education = "";
            pr.SetPropertyValue("State", State);
            pr.SetPropertyValue("City", City);
            pr.SetPropertyValue("Address", Address);
            pr.SetPropertyValue("PostalCode", PCode);
            pr.SetPropertyValue("Tel", Tel);
            pr.SetPropertyValue("CodeTel", CodeTel);
            pr.SetPropertyValue("Fax", Fax);
            pr.SetPropertyValue("Education", Education);
            pr.SetPropertyValue("Real.Job", Job);
            try
            {

                cart.InsertAddress(int.Parse(dropCity.SelectedValue), Name + " " + Family,
                    pr.Mobile, CodeTel + Tel, Address,
                    PCode, new Guid(UserId));
            }
            catch
            {

            }
        }
        pr.Save();



        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "ShowSucc('ثبت نام با موفقیت انجام شد؛  ');", true);
        try
        {
            var item = Data.GetUnit().Where(p => p.Type.Equals(1));
            if (item.Any())
            {
                var href = Request.Url.OriginalString.Replace("reg", "admin/User");
                var body = "<div style=\"direction:rtl\">" + "در سایت هورا کاربر جدید ثبت نام نمود<br> برای مشاهده کاربران " + "<a href=\"User.aspx\" target=\"_blank\">صفحه مدیریت کاربران</a>" + " را باز نمایید</div>";
                foreach (UnitMessage u in item)
                {
                    try
                    {
                        if (u.Mail.Length > 0)
                        {
                            SendMes.SendEmail(u.Mail, "ثبت نام کاربر جدید", body);
                        }
                    }
                    finally
                    {

                    }
                }
            }
            Response.Redirect("~/User.aspx");
        }
        catch
        {

        }
    }
    protected void dropState_SelectedIndexChanged1(object sender, EventArgs e)
    {
        var drop = (DropDownList)sender;
        var l = new System.Collections.Generic.List<ListItem>();
        l.Add(new ListItem("انتخاب نمایید", "0"));
        if (drop.SelectedIndex > 0)
        {
            var St = Convert.ToInt32(drop.SelectedValue.ToString());
            var city = Data.CityQ(St);
            foreach (City ct in city)
            {
                l.Add(new ListItem(ct.City1, ct.ID.ToString()));
            }
        }
        dropCity.Items.AddRange(l.ToArray());
    }
    protected void rblType_SelectedIndexChanged(object sender, EventArgs e)
    {
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "ViewRole();", true);
    }

    protected void dropStateAgent_SelectedIndexChanged(object sender, EventArgs e)
    {
        var drop = (DropDownList)sender;
        var l = new System.Collections.Generic.List<ListItem>();
        l.Add(new ListItem("انتخاب نمایید", "0"));
        if (drop.SelectedIndex > 0)
        {
            var St = Convert.ToInt32(drop.SelectedValue.ToString());
            var city = Data.CityQ(St);
            foreach (City ct in city)
            {
                l.Add(new ListItem(ct.City1, ct.ID.ToString()));
            }
        }
        if (drop == drpStates)
        {
            dropCity.Items.Clear();
            dropCity.Items.AddRange(l.ToArray());
        }
        else
        {
            dropCityAgent.Items.Clear();
            dropCityAgent.Items.AddRange(l.ToArray());
        }
    }

    protected void drpStates_SelectedIndexChanged(object sender, EventArgs e)
    {
        var drop = (DropDownList)sender;
        var l = new System.Collections.Generic.List<ListItem>();
        l.Add(new ListItem("انتخاب نمایید", "0"));
        if (drop.SelectedIndex > 0)
        {
            var St = Convert.ToInt32(drop.SelectedValue.ToString());
            var city = Data.CityQ(St);
            foreach (City ct in city)
            {
                l.Add(new ListItem(ct.City1, ct.ID.ToString()));
            }
        }

        dropCity.Items.Clear();
        dropCity.Items.AddRange(l.ToArray());


    }
}