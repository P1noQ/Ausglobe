﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Dynamic;
using System.Drawing;
using System.Globalization;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Charge : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;


    }
    Data dt = new Data();

    public int ChargeUsers()
    {
        int result = 0;
        var charge = Server.HtmlEncode(txtCharge.Text);
        result = dt.CharageUserDirect(GetCurrentUserID(), charge);
            return result;
   
       
    }
    public int ChargeUserPhysically()
    {
        var charge = Server.HtmlEncode(txtCharge.Text);
       int result = dt.ChargeUserByPhysicalCard(GetCurrentUserID(), charge);
        return result;
    }


    protected void ChargeBtn_Click(object sender, EventArgs e)
    {

        if (!User.Identity.IsAuthenticated)
        {
            lblmsg.Text = "";
            lblmsg.CssClass = "warning";
            lblmsg.Text = "برای ورود کد شارژ باید وارد سیستم شده باشید";
            return;
        }

        int res = ChargeUsers();
        switch (res)
        {
            case 0:
            {
                lblmsg.Text = "";
                lblmsg.CssClass = "warning";
                lblmsg.Text = "عملیات با خطا مواجه شد لطفا دوباره تلاش کنید.";
                break;
            }
            case 1:
            {
                lblmsg.Text = "";
                lblmsg.CssClass = "warning";
               
                lblmsg.Text = "کارت با این کد شارژ در سیستم موجود نمی باشد";
                break;
            }
            case 2:
            {
                lblmsg.Text = "";
                lblmsg.CssClass = "warning";
                lblmsg.Text = " کارت با این کد شارژ قبلا استفاده شده است";
                break;
            }
            case 4:
            {
                lblmsg.Text = "";
                lblmsg.CssClass = "warning";
                lblmsg.Text = " کارت با این کد شارژ منقضی شده است";
                break;
            }
            case 3:
            {
                lblmsg.Text = "";
                lblmsg.CssClass = "success";
                lblmsg.ForeColor = System.Drawing.Color.Green;
                lblmsg.Text = "عملیات شارژ با موفقیت انجام شد و اعتبار افزوده شد";
                break;
            }

            default:

            {
                lblmsg.Text = "";
                lblmsg.CssClass = "warning";
                lblmsg.Text = "خطا در انجام عملیات افزایش اعتبار لطفا دوباره تلاش کنید.";
                break;
            }
        }
        if (res != 3 && res !=2)
        {
            int res2 = ChargeUserPhysically();
            switch (res2)
            {
                case 0:
                    {
                        lblmsg.Text = "";
                        lblmsg.CssClass = "warning";
                        lblmsg.Text = "عملیات با خطا مواجه شد لطفا دوباره تلاش کنید.";
                        break;
                    }
                case 1:
                    {
                        lblmsg.Text = "";
                        lblmsg.CssClass = "warning";

                        lblmsg.Text = "کارت با این کد شارژ در سیستم موجود نمی باشد";
                        break;
                    }
                case 2:
                    {
                        lblmsg.Text = "";
                        lblmsg.CssClass = "warning";
                        lblmsg.Text = " کارت با این کد شارژ قبلا استفاده شده است";
                        break;
                    }
                case 4:
                    {
                        lblmsg.Text = "";
                        lblmsg.CssClass = "warning";
                        lblmsg.Text = " کارت با این کد شارژ منقضی شده است";
                        break;
                    }
                case 3:
                    {
                        lblmsg.Text = "";
                        lblmsg.CssClass = "success";
                        lblmsg.ForeColor = System.Drawing.Color.Green;
                        lblmsg.Text = "عملیات شارژ با موفقیت انجام شد و اعتبار افزوده شد";
                        break;
                    }

                default:
                    {
                        lblmsg.Text = "";
                        lblmsg.CssClass = "warning";
                        lblmsg.Text = "خطا در انجام عملیات افزایش اعتبار لطفا دوباره تلاش کنید.";
                        break;
                    }
            }
        }
    }

    public Guid GetCurrentUserID()
    {
        if (!User.Identity.IsAuthenticated)
            return new Guid();
        else
        {
            return Guid.Parse(Membership.GetUser(User.Identity.Name.ToString()).ProviderUserKey.ToString());
        }
    }
}