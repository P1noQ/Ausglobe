﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Globalization;

public partial class Downloads : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        LoadData(); 
    }

    protected void LoadData()
    {
        Page.Title = Data.GetDescription(3, "t");
        Page.MetaDescription = Data.GetDescription(3, "d");
        Page.MetaKeywords = Data.GetDescription(3, "k");
        linkdownload.Text = Data.GetDescription(3, "t");
        var pgitems = new PagedDataSource();
        pgitems.AllowPaging = true;
        pgitems.PageSize = 2;
        pgitems.CurrentPageIndex = PageNumber;
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (int i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
            rptPages.Visible = false;
        rpin.DataSource = Data.DB.Downloads;
        rpin.DataBind();
    }

    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {

        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        LoadData();
    }
    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }
    
    public static string URL(string ID)
    {
        return "DetailsDownload.aspx?id=" + ID;
    }
}