﻿using Persia;
using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net.Mail;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Supplier : System.Web.UI.Page
{
    public clsShoppingCart Lib = new clsShoppingCart();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack) return;
        const int id = 9;
        var info = Lib.Db.Pages.FirstOrDefault(p => p.Id.Equals(id));
        if (info == null) return;
        Page.Title = info.Title;
        Page.MetaDescription = info.Title;
        Page.MetaKeywords = info.Title;
        lblTitle.Text = info.Title;
        
    }

    protected void BtnSendClick(object sender, EventArgs e)
    {
        if (Session["sendSupplier"] != null)
        {
            if (Convert.ToString(Session["sendSupplier"]) != "send") return;
            Panel3.Visible = true;
            lblMessage3.Text = "شما قبلا درخواست خود را ارسال نموده اید";
            lblMessage3.ForeColor = Color.Red;
        }
        else
        {
            var error = string.IsNullOrEmpty(txtLName.Text) || string.IsNullOrEmpty(txtFName.Text) ||
                        string.IsNullOrEmpty(txtTel.Text) || string.IsNullOrEmpty(txtAddress.Text) ||
                        string.IsNullOrEmpty(txtDescription.Text) || !FileUpload1.HasFile;
            if (error)
            {
                Panel2.Visible = false;
                Panel3.Visible = false;
                Panel4.Visible = true;
                lblMessage4.Text = "لطفا در تکمیل کردن فرم دقت کنید";
                lblMessage4.ForeColor = Color.Red;
                return;
            }
            try
            {
                var file = (Calendar.ConvertToPersian(DateTime.Now).ToString().Replace("/", "").Remove(0, 2)) + "-" + DateTime.Now.Hour + DateTime.Now.Minute + DateTime.Now.Second + "-1-" + FileUpload1.FileName;
                Library.SaveFile(FileUpload1, Server.MapPath("~/upload/file/") + file);
                var ntable = new Supplier
                {
                    FName = Server.HtmlEncode(txtFName.Text),
                    lName = Server.HtmlEncode(txtLName.Text),
                    tel = Server.HtmlEncode(txtTel.Text),
                    address = Server.HtmlEncode(txtAddress.Text),
                    description = Server.HtmlEncode(txtDescription.Text),
                    file = file,
                    date = DateTime.Now,
                    catId = 37
                };
                Lib.Db.Suppliers.InsertOnSubmit(ntable);
                Lib.Db.SubmitChanges();
                Panel4.Visible = false;
                Panel2.Visible = true;
                lblMessage2.Text = "درخواست شما با موفقیت ارسال شد";
                lblMessage2.ForeColor = Color.Green;
                pnl.Visible = false;
                btnResend.Visible = true;
                Session["sendSupplier"] = "send";
            }
            catch (Exception)
            {
                Panel2.Visible = false;
                Panel5.Visible = true;
                lblMessage5.Text = "متاسفانه ارسال درخواست با مشکل موجه شد";
                lblMessage5.ForeColor = Color.Red;
                pnl.Visible = false;
                btnResend.Visible = true;
            }
            Panel5.Visible = false;
            Panel2.Visible = true;
            lblMessage2.Text = "درخواست ارسال شد";
            lblMessage2.ForeColor = Color.Green;
        }
    }

    protected void BtnResendClick(object sender, EventArgs e)
    {
        pnl.Visible = true;
        txtDescription.Text = "";
        txtFName.Text = "";
        txtLName.Text = "";
        txtTel.Text = "";
        txtAddress.Text = "";
        Panel2.Visible = false;
        btnResend.Visible = false;
    }
}