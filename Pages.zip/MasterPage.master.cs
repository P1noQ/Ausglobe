﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    Data Data = new Data();
    char classVar = '_';
    int classVarInt = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        fItem1.Text = Data.GetFooterName().FirstOrDefault(p => p.Id.Equals(1)).Name;
        fItem2.Text = Data.GetFooterName().FirstOrDefault(p => p.Id.Equals(2)).Name;
        fItem3.Text = Data.GetFooterName().FirstOrDefault(p => p.Id.Equals(3)).Name;

        rpItem1.DataSource = Data.GetFooterLink(1);
        rpItem1.DataBind();

        rpItem2.DataSource = Data.GetFooterLink(2);
        rpItem2.DataBind();

        rpItem3.DataSource = Data.GetFooterLink(3);
        rpItem3.DataBind();

        rpCat.DataSource = Data.GetProductMenu().Where(p => p.Level.Equals(0)).ToList();
        rpCat.DataBind();

        rpAbout.DataSource = Data.GetAbout().OrderBy(p => p.Id).Take(2);
        rpAbout.DataBind();

        rpInfo.DataSource = Data.GetAbout().Where(p => p.Id != 22 && p.Id != 23 && p.Id != 27 && p.Id != 28);
        rpInfo.DataBind();

        ltContact.Text = Data.Contact.ToString();

        rpManufacturers.DataSource = Data.GetBrand();
        rpManufacturers.DataBind();

        rpSpec.DataSource = Data.GetProduct().Where(p => p.Spec.Equals(true)).OrderBy(p => p.Id);
        rpSpec.DataBind();

        rpBanner.DataSource = Data.GetLeftBrand();
        rpBanner.DataBind();

        rpLinks.DataSource = Data.GetLink();
        rpLinks.DataBind();

        rpQuickLinks.DataSource = Data.GetLink();
        rpQuickLinks.DataBind();

    }
    public IList<spGetCatBranddResult> GetCat2(int level)
    {
        return Data.Getbran(level);
    }
    public object GetCatProd(string name)
    {
        var res = from q in Data.DB.spGetCatProduct().Where(p => p.LEVEL0.Equals(name)).OrderBy(p => p.Name).ToList().Take(7)
                  select new
                  {
                      q.Id,
                      q.Name
                  };
        return res.ToList();
    }
    public object GetInfo2(int id)
    {
        var res = from info in Data.DB.spGetInfo().Where(p => p.Cat.Equals(id)).OrderBy(p => p.Id).ToList()
                  select new
                  {
                      info.Name,
                      info.URL
                  };
        return res.ToList();
    }
    public string funcClassVar()
    {
        classVarInt++;
        return "" + classVar + "" + classVarInt + "";
    }
}
