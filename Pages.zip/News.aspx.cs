﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class News : System.Web.UI.Page
{
    Data dt = new Data();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        LoadData();
    }

    private void LoadData()
    {

        Page.Title = dt.GetDescription(2, "t");
        Page.MetaDescription = dt.GetDescription(2, "d");
        Page.MetaKeywords = dt.GetDescription(2, "k");
        LinkButton10.Text = dt.GetDescription(2, "t");
        var pgitems = new PagedDataSource();
        var dv = dt.News().AsDataView();
        
        pgitems.DataSource = dv;
        pgitems.AllowPaging = true;
        pgitems.PageSize = 4;
        pgitems.CurrentPageIndex = PageNumber;
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (int i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
        {
            rptPages.Visible = false;
            pagination.Attributes["class"] = "lo";
        }
        rpNews.DataSource = pgitems;
        rpNews.DataBind();
    }
    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {

        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        LoadData();
    }
    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }
    public string getd()
    {
        return "lo";
    }
}