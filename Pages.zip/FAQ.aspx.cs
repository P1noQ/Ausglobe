﻿using System;
using System.Linq;

public partial class FAQ : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        slideShow.DataSource = dt.GetSlideData();
        slideShow.DataBind();

        Page.Title = dt.GetDescription(13, "t");
        Page.MetaDescription = dt.GetDescription(13, "d");
        Page.MetaKeywords = dt.GetDescription(13, "k");
        ltFAQ.Text = dt.FAQ;
    }
}