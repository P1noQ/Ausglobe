﻿using System;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using com.samanepay.acquirer;
using System.Drawing;
using System.Web.Security;
using System.Collections.Generic;


public partial class Result : System.Web.UI.Page
{
    public clsShoppingCart Lib = new clsShoppingCart();
    public Data Data = new Data();
    public Club cb = new Club();
    public string refrenceNumber = string.Empty;
    public string reservationNumber = string.Empty;
    public string transactionState = string.Empty;
    public string traceNumber = string.Empty;
    public static readonly string MID = "10347028";
    public bool isError = false;
    public string errorMsg = "";
    public string succeedMsg = "";



    public static readonly string TerminalId = ConfigurationManager.AppSettings["TerminalId"];
    public static readonly string UserName = ConfigurationManager.AppSettings["UserName"];
    public static readonly string UserPassword = ConfigurationManager.AppSettings["UserPassword"];
    public static long OrderId;

    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Page.IsPostBack) return;

        //if (!IsPostBack)
        //{
        //    int a = Charge();
        //    if (a == 3)
        //    {

        //        finalResult.Visible = true;
        //        dvCh.Visible = true;
        //        Message.MessageGen(lblMessage, "عملیات افزایش اعتبار با موفقیت انجام شد.", Color.Green);
        //    }
        //}

            if (RequestUnpack())
            {
                double result = 0;
                if (transactionState.Equals("OK"))
                {
                    ClientScript.RegisterStartupScript(typeof(Page), "ClientScript", "alert('Transaction is ok')",true);
                    ///////////////////////////////////////////////////////////////////////////////////
                    //   *** IMPORTANT  ****   ATTENTION
                    // Here you should check refrenceNumber in your DataBase tp prevent double spending
                    ///////////////////////////////////////////////////////////////////////////////////

                    //For Ignore SSL Error
                    ServicePointManager.ServerCertificateValidationCallback =
                     delegate(object s, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors) { return true; };

                    //WebService Instance
                    var srv = new com.samanepay.acquirer.PaymentIFBinding();
             
                 
                        result = srv.verifyTransaction(Request.Form["RefNum"], Request.Form["MID"]);
                        ClientScript.RegisterStartupScript(typeof(Page), "ClientScript", "alert('Transaction was verified')", true);
            
               
                 

                    if (result > 0)
                    {

                        ClientScript.RegisterStartupScript(typeof(Page), "ClientScript",
                              string.Format("alert('The Verified amount is {0}')", result), true);
                     
                            var CodeTracking = Convert.ToInt64(reservationNumber);
                            var order = Lib.Db.Orders.FirstOrDefault(p => p.Id == CodeTracking);
                            long price = order.Price.GetValueOrDefault(0);

                            var tbCarts = Data.DB.OrderDetails.Where(p => p.OId.Equals(CodeTracking));
                            if (tbCarts != null)
                            {
                                try
                                {
                                    var address =
                                        Data.SelectAddress("/", User.Identity.Name)
                                            .FirstOrDefault(p => p.UserId.Equals(order.UserId));
                                    var post = Data.GetPost().FirstOrDefault(p => p.Id == order.PostId);
                                    var tp = tbCarts.Sum(p => p.Price * p.Count);


                                    var pricePost = 0;
                                    var city = Data.SelectCity().FirstOrDefault(p => p.ID.Equals(address.CityId));
                                    var province = Data.SelectCity().Any(p => p.ID.Equals(city.SID) && p.City1.Contains("تهران"));
                                    if (post != null && (province && post.Id.Equals(1)))
                                    {
                                        pricePost = post.priceFree > tp ? post.Price : 0;
                                    }
                                    else
                                    {
                                        if (post != null) pricePost = post.Price;
                                    }

                                    price = Int64.Parse(((((100 - order.discount) * tp) / 100) + pricePost).ToString());

                                    if (order.Cash.HasValue)
                                    {
                                        price = price - order.Cash.Value;
                                    }
                                }
                                catch { }

                            }
                          
                            long res;
                            if (result != Convert.ToDouble(price))
                            {
                                isError = true;
                                res = -1;
                                var back = srv.reverseTransaction(refrenceNumber, MID, UserName, UserPassword);

                                if (back.Equals(1))
                                {
                                    errorMsg = "مبلغ کسر شده با مبلغ تراکنش برابر نیست و به حساب شما برگردانده شد";
                                }
                            }
                            else
                            {

                                isError = false;
                                var online =
                                  Data.DB.PayOnlines.FirstOrDefault(
                                     p=>p.orderId.Equals(CodeTracking));
                                if (online != null)
                                {
                                    online.traceId = traceNumber;
                                    online.resCode = 0;
                                    online.state = true;
                                    online.description = "عملیات پرداخت آنلاین با موفقیت انجام شد"; 
                                    Data.DB.SubmitChanges();

                                }
                                succeedMsg = "بانک صحت رسيد ديجيتالي شما را تصديق نمود. فرايند خريد تکميل گشت";

                                var fact = Data.DB.Orders.FirstOrDefault(p => p.Id == CodeTracking && p.Finish == false);
                                if (fact != null)
                                {
                                   // pnlDesc.Visible = true;
                                    fact.Finish = true;
                                    Data.DB.SubmitChanges();

                                }
                            }
                            
                            if (!isError)
                            {
                                lblStatus.ForeColor = System.Drawing.Color.Green;
                                lblStatus.Text = " پرداخت موفقیت آمیز بود از قسمت فروش با شما تماس گرفته خواهد شد";

                                try
                                {

                                    int Result = Charge();

                                    switch (Result)
                                    {
                                        case 0:
                                            {

                                                break;
                                            }
                                        case 1:
                                            {
                                                Message.MessageGen(lblmsg, "کارت با این کد شارژ در سیستم موجود نمی باشد.", Color.Red);
                                                finalResult.Visible = true;
                                                break;
                                            }
                                        case 2:
                                            {
                                                Message.MessageGen(lblmsg, "کارت با این کد شارژ قبلا استفاده شده است.", Color.Red);
                                                finalResult.Visible = true;
                                                break;
                                            }
                                        case 3:
                                            {
                                                Guid UserID = Guid.Parse(ViewState["UserId"].ToString());
                                                float Price = Convert.ToSingle(ViewState["Price"].ToString());
                                                finalResult.Visible = true;
                                               
                                                Message.MessageGen(lblMessage, "عملیات افزایش اعتبار با موفقیت انجام شد.", Color.Green);
                                             //   Lib.Db.spInsertScore(17, UserID, Price);
                                                var code = Convert.ToInt64(ViewState["Code"].ToString());
                                                var od = Lib.Db.Orders.FirstOrDefault(p => p.Id.Equals(code));
                                                od.Lock = true;
                                                Lib.Db.SubmitChanges();
                                                break;
                                            }
                                        case 4:
                                            {
                                                Message.MessageGen(lblMessage, "عملیات افزایش اعتبار با موفقیت انجام شد.", Color.Green);
                                                break;
                                            }
                                        case -1:
                                            {
                                                Message.MessageGen(lblmsg, "عملیات شارژ با مشکل مواجه شد.", Color.Red);
                                                finalResult.Visible = true;
                                                break;
                                            }
                                        default:
                                            {
                                                Message.MessageGen(lblmsg, "عملیات با مشکل مواجه شد.", Color.Red);
                                                finalResult.Visible = true;
                                                break;
                                            }
                                    }
                                }
                                catch(Exception ex) {
                                    lblStatus.Text =  "خطادر شارژکارت هدیه";
                                }
                            }
                            else
                            {
                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                lblStatus.Text = errorMsg;

                            }
                      
                        
                    }

                    else
                    {
                        errorMsg = TransactionChecking((int) result);
                        lblStatus.ForeColor = System.Drawing.Color.Goldenrod;
                        lblStatus.Text =
                            "انصراف از پرداخت آنلاین ، برای پرداخت دوباره از کنترل پنل کاربری خود استفاده نمایید با تشکر";
                    }
                }
                else
                {
                    isError = true;
                    errorMsg = "متاسفانه بانک خريد شما را تاييد نکرده است";

                    ClientScript.RegisterStartupScript(typeof(Page), "ClientScript",
                              string.Format("alert('The transaction State is {0}')", transactionState), true);

                    if (transactionState.Equals("Canceled By User") || transactionState.Equals(string.Empty))
                    {
                        // Transaction was canceled by user
                        isError = true;
                        errorMsg = "تراكنش توسط خريدار كنسل شد";
                    }
                    else if (transactionState.Equals("Invalid Amount"))
                    {
                        // Amount of revers teransaction is more than teransaction
                    }
                    else if (transactionState.Equals("Invalid Transaction"))
                    {
                        // Can not find teransaction
                    }
                    else if (transactionState.Equals("Invalid Card Number"))
                    {
                        // Card number is wrong
                    }
                    else if (transactionState.Equals("No Such Issuer"))
                    {
                        // Issuer can not find
                    }
                    else if (transactionState.Equals("Expired Card Pick Up"))
                    {
                        // The card is expired
                    }
                    else if (transactionState.Equals("Allowable PIN Tries Exceeded Pick Up"))
                    {
                        // For third time user enter a wrong PIN so card become invalid
                    }
                    else if (transactionState.Equals("Incorrect PIN"))
                    {
                        // Pin card is wrong
                    }
                    else if (transactionState.Equals("Exceeds Withdrawal Amount Limit"))
                    {
                        // Exceeds withdrawal from amount limit
                    }
                    else if (transactionState.Equals("Transaction Cannot Be Completed"))
                    {
                        // PIN and PAD are currect but Transaction Cannot Be Completed
                    }
                    else if (transactionState.Equals("Response Received Too Late"))
                    {
                        // Timeout occur
                    }
                    else if (transactionState.Equals("Suspected Fraud Pick Up"))
                    {
                        // User did not insert cvv2 & expiredate or they are wrong.
                    }
                    else if (transactionState.Equals("No Sufficient Funds"))
                    {
                        // there are not suficient funds in the account
                    }
                    else if (transactionState.Equals("Issuer Down Slm"))
                    {
                        // The bank server is down
                    }
                    else if (transactionState.Equals("TME Error"))
                    {
                        // unknown error occur
                    }
                    lblStatus.ForeColor = System.Drawing.Color.Goldenrod;
                    lblStatus.Text =
                        "انصراف از پرداخت آنلاین ، برای پرداخت دوباره از کنترل پنل کاربری خود استفاده نمایید با تشکر";
                }

            }
      
    }

    //protected void BtnOnlineDescClick(object sender, System.Web.UI.ImageClickEventArgs e)
    //{
    //    var descOnline = Lib.Db.PayOnlines.FirstOrDefault(p => p.id == OrderId);
    //    if (descOnline == null)
    //    {
    //        lblMessage.ForeColor = System.Drawing.Color.Red;
    //        lblMessage.Text = "توضیحات شما در سیستم ثبت نگردید";
    //        btnOnlineDesc.Enabled = false;
    //    }
    //    else
    //    {
    //        descOnline.description = txtDescriptionsLocal.Text;
    //        lblMessage.ForeColor = System.Drawing.Color.Green;
    //        lblMessage.Text = "توضیحات شما در سیستم ثبت شد";
    //        Lib.Db.SubmitChanges();
    //        btnOnlineDesc.Enabled = false;
    //    }
    //}

    Data dt = new Data();

    public int Charge()
    {
        List<object> props = null;
        long CodeTracking = 0;
        int GiftType = 0;
        clsShoppingCart.Ca CA;
        if (Session["Charge"] != null)
        {
            CA = (clsShoppingCart.Ca)Session["Charge"];
            dt.AddCash(CA.UserId, CA.Balance, "شارژ توسط کاربر");
            return 4;
        }
        if (Session["props"] != null)
            props = (List<object>)Session["props"];
        else return 0;

        Guid GiftID = Guid.Parse(props[0].ToString());
        string GiftCode = props[1].ToString();
        string NAme = props[2].ToString();
        string NewNAme = props[3].ToString();
        Guid UserID = Guid.Parse(props[4].ToString());
        ViewState["UserId"] = UserID;
        Guid NewUserID = Guid.Parse(props[5].ToString());
        long Balance = long.Parse(props[6].ToString());
        string Mobile = props[7].ToString();
        string Email = props[8].ToString();
        string Price = props[9].ToString();

        ViewState["Price"] = Price;

        if (Session["codeTracking"] != null)
        {
            CodeTracking = long.Parse(Session["codeTracking"].ToString());
            ViewState["Code"] = CodeTracking;

        }
        else return 0;

        if (Session["gifttype"] != null)
            GiftType = int.Parse(Session["gifttype"].ToString());
        else return 0;


        if (GiftType == 1)
        {

            int res = 0;
            if (dt.InsertUserGiftCard(GiftID, CodeTracking, UserID, GiftCode))
            {
                res = dt.ChargeUser(UserID, GiftID);
                if (res == 3)
                    lblchargenumber.Text = GetCurrentGiftCode(GiftID);
                return res;
            }
            else
            {
                Message.MessageGen(lblmsg, "خطا در انجام عملیات درج", Color.Red);
                finalResult.Visible = true;
                return -1;
            }
          



            //catch
            //{
            //    Message.MessageGen(lblmsg, "خطا در انجام عملیات", Color.Red);
            //    finalResult.Visible = true;
            //    return 0;
            //}
        }

        if (GiftType == 2)
        {
      
                int res = 0;
                if (dt.InsertUserGiftCard(GiftID, CodeTracking, UserID, GiftCode, NAme, NewNAme, IsUSed: true)
                    && dt.InsertUserGiftCard(GiftID, CodeTracking, NewUserID, GiftCode, NAme, NewNAme))
                {
                    res = dt.ChargeUser(NewUserID, GiftID, true);
                    if (res == 3)
                        lblchargenumber.Text = GetCurrentGiftCode(GiftID);

                    return res;

                }
                else
                {
                    Message.MessageGen(lblmsg, "خطا در انجام عملیات درج", Color.Red);
                    finalResult.Visible = true;
                    return -1;
                }

     

            //catch
            //{
            //    Message.MessageGen(lblmsg, "خطا در انجام عملیات", Color.Red);
            //    finalResult.Visible = true;
            //    return 0;
            //}
        }

        if (GiftType == 30)
        {
            int res = 0;
            if (dt.InsertUserGiftCard(GiftID, CodeTracking, UserID, GiftCode, Name: NAme))
            {
                res = 3;
                lblchargenumber.Text = GetCurrentGiftCode(GiftID);
                string subject = "کد کارت هدیه شما از سایت هورا";
                //string Body =
                //    string.Format(
                //        "کاربر {0} بنام {1} کارت هدیه با اعتبار {2} را برای شما خریداری کرده است. <br /> {کد شارژ : {3"
                //        , User.Identity.Name, NAme, Balance, GetCurrentGiftCode(GiftID));
                //SendMes.SendEmail(Email, subject, Body);
                //SendMes.SendSms(Email, Body);
                lblmsg.Text = "کد شارژ به ایمیل و شماره موبایل مورد نظر فرستاده شد.";
                lblmsg.CssClass = "success";
                dvCh.Visible = true;
                return res;
            }
            else
            {
                Message.MessageGen(lblmsg, "خطا در انجام عملیات درج یا ارسال", Color.Red);
                return -1;
            }
          

        }


        //Message.MessageGen(lblmsg, "خطا در انجام عملیات", Color.Red);
        //finalResult.Visible = true;
        //return 0;

        if (GiftType == 40)
        {
            //try
            //{
            int res = 0;
            if (dt.InsertUserGiftCard(GiftID, CodeTracking, UserID, GiftCode, Name: NAme))
            {
                res = 3;
                lblchargenumber.Text = GetCurrentGiftCode(GiftID);
                string subject = "کد کارت هدیه شما از سایت هورا";
            string Body = " کارت اعتباری با اعتبار " + Data.PricePersian(Balance.ToString()) +
                          " برای شما خریداری کرده است " + NAme + " بنام " + User.Identity.Name.ToString() + " " +
                          "کاربر" + "<br />" + GetCurrentGiftCode(GiftID) + " کد شارژ ";
            //string Body = string.Format("کاربر {0} بنام {1} کارت هدیه با اعتبار {2} را برای شما خریداری کرده است. <br /> {کد شارژ : {3"
            //     , User.Identity.Name.ToString(), NAme.ToString(), Balance.ToString(), GetCurrentGiftCode(GiftID).ToString()).ToString();
            SendMes.SendEmail(Email, subject, Body);
            lblmsg.Text = "کد شارژ به ایمیل مورد نظر فرستاده شد.";
            lblmsg.CssClass = "success";
            dvCh.Visible = true;
            return res;
            }
            else
            {
                Message.MessageGen(lblmsg, "خطا در انجام عملیات درج یا ارسال", Color.Red);
                finalResult.Visible = true;
                return -1;
            }
            


            //}

            //catch
            //{
            //    Message.MessageGen(lblmsg, "خطا در انجام عملیات", Color.Red);
            //    finalResult.Visible = true;
            //    return 0;
            //}
        }
        if (GiftType == 50)
        {
            int res = 0;
            if (dt.InsertUserGiftCard(GiftID, CodeTracking, UserID, GiftCode, Name: NAme))
            {
                res = 3;
                lblchargenumber.Text = GetCurrentGiftCode(GiftID);
                //  string Body =
                //string.Format(
                //    "کاربر {0} بنام {1} کارت هدیه با اعتبار {2} را برای شما خریداری کرده است. <br /> {کد شارژ : {3"
                //    , User.Identity.Name, NAme, Balance, GetCurrentGiftCode(GiftID));
            //SendMes.SendSms(Email, Body);
            lblmsg.Text = "کد شارژ به موبایل مورد نظر فرستاده شد.";
            lblmsg.CssClass = "success";
            return res;
            }
            else
            {
                Message.MessageGen(lblMessage, "خطا در انجام عملیات درج یا ارسال", Color.Red);
                finalResult.Visible = true;
                return -1;
            }


          


            //catch
            //{
            //    Message.MessageGen(lblmsg, "خطا در انجام عملیات", Color.Red);
            //    finalResult.Visible = true;
            //    return 0;
            //}
          //  return 0;
        }
        return 0;
    }

    public string GetCurrentGiftCode(Guid GiftID)
    {
        return (dt.DB.UserGiftCards.FirstOrDefault(p => p.GiftId.Equals(GiftID))).GiftCode.ToString();
    }
    private bool RequestUnpack()
    {
        if (RequestFeildIsEmpty()) return false;

        refrenceNumber = Request.Form["RefNum"].ToString();
        reservationNumber = Request.Form["ResNum"].ToString();
        transactionState = Request.Form["state"].ToString();
        traceNumber = Request.Form["TraceNo"].ToString();
        return true;
    }
    private bool RequestFeildIsEmpty()
    {
        if (Request.Form["state"].ToString().Equals(string.Empty))
        {
            isError = true;
            errorMsg = "خريد شما توسط بانک تاييد شده است اما رسيد ديجيتالي شما تاييد نگشت! مشکلي در فرايند رزرو خريد شما پيش آمده است";
            ClientScript.RegisterStartupScript(typeof(Page), "ClientScript",
                            string.Format("alert('{0}')",errorMsg), true);
           
            return true;
        }

        if (Request.Form["RefNum"].ToString().Equals(string.Empty) && Request.Form["state"].ToString().Equals(string.Empty))
        {
            isError = true;
            errorMsg = "فرايند انتقال وجه با موفقيت انجام شده است اما فرايند تاييد رسيد ديجيتالي با خطا مواجه گشت";
            ClientScript.RegisterStartupScript(typeof(Page), "ClientScript",
                           string.Format("alert('{0}')", errorMsg), true);
            return true;
        }

        if (Request.Form["ResNum"].ToString().Equals(string.Empty) && Request.Form["state"].ToString().Equals(string.Empty))
        {
            isError = true;
            errorMsg = "خطا در برقرار ارتباط با بانک";
            ClientScript.RegisterStartupScript(typeof(Page), "ClientScript",
                           string.Format("alert('{0}')", errorMsg), true);
            return true;
        }
        return false;
    }

    private string TransactionChecking(int i)
    {
        bool isError = false;
        string errorMsg = "";
        switch (i)
        {

            case -1:		//TP_ERROR
                isError = true;
                errorMsg = "بروز خطا درهنگام بررسي صحت رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-1";
                break;
            case -2:		//ACCOUNTS_DONT_MATCH
                isError = true;
                errorMsg = "بروز خطا در هنگام تاييد رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-2";
                break;
            case -3:		//BAD_INPUT
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-3";
                break;
            case -4:		//INVALID_PASSWORD_OR_ACCOUNT
                isError = true;
                errorMsg = "خطاي دروني سيستم درهنگام بررسي صحت رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-4";
                break;
            case -5:		//DATABASE_EXCEPTION
                isError = true;
                errorMsg = "خطاي دروني سيستم درهنگام بررسي صحت رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-5";
                break;
            case -7:		//ERROR_STR_NULL
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-7";
                break;
            case -8:		//ERROR_STR_TOO_LONG
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-8";
                break;
            case -9:		//ERROR_STR_NOT_AL_NUM
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-9";
                break;
            case -10:	//ERROR_STR_NOT_BASE64
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-10";
                break;
            case -11:	//ERROR_STR_TOO_SHORT
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-11";
                break;
            case -12:		//ERROR_STR_NULL
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-12";
                break;
            case -13:		//ERROR IN AMOUNT OF REVERS TRANSACTION AMOUNT
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-13";
                break;
            case -14:	//INVALID TRANSACTION
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-14";
                break;
            case -15:	//RETERNED AMOUNT IS WRONG
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-15";
                break;
            case -16:	//INTERNAL ERROR
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-16";
                break;
            case -17:	// REVERS TRANSACTIN FROM OTHER BANK
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-17";
                break;
            case -18:	//INVALID IP
                isError = true;
                errorMsg = "خطا در پردازش رسيد ديجيتالي در نتيجه خريد شما تاييد نگرييد" + "-18";
                break;

        }
        if (!string.IsNullOrEmpty(errorMsg))
            ClientScript.RegisterStartupScript(typeof(Page), "ClientScript",
                           string.Format("Transaction ErrorCode is {0}')", errorMsg), true);
           
            lblMessage.Text = errorMsg;
        return errorMsg;
    }     
}