﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;
using System.Globalization;
using System.IO;
using System.Web.Security;
using System.Data;
using System.Drawing;

public partial class User : System.Web.UI.Page
{
    public Data Data = new Data();
    public Club Club = new Club();
    public clsShoppingCart cart = new clsShoppingCart();
    public class UserData
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
    protected void Render(HtmlTextWriter w, Control c)
    {
        var sex = "";
        if (!Profile.Sex)
        {
            sex = "جناب آقای ";
        }
        else
        {
            sex = "سرکار خانم ";
        }
        var r = "";
        var t = "";
        if (User.IsInRole("Real"))
        {
            r = "حقیقی";
            t = "<br>وضیعت کاربری: عادی";
        }
        else if (User.IsInRole("Legal"))
        {
            r = "حقوقی";
            t = "<br>وضعیت کاربری: نماینده";
        }
        else
        {
            r = "مدیر سایت";
        }
        var item = Data.GetOrderList(User.Identity.Name);
        var check = item.Count(p => p.Status.Contains("صف"));
        var com = item.Count(p => p.Status.Contains("تایید"));
        var cchk = "";
        if (check > 0)
        {
            cchk = "<br>فاکتورهای در انتظار: " + check.ToString();
        }
        var ccom = "";
        if (com > 0)
        {
            ccom = "<br>فاکتورهای تایید شده: " + com.ToString();
        }
        var mes = SendMes.GetSendMesCount(User.Identity.Name);
        var cmes = "";
        if (mes > 0)
        {
            cmes = "<br>پیامهای جدید: " + mes.ToString();
        }
        var s = sex + Profile.Name + " " + Profile.Family + " خوش آمدید<br>";
        s = s + "نام کاربری: " + User.Identity.Name + "<br>نوع کاربری: " + r + t + cchk + ccom + cmes;
        w.Write("<div class=\"widget widget__user\">\n\r<div class=\"widget_header\">" + s + "</div></div>");
    }
    //protected override void OnInit(EventArgs e)
    //{
    //    if (!User.Identity.IsAuthenticated) Response.Redirect("Login.aspx");
    //    var pan = (Label)Master.FindControl("pan");
    //    pan.SetRenderMethodDelegate(Render);
    //    base.OnInit(e);
    //}

    protected void GetCaptcha(object sender, EventArgs e)
    {
        CaptchaImage1.ImageUrl = "icon/loading35.gif";
        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 75;
        CaptchaImage1.Text = imgcode;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        if (!User.Identity.IsAuthenticated) Response.Redirect("login.aspx");
        CaptchaImage1.Width = 270;
        CaptchaImage1.Height = 75;

        var imgcode = Data.GenerateRandomCode();
        CaptchaImage1.Text = imgcode;
        var user = User.Identity.Name;
        rpArchive.DataSource = Data.GetQAByUser(user).OrderByDescending(p => p.DateR);
        rpArchive.DataBind();

        rpCm.DataSource = Data.DB.spGetCommentUser(user);
        rpCm.DataBind();

        var tclub = Club.GetClub().Where(p => p.UserName.ToLower().Equals(user.ToLower()));
        btnToPrice.Visible = tclub.Any(p => p.Total.GetValueOrDefault(0) > 0);

        rpFirstchart.DataSource = tclub;
        rpFirstchart.DataBind();

        var stat = Club.GetClubUserStat(Membership.GetUser(user).ProviderUserKey.ToString()).OrderBy(p => p.SID);
        rpSecondchart.DataSource = stat.Take(1);
        rpSecondchart.DataBind();

        Guid pvkey = new Guid();
        pvkey = Guid.Parse(Membership.GetUser(user).ProviderUserKey.ToString());


        rpRec.DataSource = Data.UserSetting(user);
        rpRec.DataBind();

        if (!User.Identity.IsAuthenticated) Response.Redirect("Default.aspx");


        var log = new List<UserData>();
        var v = new UserData
        {
            Name = "نام کاربری",
            Value = user
        };
        log.Add(v);

        var r = "";
        r = User.IsInRole("Real") ? "حقیقی" : "حقوقی";
        if (User.IsInRole("Job"))
        {
            r = r + " همکار";
        }
        var v1 = new UserData
        {
            Name = "سطح کاربری",
            Value = r
        };
        log.Add(v1);
        var userid = Data.GetUserId(user);
        var cred = Data.GetUserCharge(userid);
        if (cred > 0)
        {
            var v2 = new UserData
            {
                Name = "اعتبار نقدی",
                Value = Data.PricePersian(cred.ToString())
            };
            log.Add(v2);
        }
        var poi = Data.DB.spGetClubUser(userid).Sum(p => p.Total);
        if (poi > 0)
        {
            var v3 = new UserData
            {
                Name = "میزان امتیاز",
                Value = Data.PricePersian(poi.ToString(), false)
            };
            log.Add(v3);
        }
        var od = Data.GetOrderList(User.Identity.Name);
        var check = od.Count(p => p.Status.Contains("حال"));
        var com = od.Count(p => p.Status.Contains("اتمام"));
        var cchk = "";
        if (check > 0)
        {
            var v4 = new UserData
            {
                Name = "فاکتورهای در انتظار",
                Value = check.ToString()
            };
            log.Add(v4);
        }
        var ccom = "";
        if (com > 0)
        {
            var v5 = new UserData
            {
                Name = "فاکتورهای تایید شده",
                Value = com.ToString()
            };
            log.Add(v5);
        }


        rpLogin.DataSource = log;
        rpLogin.DataBind();

        var plist = Data.DB.spGetPayList(User.Identity.Name);
        rpDetails.DataSource = plist;
        rpDetails.DataBind();

        var item = Data.GetOrderList(User.Identity.Name);
        gvList.DataSource = item;
        gvList.DataBind();
        var mes = SendMes.GetSendMes(User.Identity.Name).OrderByDescending(p => p.Id);
        GVMessage.DataSource = mes;
        GVMessage.DataBind();

        lblUser.InnerText = "کاربر گرامی " + User.Identity.Name + " خوش آمدید";
        lblUser.Attributes.Add("style", "padding-right:15px");
        var U = User.Identity.Name;
        var mem = Membership.GetUser(U);
        txtEmail.Text = mem.Email;
        txtFirst_Name.Text = Profile.Name;
        txtLastName.Text = Profile.Family;
        var member = Membership.GetUser(new Guid(userid.ToString()));
        var pr = Profile.GetProfile(mem.UserName);

        if (pr.GetPropertyValue("City").ToString().Length == 0)
        {
            sinfo.Visible = false;
            lblCompleteInfo.Visible = true;
            var key = Membership.GetUser(User.Identity.Name).ProviderUserKey.ToString();
            lblCompleteInfo.Text = string.Format("جهت تکمیل اطلاعات <a href='reg.aspx?user={0}' >کلیک</a> نمایید",key);
            
            //ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "infodiv('divinfo');", true);
        }
        else
        {
            lblCompleteInfo.Visible = false;
            sinfo.Visible = true;
            
        }

        if (Profile.Sex)
        {
            rblSex.SelectedIndex = 1;
        }
        else
        {
            rblSex.SelectedIndex = 0;
        }

        var news = "";

        if (Profile.News.Length > 0)
        {
            news = Profile.News;
        }
        else
        {
            news = "خیر";
        }
        rblNews.SelectedIndex = rblNews.Items.IndexOf(rblNews.Items.FindByText(news));
        List<State> s = new List<State>();
        s.Add(new State { State1 = "انتخاب نمایید", ID = 0 });
        s.AddRange(Data.StateQ().AsEnumerable());
        s.ForEach(p => dropState.Items.Add(new ListItem(p.State1.ToString(), p.ID.ToString())));
        dropState.SelectedIndex = dropState.Items.IndexOf(dropState.Items.FindByText(Profile.State));

        s.ForEach(p => dropStateAgent.Items.Add(new ListItem(p.State1.ToString(), p.ID.ToString())));
        dropStateAgent.SelectedIndex = dropStateAgent.Items.IndexOf(dropStateAgent.Items.FindByText(Profile.State));



        var SID = Convert.ToInt32(dropState.SelectedValue);
        var ct = Data.CityQ(SID).OrderBy(p => p.City1);

        List<City> c = new List<City>();
        c.Add(new City { SID = SID, ID = 0, City1 = "انتخاب نمایید" });
        c.AddRange(Data.CityQ(SID).OrderBy(p => p.City1).AsEnumerable());

        c.ForEach(p => dropCity.Items.Add(new ListItem(p.City1.ToString(), p.ID.ToString())));
        dropCity.SelectedIndex = dropCity.Items.IndexOf(dropCity.Items.FindByText(Profile.City));

        c.ForEach(p => dropCityAgent.Items.Add(new ListItem(p.City1.ToString(), p.ID.ToString())));
        dropCityAgent.SelectedIndex = dropCityAgent.Items.IndexOf(dropCityAgent.Items.FindByText(Profile.City));
        if (Profile.BirthDate.Length > 0)
        {
            var gd = Profile.BirthDate.ToString().Split("/".ToArray());
            var bd = new DateTime(Convert.ToInt32(gd[0]), Convert.ToInt32(gd[1]), Convert.ToInt32(gd[2]), new PersianCalendar());
            txtBirth.Text = bd.Year.ToString() + "/" + bd.Month.ToString("00") + "/" + bd.Day.ToString("00");
        }

        txtNational.Text = Profile.NationalCode;
        txtIdNo.Text = Profile.IdNo;
        txtMob.Text = Profile.Mobile;
        List<Meet> m = new List<Meet>();
        m.Add(new Meet { ID = 0, Meet1 = "انتخاب نمایید" });
        m.AddRange(Data.MeetQ().OrderBy(p => p.Meet1).AsEnumerable());
        m.Add(new Meet { ID = m.Count, Meet1 = "موارد دیگر" });
        m.ForEach(p => dropMeet.Items.Add(new ListItem { Text = p.Meet1.ToString(), Value = p.ID.ToString() }));
        if (m.Any(p => p.Meet1.Equals(Profile.Meet)))
        {
            dropMeet.SelectedIndex = dropMeet.Items.IndexOf(dropMeet.Items.FindByText(Profile.Meet));
        }
        else
        {
            dropMeet.SelectedIndex = dropMeet.Items.Count - 1;
            txtMeet.Text = Profile.Meet;
            secMeet.Attributes["class"] = "secMeet";
        }
        var edu = Data.EducationQ();
        List<Education> ed = new List<Education>();
        ed.Add(new Education { ID = 0, Education1 = "انتخاب نمایید" });
        ed.AddRange(edu.AsEnumerable());

        if (User.IsInRole("Legal"))
        {
            ed.ForEach(p => dropEduAgent.Items.Add(new ListItem(p.Education1.ToString(), p.ID.ToString())));

            if (Profile.Education.ToString().Length > 0)
            {
                dropEduAgent.SelectedIndex = dropEduAgent.Items.IndexOf(dropEduAgent.Items.FindByText(Profile.Education));
            }
            dropCorpType.SelectedIndex = dropCorpType.Items.IndexOf(dropCorpType.Items.FindByText(Profile.Legal.Type));
            txtCorpName.Text = Profile.Legal.CorpName;
            dropAct.SelectedIndex = dropAct.Items.IndexOf(dropAct.Items.FindByText(Profile.Legal.Activity));
            txtEcoCode.Text = Profile.Legal.EconomicCode;
            txtNatianId.Text = Profile.Legal.NationalId;
            txtCorpAddress.Text = Profile.Address;
            txtPCodeCorp.Text = Profile.PostalCode;
            txtTelCorp.Text = Profile.Tel;
            txtFaxCorp.Text = Profile.Fax;
            txtPosition.Text = Profile.Legal.Position;
            txtTelD.Text = Profile.Legal.DirectPhone;
            mvRole.SetActiveView(Legal);
        }
        else if (User.IsInRole("Real"))
        {
            txtAddress.Text = Profile.Address;
            txtPCode.Text = Profile.PostalCode;
            txtTel.Text = Profile.Tel;
            txtFax.Text = Profile.Fax;
            txtJob.Text = Profile.Real.Job;
            ed.ForEach(p => dropEducation.Items.Add(new ListItem(p.Education1.ToString(), p.ID.ToString())));
            dropEducation.Items.Add(new ListItem("انتخاب نمایید", "0"));

            if (Profile.Education.ToString().Length > 0)
            {
                dropEducation.SelectedIndex = dropEducation.Items.IndexOf(dropEducation.Items.FindByText(Profile.Education));
            }
            mvRole.SetActiveView(Real);

        }
    }

    protected void ToPrice(object sender, EventArgs e)
    {
        var user = Membership.GetUser().UserName.ToLower();
        var tclub = Club.GetClub().Where(p => p.UserName.ToLower().Equals(user));
        var point = Convert.ToSingle(tclub.First().Total.GetValueOrDefault(0));

        Club.ConvertPrice(user, point);
        tclub = Club.GetClub().Where(p => p.UserName.ToLower().Equals(user));
        btnToPrice.Visible = tclub.Any(p => p.Total.GetValueOrDefault(0) > 0);

        rpFirstchart.DataSource = tclub;
        rpFirstchart.DataBind();

        var stat = Club.GetClubUserStat(Membership.GetUser(user).ProviderUserKey.ToString()).OrderBy(p => p.SID);
        rpSecondchart.DataSource = stat.Take(1);
        rpSecondchart.DataBind();
    }

    protected void btnReq_Click(object sender, EventArgs e)
    {
        Label lblCat;
        CheckBox chkMob;
        CheckBox chkEmail;
        var Cat = "";
        var us = User.Identity.Name;
        var m = false;
        var em = false;
        foreach (RepeaterItem ri in rpRec.Items)
        {
            lblCat = (Label)ri.FindControl("lblCat");
            chkMob = (CheckBox)ri.FindControl("chkMob");
            chkEmail = (CheckBox)ri.FindControl("chkEmail");
            Cat = Server.HtmlEncode(lblCat.Text);
            m = chkMob.Checked;
            em = chkEmail.Checked;
            Data.UpdateUserSetting(us, Cat, em, m);

        }
    }

    protected void btnOrder_Click(object sender, EventArgs e)
    {

    }
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        var cap = Server.HtmlEncode(txtimgcode.Text.ToString().ToLower());
        lblInfo.Text = "";
        info.CssClass = "form-group";
        var Usr = User.Identity.Name.ToString();

        var mem = Membership.GetUser(Usr);
        var Email = Server.HtmlEncode(txtEmail.Text.ToString());
        var Pass = Server.HtmlEncode(txtPassowrd.Text.ToString());
        if (mem.Email != Email)
        {
            btnRegister.Attributes.Add("act", "2");

            if (mem.Email != Email && Membership.FindUsersByEmail(Email).Count > 0)
            {
                Message.MessageGen(lblInfo, "آدرس پست الکترونیکی مورد نظر وجود دارد", Color.Red);
            }
            else
            {
                mem.Email = Email;
                Membership.UpdateUser(mem);
                Message.MessageGen(lblInfo, "آدرس پست الکترونیکی تغییر یافت", Color.Green);

            }
            return;
        }
        if (Pass.Length > 0)
        {
            var Rpass = Server.HtmlEncode(txtRPassword.Text.ToString());
            if (Pass.Length > 0 && Membership.ValidateUser(Usr.ToLower(), Pass.ToLower()))
            {
                mem.ChangePassword(Pass, Rpass);
                Membership.UpdateUser(mem);
                //Message.MessageGen(lblPass, "رمز عبور تغییر یافت", Color.Green);
            }
            else if (Pass.Length > 0)
            {
                //   Message.MessageGen(lblPass, "رمز عبور معتبر نیست", Color.Red);
            }

            return;
        }

        var Name = Server.HtmlEncode(txtFirst_Name.Text.ToString());
        var Family = Server.HtmlEncode(txtLastName.Text.ToString());
        var Sex = true;
        if (rblSex.SelectedIndex == 1)
        {
            Sex = true;
        }
        else
        {
            Sex = false;
        }
        var Birth = Server.HtmlEncode(txtBirth.Text.ToString());

        var National = Server.HtmlEncode(txtNational.Text.ToString());
        var IdNo = Server.HtmlEncode(txtIdNo.Text.ToString());
        var Mobile = Server.HtmlEncode(txtMob.Text.ToString());
        var State = Server.HtmlEncode(dropState.SelectedItem.Text.ToString());
        var City = Server.HtmlEncode(dropCity.SelectedItem.Text.ToString());
        var Meet = Server.HtmlEncode(dropMeet.SelectedItem.Text.ToString());
        var News = Server.HtmlEncode(rblNews.SelectedItem.Text.ToString());
        Membership.UpdateUser(mem);
        Profile.SetPropertyValue("Name", Name);
        Profile.SetPropertyValue("Family", Family);
        Profile.SetPropertyValue("Sex", Sex);
        Profile.SetPropertyValue("BirthDate", Birth);
        Profile.SetPropertyValue("NationalCode", National);
        Profile.SetPropertyValue("IdNo", IdNo);
        Profile.SetPropertyValue("Mobile", Mobile);
        Profile.SetPropertyValue("State", State);
        Profile.SetPropertyValue("City", City);
        Profile.SetPropertyValue("Meet", Meet);
        Profile.SetPropertyValue("News", News);

        Membership.UpdateUser(mem);
        if (txtCorpName.Text.Length > 0) //l
        {
            var CorpType = Server.HtmlEncode(dropCorpType.SelectedItem.Text.ToString());
            var CorpName = Server.HtmlEncode(txtCorpName.Text.ToString());
            var Act = Server.HtmlEncode(dropAct.SelectedItem.Text.ToString());
            var EcoCode = Server.HtmlEncode(txtEcoCode.Text.ToString());
            var NationalID = Server.HtmlEncode(txtNatianId.Text.ToString());
            var CorpAddress = Server.HtmlEncode(txtCorpAddress.Text.ToString());
            var PCodeCorp = Server.HtmlEncode(txtPCodeCorp.Text.ToString());
            var CorpTel = Server.HtmlEncode(txtTelCorp.Text.ToString());

            var CorpFax = Server.HtmlEncode(txtFaxCorp.Text.ToString());
            var Position = Server.HtmlEncode(txtPosition.Text.ToString());
            var Education = Server.HtmlEncode(dropEduAgent.SelectedItem.Text.ToString());
            if (Education.Contains("انتخاب"))
            {
                Education = "";
            }
            var TelD = Server.HtmlEncode(txtTelD.Text.ToString());
            Profile.SetPropertyValue("Legal.Type", CorpType);
            Profile.SetPropertyValue("Legal.CorpName", CorpName);
            Profile.SetPropertyValue("Legal.Activity", Act);
            Profile.SetPropertyValue("Legal.EconomicCode", EcoCode);
            Profile.SetPropertyValue("Legal.NationalId", NationalID);
            Profile.SetPropertyValue("Address", CorpAddress);
            Profile.SetPropertyValue("PostalCode", PCodeCorp);
            Profile.SetPropertyValue("Tel", CorpTel);
            Profile.SetPropertyValue("Fax", CorpFax);
            Profile.SetPropertyValue("Education", Education);
            Profile.SetPropertyValue("Legal.Position", Position);
        }
        else //r
        {
            var Address = Server.HtmlEncode(txtAddress.Text.ToString());
            var PCode = Server.HtmlEncode(txtPCode.Text.ToString());
            var Tel = Server.HtmlEncode(txtTel.Text.ToString());
            var Fax = Server.HtmlEncode(txtFax.Text.ToString());
            var Job = Server.HtmlEncode(txtJob.Text.ToString());
            var Education = Server.HtmlEncode(dropEducation.SelectedItem.Text.ToString());
            if (Education.Contains("انتخاب"))
            {
                Education = "";
            }
            Profile.SetPropertyValue("Address", Address);
            Profile.SetPropertyValue("PostalCode", PCode);
            Profile.SetPropertyValue("Tel", Tel);
            Profile.SetPropertyValue("Fax", Fax);
            Profile.SetPropertyValue("Education", Education);
            Profile.SetPropertyValue("Real.Job", Job);
        }
        Profile.Save();

        //
    }

    protected void SelectedIndexChanged(object sender, EventArgs e)
    {
        var drop = (DropDownList)sender;
        var l = new System.Collections.Generic.List<ListItem>();
        l.Add(new ListItem("انتخاب نمایید", "0"));
        if (drop.SelectedIndex > 0)
        {
            var St = Convert.ToInt32(drop.SelectedValue.ToString());
            var city = Data.CityQ(St);
            foreach (City ct in city)
            {
                l.Add(new ListItem(ct.City1, ct.ID.ToString()));
            }
        }
        if (drop == dropState)
        {
            dropCity.Items.Clear();
            dropCity.Items.AddRange(l.ToArray());
        }
        else
        {
            dropCityAgent.Items.Clear();
            dropCityAgent.Items.AddRange(l.ToArray());
        }
    }

    protected void dropState_SelectedIndexChanged(object sender, EventArgs e)
    {
        dropCity.DataSource = Data.City(Convert.ToInt32(dropState.SelectedValue));
        dropCity.DataBind();
        //
    }
    protected void GVMessageRowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName.Equals("Remove"))
        {
            try
            {
                var Id = Convert.ToInt32(e.CommandArgument.ToString());
                var item = SendMes.GetSendMes().First(p => p.Id.Equals(Id));
                Data.DB.Sends.DeleteOnSubmit(item);
                Data.DB.SubmitChanges();
                Message.MessageGen(lblMes, "پیام مورد تظر حذف گردید", Color.Green);

                var mes = SendMes.GetSendMes(User.Identity.Name).OrderByDescending(p => p.Id);
                GVMessage.DataSource = mes;
                GVMessage.DataBind();
                mesdiv.Attributes["class"] = "media";

            }
            catch
            {
                Message.MessageGen(lblMes, "پیام حذف نگردید دوباره سعی نمایید", Color.Red);


            }
        }
    }

    public IList<UserData> GetDet()
    {
        UserData ud;
        List<UserData> det = new List<UserData>();
        var value = "";
        var item = Club.GetClubUserStat(Membership.GetUser().ProviderUserKey.ToString()).OrderBy(p => p.SID);
        foreach (spGetClubUserLResult stat in item)
        {
            value = stat.SID.Equals(11) ? stat.Sub.ToString() : stat.Value.ToString();
            ud = new UserData
            {
                Name = stat.Role,
                Value = value
            };
            det.Add(ud);
        }
        return det.ToList();
    }
    //protected void GvListRowCommand(object sender, GridViewCommandEventArgs e)
    //{
    //    try
    //    {
    //        switch (e.CommandName)
    //        {
    //            case "clear":
    //                DeleteRecord(e.CommandArgument.ToString());
    //                break;
    //        }
    //    }
    //    catch
    //    {

    //        Message.MessageGen(lblMes, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
    //    }
    //}
    //protected void DeleteRecord(string code)
    //{
    //    try
    //    {
    //        Message.EmptyMessage(lblMes);
    //        var WId = new Guid(code);
    //        var UId = new Guid(Membership.GetUser().ProviderUserKey.ToString());
    //        if (Data.DeleteWarrantyReg(WId, UId))
    //            Message.MessageGen(lblMes, "عملیات با موفقیت انجام شد", Color.Green);
    //        else
    //            Message.MessageGen(lblMes, "عملیات با موفقیت انجام نشد", Color.Red);


    //        var g = new Guid(Membership.GetUser().ProviderUserKey.ToString());
    //        var war = Data.GetWarranty(g).OrderByDescending(w => w.date);
    //        gvList.DataSource = war;
    //        gvList.DataBind();
    //    }
    //    catch
    //    {
    //        Message.MessageGen(lblMes, "سیستم دچار مشکل است .لطفا دوباره سعی کنید", Color.Red);
    //    }
    //}
    public static bool StateV(string Stat)
    {
        if (Stat.Length.Equals(0))
            return false;
        else
            return true;
    }
    protected void ViewStatus(object sender, EventArgs e)
    {
        var btnStatus = (LinkButton)sender;
        var Id = Convert.ToInt64(btnStatus.CommandArgument.ToString());
        var item = cart.GetState(Id).OrderByDescending(p => p.Id);
        gvStatus.DataSource = item;
        gvStatus.DataBind();
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "infodiv('divlist'),ShowState();", true);
    }

    protected void HideState(object sender, EventArgs e)
    {
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "infodiv('divlist'),HideState();", true);
    }
    protected void lnkCredit_Click(object sender, EventArgs e)
    {
        Response.Redirect("Credit.aspx");
    }
    protected void gvList_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        var item = Data.GetOrderList(User.Identity.Name);
        gvList.PageIndex = e.NewPageIndex;
        gvList.DataSource = item;
        gvList.DataBind();

    }
    //protected void reg_Click(object sender, EventArgs e)
    //{
    //   var key =  Membership.GetUser(User.Identity.Name).ProviderUserKey.ToString();
    //   Response.Redirect(string.Format("reg.aspx?user={0}",key.ToString()));
    //}
}