﻿using System;
using System.Drawing;
using System.Globalization;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Threading;
using CustomLabel;

public partial class DetailsProduct : System.Web.UI.Page
{
    Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Request.QueryString["Id"] == null)
        {

        }
        else
        {
            int id = 0;
            try
            {
                id = Convert.ToInt32(Request.QueryString["Id"].ToString());
            }
            catch (Exception)
            {
                return;
            }
            //Page.Title = Data.GetProduct().FirstOrDefault(p => p.Id.Equals(id)).Name;
            //Page.MetaKeywords = Data.GetProduct().FirstOrDefault(p => p.Id.Equals(id)).Keyword;
            //Page.Title = Data.GetProduct().FirstOrDefault(p => p.Id.Equals(id)).Description;
        }
    }
}