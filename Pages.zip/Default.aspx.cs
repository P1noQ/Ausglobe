﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{

    Data Data = new Data();
    private clsShoppingCart cart = new clsShoppingCart();
    clsCompare Comp = new clsCompare();
    db_atrDataContext db = new db_atrDataContext();

    protected void Page_Load(object sender, EventArgs e)
    {
        slideShow.DataSource = Data.GetSlideData();
        slideShow.DataBind();

        var Description = Data.GetDescription(1);
        litTitle.Text = Description.Title;

        //rpMatn.DataSource = Data.GetNews();
        //rpMatn.DataBind();

        rpCatImage.DataSource = Data.GetProductMenu().Where(p => p.Level.Equals(0)).OrderByDescending(p => p.Id).Take(3);
        rpCatImage.DataBind();

        rpSubCategories.DataSource = Data.GetProductMenu().Where(p => p.Level.Equals(1) && p.Image != ("def.jpg")).OrderByDescending(p => p.Id).Take(12);
        rpSubCategories.DataBind();

        //rpProductFeatured.DataSource = Data.GetProduct();
        //rpProductFeatured.DataBind();


    }
    public int? getPrice(int id)
    {
        var price = Data.DB.PColors.FirstOrDefault(p => p.PID.Equals(id));
        return price.Price;
    }
    public IList<spGetProductResult> GetSpecProduct(int Skip)
    {
        var res = Data.GetProduct().Where(p => p.Spec.GetValueOrDefault(false).Equals(true) && p.View.GetValueOrDefault(false).Equals(true)).Skip(Skip).Take(1).ToList();
        return res;
    }
    public IList<spGetProductResult> GetProductByCat(int Id)
    {
        return Data.GetProduct().Where(p => p.Level0.GetValueOrDefault(0).Equals(Id) && p.View.GetValueOrDefault(false).Equals(true)).Take(10).ToList();
    }
    protected void rpProduct_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("Addcart"))
        {

        }
    }

    protected void addwish_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        if (User.Identity.IsAuthenticated)
        {
            var uname = User.Identity.Name;
            Data.insertFav(uname, pid);

            var sabtsuc = "اضافه شد";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('" + sabtsuc + "'),GoCarosel();", true);

        }
        else
        {
            var erorrmes = " برای درج ابتدا باید ثبت نام کنید";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('" + erorrmes + "'),GoCarosel();", true);
        }
    }

    protected void adDataocompare_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;
        Comp.Add(Convert.ToInt32(AddCart.CommandArgument.ToString()));
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('به مقایسه اضافه شد'),GoCarosel();", true);
    }

    public string Max(int CID)
    {
        var cs = cart.SizeCount(CID);
        if (cs.HasValue)
        {
            return cs.ToString();
        }
        else
        {
            return "";
        }

    }

    protected void DrpSize_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (DrpSize.SelectedIndex != 0)
        {
            sid = Convert.ToInt32(DrpSize.SelectedValue);
            var bindcolor = Data.DB.PColors.Where(p => p.SID.Equals(sid) && p.PID.Equals(ViewState["PId"]));
            RpColor.DataSource = bindcolor;
            RpColor.DataBind();
            var getdetails = Data.DB.PSizes.FirstOrDefault(p => p.Id.Equals(sid)).Image;
            if (getdetails != null)
            {
                imgsize.ImageUrl = "admin/uploadimage/size/" + getdetails;
                imgsize.Visible = true;
            }
        }


    }
    protected void RpColor_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("addcolor"))
        {
            CLabel1.Save = e.CommandArgument.ToString();
            //var csid = Convert.ToInt32(DrpSize.SelectedValue);
            for (int i = 0; i < RpColor.Items.Count; i++)
            {
                var lnkcolor = (LinkButton)RpColor.Items[i].FindControl("lnkcolor");

                lnkcolor.CssClass = "";
                if (lnkcolor.CommandArgument == CLabel1.Save)
                {
                    lnkcolor.CssClass = "active";

                    var getdetails = Data.DB.PColors.FirstOrDefault(p => p.SID.Equals(sid) && p.Id.Equals(lnkcolor.CommandArgument));
                    var pid = getdetails.PID;
                    var pr = 0;
                    if (
                        Data.DB.spGetProductPrio()
                            .Any(
                                p =>
                                    p.Id.Equals(pid) && p.IsSale.GetValueOrDefault(false) && p.DateDis.HasValue &&
                                    p.DateDis.Value >= DateTime.Now))
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else if (getdetails.DateDis.HasValue && getdetails.DateDis.Value >= DateTime.Now)
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else
                        pr = getdetails.Price.GetValueOrDefault(0);


                    lblprice.Text = " قیمت " + Data.PricePersian(pr.ToString());
                    if (Data.IsAvailSize(pid, Convert.ToInt32(CLabel1.Save)))
                    {
                        lblprice.CssClass = "";
                        lnkaddtocart.Enabled = true;
                    }
                    else
                    {
                        lblprice.CssClass = "noavail";
                        lnkaddtocart.Enabled = false;
                    }
                }
            }
            UpdatePanel5.Update();
        }
    }
    static int sid = 0;
    static int cid = 0;
    static bool nocolorEx = false;
    protected void AddCart(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;
        pDrpSize.Visible = true;
        RpColor.Visible = true;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        var pname = Data.GetProduct(pid).First().Name.ToString();
        var ordid = cart.OrdId;
        var bindsize = Data.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (bindsize.Count() != 0)
        {
            DrpSize.Items.Clear();
            DrpSize.Items.Add(new ListItem("انتخاب نمایید", "0"));
            bindsize.ToList().ForEach(p => DrpSize.Items.Add(new ListItem(p.SizeName, p.Id.ToString())));
            ViewState["PId"] = pid;
            RpColor.DataBind();
            lblprice.Text = "";
            lblprice.CssClass = "";
            imgsize.ImageUrl = "";
            imgsize.Visible = false;
            lnkaddtocart.CommandArgument = pid.ToString();
            UpdatePanel5.Update();

        }
        var ProductSizes = Data.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (ProductSizes.Count() == 1)
        {
            var nosize = ProductSizes.FirstOrDefault();
            if (nosize.SizeName.Equals("بدون وزن"))
            {
                pDrpSize.Visible = false;
                sid = nosize.Id;
                var bindcolor = Data.DB.PColors.Where(p => p.SID.Equals(nosize.Id) && p.PID.Equals(ViewState["PId"]));
                RpColor.DataSource = bindcolor;
                RpColor.DataBind();
                imgsize.ImageUrl = "admin/uploadimage/size/" + nosize.Image;

                var Productcolors = Data.DB.PColors.Where(p => p.SID.Equals(nosize.Id) && p.PID.Equals(ViewState["PId"]));
                if (Productcolors.Count() == 1)
                {
                    var nocolor = Productcolors.FirstOrDefault();
                    if (nocolor.Name.Equals("بدون رنگ"))
                    {
                        RpColor.Visible = false;
                        CLabel1.Visible = false;
                        cid = nocolor.Id;


                        var getdetails = Data.DB.PColors.FirstOrDefault(p => p.SID.Equals(sid) && p.Id.Equals(cid));
                        var ppid = getdetails.PID;
                        var pr = 0;
                        if (
                            Data.DB.spGetProductPrio()
                                .Any(
                                    p =>
                                        p.Id.Equals(ppid) && p.IsSale.GetValueOrDefault(false) && p.DateDis.HasValue &&
                                        p.DateDis.Value >= DateTime.Now))
                            pr = getdetails.DisPrice.GetValueOrDefault(0);
                        else if (getdetails.DateDis.HasValue && getdetails.DateDis.Value >= DateTime.Now)
                            pr = getdetails.DisPrice.GetValueOrDefault(0);
                        else
                            pr = getdetails.Price.GetValueOrDefault(0);


                        lblprice.Text = " قیمت " + Data.PricePersian(pr.ToString());
                        if (Data.IsAvailSize(ppid, cid))
                        {
                            lblprice.CssClass = "";
                            lnkaddtocart.Enabled = true;
                        }
                        else
                        {
                            lblprice.CssClass = "noavail";
                            lnkaddtocart.Enabled = false;
                        }

                    }
                }
            }

        }
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loadpopup();", true);

    }
    protected void lnkaddtocart_Command(object sender, CommandEventArgs e)
    {
        if (User.IsInRole("Job"))
        {

        }

        var pid = Convert.ToInt32(lnkaddtocart.CommandArgument);

        var ProductSizes = Data.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (ProductSizes.Count() == 1)
        {
            var nosize = ProductSizes.FirstOrDefault();
            if (nosize.SizeName.Equals("بدون وزن"))
            {
                sid = nosize.Id;
                var Productcolors = Data.DB.PColors.Where(p => p.SID.Equals(sid) && p.PID.Equals(pid));
                if (Productcolors.Count() == 1)
                {
                    var nocolor = Productcolors.FirstOrDefault();
                    if (nocolor.Name.Equals("بدون رنگ"))
                    {
                        cid = nocolor.Id;
                    }
                    else
                    {
                        try
                        {
                            cid = Convert.ToInt32(CLabel1.Save);
                        }
                        catch
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ را انتخاب کنید')", true);
                            cid = 0;
                            sid = 0;
                            return;
                        }
                    }

                }
                else
                {
                    try
                    {
                        cid = Convert.ToInt32(CLabel1.Save);
                    }
                    catch
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ را انتخاب کنید')", true);
                        cid = 0;
                        sid = 0;
                        return;
                    }
                }
            }
            else
            {
                try
                {
                    sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
                    cid = Convert.ToInt32(CLabel1.Save);
                }
                catch
                {
                    if (sid == 0)
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert(' سایز را انتخاب کنید')", true);
                    else
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert(' رنگ را انتخاب کنید')", true);
                    cid = 0;
                    sid = 0;
                    return;
                }
            }
        }
        else
        {
            sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
            cid = Convert.ToInt32(CLabel1.Save);
        }

        //var sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
        //cid = Convert.ToInt32(CLabel1.Save);
        var ordid = cart.OrdId;
        var pname = Data.GetProduct(pid).First().Name.ToString();
        //if (!Data.IsAvailSize(pid, sid))
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "hidepopup(),loginerror('" + pname + " موجود نیست'),GoCarosel(),Addjust();", true);
        //    return;
        //}
        int count = Convert.ToInt32(txtCount.Text);
        var ins = cart.InsertShoppingCart(pid, sid, cid, count, ordid, User.IsInRole("Job"));

        var mes = "";
        if (ins.Equals(0))
        {
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),showbasket('" + pname + "'),benefite('" + bent + "'),GoCarosel(),Addjust();", true);

        }
        else
        {
            switch (ins)
            {
                case 2:
                    mes = "به علت عدم موجودی محصول " + pname + " حذف گردید";
                    break;
                case 3:
                    mes = "امکان درج بیشتر محصول " + pname + " وجود ندارد";
                    break;
                case 4:
                    mes = "محصول " + pname + " موجود نیست";
                    break;

            }
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            if (sid == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('سایز را انتخاب کنید')", true);
                cid = 0;
                sid = 0;
                return;
            }
            if (sid != 0 && lblprice.Text == "" || nocolorEx)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ را انتخاب کنید')", true);
                cid = 0;
                sid = 0;
                return;
            }
            if (sid == 0 && lblprice.Text == "")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ یا سایز را انتخاب کنید')", true);
                cid = 0;
                sid = 0;
                return;
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),loginerror('" + mes + "'),GoCarosel(),benefite('" + bent + "'),Addjust();", true);

        }
        cid = 0;
        sid = 0;
    }

    protected void AddtoCart_Click(object sender, EventArgs e)
    {

    }
}