﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ChargeReport : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        Guid pvkey = new Guid();
        if (IsPostBack) return;
        if (User.Identity.IsAuthenticated)
        {
            pvkey = Guid.Parse(Membership.GetUser(Page.User.Identity.Name).ProviderUserKey.ToString());
            BindGird(pvkey);
        
        }


    }

    private void BindGird(Guid UserID)
    {
        var item = dt.DB.UserGiftCards.Where(p => p.UserId.Equals(UserID));
        if (item!=null && item.Count() > 0)
            gvCharge.DataSource = item;
        gvCharge.DataBind();    
    }

    protected void gvCharge_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        var item = dt.DB.UserGiftCards;
        gvCharge.DataSource = item;
        gvCharge.PageIndex = e.NewPageIndex;
        gvCharge.DataBind();
    }
}