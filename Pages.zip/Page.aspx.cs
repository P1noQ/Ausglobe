﻿using System;
using System.Linq;

public partial class Pages : System.Web.UI.Page
{
    public Data dt = new Data();

    protected void Page_Load(object sender, EventArgs e)
    {
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;

        var info = dt.DB.Pages.FirstOrDefault(p => p.Id.Equals(id));
        if (info == null) return;
        Page.Title = info.Title;
        Page.MetaDescription = info.Title;
        Page.MetaKeywords = info.Title;
        lblTitle.Text = info.Title;
        lblMain.InnerHtml = info.Body;
    }
}