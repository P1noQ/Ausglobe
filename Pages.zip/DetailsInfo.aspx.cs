﻿using System;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DetailsInfo : Page
{
    public clsShoppingCart Lib = new clsShoppingCart();

    protected void Page_Load(object sender, EventArgs e)
    {
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
        HiddenField1.Value = new ClsBase().UserId().ToString();
        HiddenField2.Value = id.ToString(CultureInfo.InvariantCulture);
        var pro = Lib.SelectInfo().FirstOrDefault(p => p.id.Equals(id));
        if (pro == null) return;
        pro.visite++;
        Lib.Db.SubmitChanges();
        lblLike.Text = string.IsNullOrEmpty(pro.other) ? "0" : pro.other;
        lblTitle.Text = pro.title;
        lblBreif.Text = pro.breif;
        ltrMain.Text = pro.main;
        ltrVisite.Text = pro.visite.ToString(CultureInfo.InvariantCulture);
        bigpic.Src = string.Format("upload/info/{0}", pro.image);
        bigpic.Alt = string.Format("upload/info/{0}", pro.image);
        Page.Title = pro.title;
        Page.MetaDescription = pro.title;
        Page.MetaKeywords = pro.title;
        if (Page.IsPostBack) return;
        ViewState["like"] = false;
        LoadData();
    }

    private void LoadData()
    {
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
        var dv = Lib.SelectCommentInfo().Where(p => p.infoId.Equals(id) && p.active);
        var pgitems = new PagedDataSource
        {
            DataSource = dv.ToList(),
            AllowPaging = true,
            PageSize = 6,
            CurrentPageIndex = PageNumber
        };
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (var i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
            rptPages.Visible = false;
        rpComment.DataSource = pgitems;
        rpComment.DataBind();
    }

    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }

    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        LoadData();
    }

    protected void BtnSendClick(object sender, EventArgs e)
    {
        int x;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out x)) return;

        if (Comments.CommentInfo(x))
        {
            Panel3.Visible = true;
            lblMessage3.Text = "شما قبلا نظر خودرا برای این محصول ارسال نموده اید";
            lblMessage3.ForeColor = Color.Red;
        }
        else
        {
            var error = string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtEmail.Text) ||
                        string.IsNullOrEmpty(txtMessage.Text) || string.IsNullOrEmpty(txtsubject.Text);
            if (error)
            {
                Panel2.Visible = false;
                Panel3.Visible = false;
                Panel4.Visible = true;
                lblMessage4.Text = "لطفا در تکمیل کردن فرم دقت کنید";
                lblMessage4.ForeColor = Color.Red;
                return;
            }
            try
            {
                var ntable = new tblCommentInfo
                {
                    fullName = Server.HtmlEncode(txtName.Text),
                    subject = Server.HtmlEncode(txtsubject.Text),
                    mail = Server.HtmlEncode(txtEmail.Text),
                    message = Server.HtmlEncode(txtMessage.Text),
                    active = false,
                    date = DateTime.Now,
                    infoId = x,
                    userId = Page.User.Identity.IsAuthenticated ? new ClsBase().UserId() : (Guid?)null
                };
                Lib.Db.tblCommentInfos.InsertOnSubmit(ntable);
                Lib.Db.SubmitChanges();
                Panel4.Visible = false;
                Panel2.Visible = true;
                lblMessage2.Text = "نظر شما با موفقیت ارسال شد";
                lblMessage2.ForeColor = Color.Green;
                pnl.Visible = false;
                btnResend.Visible = true;
            }
            catch (Exception)
            {
                Panel2.Visible = false;
                Panel5.Visible = true;
                lblMessage5.Text = "متاسفانه ارسال نظر با مشکل موجه شد";
                lblMessage5.ForeColor = Color.Red;
                pnl.Visible = false;
                btnResend.Visible = true;
                return;
            }
            Panel5.Visible = false;
            Panel2.Visible = true;
            lblMessage2.Text = "نظر شما ارسال شد";
            lblMessage2.ForeColor = Color.Green;
        }
    }

    protected void BtnResendClick(object sender, EventArgs e)
    {
        pnl.Visible = true;
        txtMessage.Text = "";
        txtEmail.Text = "";
        txtName.Text = "";
        txtsubject.Text = "";
        Panel2.Visible = false;
        btnResend.Visible = false;
    }

    [System.Web.Services.WebMethod]
    public static void Sharing(Guid us, string id)
    {
        try
        {
            if (string.IsNullOrEmpty(us.ToString()) || string.IsNullOrEmpty(id)) return;

            var clsLib = new Library();
            var user = clsLib.SelectVwInfoUser().FirstOrDefault(p => p.UserId.Equals(us));
            if (user == null) return;
            int pId;
            if (!int.TryParse(id, out pId)) return;
            var info = clsLib.SelectInfo().FirstOrDefault(p => p.id.Equals(pId));
            if (info == null) return;
            if (clsLib.SelectInfoShare().Any(p => p.infoId.Equals(info.id) && p.userId.Equals(user.UserId))) return;
            if (clsLib.SelectInfoShare().Count(p => p.date.Equals(DateTime.Now.Date) && p.userId.Equals(user.UserId)) > 3) return;
            var share = new tblInfoShare
            {
                userId = user.UserId,
                infoId = info.id,
                date = DateTime.Now
            };
            clsLib.Db.tblInfoShares.InsertOnSubmit(share);
            clsLib.Db.SubmitChanges();
        }
        catch (Exception)
        {
            return;
        }
    }

    protected void BtnLike_Click(object sender, EventArgs e)
    {
        if (ViewState["like"].Equals(true)) return;
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
        var pro = Lib.SelectInfo().FirstOrDefault(p => p.id.Equals(id));
        if (pro == null) return;
        int like;
        int.TryParse(pro.other, out like);
        like++;
        ViewState["like"] = true;
        pro.other = like.ToString(CultureInfo.InvariantCulture);
        lblLike.Text = like.ToString(CultureInfo.InvariantCulture);
        Lib.Db.SubmitChanges();
    }
}