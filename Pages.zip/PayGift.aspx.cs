﻿using ir.shaparak.sep;
using  com.samanepay.acquirer;
using System;
using System.Configuration;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Web.UI;
using System.Web.UI.WebControls;
using Microsoft.SqlServer;
using System.Web.UI;

public partial class PayGift1 : System.Web.UI.Page
{
    public static readonly string PgwSite = ConfigurationManager.AppSettings["PgwSite"];
    public static readonly string CallBackUrl = ConfigurationManager.AppSettings["CallBackUrl"];
    public static readonly string TerminalId = ConfigurationManager.AppSettings["TerminalId"];
    public static readonly string UserName = ConfigurationManager.AppSettings["UserName"];
    public static readonly string UserPassword = ConfigurationManager.AppSettings["UserPassword"];
    public static readonly string MID = "10347028";
    public static long CodeTracking;
    public static string Date;
    public static string Time;
    public static string RefId = "";

    Data Lib = new Data();
    clsShoppingCart cart=new clsShoppingCart();

    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (IsPostBack) return;

        ViewProvince();
        ViewFristCity();
        SetDefaultDateTime();
            
        
        if (Session["CodeTracking"] == null || !User.Identity.IsAuthenticated)
        {
            ErrorMessage(" خطا در  نحوه ورود به صفحه پرداخت لطفا از کنترل پنل کاربری خود برای پرداخت استفاده نمایید",
                Color.Red);
            Session.Remove("CodeTracking");
            return;
        }
        CodeTracking = long.Parse(Session["CodeTracking"].ToString());
        var typePay = Lib.GetOrderList("",true).FirstOrDefault(p => p.Id == CodeTracking);
        var Gifttype = Lib.DB.Orders.FirstOrDefault(p => p.Id.Equals(CodeTracking));
        var selectpay = "";
        if (typePay==null && Gifttype!=null)
        {
            selectpay = Gifttype.TypePay;
        }
        else if (typePay != null && Gifttype == null)
        {
            selectpay = typePay.Pay;
        }
        if (typePay == null && Gifttype == null)
        {
            ErrorMessage("کد پیگیری با این شماره موجود نمی باشد لطفا با مدیریت سایت تماس بگیرید", Color.Red);
            Session.Remove("CodeTracking");
        }
        else
        {
            cart.GetCode(CodeTracking);
            switch (selectpay)
            {
                case "کارت به کارت":
                {
                    MultiViewPay.SetActiveView(ViewCardPay);
                    lblCodeTracking.Text = CodeTracking.ToString(CultureInfo.InvariantCulture);
                    break;
                }
                case "پرداخت در محل":
                {
                    MultiViewPay.SetActiveView(ViewLocal);
                    lblCodeTracking.Text = CodeTracking.ToString(CultureInfo.InvariantCulture);
                    break;
                }
                case "آنلاین":
                {
                    MultiViewPay.SetActiveView(ViewOnline);
                    lblCodeTracking.Text = CodeTracking.ToString(CultureInfo.InvariantCulture);
                    break;
                }
                case "هدیه":
                {
                    MultiViewPay.SetActiveView(ViewGift);
                    lblCodeTracking.Text = CodeTracking.ToString(CultureInfo.InvariantCulture);

                    ViewGiftImg();
                    ViewPostCardImg();
                    break;
                }
                case "کسر از اعتبار":
                    if (Session["ChargeReduce"] != null)
                    {
                        parag.Visible = false;
                        lblCodeTracking.Text = CodeTracking.ToString(CultureInfo.InvariantCulture);
                        Session.Remove("ChargeReduce");
                        Data dt = new Data();
                        var item = dt.DB.Orders.FirstOrDefault(p => p.Id.Equals(CodeTracking));
                        if (item != null)
                        {
                            item.Status = "به اتمام رسیده";
                            item.Lock = true;
                            dt.DB.SubmitChanges();
                            dt.DB.spInsertScore(14, item.UserId, 1);
                        }
                        Message.MessageGen(lblMessage, "خرید با موفقیت انجام شد از بخش فروش با شما تماس خواهد گرفته شد.",
                            Color.Green);

                    }
                    else
                    {
                        ViewCredit();
                    }
                    break;
                default:
                {
                    

                    ErrorMessage("ثبت درخواست شما درسیستم نادرست درج شده است لطفا دوباره درخواست خود را ثبت نمایید",
                        Color.Red);
                    break;
                }
            }
        }
    }

    private static void SetDefaultDateTime()
    {
        Date = DateTime.Now.Year.ToString(CultureInfo.InvariantCulture) + DateTime.Now.Month.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0') + DateTime.Now.Day.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0');
        Time = DateTime.Now.Hour.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0') + DateTime.Now.Minute.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0') + DateTime.Now.Second.ToString(CultureInfo.InvariantCulture).PadLeft(2, '0');
    }

    protected void BtnLocalClick(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(CodeTracking.ToString(CultureInfo.InvariantCulture)))
        {
            ErrorMessage("به علت تغییر در انجام عملیات ثبت کد پیگیری شما لغو شده است لطفا از کنترل پنل کاربری خود دوباره برای ثبت درخواست خود اقدام نمایید", Color.Red);
            MultiViewPay.SetActiveView(ViewLocal);
            return;
        }
        var local = new PayPlace
        {
           OId= CodeTracking,
            description = Server.HtmlEncode(txtDescriptionsLocal.Text),
            date = DateTime.Now
        };
        var factor = Lib.GetOrderList("", true).FirstOrDefault(p => p.Id == CodeTracking);
        var Gifttype = Lib.DB.Orders.FirstOrDefault(p => p.Id.Equals(CodeTracking));
        bool finishtype =false;
        if (factor == null && Gifttype != null)
        {
            finishtype = Gifttype.Finish;
        }
        else if (factor != null && Gifttype == null)
        {
            finishtype = factor.Finish;
        }
        if (factor != null || Gifttype!=null)
        {
            if (finishtype==true)
            {
                ErrorMessage("پرداخت برای درخواست توسط شما ثبت شده است در صورت بروز مشکل در روال کاری با قسمت فروش تماس بگیرید با تشکر", Color.Red);
                return;
            }
            if (factor != null && Gifttype == null)
            {
                factor.Finish = true; 
            }
            else if (factor == null && Gifttype != null)
            {
                Gifttype.Finish = true;
            }
            Lib.DB.PayPlaces.InsertOnSubmit(local);
            Lib.DB.SubmitChanges();
            Session.Remove("CodeTracking");
            ErrorMessage("درخواست سبد خرید شما در سیستم ثبت شد کاربر گرامی بعد از بررسی قسمت فروش با شما تماس گرفته خواهد شد", Color.Green);
            MultiViewPay.SetActiveView(ViewEndPay);
        }
        else
        {
            ErrorMessage("کد پیگیری با این شماره موجود نمی باشد لطفا با مدیریت سایت تماس بگیرید", Color.Red);
            MultiViewPay.SetActiveView(ViewLocal);
        }
    }

    protected void BtnCartPayClick(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(CodeTracking.ToString(CultureInfo.InvariantCulture)))
        {
            ErrorMessage(" خطا در  نحوه ورود به صفحه پرداخت لطفا از کنترل پنل کاربری خود برای پرداخت استفاده نمایید", Color.Red);
            MultiViewPay.SetActiveView(ViewCardPay);
            return;
        }
        var dt= DateTime.Now;
        var cardPay = new PayCard
        {
            BankName = Server.HtmlEncode(txtNameBank.Text),
            Card4 = Server.HtmlEncode(txtCard4.Text),
            Price = long.Parse(txtPrice.Text),
            CodeFish = Server.HtmlEncode(txtCodeFish.Text),
            Description = Server.HtmlEncode(txtDescriptionsCardPay.Text),
            Date = dt,
            OId = CodeTracking
        };
        var factor = Lib.GetOrderList("", true).FirstOrDefault(p => p.Id == CodeTracking);
        var Gifttype = Lib.DB.Orders.FirstOrDefault(p => p.Id.Equals(CodeTracking));
        bool finishtype = false;
        if (factor == null && Gifttype != null)
        {
            finishtype = Gifttype.Finish;
        }
        else if (factor != null && Gifttype == null)
        {
            finishtype = factor.Finish;
        }
        if (factor != null || Gifttype != null)
        {
            if (finishtype == true)
            {
                ErrorMessage("پرداخت برای درخواست توسط شما ثبت شده است در صورت بروز مشکل در روال کاری با قسمت فروش تماس بگیرید با تشکر", Color.Red);
                return;
            }
            if (factor != null && Gifttype == null)
            {
                factor.Finish = true;
            }
            else if (factor == null && Gifttype != null)
            {
                Gifttype.Finish = true;
            }
            Lib.DB.PayCards.InsertOnSubmit(cardPay);
            Lib.DB.SubmitChanges();
            Session.Remove("CodeTracking");
            ErrorMessage("درخواست سبد خرید شما در سیستم ثبت شد کاربر گرامی بعد از بررسی قسمت فروش با شما تماس گرفته خواهد شد", Color.Green);
            MultiViewPay.SetActiveView(ViewEndPay);
        }
        else
        {
            ErrorMessage("کد پیگیری با این شماره موجود نمی باشد لطفا با مدیریت سایت تماس بگیرید", Color.Red);
            MultiViewPay.SetActiveView(ViewCardPay);
        }
    }

    private void ErrorMessage(string message, Color color)
    {
        lblMessage.ForeColor = color;
        lblMessage.Text = message;
    }

    protected void ImageButtonGiftClick(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (string.IsNullOrEmpty(CodeTracking.ToString(CultureInfo.InvariantCulture)))
            {
                ErrorMessage(" خطا در  نحوه ورود به صفحه پرداخت لطفا از کنترل پنل کاربری خود برای پرداخت استفاده نمایید", Color.Red);
                MultiViewPay.SetActiveView(ViewGift);
                return;
            }
            var giftPay = new PayGift
            {
                bankName = Server.HtmlEncode(txtNameBankGift.Text),
                card4 = Server.HtmlEncode(txtCard4Gift.Text),
                price = long.Parse(txtPriceGift.Text),
                codeFish = Server.HtmlEncode(txtCodeFishGift.Text),
                orderId = CodeTracking,
                description = Server.HtmlEncode(txtDescriptionGift.Text),
                address = Server.HtmlEncode(txtaddressGift.Text),
                text = Server.HtmlEncode(txtText.Text),
                cityId = int.Parse(ddlCity.SelectedValue),
                tel = txtTelGift.Text,
                date = DateTime.Now
            };
            var factor = Lib.DB.Orders.FirstOrDefault(p => p.Id == CodeTracking);

            if (factor != null)
            {
                if (factor.Finish)
                {
                    ErrorMessage("پرداخت برای درخواست توسط شما ثبت شده است در صورت بروز مشکل در روال کاری با قسمت فروش تماس بگیرید با تشکر", Color.Red);
                    return;
                }
                factor.Finish = true;
                Lib.DB.SubmitChanges();
                Lib.DB.PayGifts.InsertOnSubmit(giftPay);
                Lib.DB.SubmitChanges();
                Session.Remove("CodeTracking");
                ErrorMessage("درخواست سبد خرید شما در سیستم ثبت شد کاربر گرامی بعد از بررسی قسمت فروش با شما تماس گرفته خواهد شد", Color.Green);
                MultiViewPay.SetActiveView(ViewEndPay);
            }
            else
            {
                ErrorMessage("کد پیگیری با این شماره موجود نمی باشد لطفا با مدیریت سایت تماس بگیرید", Color.Red);
                MultiViewPay.SetActiveView(ViewCardPay);
            }
        }
        catch
        {
            ErrorMessage("خطا در ثبت اطلاعات لطفا از طرق کنترل پنل کاربری خود از قسمت سفارشات اقدام به ثبت نهایی  نمایید ", Color.Red);
        }
    }

    public void ViewCredit()
    {
        lblCodeTracking.Text = CodeTracking.ToString(CultureInfo.InvariantCulture);
        var order = Lib.DB.Orders.FirstOrDefault(p => p.Id == CodeTracking);
        if (order == null)
        {
            ErrorMessage("کد پیگیری با این شماره موجود نمی باشد لطفا با مدیریت سایت تماس بگیرید", Color.Red);
        }
        //check in request for codetracking for state tb_factor
        if (order.Finish)
        {
            Session.Remove("CodeTracking");
            ErrorMessage("درخواست سبد خرید شما در سیستم ثبت شد کاربر گرامی بعد از بررسی قسمت فروش با شما تماس گرفته خواهد شد", Color.Green);
            MultiViewPay.SetActiveView(ViewEndPay);
        }
        else
        {
            MultiViewPay.SetActiveView(ViewOnline);
        }
    }

    public void ViewGiftImg()
    {

        var gift = Lib.DB.Gifts.ToList().AsQueryable();
        var i = 0;
        foreach (var g in gift)
        {
            var item = new ListItem("<img class='csGiftListImg' style='width:76px;' src='" + "upload/info/thumb/" + g.Image + "' /><img src='App_Themes/css/shoping/img/paper_select.png' class='csSelect' />", g.id.ToString(CultureInfo.InvariantCulture))
            {
                Selected = i.Equals(0)
            };
            i++;
            RadioButtonListGift.Items.Add(item);
            RadioButtonListGift.CellPadding = 5;
            RadioButtonListGift.CellSpacing = 5;
        }
    }

    public void ViewPostCardImg()
    {
        var gift = Lib.GetPost();
        int i = 0;
        foreach (var g in gift)
        {
            var item = new ListItem("<img src='" + "upload/info/thumb/" + g.Image + "' />", g.Id.ToString(CultureInfo.InvariantCulture));
            item.Selected = i.Equals(0);
            i++;
            RadioButtonListPostCard.Items.Add(item);
            RadioButtonListPostCard.CellPadding = 5;
            RadioButtonListPostCard.CellSpacing = 5;
        }
    }

    public void ViewProvince()
    {
        ddlProvince.DataSource = Lib.StateQ().OrderBy(p => p.State1);
        ddlProvince.DataBind();
    }

    public void ViewFristCity()
    {

        var province = Lib.StateQ().OrderBy(p => p.State1).FirstOrDefault();
        var city = Lib.SelectCity().Where(p => p.SID.Equals(province.ID));
        ddlCity.DataSource = city;
        ddlCity.DataBind();
    }

    private void BypassCertificateError()
    {
        ServicePointManager.ServerCertificateValidationCallback +=
            delegate(
                Object sender1,
                X509Certificate certificate,
                X509Chain chain,
                SslPolicyErrors sslPolicyErrors)
            {
                return true;
            };
    }
    protected void DdlProvinceSelectedIndexChanged(object sender, EventArgs e)
    {
        var city = Lib.SelectCity().OrderBy(q => q.City1).Where(p => p.SID.Equals(int.Parse(ddlProvince.SelectedValue)));
        ddlCity.DataSource = city.ToList();
        ddlCity.DataBind();
    }

    protected void BtnOnlinePayClick(object sender, EventArgs e)
    {
        try
        {
            //chack if codeTracking

            if (string.IsNullOrEmpty(CodeTracking.ToString(CultureInfo.InvariantCulture)))
            {
                ErrorMessage(
                    " خطا در  نحوه ورود به صفحه پرداخت لطفا از کنترل پنل کاربری خود برای پرداخت استفاده نمایید",
                    Color.Red);
                MultiViewPay.SetActiveView(ViewOnline);
                return;
            }
            //found code tracking in tb_factor
            var order = Lib.DB.Orders.FirstOrDefault(p => p.Id == CodeTracking);
            if (order == null)
            {
                ErrorMessage("کد پیگیری با این شماره موجود نمی باشد لطفا با مدیریت سایت تماس بگیرید", Color.Red);
                return;
            }

            //check in request for codetracking for state tb_factor
            if (order.Finish)
            {
                ErrorMessage(
                    "پرداخت برای درخواست توسط شما ثبت شده است در صورت بروز مشکل در روال کاری با قسمت فروش تماس بگیرید با تشکر",
                    Color.Red);
                return;
            }
            //create record online request
            var online = new PayOnline
            {
                orderId = order.Id,
                resCode = -1,
                state = false,
                date = DateTime.Now
            };
            Lib.DB.PayOnlines.InsertOnSubmit(online);
            Lib.DB.SubmitChanges();
            var idOnline = online.id.ToString(CultureInfo.InvariantCulture);
            long price = order.Price.GetValueOrDefault(0);

            var tbCarts = Lib.DB.OrderDetails.Where(p => p.OId.Equals(online.orderId));
            if (tbCarts.Any())
            {
                var address =
                    Lib.SelectAddress(User.Identity.Name, "/").FirstOrDefault(p => p.UserId.Equals(order.UserId));
                var post = Lib.GetPost().FirstOrDefault(p => p.Id == order.PostId);
                var tp = tbCarts.Sum(p => p.Price*p.Count);


                var pricePost = 0;
                var city = Lib.SelectCity().FirstOrDefault(p => p.ID.Equals(address.CityId));
                var province = Lib.SelectCity().Any(p => p.ID.Equals(city.SID) && p.City1.Contains("تهران"));
                if (post != null && (province && post.Id.Equals(1)))
                {
                    pricePost = post.priceFree > tp ? post.Price : 0;
                }
                else
                {
                    if (post != null) pricePost = post.Price;
                }

                price = Int64.Parse(((((100 - order.discount)*tp)/100) + pricePost).ToString());

                if (order.Cash.HasValue)
                {
                    price = price - order.Cash.Value;
                }

            }
            // send request for bank
            // send request for bank
            BypassCertificateError();
            var init = new ir.shaparak.sep.PaymentIFBinding();
        var refNum = init.RequestToken("10347028", CodeTracking.ToString(), price, 0, 0, 0, 0, 0, 0, "", "", 0);
            if (refNum.Substring(0, 1).Equals("-"))
            {
                ErrorMessage(refNum, Color.Red);
                return;
            }
            //PayOutputLabel.Text = result;
            //ErrorMessage("در حال اتصال به بانک", Color.Green);
            // ClientScript.RegisterStartupScript(typeof (Page), "ClientScript",
            //        string.Format("<script language='javascript' type='text/javascript'> postRefId({0},{1});</script> ",price,CodeTracking)
            //           , false);

            //save info bank in database to tb_online recorde refID and resCode
            var saveRefid = Lib.DB.PayOnlines.FirstOrDefault(p => p.id == Int64.Parse(idOnline));
            if (saveRefid != null)
            {
                saveRefid.refId = refNum;
                saveRefid.resCode = 1;
                Lib.DB.SubmitChanges();


                //Redirect send page bank saman if refNum.Substring(0, 1) != "-"
                if (refNum.Substring(0, 1) != "-")
                    ClientScript.RegisterStartupScript(typeof (Page), "ClientScript",
                      string.Format("<script language='javascript' type='text/javascript'> postRefId({0},{1});</script> ",price,CodeTracking)
                        , false);

                else
                {
                    ErrorMessage("خطا در عملیات بانکی لطفا دوباره سعی نمایید", Color.Red);
                }
            }
        
        }
        catch (Exception ex)
        {

            //Error in request pay of bank
            ErrorMessage("خطا در عملیات بانکی لطفا دوباره سعی نمایید", Color.Red);
            //PayOutputLabel.Text = "Error: " + exp.Message;
        }
    }
}