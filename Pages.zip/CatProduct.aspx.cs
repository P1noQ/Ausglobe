﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Threading;
using System.Text;
using System.Security.Cryptography;

public partial class CatProduct : System.Web.UI.Page
{
    public Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        rpDDMBrand.DataSource = Data.GetBrand();
        rpDDMBrand.DataBind();
        if (Request.QueryString["Id"] == null)
        {
            litTitle.Text = "Categories";
            litNextPage.Text = "All Categories";
            litSubCat.Text = "Categories";
            rpSubCat.DataSource = Data.DB.spGetCatProduct().Where(p => p.Level.Equals(0));
            rpSubCat.DataBind();
            divDisplay.Style.Add("display", "none");
        }
        else
        {
            int catId = 0;
            try
            {
                catId = Convert.ToInt32(Request.QueryString["Id"].ToString());
            }
            catch (Exception)
            {
                return;
            }
            var firstData = Data.DB.catComments.FirstOrDefault(p => p.catId.Equals(catId));
            var secondData = Data.DB.catComments.Where(p => p.catId.Equals(catId));
            var catData = Data.DB.spGetCatProduct().FirstOrDefault(p => p.Id.Equals(catId));
            try
            {
                //ltFirstData.Text = firstData.comment;

                rpPDF.DataSource = secondData;
                rpPDF.DataBind();
            }
            catch(Exception ex)
            {

            }
            litTitle.Text = catData.Name;
            litNextPage.Text = catData.Name;
            litSubCat.Text = catData.Name;
            rpSubCat.DataSource = Data.DB.spGetCatProduct().Where(p => p.LEVEL0.Equals(catData.Name));
            rpSubCat.DataBind();
            var product = Data.GetProduct().Where(p => p.Cat.Equals(catId));
            if (product.Count() == 0)
            {
                divDisplay.Style.Add("display", "none");
            }
            else
            {
                rpProduct.DataSource = product;
                rpProduct.DataBind();
            }
        }
    }
    public string GetCatName(int Id)
    {
        return Data.GetProductMenu().FirstOrDefault(p => p.Id.Equals(Id)).Name;
    }
    protected void lbBrand_Click(object sender, EventArgs e)
    {

    }

    protected void AddtoCart_Click(object sender, EventArgs e)
    {

    }
}