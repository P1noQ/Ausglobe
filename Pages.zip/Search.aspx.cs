﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections.Generic;

public partial class Search : System.Web.UI.Page
{
    public clsShoppingCart cart = new clsShoppingCart();
    public Data dt = new Data();
    public clsCompare Comp = new clsCompare();
    static string RootCats = "";
    static string Brands = "";
    static string ProductAttrs = "";
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;

        var maxp = dt.MaxPrice().ToString();
        var maxa = dt.MaxAge().ToString();
        sc.InnerHtml = sc.InnerHtml.Replace("PMAX", maxp);
        sc.InnerHtml = sc.InnerHtml.Replace("AMAX", maxa);
        lblPrice_Rang.Text = "0 -" + maxp;
        lblAge_Range.Text = "0 -" + maxa;
        Price_max.Text = maxp;
        Age_max.Text = maxa;
        cart.AddList();
        Comp.AddCompare();

        var Menu0 = dt.GetProductMenu().Where(p => p.Level.Equals(0)).ToList();
        chkLev0.DataSource = Menu0;
        chkLev0.DataBind();
        //var Menu1 = dt.GetProductMenu().Where(p => p.Level.Equals(1)).ToList();
        chkLev1.DataSource = dt.GetBrand().ToList();
        chkLev1.DataBind();
        var at = dt.GetCatAttr(null);
        rpAttr.DataSource = at;
        rpAttr.DataBind();


        if (Session["AdvSearch"] != null)
        {
            rpSearch.DataSource = null;
            rpSearch.DataBind();
            List<string> Params = (List<string>)Session["AdvSearch"];

            string RootCats2 = Params[0];
            string Brands2 = Params[1];
            string ProductAttrs2 = Params[2];
            string MaxPrice = Params[3];
            string MinPrice = Params[4];
            string MaxAge = Params[5];
            string MinAge = Params[6];

            string OnlyAvailable = Params[7];
            if (OnlyAvailable == "false")
                AdvancedSearch(RootCats2, Brands2, ProductAttrs2, MaxPrice, MinPrice, MaxAge, MinAge);
            else
                AdvancedSearch(RootCats2, Brands2, ProductAttrs2, MaxPrice, MinPrice, MaxAge, MinAge, "true");
            Session["PSearch"] = null;
            RootCats = "";
            Brands = "";
            ProductAttrs = "";

        }

        if (Session["PSearch"] != null)
        {
            var query = Session["PSearch"].ToString();
            Page.Title = query + " : " + "نتیجه جستجو"; ;
            Page.MetaDescription = query;
            Page.MetaKeywords = query;
            lblTitle.Text = query + " : " + "نتیجه جستجو برای";
            visresualt.Visible = true;
            LD1();
            Session["AdvSearch"] = null;
        }
    }
    private void LD1()
    {
        var query = Session["PSearch"].ToString();
        int cat;
        var dv1 = dt.GetProductByWord(query, DrpPriceSort.SelectedIndex).Where(p => p.View.Equals(true));

        var pgitems = new PagedDataSource
        {
            DataSource = dv1.ToList(),
            AllowPaging = true,
            PageSize = 12,
            CurrentPageIndex = PageNumber
        };
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (var i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else

            rptPages.Visible = false;
        rpSearch.DataSource = pgitems;
        rpSearch.DataBind();
    }
    private void AdvancedSearch(string RootCats, string Brands,
        string ProductAttrs, string MaxPrice, string MinPrice, string MaxAge, string MinAge, string OnlyAvailables = "false")
    {

        var dv = dt.AdvancedSearch(RootCats, Brands, ProductAttrs, int.Parse(MaxPrice),
           int.Parse(MinPrice), int.Parse(MaxAge), int.Parse(MinAge), DrpPriceSort.SelectedIndex, OnlyAvailables);
        var pgitems = new PagedDataSource
        {
            DataSource = dv,
            AllowPaging = true,
            PageSize = int.Parse(DrpPageSize.SelectedValue),
            CurrentPageIndex = PageNumber
        };
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (var i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
            rptPages.Visible = false;
        rpSearch.DataSource = pgitems;
        rpSearch.DataBind();

    }



    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }

    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;

        //LoadData();
    }

    static int sid = 0;
    static int cid = 0;
    static bool nocolorEx = false;
    protected void AddCart(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        var pname = dt.GetProduct(pid).First().Name.ToString();
        var ordid = cart.OrdId;
        var bindsize = dt.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (bindsize.Count() != 0)
        {
            DrpSize.Items.Clear();
            DrpSize.Items.Add(new ListItem("انتخاب نمایید", "0"));
            bindsize.ToList().ForEach(p => DrpSize.Items.Add(new ListItem(p.SizeName, p.Id.ToString())));
            RpColor.DataBind();
            lblprice.Text = "";
            lblprice.CssClass = "";
            imgsize.ImageUrl = "";
            imgsize.Visible = false;
            lnkaddtocart.CommandArgument = pid.ToString();
            lnkaddtocart.CommandArgument = pid.ToString();
            UpdatePanel5.Update();
            ViewState["PId"] = pid;

        }
        var ProductSizes = dt.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (ProductSizes.Count() == 1)
        {
            var nosize = ProductSizes.FirstOrDefault();
            if (nosize.SizeName.Equals("بدون وزن"))
            {
                pDrpSize.Visible = false;
                sid = nosize.Id;
                var bindcolor = dt.DB.PColors.Where(p => p.SID.Equals(nosize.Id) && p.PID.Equals(ViewState["PId"]));
                RpColor.DataSource = bindcolor;
                RpColor.DataBind();
                imgsize.ImageUrl = "admin/uploadimage/size/" + nosize.Image;

                var Productcolors = dt.DB.PColors.Where(p => p.SID.Equals(nosize.Id) && p.PID.Equals(ViewState["PId"]));
                if (Productcolors.Count() == 1)
                {
                    var nocolor = Productcolors.FirstOrDefault();
                    if (nocolor.Name.Equals("بدون رنگ"))
                    {
                        RpColor.Visible = false;
                        CLabel1.Visible = false;
                        cid = nocolor.Id;


                        var getdetails = dt.DB.PColors.FirstOrDefault(p => p.SID.Equals(sid) && p.Id.Equals(cid));
                        var ppid = getdetails.PID;
                        var pr = 0;
                        if (
                            dt.DB.spGetProductPrio()
                                .Any(
                                    p =>
                                        p.Id.Equals(ppid) && p.IsSale.GetValueOrDefault(false) && p.DateDis.HasValue &&
                                        p.DateDis.Value >= DateTime.Now))
                            pr = getdetails.DisPrice.GetValueOrDefault(0);
                        else if (getdetails.DateDis.HasValue && getdetails.DateDis.Value >= DateTime.Now)
                            pr = getdetails.DisPrice.GetValueOrDefault(0);
                        else
                            pr = getdetails.Price.GetValueOrDefault(0);


                        lblprice.Text = " قیمت " + Data.PricePersian(pr.ToString());
                        if (dt.IsAvailSize(ppid, cid))
                        {
                            lblprice.CssClass = "";
                            lnkaddtocart.Enabled = true;
                        }
                        else
                        {
                            lblprice.CssClass = "noavail";
                            lnkaddtocart.Enabled = false;
                        }

                    }
                }
            }

        }
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loadpopup();", true);

    }
    protected void addtocompare_Click(object sender, EventArgs e)
    {
        var AddtoCart = (LinkButton)sender;
        int ID = int.Parse(AddtoCart.CommandArgument.ToString());
        Comp.Add(ID);
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('به مقایسه اضافه شد');", true);
    }
    protected void addwish_Click(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        if (User.Identity.IsAuthenticated)
        {
            var uname = User.Identity.Name;
            dt.insertFav(uname, pid);

            var sabtsuc = "اضافه شد";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('" + sabtsuc + "');", true);

        }
        else
        {
            var erorrmes = " برای درج ابتدا باید ثبت نام کنید";
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('" + erorrmes + "');", true);
        }

    }
    protected void DrpSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (DrpSize.SelectedIndex != 0)
        {
            sid = Convert.ToInt32(DrpSize.SelectedValue);
            var bindcolor = dt.DB.PColors.Where(p => p.SID.Equals(sid) && p.PID.Equals(ViewState["PId"]));
            RpColor.DataSource = bindcolor;
            RpColor.DataBind();
            var getdetails = dt.DB.PSizes.FirstOrDefault(p => p.Id.Equals(sid)).Image;
            if (getdetails != null)
            {
                imgsize.ImageUrl = "admin/uploadimage/size/" + getdetails;
                imgsize.Visible = true;
            }
        }


    }
    protected void RpColor_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("addcolor"))
        {
            CLabel1.Save = e.CommandArgument.ToString();
            sid = Convert.ToInt32(DrpSize.SelectedValue);
            for (int i = 0; i < RpColor.Items.Count; i++)
            {
                var lnkcolor = (LinkButton)RpColor.Items[i].FindControl("lnkcolor");

                lnkcolor.CssClass = "";
                if (lnkcolor.CommandArgument == CLabel1.Save)
                {
                    lnkcolor.CssClass = "active";

                    var getdetails = dt.DB.PColors.FirstOrDefault(p => p.SID.Equals(sid) && p.Id.Equals(lnkcolor.CommandArgument));
                    var pid = getdetails.PID;
                    var pr = 0;
                    if (
                        dt.DB.spGetProductPrio()
                            .Any(
                                p =>
                                    p.Id.Equals(pid) && p.IsSale.GetValueOrDefault(false) && p.DateDis.HasValue &&
                                    p.DateDis.Value >= DateTime.Now))
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else if (getdetails.DateDis.HasValue && getdetails.DateDis.Value >= DateTime.Now)
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else
                        pr = getdetails.Price.GetValueOrDefault(0);


                    lblprice.Text = "قیمت" + Data.PricePersian(pr.ToString());
                    if (dt.IsAvailSize(pid, Convert.ToInt32(CLabel1.Save)))
                    {
                        lblprice.CssClass = "";
                        lnkaddtocart.Enabled = true;
                    }
                    else
                    {
                        lblprice.CssClass = "noavail";
                        lnkaddtocart.Enabled = false;
                    }
                }
            }
            UpdatePanel5.Update();
        }
    }
    protected void lnkaddtocart_Command(object sender, CommandEventArgs e)
    {
        if (User.IsInRole("Job"))
        {

        }

        var pid = Convert.ToInt32(lnkaddtocart.CommandArgument);

        var ProductSizes = dt.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (ProductSizes.Count() == 1)
        {
            var nosize = ProductSizes.FirstOrDefault();
            if (nosize.SizeName.Equals("بدون وزن"))
            {
                sid = nosize.Id;
                var Productcolors = dt.DB.PColors.Where(p => p.SID.Equals(sid) && p.PID.Equals(pid));
                if (Productcolors.Count() == 1)
                {
                    var nocolor = Productcolors.FirstOrDefault();
                    if (nocolor.Name.Equals("بدون رنگ"))
                    {
                        cid = nocolor.Id;
                    }
                    else
                    {
                        try
                        {
                            cid = Convert.ToInt32(CLabel1.Save);
                        }
                        catch
                        {
                            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ را انتخاب کنید')", true);
                            cid = 0;
                            sid = 0;
                            return;
                        }
                    }

                }
                else
                {
                    try
                    {
                        cid = Convert.ToInt32(CLabel1.Save);
                    }
                    catch
                    {
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ را انتخاب کنید')", true);
                        cid = 0;
                        sid = 0;
                        return;
                    }
                }
            }
            else
            {
                try
                {
                    sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
                    cid = Convert.ToInt32(CLabel1.Save);
                }
                catch
                {
                    if (sid == 0)
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert(' سایز را انتخاب کنید')", true);
                    else
                        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert(' رنگ را انتخاب کنید')", true);
                    cid = 0;
                    sid = 0;
                    return;
                }
            }
        }
        else
        {
            sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
            cid = Convert.ToInt32(CLabel1.Save);
        }

        //var sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
        //cid = Convert.ToInt32(CLabel1.Save);
        var ordid = cart.OrdId;
        var pname = dt.GetProduct(pid).First().Name.ToString();
        //if (!dt.IsAvailSize(pid, sid))
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "hidepopup(),loginerror('" + pname + " موجود نیست'),GoCarosel(),Addjust();", true);
        //    return;
        //}
        int count = Convert.ToInt32(txtCount.Text);
        var ins = cart.InsertShoppingCart(pid, sid, cid, count, ordid, User.IsInRole("Job"));

        var mes = "";
        if (ins.Equals(0))
        {
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),showbasket('" + pname + "'),benefite('" + bent + "'),GoCarosel(),Addjust();", true);

        }
        else
        {
            switch (ins)
            {
                case 2:
                    mes = "به علت عدم موجودی محصول " + pname + " حذف گردید";
                    break;
                case 3:
                    mes = "امکان درج بیشتر محصول " + pname + " وجود ندارد";
                    break;
                case 4:
                    mes = "محصول " + pname + " موجود نیست";
                    break;

            }
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            if (sid == 0)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('سایز را انتخاب کنید')", true);
                cid = 0;
                sid = 0;
                return;
            }
            if (sid != 0 && lblprice.Text == "" || nocolorEx)
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ را انتخاب کنید')", true);
                cid = 0;
                sid = 0;
                return;
            }
            if (sid == 0 && lblprice.Text == "")
            {
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "alert('رنگ یا سایز را انتخاب کنید')", true);
                cid = 0;
                sid = 0;
                return;
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),loginerror('" + mes + "'),GoCarosel(),benefite('" + bent + "'),Addjust();", true);

        }
        cid = 0;
        sid = 0;
    }

    static List<string> idlist0 = new List<string>();
    static List<string> idlist1 = new List<string>();
    static List<string> idlist2 = new List<string>();
    static List<string> idlist3 = new List<string>();
    protected void chkLev0_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < chkLev0.Items.Count; i++)
        {
            if (chkLev0.Items[i].Selected)
            {
                string result = idlist0.Find(delegate (string str) { return str == chkLev0.Items[i].Value; });
                if (result != null)
                {

                }
                else
                {
                    idlist0.Add(chkLev0.Items[i].Value);
                }

            }
            else if (!chkLev0.Items[i].Selected)
            {
                idlist0.Remove(chkLev0.Items[i].Value);
            }
        }
        Label1.Text = "";
        //RootCats = "";
        //Brands = "";
        //ProductAttrs = "";
        foreach (var x in idlist0)
        {

            //Label1.Text += x + ",";
            RootCats += x + ",";

        }

        //AdvancedSearch(RootCats, Brands, ProductAttrs,Price_max.Text,Price_min.Text,
        //  Age_max.Text, Age_min.Text);

        Session["AdvSearch"] = new List<string>();
    }
    protected void chkLev1_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < chkLev1.Items.Count; i++)
        {
            if (chkLev1.Items[i].Selected)
            {
                string result = idlist1.Find(delegate (string str) { return str == chkLev1.Items[i].Value; });
                if (result != null)
                {

                }
                else
                {
                    idlist1.Add(chkLev1.Items[i].Value);
                }

            }
            else if (!chkLev1.Items[i].Selected)
            {
                idlist1.Remove(chkLev1.Items[i].Value);
            }




        }

        Label2.Text = "";
        //RootCats = "";
        //Brands = "";
        //ProductAttrs = "";
        foreach (var x in idlist1)
        {

            //Label2.Text += x + ",";
            Brands += x + ",";
        }

        //AdvancedSearch(RootCats, Brands, ProductAttrs, Price_max.Text, Price_min.Text,
        // Age_max.Text, Age_min.Text);
        //RootCats = "";
        //Brands = "";
        //ProductAttrs = "";
        Session["AdvSearch"] = new List<string>();
    }

    protected void chkAttrVal_SelectedIndexChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < rpAttr.Items.Count; i++)
        {


            CheckBoxList chkAttrVal = (CheckBoxList)rpAttr.Items[i].FindControl("chkAttrVal");
            for (int j = 0; j < chkAttrVal.Items.Count; j++)
            {
                if (chkAttrVal.Items[j].Selected)
                {
                    string result = idlist3.Find(delegate (string str) { return str == chkAttrVal.Items[j].Value; });
                    if (result != null)
                    {

                    }
                    else
                    {
                        idlist3.Add(chkAttrVal.Items[j].Value);
                    }

                }
                else if (!chkAttrVal.Items[j].Selected)
                {
                    idlist3.Remove(chkAttrVal.Items[j].Value);
                }

            }

        }

        Label4.Text = "";
        //RootCats = "";
        //    Brands = "";
        //ProductAttrs = "";
        foreach (var x in idlist3)
        {
            //Label4.Text += x + ",";
            ProductAttrs += x + ",";
        }
        //AdvancedSearch(RootCats, Brands, ProductAttrs, Price_max.Text, Price_min.Text,
        // Age_max.Text, Age_min.Text);
        //RootCats = "";
        //Brands = "";
        //ProductAttrs = "";
        Session["AdvSearch"] = new List<string>();

    }
    protected void btnFilter_Click(object sender, EventArgs e)
    {
        //     RootCats = "";
        //static string Brands = "";
        //static string ProductAttrs = "";
        //Session["AdvSearch"] = null;
        //List<string> list = new List<string>();
        //list.Add(RootCats);
        //list.Add(Brands);
        //list.Add(ProductAttrs);
        //Session["AdvSearch"] = list;
        //RootCats = "";
        //Brands = "";
        //ProductAttrs = "";
        //Response.Redirect("~/Search.aspx");
        //AdvancedSearch(RootCats, Brands, ProductAttrs, Price_max.Text, Price_min.Text,
        //Age_max.Text, Age_min.Text);
        Session["AdvSearch"] = null;
        List<string> list = new List<string>();
        list.Add(RootCats);
        list.Add(Brands);
        list.Add(ProductAttrs);
        list.Add(Price_max.Text);
        list.Add(Price_min.Text);
        list.Add(Age_max.Text);
        list.Add(Age_min.Text);
        if (chkOnlyAvailables.Checked)
            list.Add("true");
        else
            list.Add("false");
        //list.Add(lbl)
        Session["AdvSearch"] = list;
        RootCats = "";
        Brands = "";
        ProductAttrs = "";
        Response.Redirect("~/Search.aspx");

    }
    protected void DrpPriceSort_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Session["Search"] != null)
        {

            var q = Server.HtmlEncode(lblTitle.Text);
            int cat;
            var dv = dt.GetProductByWord(q, DrpPriceSort.SelectedIndex).Where(p => p.View.GetValueOrDefault(false));

            var pgitems = new PagedDataSource
            {
                DataSource = dv.ToList(),
                AllowPaging = true,
                PageSize = int.Parse(DrpPageSize.SelectedValue),
                CurrentPageIndex = PageNumber
            };
            if (pgitems.PageCount > 1)
            {
                rptPages.Visible = true;
                var pages = new System.Collections.ArrayList();

                for (var i = 0; i < pgitems.PageCount; i++)
                    pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
                rptPages.DataSource = pages;
                rptPages.DataBind();
            }
            else
                rptPages.Visible = false;
            rpSearch.DataSource = pgitems;
            rpSearch.DataBind();
        }
        if (Session["AdvSearch"] != null)
        {
            var Params = (List<string>)Session["AdvSearch"];
            if (Params.Count == 0)
            {
                AdvancedSearch(RootCats, Brands, ProductAttrs, Price_max.Text, Price_min.Text,
                        Age_max.Text, Age_min.Text);
                RootCats = "";
                Brands = "";
                ProductAttrs = "";
            }
            if (Params.Count > 0)
            {
                string RootCats2 = Params[0];
                string Brands2 = Params[1];
                string ProductAttrs2 = Params[2];
                string MaxPrice = Params[3];
                string MinPrice = Params[4];
                string MaxAge = Params[5];
                string MinAge = Params[6];
                string OnlyAvailable = Params[7];
                if (OnlyAvailable == "false")
                    AdvancedSearch(RootCats2, Brands2, ProductAttrs2, MaxPrice, MinPrice, MaxAge, MinAge);
                else
                    AdvancedSearch(RootCats2, Brands2, ProductAttrs2, MaxPrice, MinPrice, MaxAge, MinAge, "true");
            }
        }
    }
    protected void DrpPageSize_SelectedIndexChanged(object sender, EventArgs e)
    {

        if (Session["Search"] != null)
        {

            var q = Server.HtmlEncode(lblTitle.Text);
            int cat;
            var dv = dt.GetProductByWord(q, DrpPriceSort.SelectedIndex).Where(p => p.View.GetValueOrDefault(false));

            var pgitems = new PagedDataSource
            {
                DataSource = dv.ToList(),
                AllowPaging = true,
                PageSize = int.Parse(DrpPageSize.SelectedValue),
                CurrentPageIndex = PageNumber
            };
            if (pgitems.PageCount > 1)
            {
                rptPages.Visible = true;
                var pages = new System.Collections.ArrayList();

                for (var i = 0; i < pgitems.PageCount; i++)
                    pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
                rptPages.DataSource = pages;
                rptPages.DataBind();
            }
            else
                rptPages.Visible = false;
            rpSearch.DataSource = pgitems;
            rpSearch.DataBind();
        }
        if (Session["AdvSearch"] != null)
        {
            var Params = (List<string>)Session["AdvSearch"];
            if (Params.Count == 0)
            {
                AdvancedSearch(RootCats, Brands, ProductAttrs, Price_max.Text, Price_min.Text,
                        Age_max.Text, Age_min.Text);
                RootCats = "";
                Brands = "";
                ProductAttrs = "";
            }
            if (Params.Count > 0)
            {
                string RootCats2 = Params[0];
                string Brands2 = Params[1];
                string ProductAttrs2 = Params[2];
                string MaxPrice = Params[3];
                string MinPrice = Params[4];
                string MaxAge = Params[5];
                string MinAge = Params[6];
                string OnlyAvailable = Params[7];
                if (OnlyAvailable == "false")
                    AdvancedSearch(RootCats2, Brands2, ProductAttrs2, MaxPrice, MinPrice, MaxAge, MinAge);
                else
                    AdvancedSearch(RootCats2, Brands2, ProductAttrs2, MaxPrice, MinPrice, MaxAge, MinAge, "true");
            }
        }
    }

}