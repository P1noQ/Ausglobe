﻿using System;
using System.Linq;
using System.Web.UI;

public partial class Brands : Page
{
    public Library Lib = new Library();

    protected void Page_Load(object sender, EventArgs e)
    {
        rpBrand.DataSource = Lib.SelectInfo("brand").Where(p => p.active).ToList();
        rpBrand.DataBind();
        Desc();
    }

    private void Desc()
    {
        Page.Title = "برندها";
        Page.MetaDescription = "برندها";
        Page.MetaKeywords = "برندها";
        ltrTitle.Text = "برندها";
    }
}