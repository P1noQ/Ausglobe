﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using System.Web.Services;

public partial class Share : System.Web.UI.Page
{
    public Data Data = new Data();
    public Club Club = new Club();
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }

    [WebMethod()]
    public static void ShareSo(string user, int id, string page, string social)
    {
        var Cl = new Club();
        
        try
        {
            if (string.IsNullOrEmpty(user))
                return;
            var g = new Guid(Membership.GetUser(user).ProviderUserKey.ToString());
            switch (page)
            {
                case "product":
                    Cl.InsertProductShare(id, g, social);
                    break;
                case "event":
                    Cl.InsertInfoShare(id, g, 1, social, 1);
                    break;
                case "download":
                    Cl.InsertInfoShare(id, g, 2, social, 2);
                    break;
                case "about":
                    Cl.InsertInfoShare(id, g, 3, social, 3);
                    break;
                case "wikia":
                    Cl.InsertInfoShare(id, g, 4, social, 17);
                    break;
                case "wikin":
                    Cl.InsertInfoShare(id, g, 5, social, 18);
                    break;
                default:
                    break;
            }
        }
        catch
        {
            return;
        }
    }
}