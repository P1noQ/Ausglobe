﻿using System;

public partial class PasswordRecovery : System.Web.UI.Page
{
    public Library Lib = new Library();protected void Page_Load(object sender, EventArgs e) 
    {
        if (User.Identity.IsAuthenticated)
        {
            Response.Redirect("Default.aspx");
        }
    }
}