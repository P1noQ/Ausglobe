﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security;
using System.Drawing;
using System.Web.Security;
using System.Web.Profile;

public partial class PreReg : System.Web.UI.Page
{
    Data dt = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        mvReg.ActiveViewIndex = 0;
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        string Email = Server.HtmlEncode(txtEmail.Text);
        string Pass = Server.HtmlEncode(txtPassword.Text);
        if (Membership.FindUsersByEmail(Email).Count > 0)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('ایمیل قبلا ثبت شده است');", true);
        }
        else
        {
            try
            {
                var mem = Membership.CreateUser(Email, Pass, Email);
                dt.CreateUserSetting(Email);

                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "ShowSucc(' ثبت نام با موفقیت انجام شد؛ برای فعالسازی حساب کاربری ایمیل خود را بررسی نمایید و در صورت عدم مشاهده پوشه اسپم را چک کنید ');", true);
                //var l = Request.Url.OriginalString.Replace("PreReg.aspx", "Login.aspx?user=" + mem.ProviderUserKey.ToString());
                var l = "http://hooraa.com/Login.aspx?user=" + mem.ProviderUserKey.ToString();
                SendMes.SendEmail(Email, "فعالسازی حساب کاربری", "برای فعالسازی حساب کاربری لینک زیر را باز نمایید<br><a href=\"" + l + "\" target=\"_blank\">فعالسازی حساب کاربری</a>");
            }
            catch
            {
                lblSuccessMess.Text = "خطا در انجام عملیات";
            }
            finally
            {
                mvReg.ActiveViewIndex = 1;
            }
            mvReg.ActiveViewIndex = 1;
            //main_div.Visible = false;
            //SuccessMes.Visible = true;
            //Response.Redirect("reg.aspx?user=" + mem.ProviderUserKey.ToString());
        }
    }
}