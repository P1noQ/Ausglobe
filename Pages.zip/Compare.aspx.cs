﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Compare : System.Web.UI.Page
{
    Data dt = new Data();
    public  clsShoppingCart cart=new clsShoppingCart();
    clsCompare comp = new clsCompare();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        comp.AddCompare();
        LoadData();
    }

    private void LoadData()
    {
        var itemCommand = new List<clsCompare.CompA>();
        var item = new List<clsCompare.CompP>();
        var t = comp.ListData.Where(p => p.Id != 0);


        var t2 = new clsCompare.CompP();
        t2.Id0 = comp.ListData[0].Id;
        t2.Id1 = comp.ListData[1].Id;
        t2.Id2 = comp.ListData[2].Id;
        t2.Id3 = comp.ListData[3].Id;
        t2.Col = comp.ListData.Count(p => !p.Id.Equals(0)) + 1;
        if (t2.Col != 1)
        {


            itemCommand.AddRange(t);

            item.Add(t2);
            rpDetails.DataSource = item;
            
            rpCpmmandAddCart.DataSource = itemCommand;
            rpRemove.DataSource = itemCommand;
            
            var list = comp.GetAttributeName(comp.ListData[0].Id, comp.ListData[1].Id, comp.ListData[2].Id,
                comp.ListData[3].Id);
            rpAttr.DataSource = list;
        }
        rpDetails.DataBind();
        rpCpmmandAddCart.DataBind();
        rpRemove.DataBind();
        rpAttr.DataBind();
    }
    protected void AddCart(object sender, EventArgs e)
    {
        var AddCart = (LinkButton)sender;

        var pid = Convert.ToInt32(AddCart.CommandArgument.ToString());
        var pname = dt.GetProduct(pid).First().Name.ToString();
        var ordid = cart.OrdId;
        var bindsize = dt.DB.PSizes.Where(p => p.PID.Equals(pid));
        if (bindsize.Count() != 0)
        {
            DrpSize.Items.Clear();
            DrpSize.Items.Add(new ListItem("انتخاب نمایید", "0"));
            bindsize.ToList().ForEach(p => DrpSize.Items.Add(new ListItem(p.SizeName, p.Id.ToString())));
            RpColor.DataBind();
            lblprice.Text = "";
            lblprice.CssClass = "";
            imgsize.ImageUrl = "";
            lnkaddtocart.CommandArgument = pid.ToString();
            UpdatePanel5.Update();

        }
        ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loadpopup();", true);
    }

    protected void DrpSize_SelectedIndexChanged(object sender, EventArgs e)
    {
        var sid = Convert.ToInt32(DrpSize.SelectedValue);
        var bindcolor = dt.DB.PColors.Where(p => p.SID.Equals(sid));
        RpColor.DataSource = bindcolor;
        RpColor.DataBind();
        var getdetails = dt.DB.PSizes.FirstOrDefault(p => p.Id.Equals(sid));
        imgsize.ImageUrl = "admin/uploadimage/size/" + getdetails.Image;
    }
    protected void RpColor_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.Equals("addcolor"))
        {
            CLabel1.Save = e.CommandArgument.ToString();
            var sid = Convert.ToInt32(DrpSize.SelectedValue);
            for (int i = 0; i < RpColor.Items.Count; i++)
            {
                var lnkcolor = (LinkButton)RpColor.Items[i].FindControl("lnkcolor");

                lnkcolor.CssClass = "";
                if (lnkcolor.CommandArgument == CLabel1.Save)
                {
                    lnkcolor.CssClass = "active";

                    var getdetails = dt.DB.PColors.FirstOrDefault(p => p.SID.Equals(sid) && p.Id.Equals(lnkcolor.CommandArgument));
                    var pid = getdetails.PID;
                    var pr = 0;
                    if (
                        dt.DB.spGetProductPrio()
                            .Any(
                                p =>
                                    p.Id.Equals(pid) && p.IsSale.GetValueOrDefault(false) && p.DateDis.HasValue &&
                                    p.DateDis.Value >= DateTime.Now))
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else if (getdetails.DateDis.HasValue && getdetails.DateDis.Value >= DateTime.Now)
                        pr = getdetails.DisPrice.GetValueOrDefault(0);
                    else
                        pr = getdetails.Price.GetValueOrDefault(0);


                    lblprice.Text = "قیمت" + Data.PricePersian(pr.ToString());
                    if (dt.IsAvailSize(pid, Convert.ToInt32(CLabel1.Save)))
                    {
                        lblprice.CssClass = "";
                        lnkaddtocart.Enabled = true;
                    }
                    else
                    {
                        lblprice.CssClass = "noavail";
                        lnkaddtocart.Enabled = false;
                    }
                }
            }


            UpdatePanel5.Update();
        }
    }
    protected void lnkaddtocart_Command(object sender, CommandEventArgs e)
    {
        if (User.IsInRole("Job"))
        {

        }
        var pid = Convert.ToInt32(lnkaddtocart.CommandArgument);
        var sid = Convert.ToInt32(Server.HtmlEncode(DrpSize.SelectedValue));
        var cid = Convert.ToInt32(CLabel1.Save);
        var ordid = cart.OrdId;
        var pname = dt.GetProduct(pid).First().Name.ToString();
        //if (!dt.IsAvailSize(pid, sid))
        //{
        //    ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "hidepopup(),loginerror('" + pname + " موجود نیست'),GoCarosel(),Addjust();", true);
        //    return;
        //}
        var ins = cart.InsertShoppingCart(pid, sid, cid, 1, ordid, User.IsInRole("Job"));
        var mes = "";
        if (ins.Equals(0))
        {
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),showbasket('" + pname + "'),benefite('" + bent + "'),GoCarosel(),Addjust();", true);

        }
        else
        {
            switch (ins)
            {
                case 2:
                    mes = "به علت عدم موجودی محصول " + pname + " حذف گردید";
                    break;
                case 3:
                    mes = "امکان درج بیشتر محصول " + pname + " وجود ندارد";
                    break;
                case 4:
                    mes = "محصول " + pname + " موجود نیست";
                    break;

            }
            string bent = Data.PricePersian(cart.Benefit().ToString());
            if (bent.Contains("تماس"))
            {
                bent = "0 ريال";
            }
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                "hidepopup(),loginerror('" + mes + "'),GoCarosel(),benefite('" + bent + "'),Addjust();", true);
        }
    }

    protected void Remove(object sender, EventArgs e)
    {
        var Remove = (LinkButton) sender;
        var pid = Convert.ToInt32(Remove.CommandArgument.ToString());
        comp.Remove(pid);
        LoadData();
    }
    public IList<spGetAttrProdCompResult> GetProductValue(int PID, int AID)
    {
        return comp.DB.spGetAttrProdComp(PID, AID).ToList();
    }

    public IList<spGetAttrValCompResult> GetAttributeValue(int AID, int PID0, int PID1, int PID2, int PID3)
    {
        return comp.DB.spGetAttrValComp(AID, PID0, PID1, PID2, PID3).ToList();
    }

    public IList<spDetailsProductCompResult> Render(int p0, int p1, int p2, int p3)
    {
        return comp.DB.spDetailsProductComp(p0, p1, p2, p3).ToList();
    }
    public static bool ShowCol(int PID)
    {
        if (PID.Equals(0))
            return false;
        else
            return true;
    }

    public bool IsAvail(int PID)
    {
        return dt.DB.fnProductAvailable(PID,0).GetValueOrDefault(false);
    }
}