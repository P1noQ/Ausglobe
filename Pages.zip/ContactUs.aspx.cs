﻿using System;
using System.Linq;

public partial class Contact : System.Web.UI.Page
{
    Data Data = new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        ltText.Text = Data.GetDescription(11).Title;
        ltH2.Text = Data.GetDescription(11).Title;
        Page.Title = Data.GetDescription(11).Title;
        Page.MetaDescription = Data.GetDescription(11).Description1;
        Page.MetaKeywords = Data.GetDescription(11).Keywords;
        ltMap.Text = Data.GetAbout().FirstOrDefault(p => p.Id.Equals(27)).Body;
        if (!Page.IsPostBack)
        {
            var ddlAboutVar = Data.GetCatPart();
            ddlAbout.DataSource = ddlAboutVar;
            ddlAbout.DataTextField = "Part";
            ddlAbout.DataValueField = "Id";
            ddlAbout.DataBind();
        }
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
        try
        {
            Data.InsertContact(int.Parse(ddlAbout.SelectedItem.Value), txtEmail.Text, txtFullName.Text, ddlAbout.SelectedItem.Text, enquiry.Value);
            lblSended.Text = "Message sent";
            return;
        }
        catch(Exception ex)
        {
            lblSended.Text = "Problem with Sending";
            return;
        }
    }
}