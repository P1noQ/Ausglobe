﻿using System;
using System.Globalization;
using System.Linq;
using System.Web.UI.WebControls;

public partial class Info : System.Web.UI.Page
{
    public Library Lib = new Library();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack) return;
        LoadData();
    }

    private void LoadData()
    {
        IQueryable<tblInfo> dt;
        if (Request.QueryString["type"] != null)
        {
            DescriptionPage(6);
            dt = Lib.SelectInfo(Request.QueryString["type"]);
        }
        else
        {
            int id;
            if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
            dt = Lib.SelectInfo().Where(p => p.catId.Equals(id));
            var view = Lib.SelectCategory().FirstOrDefault(p => p.id.Equals(id));
            if (view == null) return;
            Desc(id);
        }

        var pgitems = new PagedDataSource
        {
            DataSource = dt.ToList(),
            AllowPaging = true,
            PageSize = 12,
            CurrentPageIndex = PageNumber
        };
        if (pgitems.PageCount > 1)
        {
            rptPages.Visible = true;
            var pages = new System.Collections.ArrayList();

            for (int i = 0; i < pgitems.PageCount; i++)
                pages.Add((i + 1).ToString(CultureInfo.InvariantCulture));
            rptPages.DataSource = pages;
            rptPages.DataBind();
        }
        else
            rptPages.Visible = false;
        rpInfo.DataSource = pgitems;
        rpInfo.DataBind();
    }

    private int PageNumber
    {
        get { return ViewState["PageNumber"] != null ? Convert.ToInt32(ViewState["PageNumber"]) : 0; }
        set { ViewState["PageNumber"] = value; }
    }

    private void DescriptionPage(int id)
    {
        var desc = Lib.SelectDescription(id).ToList().FirstOrDefault();
        if (desc == null) return;
        Page.Title = desc.title;
        Page.MetaDescription = desc.description;
        Page.MetaKeywords = desc.keyword;
        lblTitle.Text = desc.title;
    }

    private void Desc(int id)
    {
        var info = Lib.SelectCategory().FirstOrDefault(p => p.id.Equals(id));
        if (info == null) return;
        Page.Title = info.name;
        Page.MetaDescription = info.name;
        Page.MetaKeywords = info.name;
        lblTitle.Text = info.name;
    }

    protected void RptPagesItemCommand1(object source, RepeaterCommandEventArgs e)
    {
        PageNumber = Convert.ToInt32(e.CommandArgument) - 1;
        if (Request.QueryString["type"] != null)
        {
            LoadData();
            DescriptionPage(6);
        }
        else
        {
            int id;
            if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
            LoadData();
        }
    }
}