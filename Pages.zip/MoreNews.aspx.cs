﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MoreNews : System.Web.UI.Page
{
    private Club Club = new Club();
    Data Data=new Data();
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;

        try
        {
            var item = Data.DB.News.Where(p => p.Id.Equals(id));

            Repeater1.DataSource = item;
            Repeater1.DataBind();

            var ne = item.First();
            var tit = ne.Title;
            Page.Title = tit;
            Page.MetaDescription = ne.Description;
            Page.MetaKeywords = ne.Keyword;
            LinkButton10.Text = tit;
            Data.DB.spVisitNews(id);
            BindRatings();
            hfId.Value = id.ToString();
            if (User.Identity.IsAuthenticated)
                hfUser.Value = User.Identity.Name;
            var pcom = Club.GetInfoComment(id, "رویدادها").OrderByDescending(p => p.DateI).ToList();
            if (pcom.Count() > 10)
            {
                var co = Convert.ToDouble(pcom.Count());
                var pageComment = new List<Club.Paging>();
                var c = Math.Ceiling(co / 10);
                Club.Paging l;
                for (int i = 1; i <= c; i++)
                {
                    if (i.Equals(1))
                    {
                        l = new Club.Paging
                        {
                            Id = i,
                            Class = "a"
                        };
                    }
                    else
                    {
                        l = new Club.Paging
                        {
                            Id = i,
                            Class = "b"
                        };
                    }
                    pageComment.Add(l);
                }
                rpcommentPage.DataSource = pageComment.ToList();
                rpcommentPage.DataBind();
                rpcommentPage.Visible = true;

            }
            else
            {
                rpcommentPage.Visible = false;

            }
            rpComment.DataSource = pcom.Take(10).ToList();
            rpComment.DataBind();

        }
        catch
        {
            
        }
    }
    protected void sendbtn_Click(object sender, EventArgs e)
    {
        int Nid;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out Nid)) return;
       
        if (!User.Identity.IsAuthenticated)
        {
            ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "loginerror('وارد شوید');", true);
            return;
        }
        else
        {
            var UserName = User.Identity.Name;
            var Subject = Server.HtmlEncode(txtsub.Text);
            var Text = Server.HtmlEncode(txtidea.Text);
            var res = Club.InsertNewsComment(Nid, UserName, Subject, Text);
            if (res == 0)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script", "showbasket('ثبت شد');", true);
            else if (res == -1)
                ScriptManager.RegisterStartupScript(this.Page, this.GetType(), "script",
                    "loginerror('شما قبلاٌ نظر ثبت نموده اید');", true);
        }
    }
    protected void Rating1Changed(object sender, AjaxControlToolkit.RatingEventArgs e)
    {
        Thread.Sleep(500);

        try
        {

            int id;
            if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;

            if (!User.Identity.IsAuthenticated)
            {
                lblMsg.Text = " برای امتیاز دهی عضو شوید ";
                lblMsg.ForeColor = Color.Red;
                BindRatings();
                return;
            }
            if (Data.DB.InfoRatings.Any(p => p.UserId.Equals(Data.GetUserId(User.Identity.Name)) && p.InfoId.Equals(id)&& p.Cat.Equals(1)))
            {
                lblMsg.Text = " قبلا امتیاز ثبت نموده اید ";
                lblMsg.ForeColor = Color.Red;
                BindRatings();
                return;
            }
            if (Club.InsertInfoRate(id, Data.GetUserId(User.Identity.Name), RatingProduct.CurrentRating, 1, 3)) ;
            {
                lblMsg.Text = "امتیاز شما ثبت شد ";
                lblMsg.ForeColor = Color.Green;
                BindRatings();
            }
        }
        catch
        {
            lblMsg.Text = "خطا در انجام عملیات ثبت امتیاز";
            lblMsg.ForeColor = Color.Red;
        }
    }

    public void BindRatings()
    {
        int id;
        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;
        lblRating.Text = Data.DB.InfoRatings.Count(p => p.InfoId.Equals(id)&& p.Cat.Equals(1)).ToString(CultureInfo.InvariantCulture);
        var rating = Data.DB.InfoRatings.Where(p => p.InfoId.Equals(id)&& p.Cat.Equals(1));
        int avg;
        if (!rating.Any())
        {
            avg = 0;
        }
        else
        {
            avg = (int)rating.Average(p => p.Rating);
            if (avg > 6)
            {
                avg = 6;
            }
        }
        RatingProduct.CurrentRating = avg;
    }
    protected void PageComment(object sender, EventArgs e)
    {
        var btnPage = (LinkButton)sender;
        var Id = Convert.ToInt32(btnPage.CommandArgument.ToString());

        int id;

        if (Request.QueryString["id"] == null || !int.TryParse(Request.QueryString["id"], out id)) return;

        var pcom = Club.GetInfoComment(id, "رویدادها").OrderByDescending(p => p.DateI).ToList();

        var co = Convert.ToDouble(pcom.Count());
        var pageComment = new List<Club.Paging>();
        var c = Math.Ceiling(co / 10);
        Club.Paging l;
        for (int i = 1; i <= c; i++)
        {
            if (i.Equals(Id))
            {
                l = new Club.Paging
                {
                    Id = i,
                    Class = "a"
                };
            }
            else
            {
                l = new Club.Paging
                {
                    Id = i,
                    Class = "b"
                };
            }
            pageComment.Add(l);
        }
        rpcommentPage.DataSource = pageComment.ToList();
        rpcommentPage.DataBind();

        rpComment.DataSource = pcom.Skip((Id - 1) * 10).Take(10).ToList();
        rpComment.DataBind();
    }
}